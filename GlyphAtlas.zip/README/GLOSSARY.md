# Glyph Atlas — GLOSSARY

> **项目速查。** 记录当前代码的结构、术语、符号、数据流、文件职责和边界。产品事件与决策过程看 `PRODUCT-LOG.md`；协作方式看 `COLLABORATION-NOTES.md`。
>
> **与代码实时同步。** 新增/改名/删除代码符号、改变行为边界时，先改本文件。不要在本文件末尾追加日期段落；当前事实直接写进对应章节。旧架构、旧符号、旧版本对比不留在正文。**`README/` 不新增文件；术语/结构变化直接改本文件。**

约定：

- `Class.method` 为实例方法，`Class.+method` 为类方法，`private` 表示实现文件内可见。
- 布局坐标一律为**点（pt）**；字体内部数值为**设计单位（font units）**，换算为 `units × size / upem`。
- `GA` 为项目命名空间。
- 同一概念只保留一个主术语；其他常见说法见第 11 节。

## 0. 架构速查

```text
侧栏 attributedText + 明确选择的 GID
  → GAMainWindowController.scheduleAnalysis（generation）
  → analysisQueue: GATextQueryModel.analyzeText:selections:cancelled:
      → GAFontDocument.rawScanContent:selections:
          → GASubstitutionEngine：已解析表程序 + 完整输入
          → 单字上下文目录 + GSUB/AAT 实际匹配 + 所有 FV 分支
      → applyRawResult:（按原文 UTF-16 来源投影）
  → GABuildDisplayGroups → GABuildScanDisplaySnapshot → 一份完整 snapshot
      → Sidebar rows（稳定根、variants、独立临时行）
      → 原生 NSTextView / TextKit 2 显示

点击：TextKit 原生字符索引 → 已保存的 CTLine GID 命中 → 原文范围 → 侧栏选择
```

关键事实：

- 每次文字/选择变化是**一次完整查询、一次发布**；没有逐字任务、子串队列或流式候选。旧 generation 不能写回。
- 侧栏普通激活和 Shift 插入要求已发布快照的 generation 与当前请求一致，并核对原文。新结果到达前暂存最近一次操作。侧栏按 field editor 的实际编辑范围追踪原始来源，只有新结果仍有同一来源范围与完整 GID 序列时才执行。无法确认位置、来源被修改或候选改变时静默取消。
- 候选发现由项目自己的 GSUB/AAT 执行器完成；多字视图的最终排版和绘制仍由原生 TextKit 2 完成。
- 原生 GID 读取走私有 `NSTextLayoutManager.requiresCTLineRef` / `NSTextLineFragment.lineRef`；不读取 TextKit 1 的 `layoutManager`，也不建立第二套 shaping。
- 字体排印菜单使用 `CTFontCopyFeatures` 的本地化目录、默认值和互斥标记，原生 `NSMenu` 分组；每个字体窗口保存自己的选择，未覆盖的项目保留字体默认。
- 三种视图：Glyph Grid（出厂默认）、Characters、Single Glyph。窗口可按已保存的整套开档设置初始化。

## 1. 数据模型

| 符号 | 当前含义 |
| --- | --- |
| `GAFontDocument` | 字体资源、原生字体所有权、查询与度量入口；切轴时以新 descriptor 重绑，共享解析表和 inventory |
| `GAFontBox` | 持有一个 `CTFontRef` 的 ARC owner；公开 header 只暴露 `font`，页面度量内部字段在 `GAFontEngine.m` 的 private extension |
| `GAGlyphVariant` | 已绑定字体与原文范围的显示字形；可含多个 GID，可带 shaping positions |
| `GACharacterGroup` | 一个可独立操作的 nominal 组件、不可拆原子来源、明确选择组或额外组合组，持有候选列表；多字视图另保留原生字素簇单位 |
| `GAGlyphSelection` / `GAGlyphSelectionRun` | 持久 GID 元数据与 attributed-string UTF-16 范围；run 只保存文字、GID、来源标签和 ligature 标志 |
| `GAGlyphQueryIdentity` / `GAGlyphQueryKey` | 不可变查询身份，以文字起首，每个选择用起点／长度／完整GID数组三个固定槽；hash及完整值判等共同识别请求，来源标签不参与身份 |
| `GAScanCandidate` / `GARawScanResult` | 完整输入候选与 nominal `sourceRanges`；范围相对原文，`targetGroupIndex` 指向由这些范围建立的源组 |
| `GATextQueryModel` | 当前完整输入、结果和显示组；只保存上次身份/结果，没有第二套历史缓存；变体重绑定可取消，结果与显示组完成后在 analysisQueue 一起替换 |
| `GAModelStringFromFieldText` | 直接从当前 field editor 字符串还原有效换行标记；不复制富文字属性，也不缓存编辑中的文字 |
| `GABuildDisplayGroups` | 独立于窗口的侧栏行数据构建；生产 UI 与诊断共用 |
| `GAScanDisplaySnapshot` / `GABuildScanDisplaySnapshot` | 查询模型模块内的完整侧栏／多字预览投影；保留缺字过滤、原生字素簇及来源映射，主窗口不再镜像保存其中三份多字状态 |
| `GAGlyphResolution` | 一次惰性反查的既有 parent + 临时 variant；侧栏单独持有，不写入 group.variants |
| `GAGlyphLayoutRun` | 原生排版的命中结果：原文范围 + GID；private in `GAMultiGlyphView.m` |
| `GAAllGlyphEntry` | 全字 inventory 的一项：GID + Unicode 映射 |
| `GARowItem` | 侧栏行数据；private in `GASidebarViewController.m` |
| `GAGlyphPage` | 字体单位下的页面：`size`、`baseline`、`ink` |

语义：

| 符号/属性 | 含义 | 不要混淆 |
| --- | --- | --- |
| `base` | 稳定根：该字符默认 cmap 字形（不应用 shaping） | 不是“没有任何来源” |
| `temporary` / `GAGlyphResolution` | 点击的布局 GID 不在主列表时，临时解析并挂到某个既有 parent 下；随用户选择保留 | 不是 pending 选择，也不是 group 的持久 variant |
| `seeded` | 该组代表一个选择 run；首个 variant 是用户激活的 GID | 不是普通源组 |
| `insertedLigature` | 只为浏览而加入的组合组，重叠已有源组，不参与文本绘制 | 不是可激活的源文本 |
| `glyphKey` | 完整GID序列的字串键，用于组合候选集合去重；侧栏身份直接使用完整GID数组 | 去重集合仍依赖有效hash |
| `featureSources` | 真实读到的 feature/selector 来源；没有就空 | 不补 `actual` |
| `sourceTextRange` | 相对当前原文的 UTF-16 范围 | 不是整形内部索引 |

## 2. 字体与 CoreText

| 中文 | English | 说明 | 代码 / API |
| --- | --- | --- | --- |
| 字体文件 | font file | ttf/otf/ttc/otc/dfont/woff/woff2 | `GAFontURLIsFont`、`GAFontContentTypes()` |
| 字体描述符 | font descriptor | 字体面、变化轴、feature 配置的查询对象 | `CTFontDescriptorRef` |
| 字体面 | face | 文件/集合中的一套具体样式 | descriptor 数组 |
| 字体集合 | font collection | TTC/OTC 中多个 face | `CTFontManagerCreateFontDescriptorsFromURL` |
| 字体资源 | font resource | 归并后的可选项；VF 的具名实例合成一个资源 | `GAFontResource` |
| 可变字体 | variable font | 由 `fvar` 轴控制的字体 | `CTFontCopyVariationAxes`、`CTFontCopyVariation` |
| 变化轴 | variation axis | `wght`、`opsz`、`GRAD` 等 | `kCTFontVariationAxisIdentifierKey` |
| 具名实例 | named instance | 预设 variation 坐标 | `GAFontInstance` |
| 字体全名 | full name | 原生显示名 | `CTFontCopyDisplayName`、`GAFontDocument.fullName` |
| 本地化家族名 | localized family name | VF 唯一家族名候选 | `CTFontCopyLocalizedName(kCTFontFamilyNameKey)` |
| PostScript 名 | PostScript name | 判断 run 是否来自当前字体 | `CTFontCopyPostScriptName` |
| em / upem | units per em | 通常 1000/2048；整形字号 200 | `CTFontGetUnitsPerEm`、`GAFontShapingSize` |
| 字体匹配 | font matching | 用 PostScript name 拒绝 fallback run | `GAFontsMatch`（private） |
| 字体 fallback | font fallback | CoreText 自动借字体；其 GID 不能当当前字体 GID | 空 cascade list + run 过滤 |
| 字形 ID | glyph ID / GID | 字体内部 glyph index | `CGGlyph`、`GAGlyphVariant.glyphIDs` |
| 字形名称栏 | glyph label | 字体表提供的名称、CID-keyed CFF1 的 `CID n`，或无记录时的 `GID n` | `GAGlyphLabels` |
| CID | character identifier | CID-keyed CFF1 在 charset 中记录的字符集合编号，与字体内 GID 可以不同 | 显示用，交互定位仍以 GID 为准 |
| `.notdef` / 缺字 | .notdef / missing glyph | GID 0；多字视图会过滤未 seed 的缺字 | `shapeString:` 的 GID 0 回退 |
| Unicode 映射 | Unicode map | GID → Unicode scalars | `CTFontCopyCharacterSet`、`CTFontGetGlyphsForCharacters` |
| Unicode 标量 | Unicode scalar | 码位；一个字形可映射多个 | `GAGlyphVariant.unicodeScalars` |
| 码位名称 | Unicode name | 系统 ICU 名称 | `GAUnicodeNameForScalar()` |
| GSUB | Glyph Substitution Table | 字形替代表 | `CTFontCopyTable(kCTFontTableGSUB)` |
| GPOS | Glyph Positioning Table | 字形定位表 | `CTFontCopyTable(kCTFontTableGPOS)` |
| AAT | Apple Advanced Typography | feature type/selector；morx/mort | `CTFontCopyFeatures` |
| `vert` / `vrt2` | vertical forms | 竖排字形替换；vrt2 优先于 vert | `Resource::verticalFeature(branch)` |
| `hmtx` | horizontal metrics | 水平 advance / LSB | `CTFontCopyTable`、`CGFontGetGlyphAdvances` |
| `vmtx` / `vhea` | vertical metrics | 垂直 advance / TSB | `CTFontCopyTable`、`hasVerticalMetricsForVariant:` |
| `hhea` / `OS/2` | horizontal header / OS/2 | ascent/descent、typo metrics、fsSelection | `CTFontGetAscent/Descent`、engine `Resource` |
| `fvar` / `avar` | variations | 轴、坐标正规化 | `GAVariation` |
| `MVAR` | metrics variations | `hasc`/`hdsc` typo 度量增量 | engine `Resource`、`typoMetricsAscender:descender:` |
| `VVAR` | vertical variations | CoreText 应用 advance；项目不解析 tsbMap | CoreText |
| `trak` | tracking table | 随字号变化的 tracking | `CTFontGetAdvancesForGlyphs` 应用 |
| 水平 advance | horizontal advance | 水平步进宽度 | `advanceInFontUnitsForVariant:` |
| 垂直 advance | vertical advance | 垂直步进高度；无 vmtx 时页面回退其他度量 | 同上 |
| 上升部 / 下降部 | ascent / descent | 基线上下高度 | `CTFontGetAscent/Descent` |
| 基线 | baseline | 字形绘制参考线 | `GAGlyphPage.baseline` |
| 左边距 | left side bearing (LSB) | 墨迹左缘到原点 | `CGRectGetMinX(inkBox)` |
| 竖排顶边距 | top side bearing (TSB) | vmtx 顶部留白；页面不再用它推 origin | `verticalTopSideBearingForVariant:` |
| 墨迹框 | ink bounds | 轮廓外接框，可为空 | `CTFontGetBoundingRectsForGlyphs` |
| 字身框 | em box / advance box | 单字/侧栏/全字页面的度量矩形 | `GAGlyphPage` |
| shaping 字号 | shaping size | 变体分析/整形字号（200） | `GAFontShapingSize` |

### 2.1 可载入的字体格式

`GAFontURLIsFont` / 打开面板先按 UTI 过滤，能否真正打开由 `CTFontManagerCreateFontDescriptorsFromURL` 决定。

| 扩展名 | UTI | 实测结果（macOS 14.8.7） |
| --- | --- | --- |
| `.ttf` | `public.truetype-ttf-font` | 可读 |
| `.otf` | `public.opentype-font` | 可读，CFF 与 TrueType 轮廓均可 |
| `.ttc` | `public.truetype-collection-font` | 可读；多样式时弹出 “Choose Font Style”，按语言规则显示样式数 |
| `.otc` | `public.opentype-collection-font` | 可读 |
| `.dfont` | `com.apple.truetype-datafork-suitcase-font` | 可读 |
| `.woff` | `org.w3c.woff` | 可读，两种 flavor 均通过 |
| `.woff2` | `org.w3c.woff2` | 可读 |

- `woff` / `woff2` 不 conform 到 `public.font`，`GAFontContentTypes()` 与 `Info.plist` 显式列出。
- `public.font` 还包含 Type 1 `.pfa` / `.pfb`：打开面板放行，但 CoreText 返回 0 个 descriptor，app 报 “Cannot Open Font”。
- 过滤只看文件 UTI（通常由扩展名决定），不做 magic-byte 嗅探。
- 以上为 14.8.7 结果；最低目标 macOS 12.0 未实机。

### 2.2 页面度量（`pageForVariant:usesVerticalMetrics:`）

| 用途 | `usesVerticalMetrics` | 宽 | 高 | baseline |
| --- | --- | --- | --- | --- |
| 单字边界框视图 | `YES`，有 `vmtx`/`vhea` | 水平 advance（多 GID 求和） | 当前坐标的 CoreText 垂直 advance | `height − origin` |
| 单字边界框视图 | `YES`，无 `vmtx` | 水平 advance | OS/2 `sTypoAscender + \|sTypoDescender\|`（含 MVAR `hasc`/`hdsc`） | `\|sTypoDescender\|` |
| 侧栏缩略图 / 全字网格 | `NO` | 水平 advance | 同上 OS/2 typo 高度；不用 `vmtx` | `\|sTypoDescender\|` |

补充：

- **竖排 origin**：`CTFontGetVerticalTranslationsForGlyphs` 取垂直原点；CFF 为每字形 VORG，TrueType 为字体级 origin。页面不使用 vmtx TSB，也不解析 VVAR `tsbMapping`；TSB 变化刻意忽略。
- **OS/2 回退**：OS/2 缺失/过短、`head` 缺失或 upem 为 0（位图字体）、或 typo 高度 ≤ 0 时，改用 CoreText ascent + descent，baseline 用 CoreText descent。
- **正数 descender**：部分字体把 `sTypoDescender` 存成正数；页面取绝对值当深度，不使用字面 `asc − desc`。
- **不含 `sTypoLineGap`**；`MVAR` 只解析 version 1 的 `hasc`/`hdsc`，坐标用现有 fvar/avar 正规化。
- **ink** 始终来自当前实例的 `CTFontGetBoundingRectsForGlyphs`，换算到字体单位。
- **缓存**：`GABoundingBoxView.setVariant:` 计算并保存 `GAGlyphPage`；`drawRect:` 不再每帧计算。页面只依赖 variant（字体实例 + GID），切轴/换选择会换 variant 并刷新。全字网格按 GID 缓存；侧栏缩略图在 `setVariant:` 缓存。
- 若 width/height ≤ 0：width 回退 ink 宽或 `0.01 em`；height 回退 ink 高或 `1 em`。

### 2.3 字体命名

| 场景 | 规则 |
| --- | --- |
| 普通字体 | 资源名与窗口标题使用 `CTFontCopyDisplayName`（`document.fullName`） |
| 可变字体 + 家族名唯一 | 资源归并后，若本地化 Family Name 在剩余选项中唯一，资源名使用该家族名，并令 `usesFamilyName = YES` |
| 静态资源 | 参与“家族名是否重复”的判断，但保留原生 full/display name |
| 家族名重复或缺失 | 保留原生 display name |
| 窗口标题 / 工具栏 | `usesFamilyName ? resource.name : document.fullName`；切轴后保持打开时决定的名字 |
| Popover 预设 | 非本地化 style name（`CTFontCopyName`）；坐标匹配不上时显示 Custom |
| 坐标反查字体名 | 不存在；不恢复 instance fullName、familyName 匹配或自定义坐标命名 |

### 2.4 可变字体与 FeatureVariations

- 资源归并：默认坐标 descriptor 归并；共同非默认坐标→全默认后 `CFEqual(CTFont)`，不经过 CGFont。静态 face 保持独立；多资源时显示选择 sheet。
- 发现阶段枚举所有 GSUB FeatureVariations 分支，候选取并集；实际布局按当前坐标和条件优先级选择。
- 条件支持 Condition Format 1 与 avar 1；未知条件/avar 2 的限制见第 12 节。
- `opsz` 显式固定，不跟随显示字号；条件判定用 descriptor 请求坐标，避免 `CTFontCopyVariation` 截短小数。
- 切轴只重绑字体/度量与可见行；不 reload、不重扫、不改变列表成员/顺序/选定 GID。

## 3. 整形、变体与查询

- `applyRawResult:` 对少于32项的组沿用直接扫描／复制；达到门槛后建立保序 builder 与散列桶，桶内仍核对完整 GID、ligature 标志及连字来源范围。来源合并、顺序与取消时已完成的部分保持，结束或取消时发布 builder。
- 字体查询沿用 `discoverText` 已按来源起点排序的base范围，直接枚举原文字素簇范围补齐未覆盖的来源，再最终排序，并在 `GARawScanResult.sourceRanges` 上定位候选的 `targetGroupIndex`。侧栏源组由 `GAGroupsForScanResult` 按这些 nominal 来源范围建立。硬换行保留范围，仍分段执行，不跨段匹配连字。
- `GATextPreparation.scalarSources` 将准备后的 scalar 及原始 scalar 的 canonical decomposition 配对，保留每个 nominal 组件真实的 UTF-16 来源；一枚 prepared scalar 覆盖原文多码时仍为一个组件。来源重叠的多个 GID 继续保持原子序列，例如单个已编码字符因字体现有 cmap 不支持而分解。UVS 与 base 范围合并，不拆 surrogate pair。
- 可独立组件各列自己的稳定根与直接替换；替换跨越两个以上 nominal 源组时，通过现有 composition/ligature 组路径展示，连同该组合根的直接替换。判断依据是实际匹配的来源跨度，既不是 Unicode 码位数量，也不依 feature 名称猜测。单一组件的一对多替换仍保留完整 GID 序列一列。UI 只展示原有真实 feature/AAT 来源，不添加「连字」「合成」「字形序列」来源标签。
- 字群内的明确 GID selection 可覆盖一个独立组件；Unicode 准备在 selection 边界两侧分别规范化，避免邻接输入把 literal seed 合成为另一字形。替换验证按 nominal 组件来源完整覆盖，不再强制 selection 覆盖整个 grapheme；sourceText/UTF-16 范围保留，编码替换与 unencoded run 沿用原有激活流程。
- `GABuildDisplayGroups` 构建来源与明确选择列，再交给私有 `GAInsertCombinationGroups` 完成组合范围归并、排序、稳定根及插入位置。两个阶段共用当前调用输入，取消回传nil。
- `DisplayCopy` 始终建立独立侧栏组。没有连字候选时沿用组内不可变 variants 数组，存在连字时按原顺序过滤并复制数组。
- `GABuildDisplayGroups` 在至少64个来源组、16个独立组合范围时，用本次投影的两份有序端点数组统计相交来源数；支持未排序、重叠及重复来源，空范围／NSNotFound不计，溢出范围回到原扫描。小投影沿用直接统计；不增加跨查询缓存，不改变明确选择合并、来源顺序或组合排序规则。
- `GABuildDisplayGroups` 另在至少256来源组、8个明确选择时，按准确来源范围建立保序seed候选桶；有效选择另有同范围桶及两份排序端点，用于同输入组合判等和相交排除。桶只在本次投影存在，小输入沿用直接循环；无效／溢出端点回到旧扫描，不假设来源组排序或互不重叠。取消后不发布结果；省略工作后poll次数可以不同。
- `scalarScript` 将ICU shortName的四字节直接小写打包为OpenType Tag，保留原五个特殊tag映射及DFLT规则；ICU调用和Unicode数据库不变，不增加script缓存。
- `prepareText` 对已编码的单个非代理 UTF-16 单位直接沿用原码值、nominal GID 和来源范围。变体选择符、未编码字符、多单位组合仍走原正規化及来源映射。
- `positionsForGlyphIDs:` 完成原有文字上下文处理后，单GID若不在解析后的任何GPOS type 1 coverage内且字体单位有效，直接返回一项零原点。扩展解包后的直接或巢状type 1均纳入覆盖检查。
- 当前完整查询的组合字投影复制 `GAGlyphVariant`，同字体实例且对应同一原文范围时沿用已有 positions；独立复制可变来源列表。切换字体实例的 `rebindVariant:content:` 共用记录复制并重新定位。
- `prepareText` 按已验证的有序选择与原始group依序生成输出，保留最后字素簇尚未处理的suffix供下一个选择使用，避免反复从开头搜索及搬动vector后缀。prefix／suffix的来源、script／level、literal GID及identity编号和原验证错误保持；无选择时不建立第二份group vector。
- 字形名称／编码装饰：空GID直接得到空名称与aliases；单GID直接使用unicodeMap已有的冻结、去重、升序aliases，不重建集合／排序／join。多GID仍合并去重排序，base的原文编码补值仍由调用端处理。每个字体面采用不可变 `GAGlyphLabels`，同一 face 的变轴文档共享。TrueType／CFF2 读 post 的标准／自订名称，name-keyed CFF1 读 charset 对应的 SID 字串，CID-keyed CFF1 按 charset 查实际 CID。缺项／无名称表／不支持的名称数据用 GID；已存名称按原字串显示。`featureSources`按第一个ASCII空格取tag，保留大小写／空白及原顺序，不分割为临时数组；仍在构造器建立内部mutable array，延后建立的原型因收益不足已撤回。
- 多字 snapshot 先过滤缺字来源，再合并原字素簇中保留的相邻组件。明确 selection 使用自己的准确范围。`sourceRangeForMultiGroup:` 由显示组范围及起点位移映射还原原文布局范围。`multiOmissions` 记录跨缺字的排版边界。
- GSUB 执行器覆盖 type 1–8、extension、嵌套上下文；发现阶段收集重叠与嵌套规则，实际执行遵守 lookup 顺序。FeatureVariations 合并所有分支。
- GSUB 的候选发现、确定性执行与来源回放共用同一执行器。候选共用未修改的字形区块，修改时只复制受影响区块；来源回放仍保留完整的前后序列。发现达到安全上限时保留已验证的候选并标记本次未完成，完整文本缓存与文字模型都允许同一输入重查。
- AAT 覆盖 morx/mort 的 0/1/2/4/5 子表、16 种重排、状态/标记/栈/插入、方向、段尾动作和 chain selector。Type 2 候选共用一份工作缓冲区，每次恢复实际改写的区段。候选发现用独立预算，达到上限时保留已验证的结果并标记未完成。没有无上下文的全状态静态目录。
- 单字上下文候选由 `GAGlyphCatalogue.cpp` 的 `OpenType::relatedSubstitutions` 和引擎的 `relatedOutputs:` 从 feature 可达路径建立，合并所有 FV 分支；不要求输入周围文字。字面 GID 序列由 `GAFontDocument.variantsForGlyphIDs:cancelled:` 直接返回有序候选，供侧栏明确选择和全字追加使用。
- **连字**必须匹配完整实际输入/所选 GID；单独 `f` 或 `i` 不列 `fi`。未被 feature 引用的 lookup 不算候选。AAT 同样遵守。
- 完整查询身份由文字、选择范围与完整 GID 序列构成。增量缓存只按实际换行分组，以该行准备后的搜索单元和行内来源区间识别可复用的 GSUB/AAT 候选；跨换行的搜索单元使用完整查询。复用时换算回当前原文位置，仍统一生成显示快照。
- 输出保留真实来源；没有来源就留空，不补 `actual`。零输出保留 `∅` 行。
- 稳定根：`discoverContent:selections:` 直接以准备后的 cmap/UVS GID 建 base；明确选择的 seed 保留字面 GID。默认 GSUB/AAT 不再改写 base；普通候选仍执行 feature 规则。字形编码按实际 GID 装饰，只有缺少编码的 base 保留既有输入 Unicode 提示。
- cmap 在单份子表或映射的范围内隔离读表错误，继续按原顺序查找可用映射。同一变体选择符的非默认映射读坏时，仍可独立查默认映射。
- 一级候选：原 root 的直接目录输出与直接实际替换；首次形成的多字 composition 及其 root 的直接目录输出。已形成 variant 的后续输出不自动闭包进常驻列表。`primaryChange` 用替换前的输入识别来源；默认 feature、required feature 和 FV 分支照常参与发现，不按字形名称或 feature 标签加例外。
- 惰性反查：仅多字点击找不到精确 GID/序列与原文范围时，在 analysisQueue 调用 `GAFontDocument.resolveGlyphIDs:…`。先按当前方向、坐标与显示开关重放本项目引擎；最终 GID/序列与完整来源范围一致，才沿 trace 回找同一来源范围内最近的既有侧栏 parent。这不是 TextKit 内部路径证据。
- 来源兜底：从同一来源范围内的既有单字/多 GID/composition 行出发，按当前模式优先（竖排含 vert/vrt2 路径、横排不含）→最短路径→列表顺序确定一个 parent；循环、异常与执行预算受限。仍找不到则选原组 base，沿用现有选择兜底。没有 typeset-result 优先级。
- 临时结果：`GAGlyphResolution` 只在侧栏行构建时插到 parent 紧下方，名称用 secondaryLabelColor，不写入查询结果或 group.variants。同一时间一项；改选其他字形或明确取消选择才清除。
- 临时项刷新：调轴、缩放、切视图、改变排版设置、取消旧后台查找或发布新快照本身不清除已选项。快照更新复用既有 source-range 编辑映射，并以组文字、seed/composition 类型和完整 parent GID 序列找回来源；`rebindVariant:` 更新字体/positions 并保留 temporary 标志，GID 不随 TextKit 自动换成别的结果。来源被替换/删除、parent 消失或换字体时清除；结果已在常驻列表时直接使用常驻行，避免重复。
- 临时行与常驻行一起比较相同行序；仅字体/坐标重绑时可不 reload、不移选、不滚动。真正行结构变化仍走原有可见行锚点恢复。
- 点击导航提交：`selectGlyphIDs:textRange:` 未命中时不改行、选择、pending 或滚动位置；旧临时项也保留到解析完成。直接命中、`showGlyphResolution:` 的新结果与解析失败选 base，共用 private `selectVariant:inGroup:temporaryResolution:`：先生成最终行，再一次替换/选取/通知，仅对最终目标调用已有整组居中与最小揭示规则。后台解析与过期结果取消规则不变；不把 shaping 搬到主线程，也不先选旧 parent。

### 3.1 缓存

| 数据 | 保存什么 | 限制 | 省掉什么 |
| --- | --- | --- | --- |
| 共享 `Resource` | 表字节、已解析程序与索引 | 随资源/坐标版本 | 切轴后的重复读取/解析 |
| `relatedCache` | 某 GID 的上下文候选、来源和 AAT 竖排标记 | 2048 项 / 16 MiB 软限制 | 同一 GID 重复遍历 feature/嵌套动作 |
| `cache` | 完整文字+选择，或字面 GID 序列的候选结果；完整文字结果已稳定排序并冻结 | 2048 项 / 32 MiB 软限制 | 对完全相同输入重复执行发现规则及完整文字候选排序 |
| 查询模型当前结果 | 当前一次 raw 结果及身份 | 一份 | 相同请求重复提交、切轴重新发现 |

限额是近似 cost，不是精确内存；共享范围是同一文档资源及其坐标版本，不是进程全局字体缓存。

### 3.2 原生字体排印

| 对象 | 职责 |
| --- | --- |
| `GAFontFeatures` | 读取 `CTFontCopyFeatures`；每窗口的显式覆盖；未改项保留字体默认 |
| `GAFontFeatureGroup` | 系统名称、互斥性、selector 与原生定义；身份为 AAT type 或 OT tag |
| `settings` | 给原生显示字体的 AAT type/selector 或 OT tag/value 元组 |
| `replaySettings` | 附加系统提供的 OT 映射，给既有反查 replay；不改变候选发现范围 |
| `GACopyFontWithFeatureSettings` | 用 `kCTFontFeatureSettingsAttribute` 创建显示字体副本 |

- 菜单栏与主视图右键菜单在竖排、文字对齐后提供 Typography，内容随当前字体变化；原生 `NSMenu`，不嵌入或重绘系统 Typography 面板。
- 全部选中项使用 NSMenuItem 原生勾号，不指定自订状态图标。独占组仍为单选，非独占组仍可多选，互斥性由模型控制。AAT 非独占 selector 的 On/Off 成对项合成一个开关。CoreText 若把成对名称回报成同一编号，依 AAT 名称表顺序采用开项及其默认状态。独立单项与纯 OT off/on 组收进 Other。系统给出的名称与默认值不重译、不猜测。
- type 0 的全局总开关不作为实际操作项。没有整套恢复字体现有特性设置的菜单项；各项选择回到原生默认时移除对应覆盖。
- 名称在模型读入时处理一次：GAFontFeatures群名称为空则用原始OT tag／AAT type编号；selector名称为空则用已有selector标识／OT value。只补显示名称，不改标识、默认值、选择逻辑或回放设置。
- 原生 Typography 菜单只展示字体提供的特性；全文底线／删除线／中空字在主 View 同层的 Text Decorations 子菜单。构建主菜单时即建立装饰快捷键项目；字体特性目录仍在打开 Typography 时更新。
- 菜单关联实际右键视图所属窗口，避免背景窗口操作到另一字体窗口；特性叶菜单弱绑定该窗口。非多字模式可查看目录，操作禁用。
- 切轴保留同一资源的选择，换字体重建目录；异步反查捕获不可变设置并检查过期。改变排印不重新发现候选。
- TextKit 决定最终排版；必要特性、竖排及字体实现可能不接受某个请求。原有竖排引号辅助在显式关闭直书替代时不强制注入。

## 4. 多字视图（TextKit 2）

| 中文 | English | 说明 | 代码符号 |
| --- | --- | --- | --- |
| 多字视图 | multi-character view | 一个边界框视图，横排/竖排共用 | `GAMultiGlyphView` |
| 文本视图 | text view | 实际排版/绘制者；不接收鼠标 | `GAMultiTextView`（private）、`NSTextView` |
| 文本布局管理器 | text layout manager | TextKit 2 布局入口 | `NSTextLayoutManager` |
| 文本容器 | text container | 容器尺寸与内边距 | `NSTextContainer`、`textContainerInset` |
| 容器原点 | text container origin | 旋转/分数 inset 下尤其关键 | `textContainerOrigin` |
| 布局片段 | layout fragment | 段落/文本元素布局结果 | `NSTextLayoutFragment` |
| 行片段 | line fragment | 一行/一列的实际排版矩形 | `NSTextLineFragment` |
| 使用边界 | used bounds | 文本实际占用范围 | `usageBoundsForTextContainer` |
| 横排内边距 | horizontal inset | `textContainerInset = side inset`；frame = page 外扩 | `positionTextView` |
| 竖排零内边距 | vertical zero inset | frame = pageRect，inset = 0 | `positionTextView` |
| 竖排裁切 | vertical ink clipping | 竖排墨迹越出页面会被文本视图裁切 | `positionTextView` |
| 字符朝向 | vertical orientation (UAX #50) | 汉字正立、拉丁/数字旋转 | `GAVerticalScalarRotates()` |
| 替换种子 | seed | 用户选中的无编码替换字形 | `GACharacterGroup.seeded` |
| 字形信息 | glyph info | 源字符 → 指定 GID | `NSGlyphInfo`、`NSGlyphInfoAttributeName` |
| 基础字符 | base string | 种子显示字符；决定朝向/步进/断行 | `NSGlyphInfo.glyphInfoWithGlyph:forFont:baseString:` |
| 基础字符替换 | base substitution | 竖排：非直立源字符+全宽 GID → 字；直立+窄 GID → A；只改显示副本 | `replacementBaseForOriginal:glyph:font:` |
| 全宽种子 | full-width seed | advance == upem 或 字 的 advance | `glyphIsFullWidth:font:` |
| 竖排引号 | vertical quote | 非 seed 引号使用当前坐标分支的竖排替换 | `verticalQuoteGlyphForGroup:font:` |
| 文本缩放 | text scale | 51pt × 1.12^n，n = −20…20 | `GAMultiBaseFontSize`、`GAMultiClampTextScale` |
| 页面 | page | 白页矩形；尺寸来自文本布局 | `pageRect`、`pageContentSize` |
| 视口 | viewport | 滚动视图可见尺寸 | `viewportSize` |
| 文档尺寸 | document size | 视口与页面共同决定的滚动内容尺寸 | `documentSize` |
| 缩放 | zoom | 键盘/捏合改变 text scale | `zoomTextIn/Out`、`resetTextZoom` |

实现要点：

- `initUsingTextLayoutManager:YES`；`hidden`/不可编辑/不可选择/不绘制背景/`menu = nil`；鼠标事件由 `GAMultiGlyphView` 处理。
- `layoutActive` 由 Detail 依据当前视图设置；隐藏时各参数仍保存，实际布局标记 pending，显示前先更新 viewport 再一次完成布局。独立创建的 view 默认 active。
- `displayGroupIdentity` 按文字、omissions、组范围／文字／seeded／insertedLigature／首 variant 的完整 GID 序列判等。组快照用每组六槽的平面数组保存起点、长度、复制文字、seeded、insertedLigature、复制的完整 GID 序列；等价快照只替换来源对象，不重建显示副本。
- `displayFont` 复用同一 fontBox、显示字号与 feature settings 的原生字体副本；这些依赖改变才重建。已有有效首行基准且显示字体对象相同时，沿用其已读的原生度量；字号、方向或基准失效仍走原读取路径，当前行基线仍取实际 TextKit 布局。
- `refreshPreviewColors` 只更新显示 storage 已有的前景色属性与重绘；零尺寸边界附件保持原有属性结构。外观、背景、阴影变化不重新生成布局副本。
- viewport 只有有效折行方向的长度变化才完整排版；横排高度／竖排宽度单独变化时只更新 inset、页面通知及文字位置。无效尺寸、隐藏文字或 pending 保留完整路径。
- 创建时设置 `textView.textLayoutManager.requiresCTLineRef = YES`；每次 `rebuildLayout` 完成后调用 `GAReadDisplayGlyphRuns` 读取 CTLine/CTRun 的 GID 与 UTF-16 索引，映射回原文范围并保存 `glyphHits`。
- 点击：由 TextKit line fragment 的 `characterIndexForPoint:` 得到原生字符索引，经 `displaySourceIndices` 找到对应索引，在 `glyphHits` 中取得 run 并交给 `onGlyphSelected`。run 保留整组 GID 和逻辑首组件的原生 GID 与范围。整组反查要求当前文字版本及连续原文范围。若中间隔着缺字，先按可确认的首组件定位，再退到首段的基本字形。连续来源找不到整组结果时也依序尝试首组件和基本字。异步反查返回时再次检查版本。
- `MapGlyphLayoutRuns` 原地消费唯一生产调用者新建且不再读取旧范围的native hit记录，省掉第二份临时record；MergeHits输出仍独立建立，不能推广为任意调用者共享记录。横排非seed组在显示副本替换专用工作之前跳过，排序和完整TextKit布局保持，直排／seed路径不变。
- 原文范围有序、非空且互不重叠时，`MapGlyphLayoutRuns` 直接沿用已映射的 hit，补齐 leading GID；逆序、重叠及异常端点保留原 `MergeHits`。
- 多字横排无指定GID时，以既有atomic范围清单为空判定可省略显示替换排序。预览快照每组只有一份记录，来源范围长度沿用显示组；仅存原文起点发生位移的映射，由 `sourceRangeForMultiGroup:` 统一读回。
- `MapGlyphLayoutRuns` 对至少8项且已按顺序互不重叠的固定来源范围，直接以原数组二分定位首个可能相交项，并在范围外停止；小清单、重叠或顺序不符的清单保留原扫描顺序。range及leading component仍分别按原规则扩展，保持原生字形顺序；不保存额外长期索引。
- 原生读取使用 `requiresCTLineRef`，run 索引相对段落。排版时用 PostScript 名核对可读的原生 run。若 TextKit 借用其他字体，先从对应 run 的显示副本移除 VS15／VS16／ZWJ 再排版，仍借用其他字体的显示范围换成零尺寸的空白附件。换行照常，固定 GID 序列按整体处理。重排同步更新显示索引，输入及查询数据不参与此重排。`lineRef` 若为 NULL，该行无法进行 run 字体验证。
- 横排：frame 按 side inset 外扩，`textContainerInset` 同步，墨迹可越出页面。
- 首行基线补偿：GAMultiTextView在原生textContainerOrigin的容器y轴减去当前首行与1倍基准的基线差，横排向上、竖排沿右至左的行进方向补偿；页面内容长度同时从usageBounds.height扣去同一差值再取整。文字、字框、捲动尺寸与点击转换共用实际容器原点，小于1倍时首行命中区向上扩展至恢复显示的区域。
- 竖排：frame = `pageRect`、inset = 0；TextKit 旋转 bounds；竖排墨迹越界会被裁切。
- 显示字符串是私有副本：固定 GID 种子用 `NSGlyphInfo`；多 GID 种子展开为多个 run；竖排 base substitution 只改副本，不改输入框。
- 引号：`‘’“”` 组未 seed 时，GSUB 使用当前变体坐标分支，优先 `vrt2`，否则用 `vert`。保留原生竖排关闭状态及编码竖排形式（U+FE41–FE44）的处理。
- 缺字：多字快照先检查各原始来源组件的 nominal GID，再合并同一字素簇内保留的相邻组件。侧栏保留 `.notdef` 行。孤立的 VS1–VS256 以原始码位和 GID 0 列入侧栏。成对的变体序列沿用同一来源范围。原文中间的缺字跨度以不绘制、不可点击的零尺寸附件隔开前后排版。换行、断词与双向文字控制、以及附着于保留组件的默认忽略字符仍参与排版。
- 组合组只浏览，不替换源文本。
- 文本缩放范围 1/1.12^20 … 1.12^20；初始/重置为 1。
- 1倍首行基准由实际TextKit2布局读出并缓存。字级变化、横／竖排切换时失效；新变化坐标文档换入不按对象身份清除基准，而在显示字体实际套用后比较原生度量：横排只比ascent，竖排比横排ascent／descent及直排字体副本的ascent，任一变化才失效；leading及直排descent不参与基准比较。文字、窗口尺寸、边距、对齐、书写方向、语言、装饰、颜色及排印开关沿用缓存。当前倍率为1时直接使用现有布局；非1倍且基准失效时只复制当前第一行的显示内容，以同样原生TextView配置量一次1倍参照。当前倍率的基线每次按现成布局读取，不重新排全文作参照。没有行片段或有效首行来源时不发布虚构基准。
- 变轴并不保证首行基线固定。原生基准比较按实际显示字级读取，不直接用MVAR或USE_TYPO_METRICS旗标推断。竖排既可能使用原生直排度量，也可能从横排ascent／descent导出中线；因此只读默认方向的三个值会漏掉vhea变动，只读直排值也会漏掉没有直排度量时的横排度量变动。本机独立／组合变轴及fmtx、bsln、BASE、vhea等补验见PRODUCT-LOG及diagnostics/native-baseline-metric-cache-2026-11-10/。
- 恢复预设大小一次提交缩放、行距和边距，只重排一次。
- 多字撐捏方向沿用两指连线角度：≤35°调框／边距，≥75°调行高，中间调字号；Began时锁定，一段手势内转角不切换。触控板仍由NSView接收indirect触点，用normalizedPosition乘deviceSize计算。27直接触摸经GAMultiMagnificationGestureRecognizer的原生touches入口取得，先更新候选再调用super，按NSTouch.locationInView:计算实际位置，不要求可空的device属性。View的allowedTouchTypes仍只开Indirect，不能靠给NSView加Direct替代手势辨识器。结束／取消通过原生super收尾；普通magnify及无有效双指时沿原字号路径。没有触屏实机验证，方向与动作分派只以独立代理触点检查。

## 5. 单字边界框视图与几何

| 中文 | English | 说明 | 代码符号 |
| --- | --- | --- | --- |
| 单字边界框视图 | single-glyph bounding box view | 定义页 + CoreText 自绘 | `GABoundingBoxView` |
| 定义页 | definition page | 字身框对应的白页 | `page`、`GADrawPage()` |
| 页面度量 | page metrics | 见 2.2；单字边界框视图用 `usesVerticalMetrics:YES` | `GAGlyphPage`、`GAFontDocument.+pageForVariant:usesVerticalMetrics:` |
| 页面阴影 | page shadow | 22pt blur / (0,−8) offset；深浅 alpha 0.18/0.58 手调 | `GADrawPage()` |
| 主视图 | main view | 最终可见区域；字形只受此限制 | `self.bounds`、`glyphLimit` |
| 内容区 | content rect | 主视图四周 11% 内缩；页面必须在内 | `contentGuide`、`GAInsetRectByFraction()` |
| 边距比例 | side inset fraction | 0…`0.5*(1-1/1.12^22)` | `sideInsetFraction`、`GAClampSideInsetFraction()` |
| 默认边距 | default side inset | 0.1014（page 79.72%） | `GABoundingBoxDefaultSideInsetFraction` |
| 页面占比 | page fraction | `1 - 2*inset`；键盘缩放按此比例 | `GABoundingBoxPageFractionForMagnification()` |
| 最大缩放 | maximum scale | 页面/墨迹约束的线性最大公共 scale | `GAMaxScaleForAxis`（private） |
| 共同平移 | shared translation | 页面和字形共用平移 | `translationForScale`（private） |
| 边界余量 | boundary margin | 字形与主视图之间 1pt | `GABoundingBoxBoundaryMargin` |
| 缩放微调 | scale epsilon | 0.999999，防浮点边界空帧 | `GABoundingBoxScaleEpsilon` |
| 缩放步进 | zoom step | 1.12；10 步 = `1.12^10` | `GAGlyphZoomStep`、`GAGlyphZoomStep10` |
| 墨迹外溢 | ink bleed | 单字边界框视图允许字形越出页面，不裁剪 | `layer.masksToBounds` |
| 边界框背景 | bounding box background | 浅色 #FFFFFF / 深色 #3C3C3C | `GABoundingBoxBackgroundColor()` |
| 字形前景 | glyph foreground | 浅色 #222222 / 深色 #EEEEEE | `GAGlyphForegroundColor()` |

- 页面在 `setVariant:` 时计算并缓存；`drawRect:` 只使用缓存。
- 键盘/捏合缩放 ×1.12；`⌘0` 恢复默认页面（79.72%）。
- 字形只画一次（`GADrawGlyphVariant`）；overhang 不裁剪。

## 6. 全字视图

| 中文 | English | 说明 | 代码符号 |
| --- | --- | --- | --- |
| 全字视图 | all-glyphs view | 所有 GID 或所选特性输出 GID 的等距网格 | `GAAllGlyphsView` |
| 网格 | grid | 44pt 基准单元格；基础栏间距6pt、行间距8pt；额外横向空白每个栏间1份、左右两端各2份 | `GAAllGlyphsGrid` |
| 单元格缩放 | cell scale | 1.12^−10 … 1.12^10 | `GAAllGlyphsClampScale`（private） |
| 页面居中 | page centring | 格内居中 advance 宽 × 页面高；baseline 由页面度量给出；不按墨迹居中，不读 vmtx | `GAAllGlyphsGrid.drawRect`、`pageForVariant:` |
| 揭示 | reveal | 侧栏选中 GID 时在当前可见网格中按 GID 定位、滚动和闪烁 | `revealGlyphID:quick:` |
| 筛选特性 | Filter by Feature | 独立的字形目录筛选。GSUB 沿用当前变化分支的 FeatureList 顺序，同名标籤只显示一次，AAT 标籤列在其后 | `glyphOutputsForFeatureTag:cancelled:` |
| 無特性 | No Feature | 全字库存减去当前分支各可选 GSUB／AAT 特性的输出字形 | 筛选 tag 为空字符串 |
| 追加 | append | 双击编码单元格追加首字符并 pending 选中 | `GAMainWindowController.appendAllGlyphEntry:` |
| 闪烁 | highlight | 定位：0.1/0.1/1.0/0.7s；追加：0.2/0.8s | `flashIndex:quick:` |
| 边距 | margins | 水平两端各保留16pt并各加2份额外空白，栏间保留6pt并各加1份额外空白；底部18pt | `horizontalExtraSpacing`、`GAAllGlyphsSideMargin`、`GAAllGlyphsVerticalMargin` |
| 顶部间距 | top inset | 侧栏展开时普通窗口留 18 pt，全屏以安全区为准。侧栏收起时首排贴齐工具栏下缘，顶部总留白由 AppKit 计算 | `grid.topInset`、`NSScrollView.automaticallyAdjustsContentInsets` |

- 页面度量按 GID 惰性计算并缓存；字体变化时缓存失效。
- `updateLayoutForWidth:` 在重排后始终要求整幅网格重绘；文档 frame 是否改变只控制 frame 赋值。内容不足一屏时 frame 高度保持 viewport 高度，也必须重画新的格子大小与栏数。
- 水平栏数沿用原计算方式：可用宽度扣除左右各16pt，再按格宽及6pt基础栏间距取栏数。`horizontalExtraSpacing = max(0, (width − 32 − columns × cellSide − (columns − 1) × 6) / (columns + 3))`。剩余空白按栏间各1份、左右两端各2份分配，总份数为栏数加3。两端为16pt加2倍extra，栏间为6pt加extra；行间距仍为8pt。水平与垂直间距分别由 `GAAllGlyphsHorizontalGap`／`GAAllGlyphsVerticalGap` 定义，绘制与点选使用同一几何。最后一行仍对齐前面各栏，不按剩余字形数重新拉开。
- 绘制先按 `dirtyRect` 与 bounds 的交集、当前字体的 `CTFontGetBoundingBox`、共用页面基线及 `GAAllGlyphsInkOutset` 外扩选行范围，涵盖邻行越出的墨迹；再逐候选检查已有度量中的单字墨迹外接框是否与重绘区域相交，不相交便不设置字形颜色、不提交 CoreText 绘制。静态函数 `GAAllGlyphsInkRect` 共用绘制坐标转换与2pt抗锯齿余量，供闪烁失效范围及实际绘制过滤使用。保留原有按需度量快取，不预量全字墨迹、不回退 visibleRect，也不每帧遍历全字体。 此选行范围依赖字体整体外接框覆盖实际墨迹；该前提并非任意变体都成立，已确认系统字极端轴值实例存在首屏底缘少量墨迹差异。使用者接受该边缘差异并明确决定不修，保留当前实现；详见 PRODUCT-LOG。
- 网格的顶部边距、绘制及文档高度共用 `topInset`。内容可滚到工具栏后方，定位与点选使用未被工具栏遮住的可见区域。
- 27+全字网格增加单指双击的NSClickGestureRecognizer，buttonMask=0只接直接触摸，numberOfClicksRequired=2，允许被捲动手势取消；触摸与鼠标共用activateGlyphAtPoint:命中及上屏回呼。鼠标原mouseDown／窗口拖动路径保留。未全局开启NSIsTouchNative，避免改变尚未迁移界面的鼠标模拟；实际触屏识别与取消仍需硬件验收。
- 双击 Zoom veto：`windowShouldZoom:toFrame:` 仅在当前窗口左键双击、且 `containsAllGlyphAtWindowPoint:` 命中可见 Glyph Grid 单元格时拒绝 Zoom；其他视图、空隙和空白单元格照常。
- 追加编码：取第一个 Unicode 映射；若它是 C0（U+0000–U+001F）或 DEL（U+007F），按升序找第一个不在该范围的映射；都不合格则保留原映射。不是可见性过滤。全字直接追加与侧栏激活／Shift追加共用 Main 内部的 `GAInputScalarForGlyph`；侧栏同样只在有替代映射时跳过 C0／DEL，复制所有编码的行为不变。
- 全字 inventory 按字体资源建立；视图首次隐藏且尚无 inventory 时只保留最新文档与待用筛选，首次显示前建立并套用。已建立后的字体、筛选、滚动和高亮流程照旧。筛选复用其中的条目，查询完成时一起更新菜单勾选和网格。换轴更新 fontBox 和度量，筛选随当前变化分支更新。筛选外的侧栏 GID 保留选择但不跳到其他格。
- GSUB 全字筛选在单次查询内复用字形集合、集合交集及相同起点的直接替换结果。上下文 lookup 仍按位置与动作顺序求值；嵌套动作引用越界 lookup 时仅略过该动作，保留完整上下文、其他动作及其顺序，不中止整个特性的输出收集。筛选失败时保留当前字体实例已套用的结果和勾选。「无特性」等所有特性结果齐全后才套用。
- 筛选子菜单在重建时弱绑定所属字体窗口。命令沿用该窗口，即使活动窗口随后发生变化。
- 篩選子菜單的 All Glyphs（全部字）清除篩選。視圖名稱為 Glyph Grid（字形表）。
- 当前字體沒有可選的替換特性時，篩選子菜單仍可展開，只顯示停用的「沒有可篩選的特性」。
- 菜单栏的筛选特性仅在字形表视图可用，「边界框」仅在单字形及多字元视图可用。其余视图为停用项目显示对应的切换提示。

## 7. 侧栏、输入与选择

| 中文 | English | 说明 | 代码符号 |
| --- | --- | --- | --- |
| 输入框 | input field | 侧栏GASearchField／GASearchFieldCell保持原布局、使用系统默认字体；工具栏GAGlyphInputField以initWithFrame建立，两处输入明确使用systemFontOfSize:0，保留原生折行默认。两处Cell共用左右9pt文字区域与编辑过渡入口，不额外设置textContainerInset或段落缩排 | GASearchFieldCell、GAGlyphInputCell、GASidebarViewController.inputField |
| 字段编辑器 | field editor | 编辑时的 `NSTextView`；侧栏和 VF 数值栏分别客制原生文字菜单 | `currentEditor`、`GAGlyphInputEditor`、`GANumericFieldEditor` |
| 分隔符标记 | separator marker | 输入框以可见符号显示，属性保存原分隔符 | `GALineBreakAttributeName`、`GAInputSeparatorMarker` |
| 输入属性规范化 | input attribute normalization | 仅保留应用字体／颜色、selection run、换行标记 | `GANormalizedSidebarInput` |
| 选择运行 | selection run | 属性字符串中的 range + `GAGlyphSelection` | `GAGlyphSelectionAttributeName` |
| 字形列表 | glyph list | 字符组/变体/seed 行 | `NSTableView`、`setGroups:` |
| 完整列表更新 | complete list update | 先重绑仍有效的临时项，再比较包含临时项的行；结构改变时保持可见锚点 | `updateGroups:sourceText:fontDocument:`、`setGroups:`、`updateGroupsWithSameRows:rows:` |
| 变体行 | variant cell | 缩略图、名称、来源、Unicode 徽章。名称和来源被截断时可由 AppKit 暂时展开 | `GAVariantCellView` |
| 缩略图 | thumbnail | 34pt 图标、32pt/em；按页面度量居中；墨迹可画到行内边距 | `GAGlyphView` |
| Unicode 徽章 | Unicode badge | 16pt 高、3pt gap、4pt 横向 padding。原生标签由 Auto Layout 垂直居中，选取时完全不透明，平时为 75%。AppKit 展开时沿徽章外框只显示 Unicode 字符名称，使用相同字号和系统标签色，选取时用主要色，平时用次要色。系统 Unicode 数据库没有名称时不展开 | `GAUnicodeCodesView`、`GAUnicodeBadgeView`、`GAUnicodeBadgeLabel` |
| pending 选择 | pending selection | 追加/激活后按 range → 精确 GID → base 行解析 | `pendingSelectionGlyphIDs`、`rowForPendingSelection` |
| pending 等待 | pending wait | 组/base 未出现：不恢复旧选择、不跳第一 | `setGroups:` |
| 组滚动 | group scroll | 组放不下→顶对齐；能放下：顶/底/不动 | `scrollGroupContainingRow:` |
| 手动选择 | manual selection | 点击行清空 pending 和临时结果；完整快照不覆盖；改选其他字形清临时项 | `tableViewSelectionDidChange:` |
| 激活 | activate | Return/双击；编码替换文本，无编码建 run | `editGlyphVariant:inGroup:insert:` |
| Shift 激活 | shift activation | 触发事件里只有 Shift：插到自身 source range 右缘，原字形不动 | `GAModifiersAre`、`activateRowAtIndex:modifiers:`、`onGlyphShiftActivated` |
| 激活 payload | activation payload | 有 Unicode → 优先非 C0/DEL 的 Unicode 字符（无 run）；无 Unicode → sourceText + run | `activationPayloadForVariant:sourceText:selection:` |
| 复制编码 | copy encoding | 复制全部 Unicode 标量 | `copySelectedGlyphEncoding` |
| 列表失活 | inactive dim | 窗口失活时列表 alpha 0.37 | `setGlyphListDimmed:` |

激活与插入：

- 普通激活：encoded glyph 用优先非 C0/DEL 的 Unicode 字符替换原 range；unencoded glyph 建立 selection run；组合组替换整段来源。之后设置 pending 选择并重新分析。
- Shift 激活：锚点是**被点行自身**的 source range 右缘；encoded 插普通字符（不固定 GID），unencoded 插 sourceText + run；插入后不设 pending，不跳到新行，原选中行保持。
- 输入更新后若侧栏仍是旧快照，激活等新结果出来，再按编辑后的原文位置、组类型和完整 GID 序列找唯一匹配。无法核对时取消。全字追加的待选行在查找结果发布时只尝试一次，后续输入编辑会清掉旧待选。
- 打字、粘贴、双击替换、Shift 插入和全字追加由同一个原生 field editor 登记到窗口 Undo。编辑器失焦时保留文字存储，输入框同步显示；重新进入编辑时不清空还原历史。还原／重做同时恢复原输入及显式 GID 标记，并重新查询。
- 编辑使部分 GID 指定失效时，只更新受影响的属性范围，并把该更新记入同一笔原生文字还原。文字仍按原生方式编辑；断开的是会吞掉属性变更的输入合并。
- 同一源组连续 Shift 插入会倒序（后插入的更靠近源）；这是当前交互，不是 bug。
- pending 解析顺序：range → 精确 GID → base 行；找不到时保持原选择，不跳第一。`selectGlyphIDsAfterNextReload:` 的非空GID数组保留该流程，空数组直接请求来源组的base，nil取消请求。`rowForPendingSelection`在一次行扫描中记住首个base并优先寻找首个完整GID匹配；无精确命中才返回该base，空数组不匹配零输出候选。
- 三种视图共用的原生输入／粘贴在确认上屏后，自动选中本次新增内容最后位置所属来源组的基本字形；中间插入亦跟随插入位置，不跳整段末尾。`recordFieldEdit:` 从既有文字存储通知计算自动选取的目标范围，`controlTextDidChange:` 调用侧栏私有`inputDidChangeSelectingGlyphIDs:textRange:`准备pending，再通过无参数的`onTextChanged()`通知Main启动分析；全字追加共用该收尾入口。目标非空时不分视图模式，复用既有pending／背景查询／选中通知及组滚动；目标为空则取消旧待选，保留原选择恢复。最后位置只是范围定位，不截取UTF-16字符；代理对、UVS或原子来源由现有来源组覆盖规则处理。中文组字期间不发布跟随请求，Undo／Redo由侧栏取消待选，Main另行取消其待执行字形编辑并重查；新输入取代旧待选，手动改变侧栏选取沿用既有取消规则。侧栏及工具栏共用输入编辑器，自动选取不转移输入焦点。
- 全字追加的Main入口`appendAllGlyphEntry:`只准备字符与可选固定GID标记，再调用侧栏`appendInputString:selection:selectingGlyphIDs:actionName:`。侧栏沿原流程追加文字并提交Undo；成功后通过共用收尾入口登记被点击的完整GID、请求分析，最后恢复输入焦点。失败不待选、不查、不移焦。普通输入使用空GID选基本字形，全字追加使用被点击的精确GID；后续范围匹配、base回退、组滚动与选中通知相同。`handlingNativeInputEdit`只包住原生文字通知，不套到已结束程序编辑Undo分组的全字追加。侧栏激活／Shift插入仍保留其不同的选取与捲动策略。
- 纯删除与当前选中字形的来源范围相交时，自动选删除起点前一位置所属来源组的基本字形；一次删除多字亦以整段删除起点为准。删除第一字且仍有文字时选剩余第一字，全部删空则清空预览。删除其他文字仍保留原选取路径。`autoSelectionRangeAfterDeleting:` 私有方法负责删除后的选取策略，在原生编辑记录通过验证、追加本次编辑前调用；`GARemapSourceRangeThroughEdits` 共用现有来源映射，不按字面相同的字符猜删除位置。连续删除使原选中来源已消失、快照尚未发布时，继续追踪已有空GID的自动待选目标；另一次不相交的删除会将该目标一起映射。来源记录无效时不猜测，保留原流程。
- 组滚动：整组可见则不动；否则先居中整组，再最小揭示选中行（上方→顶，下方→底）。激活后“不可见则置顶”是独立旧策略。
- 修改键判断统一 `GAModifiersAre(modifiers, expected)`；只看 Command/Shift/Option/Control，Caps Lock/Fn/小键盘不参与；入口只传 `event.modifierFlags`。

### 7.1 输入菜单与常用文字

- 侧栏 `GAGlyphInputEditor` 直接继承 `NSTextView`，自身空 `updateFontPanel` 退出共享面板同步。输入编辑器为 `richText = NO`、`usesFontPanel = NO`，没有用户字符装饰编辑。右键菜单通过 `menuForEvent:` 去掉字体类别，并在原生编辑命令组后插入「常用文字」。VF 数值 cell 通过 `fieldEditorForView:` 提供 `GANumericFieldEditor`，经 `setUpFieldEditorAttributes:` 关闭文字检查；右键去掉拼字与语法／替代项目。
- `GAInput.m` 内的菜单过滤按原生子菜单中的公开 action 辨识字体、拼字和替代项目，并清理冗余分隔线。AutoFill 在侧栏、VF 右键和主 Edit 菜单均保留系统原生行为，不过滤、不隐藏，不安装晚期菜单 delegate，也不禁用系统菜单插件。
- Saved Text 直接接在原生编辑命令组末项后，不再添加／越过上方分隔线；已有分隔线留在 Saved Text 下方。主 Edit 菜单 Select All 与 Saved Text 之间也无分隔线。
- Edit 菜单紧接 Select All 加入「常用文字」子菜单；有字体且当前非空输入尚未保存时，首项保存完整当前输入。纯空白可保存。其后依保存先后（新在前）列出纯字符串。没有已打开的字体时常用文字父项停用。按 Option 时在同一位置切换为「刪除常用文字」。可储存输入且已有常用文字时，储存和清除各在自己的首列。无法储存时，一般模式省略储存命令，删除模式把分隔线和清除命令放在列表尾端。菜单随内容取宽。无字体时也可打开删除模式，删除模式列表为空时只显示停用的「沒有已儲存的文字」。
- 数据为标准偏好设置 `GASavedTexts` 字符串数组；不去空白、不做 Unicode 规范化、不保存 explicit GID 属性。保存的是还原各分隔符后的侧栏模型文字，输入时 CR／CRLF 转 LF。菜单预览复用分隔符标记，Tab 显示为 ⇥，纯空白可见化，长预览按组合字符边界省略。菜单项的 payload 保留完整模型文字。
- 输入框用 ⏎ 显示换行、↵ 显示行分隔、¶ 显示段落分隔、␌ 显示换页、␤ 显示换至下一行、␋ 显示垂直定位。仅符号与属性记录一致时才还原分隔符，字面输入或粘贴的符号按原字符处理。颜色恢复v1.6规则：普通文字经inputTextColor取得controlTextColor，GASetLineBreakMarker使用secondaryLabelColor；未编辑的两个控件都直接保留编辑器存储的显示副本，不再清除工具栏前景色。prepareFieldEditor、plainCopyOfAttributedText及两个颜色构建函数与v1.6的规则一致；原controlTextDidBeginEditing、文字改变及显式聚焦入口进行规范化。没有失焦单色模式、专用焦点颜色回呼或GAGlyphInputControl协议。
- `GASavedItemsMenu.controller` 弱引用所属字体窗口。右键创建时绑定该窗口；主 Edit 菜单 `menuNeedsUpdate:` 时绑定当时的活动窗口，后续 tracking／结束其他编辑器不会改写命令归属。子菜单每次打开重读保存数据。
- 回填复用 `GAMainWindowController.replaceInputText:` → sidebar `replaceInputText:` → 原生 field editor `insertText:replacementRange:`，先经现有跨窗口验证，再整框插入纯字符串，保留现有分析通知、换行处理与 Undo。

- 主 View 的竖排及 TextAlignment／WritingDirection／TypesettingLanguage／FontFeatures／TextDecorations 父项，每次 menuNeedsUpdate 按当前窗口的 `GAViewModeSupportsTextLayout` 同步 enabled。方向保持原条件 hidden；排版语言入口保持可见，无可操作语言时使用灰色提示。子命令仍用原生自动验证，右键隐藏规则不变。

### 7.1.1 全文文字装饰

- 主 View 在 Typography 下方提供独立 Text Decorations（文字裝飾）子菜单，内含 Underline⌘U／Strikethrough⌘L／Outline⌘Y；Edit 与右键均无这三项，也不在原生 Typography 目录中。仅多字视图可操作，无论输入选区如何，都切换整个预览。菜单 action 直接操作当前字体窗口，不经过侧栏 field editor。
- `GAMainWindowController.underlined/struckThrough/outlined` 保存每窗口选择，`GADetailViewController` 转发至 `GAMultiGlyphView`；变化只重建原生预览布局，不重新查候选。三个布林值可随整套开档设置保存。
- 多字数据管线使用 `NSString`，scan snapshot 直接构建过滤缺字后的文本。侧栏的 `NSAttributedString` 只承担明确GID／换行标记。输入通知恢复直接查询；没有装饰范围投影、RTF装饰读取、typingAttributes装饰保留或装饰专用模块。
- 多字显示基础属性按全文布林值添加 `NSUnderlineStyleAttributeName`／`NSStrikethroughStyleAttributeName` 的单线值；中空字使用 `NSStrokeWidthAttributeName = 3`，与原生 `NSTextView.outline:` 默认值一致（字号的3%）。固定GID和竖排替代复用同一属性，整段一致，绘制由 TextKit 完成。输入框字体与颜色仍由 App 控制。
- 中空字显示字体文件仍保留的轮廓，包括重叠内线；不能恢复导出前已经移除的轮廓，不提供节点或控制柄编辑。
- 30语系提供对应名称，繁体为「底線／刪除線／中空字」。

### 7.1.2 书写方向

- 仅主 View 在 Text Alignment 后、Typography 前提供 Writing Direction（書寫方向）；右键结构不变。只对多字预览启用，为原生互斥勾选。
- `baseWritingDirection` 为 `NSWritingDirectionNatural`／LTR／RTL，经 Controller、Detail 转发至多字的 `NSParagraphStyle.baseWritingDirection`。它与竖排、对齐独立，不插入方向控制字符。
- 字体构造时以 `CTFontCopySupportedLanguages` 获取系统回报的支援语言，再用公开 `NSLocale.characterDirectionForLanguage:` 检查是否至少一个为RTL，只缓存 `GAFontDocument.hasRightToLeftLanguages` 布林值。主 View 每次打开时按活动窗口的同名只读属性显隐方向子菜单；没有字体或没有RTL语言时隐藏。没有手写RTL语言白名单。
- 这是按用户要求采用的选单显示规则，不是字体是否能接受双向排版的能力位；纯数字／标点也能受基础方向影响。该CoreText语言清单不是OpenType `locl` 语言系统／替换分支清单；排版语言另由自有GSUB解析器提供。
- 切换方向会取消旧的异步原生GID反查，并把方向带入结果有效性核对。显式方向也传给自有回放的ICU段落基础方向；自有原生GID来源追查使用当前选择的OpenType语言标签回放，并保留独立分支搜索，不冒充CoreText的内部执行轨迹。
- 方向与中空字随整套开档快照保存；预设为自然方向／普通填色。载入没有RTL支援语言的字体时恢复自然方向，避免隐藏后残留无法从选单还原的显式方向。

### 7.1.3 排版语言

- 仅主 View 在书写方向后、Typography 前提供排版语言；右键不变。列出GSUB中所有具名LangSys，跨Script相同标签只列一次，使用原有完整对照与本地化名称排序。不比较预设lookup，不比较语言之间程序或最终字形。入口不随字体隐藏；没有具名LangSys或全部标签都无系统语言对应时，子菜单仅显示停用的No Selectable Languages（繁中「沒有可選語言」），不添加只有一个预设的空选择器。有可用标签时保留原预设、具名项及个别无法映射项的停用行为。
- `OpenType::languageTags()` 直接读取已解析scripts的language.name集合，不读取feature／lookup／FeatureVariations，不执行GID或shaping。`GASubstitutionEngine.languageTags` 导出，`GAFontDocument.typesettingLanguageTags` 在背景构造时缓存，Controller同名接口供菜单使用。
- 预设项清除显式语言属性；不归并或推测语言。无法映射的具名项停用。
- 语言本地化名称使用 `NSLocale.displayNameForKey:NSLocaleIdentifier value:`，未命名时返回nil并沿用官方登记表名称，再无登记才用原始tag。
- 原始标签继续保存为每窗口 `typesettingLanguageTag`，随开档快照保存；换字体不再声明的选择恢复预设。`GAFontFeatures` 内的语言名称函数与随包679项完整登记表保持，用于本地化名称与原生语言切换；未有可信系统对应的自定义标签显示但停用。
- 不要把这套GSUB菜单与CoreText原生AAT Language Tag混为一谈：CTFontCopyFeatures可返回type39组，经既有Typography模型自然展示；其selector0可以是标记为默认的No Change，非零selector对应ltag。没有type39时系统特性目录不补这一组；整个特性目录也可为NULL。App的GSUB「预设」是自行添加的“不指定文字语言”，不是直接复制CoreText语言菜单，也不等同GSUB DefaultLangSys必须存在。

### 7.2 焦点

- GAInput.m在编辑期间安装至多一个应用内leftMouseDown monitor。侧栏、工具栏及数值输入的Cell在原生编辑器取得焦点后通知开始，结束后主队列检查实际first responder，无输入框即移除。两个字形输入Cell只包住原生edit／select／end入口；Undo过渡及完整文字／属性保护由共用函数与GAGlyphInputEditor处理。
- 合格空白点击通过 `GAInputBlankClickNotification` 发出（object 是原 NSEvent）；主窗口和 Popover 各自处理自己的窗口。事件始终原样返回。
- 主窗口空白 mouseDown 时焦点回到字形列表，侧栏隐藏时交回主 NSWindow。Popover 空白 mouseDown 时交回 Popover 自己的 NSWindow。
- 跨窗口先让源 field editor 经原生验证结束编辑；失败不强制移焦。
- 文字输入框的 Enter / Escape 调用 `focusGlyphList`，Popover 内则调用 `focusWindow`。侧栏输入框按控件身份辨认，不依赖直接父视图，兼容新系统分栏附属视图；工具栏输入框则把焦点交回窗口。
- 侧栏展开时按当前焦点决定：工具栏输入框正在编辑则恢复侧栏输入框与选区；输入已失焦、主窗口仍为 first responder 时调用 `focusGlyphList`；其他控件已取得焦点时保留原焦点。切换期间也不覆盖新取得的控件焦点。不记录收起前列表是否持焦。
- Popover 关闭时沿用 `focusGlyphList`。输入框已持焦、正在切换侧栏，或关闭原因为拖出独立窗口时保留焦点。
- 空白判断排除可交互 `NSControl` 和可编辑/可选中 `NSTextView`；非交互文字标签可视为背景。

### 7.2 快捷键

| 操作 | 快捷键 |
| --- | --- |
| 多字全文底线／删除线／中空字 | `⌘U` / `⌘L` / `⌘Y` |
| Single Glyph / Characters / Glyph Grid | `⌘1` / `⌘2` / `⌘3` |
| Bounding Box | `⌘4` |
| Vertical Layout（仅多字） | `⌘5` |
| 展开／收起侧栏 | `⌃⌘S` |
| Make Text Bigger / Make Text Smaller / 回復預設大小 | `⌘+` / `⌘−` / `⌘0` |
| Expand / Shrink Bounding Box（多字） | `⌥⌘+` / `⌥⌘−` |
| Increase / Decrease Leading（多字） | `⌃⌘+` / `⌃⌘−`，每次乘／除√1.12，默认倍率上下各20步 |
| 行首 / 行尾（输入框） | `⌘←` / `⌘→`（也接受 `⌘↑` / `⌘↓`） |
| 组导航（列表） | `⌘↑` / `⌘↓`，按可见的基本字形列移动 |
| 激活 / Shift 插入 | Return / `⇧Return`（或双击 / `⇧`双击） |
| 复制编码 | `⌘C` |
| 打开字体 / 关闭窗口 | `⌘O`（另接受隐藏的 `⌘N`）/ `⌘W` |
| 帮助 | `⌘?` |

## 8. 窗口、控制器与菜单

| 中文 | English | 说明 | 代码符号 |
| --- | --- | --- | --- |
| 字体窗口 | font window | 每个窗口固定同一字体；换轴只更新同一字体的实例 | `GAMainWindowController` |
| 详情容器 | detail view controller | 三种视图、布局、缩放 | `GADetailViewController` |
| 侧栏控制器 | sidebar view controller | 输入、列表、pending、滚动 | `GASidebarViewController` |
| 侧栏输入 | sidebar input | 编辑器、换行标记、属性规范化 | `GAInput` |
| 拖放窗口 | drop window | 接收字体文件拖放 | `GADropWindow` |
| 工具栏字体名 | toolbar font name | 标题栏左侧字体名 | `NSToolbar`、`NSStackView`、`GAFontTitleField`（private） |
| 最近字体 | recent fonts | 固定 app defaults 中的路径列表作为菜单来源；仍登记系统 recent documents | `GAPersistentRecentFontPaths`、`GAAppDelegate`、`NSDocumentController` |
| 常用文字 | saved text | 跨窗口共享的显式保存纯文本；精确匹配、整框替换 | `GASavedTexts`、`GASavedItemsMenu`、`replaceInputText:` |
| 视图模式 | view mode | 全字 / 多字 / 单字 | `GAViewMode` |
| 分栏 | split view | sidebar + detail | `NSSplitViewController` |

窗口与服务：

- 未保存窗口大小时，初始frame为600×400pt；有开档快照时读取保存的外框宽高（pt），不恢复位置。没有另设整窗 `minSize` 或详情分栏的 `minimumThickness`。主视图的实际可见宽度与完整画布高度通过 Auto Layout 各设最小300pt；26的宽度从safeArea左缘计算，避免将侧栏下方的延伸背景计入。侧栏收起时画布高度包含标题栏。侧栏宽度仍为200–1000pt。
- 窗口标题隐藏，无分隔线。侧栏显示时标题区透明，26 使用 Unified 工具栏，其他系统使用 UnifiedCompact。26 将窗口按钮与字体名称包在完整浮动侧栏内部，同时让右侧画布延伸到顶部。每个字体独立窗口，关最后一个窗口不退出，不恢复上次字体或窗口。侧栏显示时，无边框可变按钮与字体名组成自订 stack，静态字体隐藏按钮，Popover 以原按钮为锚。26 的侧栏显示样式已获使用者实机截图确认。
- 主View菜单的Show Sidebar／Hide Sidebar以每个字体窗口为单位切换。展开时使用无泡泡字名／VF组（GAFontName项指定view后显式bordered=NO），VF右侧原5pt间隔保留。收起前将原侧栏输入框与列表的上缘固定在侧栏坐标，并冻结原生滚动内距；工具栏换成独立VF项及独立TextField，原字名／VF组以实测位置留在侧栏内，随原生侧栏收走。输入框不会隐藏，也不会搬入工具栏；两处文字显示同步，共享编辑器和Undo。收放动画开始前完整切换窗口工具栏样式、工具栏项目、当前输入控件、侧栏安全区补偿与详情安全区模式，并完成布局；展开前先移除独立VF／TextField，解除字名组的侧栏固定并恢复原字名工具栏项。展开动画完成后才恢复输入框原accessory约束与自动滚动内距。减少动态效果及未显示窗口时直接完成同一流程，不加入标题栏accessory或截图占位。
- 侧栏收起后，主画布铺满窗口。全字和多字的滚动区铺满主区域，由 AppKit 的原生内容内距预留工具栏高度。滚到顶端或页面尚未进入工具栏后方时，工具栏背景透明；页面滚进工具栏后方时显示原生背景和分隔样式。全字网格在收起侧栏或全屏时的自身顶部留白为 0，并启用 AppKit 自动内容内距；普通窗口展开侧栏时为 18 pt。单字的安全区只收紧页面的上方位置限制，下方位置限制沿用原页面边距。多字的 viewportSize 包含工具栏后方的完整画布，正常上下边距按完整画布高度计算。顶部原有留白不足工具栏高度时只补足差额，已由 AppKit 提供的内距不会重复计算；底部保留原边距。捲动位置沿用共用的原生比例保存。浅色默认背景为 sRGB (253, 253, 253)，深色为 (60, 60, 60)。
- 侧栏保留 `GASearchField`，工具栏采用圆角 `GAGlyphInputField`（`NSTextField` 子类），通过 `useInputInToolbarContainer:` 切换当前输入控件，继续共用原 `GAGlyphInputEditor` 与窗口 Undo Manager。工具栏输入框用当前字体显示名作原生 `placeholderString`，仅空输入时显示，不写入查询或Undo；字体载入／名称更新时及收起侧栏时经 `setToolbarInputPlaceholder:` 更新。侧栏原提示保持 Enter text。输入框在工具栏时，字形列表按输入框原高度保留顶部空间。收起侧栏后，工具栏弹性空白在LTR放输入框之后、RTL放输入框之前；VF与输入框保留原有排列；RTL弹性空白位于VF之前，VF仍在输入框之前。VF插入／移除索引为LTR的0、RTL的1，26+固定间隔仍跟在VF之后。切换前结束原生编辑，切换完成后在窗口仍持有焦点时恢复输入选区。侧栏展开时无框 VF 按钮位于字体名称旁。侧栏收合时变轴 Popover 锚定原生 VF 工具栏项目，macOS 12–13 锚定其按钮视图。26+的VF与输入项目之间插入原生固定空白以分开玻璃泡泡，静态字体一起移除VF和空白；12–15使用普通相邻项目间距，不插入额外空白。输入项目保留bordered=YES的原生玻璃泡泡；26+保留ExtraLarge TextField配置以匹配原生玻璃泡泡；此前27主机量得36pt，新版实际外观仍由使用者验收。15+禁止显示模式自订，13+把所有既定工具栏项声明为不可移动／移除；不以自订hitTest间接压制右键选单。
- macOS 26 的主窗口布局由 `GAAppKit.h` 的 `GAUsesMacOS26Layout()` 限定为系统主版本恰好26，不能使用无上限的26+判斷取代。26的detailItem使用公开automaticallyAdjustsSafeAreaInsets，将详情容器延伸到浮动侧栏下；GADetailContainerView在整块容器绘制当前预览底色，三种预览子视图的左缘约束至safeArea，顶部仍贴容器顶边，字形保留在右侧可见区。该底色沿用同一previewColors，随选色、整套开档颜色与外观更新。12–15及27不启用分栏延伸、容器底色或新左缘约束。
- macOS 26侧栏的ScrollView不绘背景，SourceList表背景透明，使用系统侧栏材质与原生选中背景，列表底部距safeArea 8pt。26及以上的输入框放在 NSSplitViewItemAccessoryViewController，左右留 12 pt，下方留 9 pt；附属视图高度按输入框的原生 fittingSize 决定。列表铺满侧栏并使用原生滚动内距；26.1及以上将accessory.preferredScrollEdgeEffectStyle设为softStyle，26.0保留系统默认。26及以上的滚动区与表均不绘制不透明背景，避免在原生侧栏材质中形成硬切。旧 SDK 通过运行时查找公开类接入该接口。仅26且侧栏展开时，split根视图additionalSafeAreaInsets.top使用Main实作内私有GAMacOS26SidebarInputTopOffset（−8pt），使整个accessory上移而不把输入框移出裁切容器；detail视图额外加回8pt，保持原安全边界。收起侧栏时两项补偿归零。27不应用补偿，保持0pt顶边偏移。较旧系统的输入框留在侧栏，左右 9 pt，顶部相对窗口 contentLayoutGuide 的约束常量为 -1 pt。
- 拖到窗口总是开新窗口；`⌘O`、启动时的打开面板、Dock 拖放都能打开。
- 启动时若有排队 URL 先打开，否则立即显示打开面板（无延迟计时器）。
- File 菜单：Open… → Open Recent → Copy to Font Book → 分隔线 → Close。Open…（台湾／香港「開啟⋯」、简体「打开…」）直接打开原生开启面板，快捷键为 `⌘O`，隐藏同项处理 `⌘N`。Copy to Font Book 显示其 Copy to All Users 替代项。
- 原生开启面板的 accessoryView 为横向NSStackView，三个NSButton放在NSStackViewGravityCenter区域，附件宽度随面板调整，使整组按钮居中；上下各8pt，按钮间距8pt；名称为目前使用者、所有使用者、系统内建（英文 Built-in），沿用各语系名称并移除省略号。面板初始展开附件。本机SDK说明directoryURL只在显示前的配置阶段设定，使用者亦回报显示中赋值无效；目前未找到其他受支持的显示中直接导航接口。按钮经 `selectFontFolder:` 保存pendingOpenPanelDirectory并取消当前面板；completion清除旧面板引用后，调用showFontOpenPanelAtDirectory:，在新面板显示前设置目录，依次前往 `~/Library/Fonts`、`/Library/Fonts`、`/System/Library/Fonts`。已有面板时重复Open只置前；外部开档先清除待切换目录再取消面板。字体载入失败的提示确认后，关闭尚未载入字体的窗口。
- 最近字体的 `GAPersistentRecentFontPaths` 是菜单唯一来源；首次 key 不存在时尝试导入当时系统仍可读的 recent URLs（已被系统清除的记录不能自动恢复）。打开成功后去重置顶，数量遵循系统 `maximumRecentDocumentCount`，仍通知 `NSDocumentController`。recentFontURLs 统一过滤不存在／非字体路径。applicationDidFinishLaunching 只调用一次 restoreSystemRecentDocuments：先清空系统列表，再将持久列表中有效URLs由旧到新登记；随后成功开字体只登记当笔URL并更新持久列表。rebuildRecentMenu 仅从有效URLs按新到旧重建App菜单，启动建菜单、悬浮展开菜单和其他刷新都不写入或清空历史。Clear Menu 明确清空App持久列表和系统列表，再刷新菜单。Dock显示仍是系统原生，排序／可见数量由macOS决定，不提供自绘Dock菜单。固定 bundle ID 的新版副本共享 defaults，ad-hoc cdhash 改变不会再让 app 清单跟着系统清空。
- Copy to Font Book 复制当前窗口原始字体到 `~/Library/Fonts`，Copy to All Users 复制到 `/Library/Fonts`。窗口打开字体时记录解析符号链接后的原文件参照，换轴继续使用同一参照。拷贝时解析文件的当前位置，原文件找不到时显示错误。目的名称沿用打开时的文件名。已在目标字体目录（含子目录，解析符号链接）时显示提示。以目录项判断名称冲突，失效链接也计入。原生提示依序提供 Replace / Keep Both / Stop，同名資料夾只提供 Keep Both / Stop，Stop 為預設按鈕。新增、Keep Both 和 Replace 都先在同卷准备一般文件副本，并重新核对来源身份。新增和 Keep Both 用排他改名提交，Replace 用 `rename` 取代目的目录项，遇到资料夹时拒绝写入。文件错误由 `presentError:` 显示。
- 30个语言／地区资源；Help15段；`GAAppDelegate.showHelp:`显式列出Help.01–Help.15，与用户定稿README的15条使用说明对应。Help.04含常用文字的保存／回填和Option删除；Help.10为当前Typography及⌘5豎排；Help.12包含横向撐捏边距、纵向撐捏行距与⌘0；Help.14含颜色；Help.15为整套预设及窗口大小。英文及繁中按README同步，各语系使用本地菜单名称。阿拉伯语和维吾尔语 Help 的快捷键使用方向隔离，保持组合键的书写顺序。`wuu-Hans`／`wuu-Hant` 用上海市区话，`yue-Hans` 用广州白话，`yue-Hant` 用香港广东话，`hsn-Hans`／`hsn-Hant` 用长沙市区话，`nan-Hans-teochew`／`nan-Hant-teochew` 用潮州话，`nan-Hans-hokkien`／`nan-Hant-hokkien` 用闽南话；闽南话简繁分别侧重厦漳泉和台湾用词。简繁资源使用各自的介面用词。系统语言名称由 macOS 提供；teochew、hokkien 子标签尚未在 IANA 注册。
- 窗口标题用 `resource.usesFamilyName ? resource.name : document.fullName`。工具栏字体名、侧栏变体的名称和来源、Variable 面板的轴名称都启用 AppKit 的原生截断文字展开。
- 字名与可变按钮使用普通 `NSStackView`，不覆写命中或 `mouseDownCanMoveWindow`。字体名使用 `GAFontTitleField`，仅覆写双击时调用原生窗口缩放；绘制、截断文字展开与其余鼠标处理沿用 AppKit。字名尺寸由 stack 的 Auto Layout 管理。标题文字变化时使游标区域失效，让 AppKit 重建展开区域。
- Variable 面板：`NSPopover` + 原生控件；数字框 75pt；顶到预设 20pt，预设到第一轴 12pt，轴左右 20pt，最后滑杆到内容底 18pt，轴内/轴间 4pt；预设用非本地化 style name；坐标不匹配显示 Custom；原生 detach，无自定义 resize 手柄；可变按钮 borderless，字体名 stack 间距 5pt。
- `windowShouldZoom:toFrame:` 的 Glyph Grid 单元格 Zoom veto 见第 6 节。

### 8.1 预览颜色、行距与整套开档设置

- 颜色、行距／缩放和整套开档命令只在主 View 菜单提供；主视图右键提供视图、边界框、竖排、文字对齐与字体排印。菜单栏的边界框命令随当前状态切换 Hide Bounding Box／Show Bounding Box（隐藏／显示边界框），不带勾号；右键维持 Bounding Box 名称及勾选状态。两者共用原命令、⌘4及视图可用条件。
- 颜色：Bounding Box 下的 Colors 子菜单依序为 Follow System、已储存配色、Save Current Palette（可储存时）、分隔线、Glyph…、Bounding Box…、Background…。没有已打开的字体时，颜色父项和应用／调色命令停用。每个字体窗口有独立 `GAPreviewColors`；三种右侧视图共享，侧栏不使用自订颜色。Background 同时填充画布与框内，Bounding Box 控制阴影颜色，自订阴影颜色完整保留其 alpha，默认阴影跟随外观为 18%／58%。Follow System 清除全部三项覆盖；零／部分／全部覆盖时分别显示勾选／混合／未勾选。
- 已储存配色是 `GASavedPalettes` 偏好中的颜色 representation 数组，按保存顺序排列，新配色加在末尾。每行以原生菜单图片展示字形／阴影／背景的 15×12pt 等宽色块，间距 3pt，阴影按 alpha 与该配色的背景合成。跟随系统的色块沿对角线分为左上浅色、右下深色，阴影色或背景色任一跟随系统时，阴影色块分两半分别与相应外观的背景合成。图片的辅助使用描述包含用途、sRGB 十六进位色值或跟随系统，以及阴影透明度。勾选依据是三个角色的覆盖色与跟随状态。相同配置已储存或整套跟随系统时隐藏储存命令；应用只修改所属窗口，复用开档快照的预览颜色应用流程。
- 按 Option 时，Colors 在同一位置切换为原生 Delete Palettes 替代项。删除菜单先列清除全部，再按原顺序列出配色。列表空时只显示停用的「沒有已儲存的配色」。菜单重开时重新读取偏好，删除配色不会改变已应用的颜色。
- 主选单的常用文字与颜色由 AppKit 原生 alternate 切换。一般和删除各自有独立的 `GASavedItemsMenu`，打开时按固定模式建立资料列。两种删除菜单共用删除单项与清除全部的动作，由菜单决定写入哪份偏好。父项的替代设定和显示状态在追踪期间维持固定，配色删除菜单关闭原生勾选栏。侧栏右键的常用文字不切换成删除模式。
- 选色器使用系统 `NSColorPanel`，仅阴影显示 alpha 滑杆；跟随系统的阴影进入选色器时按所属窗口外观解析成保留原 alpha 的固定 sRGB 色，随后可只调透明度并存档。选色器连续回填；弱绑定原字体窗口，窗口不可见后不再回填。侧栏专用编辑器的空 `updateFontPanel` 阻止共享字体／颜色面板同步；没有额外面板关闭回调或自动关闭逻辑。
- 行距（介面称 Leading）：多字视图 `lineHeightMultiple` 直接传给原生 `NSMutableParagraphStyle.lineHeightMultiple`，默认1倍；不设置额外的 `lineSpacing`，不自行移动字形。使用者按实际效果决定介面沿用「行距／Leading」，这是显示名称，内部仍使用lineHeightMultiple。键盘每步乘／除√1.12（约1.05830），从默认值上下各20步；范围为1/1.12^10…1.12^10（约0.321973…3.105848倍）。`⌃⌘+`／`⌃⌘−` 调整，按 Control 显示原生 alternate；增加／减少各自独立 action。`GADropWindow.performKeyEquivalent:` 在多字模式按 charactersIgnoringModifiers 接收 +/= 与 -/_，限定 Control+Command（允许输入+所需的Shift），其他快捷键仍走原路径。
- 行距的键盘、纵向撐捏及开档快照均经过同一 setter 夹紧范围。纵向撐捏按手势开始时的行高乘以1+magnification连续调整，沿用原方向锁定规则。旧额外行距属性、动作、计算和lineSpacing快照键已移除，不转换或读取旧值；旧快照没有lineHeightMultiple时使用默认1倍。
- View 最下方的 Use as Defaults 在全屏命令上方，单独分组；香港／台湾「作為預設值」、简体「用作默认」。它是一次保存动作，不是持续自动记忆开关；只影响将来打开的窗口，不改变当前或其他已有窗口。
- 按 Option 原生替换为 Restore Default；香港「還原預設值」、台湾「回復預設值」、简体「恢复默认」。它清除整套开档快照，之后窗口使用出厂状态，不重设现有窗口；没有字体窗口时仍可使用。
- `GAMainWindowController.saveOpeningSettings` 将视图模式、边界框显示、竖排、对齐、书写方向、原始 `typesettingLanguageTag`、全文底线／删除线／中空字、窗口外框宽高、全屏、侧栏显示／隐藏状态及展开宽度，以及 Detail 提供的颜色／全部尺寸写入单一 `GAOpeningSettings` 字典。`windowSize` 以 NSStringFromSize 保存一般窗口的 pt 宽高，全屏时使用进入全屏前记录的宽高。窗口创建时读一次，没有尺寸键的旧快照仍开 600×400pt。保存了 `fullScreen` 的新窗口在字体现有载入流程成功后调用原生全屏切换。窗口显示前先完成布局并将侧栏初始宽度设为保存的 `sidebarWidth`（旧快照缺少该键时为200pt），再按 `sidebarHidden` 复用现有侧栏切换流程恢复侧栏及工具栏，不播放初始收合动画；旧快照没有该键时保持侧栏显示。初始宽度不再于首次成为主窗口时设置，之后手动调整的宽度仍由原生收放流程保留。保存预设时，侧栏展开则读取实际宽度，隐藏则使用每窗 `sidebarExpandedWidth` 记录的收起前宽度，避免将折叠后的零宽度存入预设。Detail 的 `applyOpeningSettings:` 统一应用预览状态。
- 尺寸保存共享 `boxInset`、多字 `textScale`／`lineHeightMultiple`、全字 `cellScale`；因此隐藏视图已调整的大小也随整套状态保存。颜色保存原始 representation，系统跟随角色保持跟随，不解析成固定色。原生字体特性、文字内容、GID选择、变数轴均不跨字体保存。
- 未保存时的原始状态为 Glyph Grid、边界框开、横排、左对齐、无全文装饰、系统色，各视图用自身初始大小。原生字体特性每次使用新字体自己的默认值。
- 預覽大小命令使用 Make Text Bigger／Make Text Smaller（放大文字／縮小文字）、Expand Bounding Box／Shrink Bounding Box，以及 Increase Leading／Decrease Leading。原生字體特性的空清單提示為 No Typographic Features。
- `⌘0` 使用 Default Size（香港／台湾「預設大小」、简体「默认大小」）命令与三个模式的重设函数，恢复当前模式的出厂大小；多字同时恢复共享框、字号与行距倍率1倍，不重写已保存的开档快照。全屏仍为原生 `toggleFullScreen:`。
- 两项名称使用本机 Finder ViewOptionsWindow.strings 的 6.title／463.title。

## 9. 文件、构建与诊断

字体资源显示名为空时用现有Untitled Font，可变实例样式名为空时用现有Default，轴名称为空时用该轴原始四字节tag（如wght）。归并、坐标和实例顺序不变；GAVariationViewController直接消费模型名称，不重复判空。已有的GAFontDocument.fullName和字形名称length检查维持。

### 9.1 源码文件（`Sources/`）

| 目录 | 职责与文件 |
| --- | --- |
| `App/` | `main.m` 入口；`GAAppDelegate.{h,m}` 应用、菜单、打开与文件服务；`GAMainWindowController.{h,m}` 窗口、工具栏、队列调度、快照发布与激活接线 |
| `Font/` | `GAFontEngine.{h,m}` 字体文档／字形模型／度量；`GAFontResource.{h,m}` 字体资源与VF归并；`GAFontFeatures.{h,m}` 原生排印目录、设置及OpenType语言名称／系统语言映射；`GAGlyphSelection.{h,m}` 持久选择与查询身份；`GATextQueryModel.{h,m}` 查询、侧栏显示组及完整预览快照投影；`GAUnicode.{h,m}` 系统Unicode辅助 |
| `Views/` | `GAInput.{h,m}` 原生查询／VF输入控件、换行标记、属性规范化和编辑焦点；`GABoundingBoxView.{h,m}` 单字页面及共享缩放／滚动几何；`GAMultiGlyphView.{h,m}` 原生多字预览与GID命中；`GAAllGlyphsView.{h,m}` 全字网格；`GADetailViewController.{h,m}` 三视图容器、当前模式缩放分派与预览快照设置；`GASidebarViewController.{h,m}` 侧栏列表、pending与选择；`GAGlyphViews.{h,m}` 行／缩略图／Unicode徽章；`GAVariationViewController.{h,m}` 原生VF面板；`GAPreviewColors.{h,m}` 默认动态颜色与每窗口颜色覆盖；`GAAppKit.h` 视图模式／能力、共用顶距换算、仅26布局判断与旧SDK公开接口声明 |
| `FontLayout/` | 自有C++字体表解析、执行器与Objective-C++适配，细分如下 |

跨目录引用使用目录前缀；同目录引用保留短名。默认颜色函数由GAPreviewColors声明和实现，不再依赖边界框视图。build.sh显式收集App／Font／Views下的.m，FontLayout仍由自身脚本处理。Sources内58个代码／构建脚本文件，连根目录build.sh共59个；不计Finder元数据。

`Sources/FontLayout/`（C++17 核心 + Objective-C++ 适配）：

| 文件 | 职责与边界 |
| --- | --- |
| `GABinary.h` | 共享不可变字节、有界相对偏移、Coverage、ClassDef |
| `GACmap.{h,cpp}` | cmap 0/2/4/6/8/10/12/13、UVS 14、symbol/MacRoman fallback；讀取越界只影響出錯的子表或查找 |
| `GAGlyphBuffer.{h,cpp}` | 字面 GID、UTF-16 来源、token 身份、连字组件、预算、GDEF 过滤 |
| `GAOpenType.{h,cpp}` | 脚本/语言/feature/lookup/上下文模式/FV 程序；reverse alternate 索引；PositioningTables 以 call_once 在原触发点惰性验证 GPOS pair classes／mark target coverage，成功结果或 InvalidTable 均只保存一次 |
| `GASubstitution.cpp` | GSUB 1–8、嵌套动作、一对多、零输出、过滤、递归保护 |
| `GASubstitutionBuffer.h` | GSUB 候选共用的写时复制字形区块声明；等价比较、变更范围及实现位于 `GASubstitution.cpp` |
| `GAAAT.{h,cpp}` | morx/mort 子表、状态/标记/栈/插入、重排、方向、段尾、chain |
| `GAPositioning.cpp` | GPOS 1–9；同一 plan 执行成功后返回是否含 kern，异常仍保留 legacy 回退；legacy kern/kerx；lookup 完成后只计算附标实际需要的 LTR prefix pens，attachment resolve 复用；RTL 保留原有正向 suffix 累加次序，保证 double 结果一致 |
| `GAVariation.{h,cpp}` | fvar/avar v1 正规化、ItemVariationStore、VariationIndex。每个字体实例缓存正规化结果，坐标表损坏时保留基本 GSUB／GPOS 和静态度量 |
| `GAGlyphLabels.{h,mm}` | 不可变字形名称／CID 解析；`post` 标准名、CFF SID 与 Expert charset 常数表均私有于实现文件 |
| `GAGlyphCatalogue.cpp` | 两种 OpenType 目录：按查询 GID 建可达的候选目录，按当前变化分支收集指定特性的输出 GID |
| `GATextPreparation.{h,mm}` | grapheme、NFC/NFD、UVS、脚本、ICU bidi、Arabic joining；bidi对象使用作用域自动释放，正常完成仍在字素准备结束后提前释放 |
| `GASubstitutionEngine.{h,mm}` | Objective-C 接口、CoreText 表/advance 适配、缓存、发现策略；同 program 变体在 source 锁内取得已完成的 shared_ptr<const ParagraphCache> 快照，不共享坐标相关 positioning；program 内以完整原文缓存首 run 的 script／rtl（1024项、1MiB软限制，超过32768 UTF-16单位不保存）；实例内按 GDEF outer／inner 缓存 GPOS VariationIndex delta（互斥保护、最多2048项、失败不缓存），不跨坐标实例、不提前解析未用表 |
| `compile-font-layout.sh` | 核心编译脚本（arch/out/mode） |

### 9.2 构建

```sh
cd GlyphAtlas
bash build.sh              # 本机架构
bash build.sh -a           # arm64
bash build.sh -x           # x86_64
bash build.sh -u           # universal arm64 + x86_64
bash build.sh -z           # 本机架构，另出 dist/Glyph Atlas.zip
bash build.sh -u -z        # 通用版与ZIP
```

- 无参数以uname -m选择当前运行架构；-a／-x／-u三者互斥，架构选择由参数控制，不再读取ARCHS环境变量。-z与架构选项可并用；保留旧--zip及--help别名，常用帮助为-h。build.sh有可执行权限。
- `-z` 在 `dist/` 生成可执行的 `If Won't Open Drag this into Terminal.command`，再与 App 一起在 `.build/package` 组装。`dist/Glyph Atlas.zip` 根目录包含 `Glyph Atlas.app` 和该脚本。App 因 macOS 提示已损坏等原因打不开时，将解压后的脚本拖入 Terminal 并按 Return，脚本按自身位置定位相邻 App 并执行 `/usr/bin/xattr -rc`。打包使用 `--norsrc` 与 `--noextattr` 排除扩展属性，两份 README 提供在终端手动执行 `xattr -rc` 的方法。

- `-Wall -Wextra`，0 warning；app 用 `-O2 -flto`、`-Wl,-dead_strip -Wl,-x`（`build.sh`），核心用 `-O2 -flto`、function/data sections、hidden visibility（`compile-font-layout.sh`）。
- 最低 macOS 12.0；ad-hoc 签名；产物 `dist/Glyph Atlas.app`。
- `build.sh` 组装 app、复制所有 lproj（目前 30 个）、`Assets.car`、`AppIcon.icns`，plutil 校验，清扩展属性后签名。
- 核心由 `Sources/FontLayout/compile-font-layout.sh` 编译并链接 libc++；GUI `.m` 由 `build.sh` 编译。
- `.build/` 是草稿，不是交付物；`dist/` 是产物。
- 上游仓库：<https://github.com/Zonz-Ly/GlyphAtlas>。本工作副本有 `.git`；每轮按 COLLABORATION-NOTES 在本地提交保存，GitHub 推送须使用者明确要求。当前开发分支为 `version/1.7`；`version/1.0` 至 `version/1.6` 对应 GitHub Release 标签，`main` 为整合分支。版本阶段是前一版发布后至该版发布为止，例如v1.0发布后的工作归v1.1，当前v1.6发布后的工作归v1.7。未采用的独立实验保留分支；其余功能／性能／清理及已审阅的历史副本统一保留为版本提交历史，零散 `archive/` 标签已清除。实际状态仍以 Git 为准。

### 9.3 诊断与归档

`diagnostics/` 存放隔离探针、字体副本、截图/日志和失败/成功对照，不参与产品编译。

根目录`README.md`／`README.cn.md`保持正常Git追踪；最新要求已移除两条.gitignore规则并清除本地skip-worktree标记，`git ls-files -v`显示`H`。两份原文仍由使用者维护。

本工作副本的提交签章仅在`.git/config`本地启用：`gpg.format=ssh`、`commit.gpgsign=true`，身份为Zonz／`32699823+Zonz-Ly@users.noreply.github.com`。专用Ed25519私钥位于`/Users/zonz/.ssh/glyphatlas_signing_ed25519`（600权限，不纳入仓库），GitHub账户Zonz-Ly登记对应公钥，标题「GlyphAtlas signing — Zonz Mac」，用途Signing Key；指纹`SHA256:VpTZinggbkCeDTaltlp7Cq6mNDCuR+DBYSUgu3ETRWw`。本地验证清单为`.git/glyphatlas_allowed_signers`。全局Git配置和HTTPS远端认证未变；这些配置／私钥不随clone传播，旧未签署提交也不因本设置变成已签署。

| 目录 | 内容 |
| --- | --- |
| `all-features-off/` | AAT “All Typographic Features Off” 对 ccmp/vert/vrt2 的限定测量 |
| `ccmp-control/` | ccmp 关闭候选、WebKit 固定 commit 源码、CoreText 内部表证据 |
| `cleanup-2026-10-28/` | 清理前源码快照 |
| `cleanup-file-review-2026-10-28/` | 逐文件清理审批与 diff |
| `cleanup-recent-2026-10-29/` | 近期清理快照/diff |
| `font-copy-alerts/` | Font Book 冲突按钮术语证据与改前资源 |
| `formal-recipe-75/` | 外部四步方案对照实验（未采用） |
| `locl-control/` | locl 语言/selector 测量 |
| `multi-text-origin/` | 多字视图 textContainerOrigin 几何读回 |
| `pingfang-ui-width/` | 蘋方 UI VF 缩略图裁切诊断与最终方案证据 |
| `plangothic-control-characters/` | 控制码/控制图共享 GID 的插入问题 |
| `vf-name-readback/` | 字体命名 API、语言偏好、Source Han Serif 读数 |

研究归档的结论已并入本文件第 3/12 节和 `PRODUCT-LOG.md`；四份历史文档全文已并入 `PRODUCT-LOG.md` 的对应日期条目（2026-10-25/27/28/29），其余证据在各 `diagnostics/` 目录。

本轮收敛审计归档为 `diagnostics/performance-convergence-2026-11-11/`：H1–H4、I1–I3、J1共八项本地提交保留，徽章宽度缓存与K1空来源数组延后建立原型均捨弃；final保存起点5e94e54至最终d066c4e的累计原生离屏像素、侧栏、完整模型／原始候选、3888组基线对照及universal构建证据。侧栏同列刷新用完整glyphIDs数组判等，导航／pending同样使用完整glyphIDs数组。最后57档结构与热调用链复查未找到符合当前收益／风险标准的新项，不承诺任意输入的最优性能。

性能对照归档为 `diagnostics/performance-2026-11-10/`：progress.json 对应十二项本地提交，R01–R12 保存单项探针与前后结果，final 保存累计回归。侧栏仅宽度变化不 reloadData；行高继续依据来源标签与 Unicode 徽章数量，真实数据变化仍走原更新路径。GAUnicodeCodesView 复制当前 scalars 判等，相同编码保留既有徽章对象，选中／背景／外观仍由原设置路径更新。unicodeMap 冷构建跳过原生字符集为空的 plane，实际 scalar 仍由 CoreText 映射。

## 10. 关键对象关系

```text
GAFontDocument → GASubstitutionEngine → GAFontProgram / Resource
                                     ├─ parsed table programs + indices
                                     ├─ per-GID catalogue cache
                                     └─ whole-input discovery cache
GATextQueryModel → current query identity + GARawScanResult → GACharacterGroup
GABuildDisplayGroups → source / selection / combination groups + stable root
GABuildScanDisplaySnapshot → sidebar + native-preview groups + source map
GAMultiGlyphView → native NSTextView / TextKit 2
                ├─ display font settings (AAT selectors)
                ├─ fixed-GID display copy + source index map
                └─ native CTLine/CTRun readback → glyphHits
GASidebarViewController → rows, pending, temporary variant, scroll, focus
                       → GAInput: editor, line-break marker, normalization
GAMainWindowController → window, toolbar, query scheduling, activation
```

## 11. 术语歧义与统一写法

这一节是防误解索引。同一事物出现多种说法时，优先用主术语。

### 11.1 页面与几何

| 主术语 | 也常被说成 | 准确含义 | 不要混淆 |
| --- | --- | --- | --- |
| 单字边界框视图 | 单字视图、边界框 | 整个 `GABoundingBoxView` | 不是页面 |
| 主视图 | 可见区、视图 | 用户实际看到的 bounds；字形只受它限制 | 不是 11% 内容区 |
| 内容区 | content guide、11% | 主视图内缩 11% 的约束区；页面必须在内 | 不是页面本身 |
| 页面 | 白页、definition page | 字身框对应的白色矩形；有阴影 | 不是整个边界框视图 |
| 边距比例 | inset、side inset、留白 | `sideInsetFraction`，页面四周相对视口的比例 | 不是 `contentGuide` 的 11% |
| 文本内边距 | inset、textContainerInset | 多字视图 TextKit 的容器内边距 | 不是页面边距 |
| 页面度量 | page metrics | 字体单位下的 size/baseline/ink | 不是 UI 的 Bounding Box 显示 |
| 边界框 | Bounding Box | 菜单/可访问性里的页面框概念 | 不是字体的 ink bounds |

### 11.2 字体与字形

| 主术语 | 也常被说成 | 准确含义 | 不要混淆 |
| --- | --- | --- | --- |
| 字体文档 | font、document、字体 | `GAFontDocument`，查询入口 | 不是 `CTFontRef` |
| 字体箱 | font box、fontBox | `GAFontBox`，持有 `CTFontRef` | 不是字身框 |
| 字身框 | em box、advance box、字面框 | 页面度量矩形 | 不是 `GAFontBox` |
| advance | 步进、字宽、宽度 | 排版步进量 | 不是墨迹宽度 |
| 墨迹宽度 | ink width、bbox width | 轮廓外接框宽度 | 不是 advance |
| 字形宽度 | 字宽 | 有歧义；必须说 advance 还是 ink | 不要单独用“字宽” |
| LSB | left side bearing、左边距 | 墨迹左缘到原点 | 不是页面 side inset |
| TSB | top side bearing、上边距 | vmtx 顶部留白；页面 origin 不再用它 | 不是页面 side inset |
| 缺字 | missing、.notdef、fallback | GID 0 或字体无字形 | 不是 fallback 字体 GID |
| 种子 | seed、替换字、选中字形 | 用户激活的无编码替换 | 不是 base variant |
| 稳定根 | root、base | 默认 cmap 字形 | 不是 actual shaping 结果 |

### 11.3 查询与数据

- **解析**：字体表字节 → 规则结构，只随资源建立；不是查某段文字。
- **发现**：输入与规则 → 可浏览候选并集；不等于原生显示最终选中哪个 GID。
- **投影 / apply**：已有候选 → 当前原文范围与显示模型；不是重新匹配。
- **发布**：一份完整 snapshot → 主线程；没有单字/多字任务进度状态。
- **快取**：规则、每 GID 目录、完整输入结果、当前模型结果职责不同；见 3.1。
- **目录**（catalogue）：按查询 GID 的静态候选；不是完整文本执行结果。
- **临时结果**（temporary）：点击 GID 的惰性补给；不是 pending 选择。
- **FV 分支**（FV branch）：同一 feature 的不同条件替换；不是具名实例。

### 11.4 选择与 UI

| 主术语 | 也常被说成 | 准确含义 | 不要混淆 |
| --- | --- | --- | --- |
| selection run | 选择运行、替换 run | 属性字符串里的 range + `GAGlyphSelection` | 不是 selection group |
| selection group | 选择组 | run 在显示列表中的组 | 不是 source group |
| source group | 源组、原文字组 | 未被 run 覆盖的 nominal 组件／原子来源范围；规范化后的一个组件可对应原文多码 | 不是选择组，也不保证等于整个 grapheme |
| 组合组 | 连字组、插入组 | 只浏览的跨字符结果 | 不是源组 |
| pending 选择 | pending、待选中 | 追加/激活后等待解析的选择 | 不是普通选中 |
| 临时结果 | temporary | 点击 GID 不在主列表时的临时行 | 不是 pending |
| Shift 激活 | shift 插入、shift 双击、shift+enter | 触发事件里只有 Shift，在 source range 右缘插入 | 不是普通激活（原地替换） |
| 字形列表 | 侧栏、table、列表 | `NSTableView` 的变体行 | 不是全字网格 |
| 全字视图 | all glyphs、网格 | 所有 GID 的集合 | 不是侧栏列表 |
| 文档尺寸 | documentSize | 滚动内容尺寸 | 不是页面尺寸/视口 |

### 11.5 缩放与视图

| 主术语 | 也常被说成 | 准确含义 | 不要混淆 |
| --- | --- | --- | --- |
| textScale | 多字缩放、字号 | 多字视图 51pt × 1.12^n | 不是页面 inset |
| cellScale | 全字缩放、格子大小 | 全字视图 44pt × scale | 不是字体字号 |
| sideInsetFraction | 页面缩放、边距 | 单字/多字页面留白 | 不是文本 scale |
| zoom | 放大/缩小 | 键盘/捏合操作 | 具体改哪个 scale 要说明 |
| 页面 | page | 定义页 | 不是 viewport/document |

### 11.6 请求确认的易混点

以下术语在讨论中容易各说各话，回答时先明确：

| 说法 | 需要先确认是哪一个 |
| --- | --- |
| “字宽” | advance width / ink width / 页面宽 |
| “边距” | 页面 side inset / `textContainerInset` / 全字水平边距 / 行内 padding |
| “度量” | 字体度量（OS/2、vmtx、MVAR）/ Bounding Box 显示 / 行高与 leading |
| “页” | 单字定义页 / 多字页面矩形 / 全字单元格页面 / 滚动文档 |
| “原生” | 原生 TextKit/AppKit 行为 / 原生 AAT 设置 / 原生 GID 读回 |
| “根” | 稳定根 base / 字体资源根 / lookup 根 |

## 12. 已知限制与能力边界

- **多字慢速捲動抖動（停止排查，未修復）**：macOS14橫排長文本慢捲整頁上下抖動。使用者要求外觀完全一致，已決定放棄本輪排查與修復；不繼續製作陰影快取。正式產品未採用任何診斷改法。原生對照平穩；頁面模糊陰影是線索，仍有初測／重測差異，根因未完全證實。完整證據及評價保留於diagnostics/multi-scroll-audit-2026-11-13/與diagnostics/multi-scroll-lab-2026-11-13/，續查須由使用者重新提出。

- **完整发现成本**：仍需执行各 feature/selector/FV 分支；AAT 每起点状态遍历与候选传播可能很慢，没有全字体线性复杂度承诺。长文本仍可能昂贵。
- **缓存**：NSCache 的 count／cost 是软限制；GPOS VariationIndex 实例缓存有2048项硬上限。长文本发现和 AAT 遍历仍可能昂贵。
- **全字度量缓存**：约 56B/GID（62k 字形约 3.5MB），换字体时释放。 同一 inventory 重套相同 GID 集合时，格子沿用已有 entries 与度量缓冲；变轴仍由 fontBox 更新清除度量有效位。筛选调用继续清除既有高亮并按原入口更新布局。
- **多字竖排**：墨迹越出页面会被裁切；横排保留外扩。
- **组合组**：只浏览，不替换源文本。
- **多 GID 种子**：显示副本会展开所有组件；点击映射回原文。
- **侧栏整组滚动**：组比可视区高时只保证顶部。
- **`setTextScale:`**：夹紧后的值与当前值相差小于1e-9时直接返回；此判断在本轮清理前已存在。
- **窗口尺寸**：未保存尺寸时初始外框600×400pt，否则使用开档快照的windowSize。当前约束为主视图最小300×300pt，侧栏保留200–1000pt；小窗口的实际拖动下限与收放侧栏仍待用户验收，不把源码约束等同于各系统实机结果。
- **输入框文字内距**：侧栏与工具栏Cell共用GAInputRectByInsettingTextEdges设置左右9pt；侧栏覆写searchTextRect／titleRect／drawingRect，工具栏覆写titleRect／drawingRect，保留原生垂直几何。不额外设置textContainerInset或段落缩排，编辑与静态显示沿用同一Cell几何路径。
- **输入Cell与迁移边界**：GASearchFieldCell及GAGlyphInputCell保留薄原生几何／编辑入口，共用函数与编辑器承担状态保护。侧栏Cell另有使用者确认的26+外观相容用途，控制器继续隐藏搜索／取消按钮。以简洁为先，不为机械移出职责而增加大量Field／编辑器状态。
- **工具栏输入初始化**：使用initWithFrame:NSZeroRect，尺寸交由Auto Layout；保留圆角及26+ ExtraLarge配置，以systemFontOfSize:0明确使用系统默认字号与常规字重，沿用原生折行默认。本机14在相同后续配置下量得wraps=YES、scrollable=NO、系统13pt；26／27字级由系统决定，未作本轮实机验证。侧栏建立时同样指定systemFontOfSize:0；保留Large及原有搜索框配置。共用inputFont在控件font为nil时同样使用systemFontOfSize:0。两处闲置副本以各自field.font规范化，避免共享存储把另一处字级带入。GID、分隔符与窗口Undo沿用共用路径。
- **RTL码牌与侧栏固定**：UnicodeCodesView为每个码牌设置原生trailingAnchor、宽高及纵向间距约束，LTR齐右／RTL齐左，不再覆写layout手算frame。收起侧栏的字名固定沿用原leadingAnchor及实测frame常数，按使用者决定保持该实现。
- **Unicode名称展开方向**：沿用AppKit原生expansion提示及现有NSTextFieldCell。每次expansionFrameWithFrame读取标签userInterfaceLayoutDirection：LTR文字Left且固定原框左缘，RTL文字Right且固定原框右缘、向左加宽；字体、颜色、内距、裁切和码标签本体Center不变。方向依据界面，独立于右侧预览的文字书写方向。
- **介面文字字体角色**：字形名称的基本字形用boldSystemFontOfSize:0，其余用systemFontOfSize:0；Unicode码标签用monospacedDigitSystemFontOfSize:NSFont.labelFontSize weight:Regular，保持等宽数字并使用系统标签字号；特性来源标签仍用labelFontOfSize:0。字名字体保留Medium字重及原描述符建立方式，titleBarFontOfSize、fontWithDescriptor:size及备用systemFontOfSize的字号参数均为0，使用系统默认字号。51pt预览、200pt整形、16pt资源处理尺寸不变。
- **工具栏编辑黑字**：使用者已确认在14旧版存在；本轮按明确要求将颜色处理恢复v1.6，撤除失焦单色显示及专用颜色回呼。未将此回退宣称为已证实黑字根因修复。
- **27输入失焦字色**：使用者回报点击同一窗口其他位置后，工具栏文字不如14变浅。当前普通文字明确带controlTextColor属性，失焦镜像继续保留；尚未通过原生最小对照确认是系统设计差异、系统Bug还是此属性路径的适配问题，不作为已证实27新特性。
- **Shift 插入**：同一源组连续插入倒序；有 Unicode 的字形只插字符、不固定 GID；插入后不选中新项。
- **修饰键**：只比较 Command/Shift/Option/Control；Caps Lock/Fn/小键盘不参与。
- **ccmp**：没有找到可采用的独立关闭方法；AAT/OpenType/WebKit 候选均失败（见 `PRODUCT-LOG.md` 的「ccmp control research — 2026-10-27」）。不要声称能关。
- **locl**：文字语言可改变语言分支，但不是全局 Off；`locl=0` 未停用默认语言系统内的替换（见 `PRODUCT-LOG.md` 的「locl control research — 2026-10-27」）。
- **AAT**：没有无上下文的全状态静态目录；复杂状态机依赖实际输入。
- **专用文字 shaper**：不是 HarfBuzz 等价实现；没有 Indic 音节分析/重排/分阶段掩码等专用 shaper。GSUB lookup 类型齐全不等于所有文字系统等价。
- **定位**：无像素 hinting；device deltas 不生效；VariationIndex 生效；Anchor format 2 用表内设计坐标；不支持 kern state table 1、kerx 1/4/6、旧 AAT tuple kerning、avar v2；遇到时记录诊断并保留原生 advance。
- **竖排 TSB/TSB variation**：单字页面 origin 使用 CoreText 垂直 translation；TSB/VVAR `tsbMapping` 刻意忽略。
- **位图字体**：无 `head` 的字体（如 NISC18030）不用 OS/2 typo，回退 CoreText ascent+descent。
- **多字原生 origin 偏移**：旧的原生origin视觉偏移试验已撤回；本次明确授权的lineHeightMultiple首行基线补偿是独立逻辑，不重新处理原生内距取整或1倍原有的视觉偏移。
- **蘋方 UI VF 缩略图裁切**：产品使用每次绘制前透明填 `dirtyRect` 的 workaround；机制未完全确认，不要删除或改成一次性填充。
- **原生 GID 读回**：私有 `requiresCTLineRef`/`lineRef` 只在 macOS 14.8.7 验证；macOS 27 未验证；占位 GID、段落相对索引、run 字体差异必须处理。
- **反查边界**：本项目 replay 与 TextKit 不保证等价，只有最终 GID/序列和完整来源范围匹配才采用 replay 的上游；兜底路径是确定性目录/上下文来源，不声称是唯一真实路径。多 GID 与 composition 同样要求完整 source span。
- **名称**：VF 家族名只在剩余资源中唯一时使用；重复/缺失回退原生 display name；不做坐标反查。
- **Native font-title expansion**: uses AppKit allowsExpansionToolTips. After sidebar expansion, toggleSidebar calls invalidateCursorRectsForView: on titleFontNameField without an extra layoutSubtreeIfNeeded. In a separate macOS 14.8.7 app, all six real expansion cycles restored the tracking area from 0 to 1; the first three did not execute the separate input-focus layout path. The user confirmed full-name hover expansion without visiting another font window. Animation, reduced-motion and not-yet-visible windows share the same completion path; only normal visible animation was tested here. Evidence: diagnostics/title-expansion-nolayout-2026-11-13/summary.json; original diagnosis: diagnostics/title-expansion-2026-11-12/. VF has no ordinary tooltip.
- **本工作副本**：有 `.git`；没有 `Tests/`、`Sources.backup/`。`dist/` 与 `.build/` 是构建产物，不等于 GUI 验收证据。

## 13. 诊断与研究结论索引

| 主题 | 结论 | 位置 |
| --- | --- | --- |
| ccmp 关闭 | 33 种设置、6 个字体案例、594 次读取均未关掉 ccmp；calt/liga 对照有效；结束研究，不改产品 | `diagnostics/ccmp-control/`；全文见 `PRODUCT-LOG.md` 的 ccmp 研究条目 |
| locl 关闭 | `locl=0` 不停用默认语言系统替换；文字语言可切 TRK 分支；不能宣称全局 Off | `diagnostics/locl-control/`；全文见 `PRODUCT-LOG.md` 的 locl 研究条目 |
| All Typographic Features Off | AAT type 0/1 未关掉测试中的 ccmp，也未关掉 vert/vrt2；规范描述不等于这些 GSUB 字体实测 | `diagnostics/all-features-off/` |
| TextKit 2 私有 GID | `requiresCTLineRef` + `lineRef` 可在不切 TextKit 1 的情况下读 CTLine/GID；已接入产品；macOS 27 待验证 | `PRODUCT-LOG.md` 的「Native TextKit 2 private GID readback research — 2026-10-27」 |
| vrt2 优先 | 本机 TextKit 2 在 vert/vrt2 同时存在时匹配 vrt2；vrt2 不覆盖某 GID 时不回退 vert | 离屏 TextKit 2 探针；结论见 `PRODUCT-LOG.md` 2026-10-25/26 条目 |
| 竖排引号 | 引号补偿与一般匹配统一为“有 vrt2 选 vrt2，否则 vert”；不回退逐字 vert | `PRODUCT-LOG.md` 2026-10-26 |
| 蘋方 UI VF 裁切 | 私人字体 `head.xMax` 与裁切相关；最终用每绘制透明填 `dirtyRect`；机制未完全确认 | `diagnostics/pingfang-ui-width/` |
| 多字 origin | 原生 `textContainerOrigin` 与请求 inset 可差分数点；产品两次补偿试验均未解决视觉偏移，已撤回 | `diagnostics/multi-text-origin/` |
| 字体命名 | 原生 display name / 唯一 VF 家族名；不做坐标反查；语言偏好影响本地化名 | `diagnostics/vf-name-readback/` |
| 控制码插入 | Plangothic 等字体把控制码和控制图映射到同一 GID；全字追加优先非 C0/DEL | `diagnostics/plangothic-control-characters/` |
| 清理审批 | 逐文件清理的范围、diff 和验证边界 | `diagnostics/cleanup-2026-10-28/`、`cleanup-file-review-2026-10-28/`、`cleanup-recent-2026-10-29/`；全文见 `PRODUCT-LOG.md` 的 2026-10-25/28/29 清理条目 |
