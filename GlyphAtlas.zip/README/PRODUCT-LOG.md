# Glyph Atlas Product Log

> **事件记忆池。** 每次沟通、测试、确认、决定、代码变动、测量和遗留风险，都在这里留一条带日期的记录。它回答“我们做过什么、为什么”，不回答“现在代码是什么”。
>
> **阅读顺序。** 先看文末最新条目；当前结构/术语看 [`GLOSSARY.md`](GLOSSARY.md)；协作规则看 [`COLLABORATION-NOTES.md`](COLLABORATION-NOTES.md)。
>
> **写入规则。**
> - 新的一轮在**文件末尾追加**；同一轮在结束话题前可以持续修改对齐。
> - 旧条目被新决定/变动取代时，**不删不改正文**，只在标题标「过时，更新请看XXX」。
> - 不要在这里重写当前架构、术语表或操作手册；那些属于 `GLOSSARY.md`。
> - 不要创建编号副本或按日期拆文件。**`README/` 只允许这三个文件，不得新增任何交接文档**。测试/诊断资料放 `diagnostics/`，但不构成交接文档，可能随时被清理；记录、说明、结论仍放本文档。
>
> **README 文件夹只保留三个文件：** 本文件、`COLLABORATION-NOTES.md`、`GLOSSARY.md`。项目根目录的 `README.md` 是 GitHub 对外说明，**AI 不直接改**；发现与代码不符时告知用户，可提供修改建议，或由用户改中文后主动同步英文。

## Documentation

- `PRODUCT-LOG.md` (this file): dated events, decisions and measurements; append new rounds at the end.
- [`GLOSSARY.md`](GLOSSARY.md): current structure, terminology, data flow and boundaries; update in place.
- [`COLLABORATION-NOTES.md`](COLLABORATION-NOTES.md): how to work with the user, authorization, verification and handoff.
- Root [`README.md`](../README.md): GitHub-facing usage/limitations; **AI must not edit it** — report drift to the user.

Project root is `GlyphAtlas/`: `build.sh`, `README/`, `README.md`, `Sources/`, `Resources/`, `diagnostics/`, `dist/`; `.build/` is scratch. Requirements and build commands below are stable project facts; current behavior lives in `GLOSSARY.md`.

Glyph Atlas is a native macOS inspector for the alternate glyphs and ligatures a font provides for the text you type.

## Requirements

- macOS 12 or later (the multi-character view uses TextKit 2)
- Command Line Tools (a full Xcode installation is not required)

## Build

```bash
bash build.sh
open "dist/Glyph Atlas.app"
```

`build.sh` builds a universal binary (`arm64` + `x86_64`) by default and writes
`dist/Glyph Atlas.app`. To build only one architecture:

```bash
ARCHS=arm64 bash build.sh
ARCHS=x86_64 bash build.sh
```

The app is ad-hoc signed and has no third-party dependencies or network access.

> **历史说明（2026-10-23/24）：** 以下 `Window and input` 到 `Project layout` 是早期产品说明，保留作历史；部分数值/行为已被后续条目取代。当前结构看 `GLOSSARY.md`。

## Window and input（2026-10-23 初版；窗口最小尺寸见 GLOSSARY §8）

- Native `NSSearchField` with the system bezel, no magnifier or clear button; single-line.
- `⌘←` / `⌘↑` move the insertion point to the start of the input; `⌘→` / `⌘↓` move it to the end.
- `Return` moves focus to the glyph list. `Option-Return` and pasted line breaks are stored as a marked `U+23CE` in the one-line field: the marker is visible inline in `secondaryLabelColor`, hidden from the glyph list, and becomes a hard line break in the multi-character view. Copying, cutting, or dragging a selection writes `U+000A` back to the pasteboard.
- Native source-list `NSTableView`.
- The sidebar starts at 200 pt and can be resized between 200 and 1000 pt.
- Default and minimum window size is 600 × 400 pt.
- The font name is a toolbar item placed before the sidebar tracking separator.
- Each font opens in its own window. Closing the last window does not quit the app.
- `⌘O`, the launch open panel, drag-and-drop onto a window, and drag-and-drop onto the Dock icon all open fonts.
- Dropping a font onto a window always opens a new window.
- **Open Recent** uses the system recent-documents list, shared with the Dock's Recent Items.
- There is no automatic reopening of the last font or restoration of font windows.
- The bounding box view can be dragged to move the window.

### Input field (2026-10-23, updated 2026-10-24)

The sidebar input is a `GASearchField`, an `NSSearchField` subclass whose
`GASearchFieldCell` forces a 9 pt text inset on both edges. The search and
cancel button cells are nil, so the field keeps the bezel without a magnifier
or clear button. The custom field editor, line-break markers, and selection
runs are unchanged.

macOS 27.2 (AppKit 2775.20) returned a negative text rect from
`NSSearchFieldCell` when both button cells had been set to nil:
`{-2, 6, 178, 20}` for a 182 × 28 field. The field editor was placed at that
rect and clipped at the field's left edge, so the text started at about
0.5 pt. macOS 14.8.7 returned `{9, 6, 164, 16}` for the same nil-button
configuration. `GASearchFieldCell` overrides `searchTextRectForBounds:`,
`titleRectForBounds:`, and `drawingRectForBounds:` to put both edges at 9 pt
while keeping the cell's vertical rect.

On macOS 14.8.7 the 9 pt text inset path (placeholder, typed text, ⌘A/Delete)
was verified; the cell's text rect and field editor frame are
`{9, 6, 164, 16}` for a 182 × 28 field. macOS 27.2 is pending an on-device
check; if the new cell's field editor ignores the overridden rects, the
fallback is a stock search field with its stock buttons.

## View modes（2026-10-23 初版；显示开关、字号与默认值已更新）

The `View` menu is shared by the menu bar and the main-view context menu.

| Menu item | Shortcut | Behavior |
| --- | --- | --- |
| Single Glyph | `⌘1` | The original per-glyph bounding box view. |
| Multi-Character | `⌘2` | Lays out the full input text in one bounding box view with automatic wrapping and hard line breaks. The text is an `NSTextView` using TextKit 2. Single-clicking a glyph selects its base glyph in the sidebar; sidebar selection highlights it, while double-click/Return uses the normal activation path. |
| All Glyphs | `⌘3` | Default. One equal-spaced grid of every GID in the font; no bounding box view or inset. Each cell centres the glyph's page (horizontal advance × ascent + descent), not its ink; the baseline is descent above the page bottom. `⌘+` / `⌘-` changes cell size and therefore the number of columns. Double-clicking an encoded cell appends its first Unicode character to the input and selects that GID. Revealing a glyph from the sidebar keeps the minimal scroll when its row is already visible and centres a row that is outside the viewport. Sidebar reveal blinks the accent colour (0.1 s on, 0.1 s off), holds it for 1 s, then fades over 0.7 s; double-clicking a cell to append uses one 0.2 s highlight and a 0.8 s fade. |

Common controls:

- `Show Bounding Box` (`⌘4`) toggles the bounding box and its shadow while preserving the page inset and glyph position.
- `Vertical` (`⌘5`) toggles vertical writing and appears above `Text Alignment` in the View menu; it is enabled only in Multi-Character.
- Single: pinching or `⌘+` / `⌘-` scales the page at ×1.12 per key press; `⌘0` restores the default page (79.72% of the viewport, 10.14% side inset).
- Multi: `⌘+` / `⌘-` changes the text display scale (32 pt × 1.12^n, n = −10…20, ×1.12 per press); pinching changes the text scale too, keeping the page centre under the viewport centre. `⌥⌘+` / `⌥⌘-` changes the bounding box size at ×1.12; those are AppKit alternate menu items, so no window-level key handling intercepts them. `⌘0` restores both text scale and bounding box size.
- Multi uses one bounding box view, not one page per line. TextKit 2 decides line height, leading, column width, wrapping and the used bounds from the font's real metrics; the page is sized from those bounds.
- A line break (`U+000A`) starts a new line in horizontal writing and a new column in vertical writing; wrapped lines and hard breaks share the same line metrics.
- Multi supports left/center/right/justified alignment and horizontal/vertical writing. In vertical writing TextKit 2 applies the font's vertical forms and UAX #50 orientation (CJK upright, Latin and digits rotated) and places columns right-to-left. Horizontal text uses the font's normal kerning; ligatures are disabled (`NSLigatureAttributeName` = 0) and contextual alternates are disabled (`calt` = 0) so supported source characters stay visible and unligated.
- In vertical writing, a `‘`/`’`/`“`/`”` group that is not seeded uses the font's `vert` output when one exists; a seed affects only its own group. It is not substituted when that output is already the encoded vertical form (U+FE41/U+FE43 for `‘`/`“`, U+FE42/U+FE44 for `’`/`”`). The selected `vert` GID then goes through the same 字/A base-name rule as a seed, so the display copy may use 字 or A as its base string while the GID stays unchanged.
- Missing glyphs (base variant GID 0, not seeded, not a line break) are omitted while the controller builds the text and groups handed to the multi-character view. The filtered text and group ranges match, so the view does no filtering or offset mapping; the sidebar still lists the `.notdef` variant for inspection.
- Unencoded replacement glyphs are specified with `NSGlyphInfo`, so TextKit draws the selected GID in the normal text flow; no glyph is drawn by the view itself.
- In vertical writing the base character decides the seed's orientation. If the source character is not upright (UAX #50) and the selected GID is full-width (its advance equals the em or the advance of 字), the display copy uses 字 as the base so the glyph stays upright. If the source character is upright and the GID is narrow, it uses A as the base so the glyph turns. This substitution happens only in a private copy of the displayed attributed string; the input field is never modified. The GID is unchanged. `NSGlyphInfo`'s base string is rebuilt to match the substituted character because TextKit ignores a glyph info whose base string differs from the character.
- All Glyphs: `⌘0` restores the default grid scale.

## Glyph rows

Each row shows:

- the glyph drawn at its real size relative to the font's em
- the glyph name, or `GID n` when the font has no usable name
- the original OpenType feature tags that produced it
- Unicode code badges at the right edge, with the Unicode character name as a tooltip

Synthetic glyph names such as `gidNNN`, `uniXXXX.N`, and `uniXXXX_uXXXX` are replaced with the actual GID.

## Analysis（2026-10-23 初版，过时，更新请看 GLOSSARY §3）

Text is split into composed-character groups. For each group the app collects:

1. direct GSUB single and alternate substitutions
2. results from shaping with each OpenType and AAT feature setting

It also enumerates contiguous substrings by context length, shortest first, and left to right within a length:

```text
ab, bc, cd, ..., abc, bcd, ..., abcd, ...
```

Each substring is shaped separately. A shape whose glyph cluster covers more than one source character becomes a **combination group** (ligature or contextual substitution):

- one group per source range
- multiple schemes for the same range are kept together
- combination groups are listed after all character groups, in scan order: shorter contexts first, then by source position, so a result found later is always below one found earlier (`ff`, `fi`, `fl`, then `ffi`)
- a contextual substitution that covers a single character stays a variant row of that character's group
- groups are rebuilt from scratch after every text change

Raw scan results are cached by content in `GATextScanModel`; a display group and a ligature group are range-bound and rebuilt per text. The cache is per font document and is discarded when the font changes. A ligature group still has no persistent identity beyond its current text range.

Line breaks are layout, not glyphs. Their character groups keep the text ranges intact but are hidden from the glyph list, and the substring scan treats them as boundaries: no substring crosses a line break.

Raw scans run off the main thread. Each text change reconciles the current text's complete desired context set against the content cache and the pending queue: still-valid pending subitems stay in their old items and are rebound to their new ranges, contexts that disappeared are dropped, and each group's missing items are appended after the old items. The current subitem always finishes; its result is cached by content and applied to every current position with that content, so a new text never waits for an old whole-text pass and never rescans cached content. There is no input-length limit.

The sidebar and the multi-character view receive the display groups after every model update and every completed subitem. The first publication uses `setGroups:`; later ones use `applyStreamedGroups:`. The multi-character text is rebuilt when a text change has finished its single-character scan pass, or when the seed signature changes. Combination groups appear in group⇒item⇒subitem order while the rest of the scan continues. The selected row is restored from its glyph key and text range without scrolling. Pending contexts that have not been scanned yet are simply absent from the display.

The first full pass is still quadratic in the number of contexts (the complete scan is required). Subsequent edits scan only contexts whose content is not cached, but the desired-set enumeration itself remains O(n²). Keeping the cache bounded for very long texts is future work.

AAT is used only to discover glyphs and substitutions. AAT type/selector names are not shown as feature sources. OpenType sources use the raw tag and value, for example `liga` or `aalt 2`.

## Single-character path (2026-10-23) — 过时，更新请看「Complete query pipeline…」与 GLOSSARY §3

The current single-character path:

- `GATextScanModel` builds a `content → [1 字组 index]` index in `rebuildGroups`. Cached single-character results are applied through that index instead of scanning every group for each unique character, reducing the single-character part from O(n²) to O(n).
- A length-1 scan result is applied once, through the index, to every group with the same content. `aaaa` still produces four variants; the redundant first apply on the scan subitem was removed.
- `singleCharacterScanComplete` now treats "no pending length-1 subitems" as complete. This makes cached single-character text refresh the multi-character view.
- `clearScanDisplay` resets the multi-character signature and `scheduleAnalysis` advances the generation before clearing, so an old generation cannot write a stale signature or snapshot over the new text.

Measured on an isolated 1,000-character test (1,000 different CJK characters, one per line, PingFang SC, 100 append/withdraw cycles): `updateText` fell from roughly 220–225 ms to roughly 160 ms. The remaining cost is the O(n²) context enumeration in `desiredSubitems`; it was not changed in this cleanup. A 1,000-character single-paragraph app-level run was not performed because the initial multi-context scan is very slow.

Deferred: the `setTextScale:` same-value guard and merging `setGroups:` / `applyStreamedGroups:` were intentionally left out (the latter has different fallback, notify, and pending policies).

## All-glyph and sidebar page metrics (2026-10-24) — 过时，更新请看「OS/2 typographic page metrics」与 GLOSSARY §2.2

The all-glyphs grid used to centre each glyph's **ink bounding box**. The sidebar thumbnails did the same. Both are wrong for punctuation, quotes, and accents: they floated on the cell/icon centre line regardless of their typographic height.

The grid and the sidebar now use one page metric:

- page width: the horizontal advance (`hmtx`, raw font units)
- page height: `ascent + descent`
- baseline: descent up from the page bottom

The single-glyph bounding box view is unchanged: it keeps its `vmtx`/`vhea` vertical advance and top-side-bearing baseline. `GAFontDocument +pageForVariant:usesVerticalMetrics:` selects the mode; the bounding box view passes `YES`, the grid and the sidebar pass `NO`. The `NO` path does not read `vmtx`/`vhea`. The grid caches one `GAGlyphPage` per GID; each sidebar thumbnail computes it once in `setVariant:`.

Sidebar thumbnails keep their 32 pt/em glyph size. For fonts whose page is taller than the 34 pt icon (ThemeX Hiragino Sans is about 1.4 em), the glyph is drawn past the icon's bounds into the row's vertical padding, so descenders are not clipped. The icon does not draw the page rectangle; it only uses the page for the advance centre and baseline.

Measured at the default 44 pt all-glyph cell, against the old ink-centred layout:

| Change | ThemeX Hiragino Sans | Arial Unicode (no `vmtx`) |
| --- | --- | --- |
| comma | down about 14.5 pt | down about 15.5 pt |
| period | down about 12 pt | down about 13 pt |
| quotes / asterisk | up about 8.5–9.5 pt | up about 7–7.5 pt |
| digits, capitals, CJK | within 0.5 pt | within 1.5 pt (most unchanged) |

Cost: a page-metric cache miss remains sub-0.1 ms per GID on ThemeX Hiragino Sans; the `NO` path avoids the `vmtx` reads. The default window shows 49 glyphs; 1,000 visible glyphs cost tens of milliseconds once. Later frames and already-seen GIDs are cache hits. The cache is one 56-byte `GAGlyphPage` per GID (about 3.5 MB for a 62,000-glyph font) and is released when the font changes.

The single-glyph bounding box view was compared pixel-for-pixel before and after the shared-metric refactor for ThemeX Hiragino Sans, with a comma selected; the bounding box region was identical. The sidebar thumbnail keeps its 32 pt/em size, so a page taller than the icon (ThemeX is about 1.4 em) draws into the row's vertical padding instead of clipping: the g descender is complete in the row.

## Selected glyph runs

Select a glyph and press **Return**, or double-click it.

### Encoded glyphs

The source text is replaced with the glyph's first Unicode character:

- a normal character variant replaces that character
- a ligature variant replaces the entire source range of the ligature
- if the glyph maps to several Unicode characters, activation still inserts only the first one; Copy keeps all of them

The new text is analyzed again and a new list is built. No selection run is stored.

### Unencoded glyphs

The source range is marked as a **selection run** in the input field's attributed string:

- one run covers the original character, or the complete ligature source such as `fi`
- the run stores the original substring, the exact glyph IDs, and feature labels for display
- the chosen glyph becomes the base glyph of a group displayed in place of the covered characters
- ligature groups and character groups overlapping the run are suppressed
- unlike an unseeded ligature group, the selection group replaces the covered characters in place
- analysis runs again immediately

Runs are ranges in the attributed text, not occurrence indexes. Inserting or deleting text before or after a run moves the run automatically. Editing inside a run changes its source text, so the run is dissolved and the text returns to normal character groups. Deleting a run's entire range removes it.

The input field keeps its native search-field appearance. User edits and pastes are normalized to plain text, so formatting copied from other applications is discarded; only the internal selection-run attributes are preserved.

### Shift activation (2026-10-24)

Hold Shift while double-clicking a glyph or pressing Return/Enter. The activated glyph is inserted as a new item immediately after its own source range; the glyph already at that position is not replaced.

- The anchor is the activated row's own source range, resolved by the same `sourceRangeForVariant:inGroup:text:` path as normal activation. The insertion point is `NSMaxRange(range)`.
- The source character for the new item is the text of that source range. A combination group contributes its whole source range.
- An encoded glyph inserts its first Unicode character as plain text and stores no run.
- An unencoded glyph inserts the source text with a `GAGlyphSelection` run carrying the exact glyph IDs and feature labels.
- The existing glyph's text, run, glyph IDs, and feature labels are unchanged.
- The inserted item is not selected or scrolled to; the list keeps the activated row selected. Normal activation still selects the glyph it produces.
- Repeated Shift activation from the same source group inserts at the same point, so later insertions appear closer to the source (reverse order). This is the current interaction, not a bug.
- Shift is read from the triggering event's modifier flags. Only Shift may be held among Command, Shift, Option, and Control; Caps Lock and function keys do not disable the mode.
- Shift+Return/Enter on the selected row behaves like Shift+double-click on that row: it inserts a copy after itself.
- If the variant has Unicode, the inserted character is a normal source character; it is not selected, so no pending selection waits on the clicked GID.

## Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| Return / Enter | Activate the selected glyph (same as double-click) |
| Double-click | Activate a glyph |
| Shift+Return / Shift+double-click | Insert the activated glyph after its own source range (Shift activation) |
| `⌘C` | Copy the actual Unicode character(s) of an encoded glyph |
| `⌘↑` / `⌘↓` (glyph list) | Move to the previous / next character group's base glyph |
| `⌘←` / `⌘↑` / `⌘→` / `⌘↓` (input) | Move the insertion point to the start / end of the input |
| `⌘1` | Single Glyph view |
| `⌘2` | Multi-Character view |
| `⌘3` | All Glyphs view |
| `⌘4` | Show Bounding Box |
| `⌘5` | Vertical writing (Multi-Character) |
| `⌘+` / `⌘-` | Zoom the active view; in Multi-Character this changes text size |
| `⌥⌘+` / `⌥⌘-` | Multi-Character: Bounding Box Zoom In/Out |
| `⌘0` | Reset the active view zoom (Multi-Character resets text and bounding box size) |
| `⌘O` | Open fonts |
| `⌘W` | Close the window |

`Edit > Copy` also copies an encoded glyph's characters and is disabled for unencoded glyphs.

## Bounding Box — 过时，更新请看「Single-glyph page uses CoreText's vertical origin」与 GLOSSARY §2.2

The bounding box view and detail panel use a flat titlebar-matched background: `#FFFFFF` in light appearance and `#3C3C3C` in dark appearance. The glyph is drawn with `#222222` in light appearance and `#EEEEEE` in dark appearance. The bounding box view keeps its default 79.72% page (10.14% side inset) and page shadow.

The single-glyph page and glyph are sized from real font metrics:

- page width from horizontal advance
- page height from the `vmtx`/`vhea` vertical advance when present; `ascent + descent` fallback otherwise
- baseline from the `vmtx` top side bearing, or `descent` when there is no vertical table
- glyphs are drawn at their real font-unit size and origin
- overhanging ink is not clipped

The multi-character page is the area of the `NSTextView` layout: in horizontal writing its width is the viewport page width and its height is the used text height; in vertical writing its height is the viewport page height and its width is the used column extent. The text view is transparent and sits over the page; the page shadow and background are still drawn by `GAMultiGlyphView`.

Horizontal writing expands the text view frame by the bounding box side inset and sets `textContainerInset` accordingly, so ink can overhang the page. Vertical writing keeps the text view frame equal to `pageRect` and the inset zero: the vertical text view's bounds are rotated, and the inset-expanded frame moves `textContainerOrigin` off the page. Vertical ink overhanging the page is therefore clipped; the single-glyph bounding box view still draws overhang.

## Limitations（2026-10-23 初版，过时，更新请看 GLOSSARY §12）

- Analysis is limited to the current input text and its contiguous substrings. It does not invent contexts that are not present in the text.
- GSUB is parsed directly only for single and alternate substitutions. Ligatures and contextual substitutions are discovered through CoreText shaping.
- GID-level analysis (`analyzeGlyphIDs:`) covers GSUB single/alternate substitutions only.
- AAT substitution results are not labeled with AAT type/selector names.
- Variable fonts open at their default coordinates and can be adjusted through the variation popover; substitution discovery includes the union of GSUB FeatureVariations branches and stays cached as axes change.
- Features or substitutions available only through private font tables or not exposed by CoreText cannot be enumerated.
- Glyph names depend on the font's glyph-name data (`post` table or CFF charset); when CoreText returns no usable name, the app shows `GID n`.
- The multi-character view requires TextKit 2 (macOS 12 or later).
- An unencoded replacement glyph is specified with `NSGlyphInfo`. Only the first GID of a multi-GID variant is drawn. In vertical writing a full-width GID on a rotated source character is rebased to 字, and a narrow GID on an upright source character to A, so the glyph's orientation follows its design; this rebasing applies to single UTF-16 characters and only in the display copy.
- Vertical ink that overhangs the multi-character page is clipped by the text view; horizontal keeps the inset margin. The single-glyph bounding box view still draws overhang.
- Browser-only ligature groups (`insertedLigature`) are not substituted in the multi-character view; the source characters are still shaped by TextKit.
- Sidebar thumbnails keep their 32 pt/em glyph size. When the page is taller than the 34 pt icon, the ink is drawn into the row padding instead of being scaled; this was verified on macOS 14.8.7.
- Shift activation inserts the first Unicode character for an encoded glyph and stores no run, so the exact clicked GID is not pinned. For an unencoded glyph it stores the run.

## Reference

- [Terminology and API glossary](GLOSSARY.md)
- [Collaboration notes](COLLABORATION-NOTES.md)

## Diagnostics（初版，链接已失效；现行诊断索引见 GLOSSARY §9.3）

> 以下原始清单保留作历史。这些路径在整理时已不存在；现行诊断目录见 `GLOSSARY.md` §9.3；历史文档全文见对应日期条目。

- [Diagnostics notes](../diagnostics/README.md)
- [I.Ming data](../diagnostics/I.Ming-info.txt)
- [PingFang data](../diagnostics/PingFang-info.txt)
- [Fonts without vmtx](../diagnostics/no-vmtx-fonts.txt)
- [CJK hmtx/vmtx measurements](../diagnostics/cjk-vmtx-fonts.txt)
- [Diagnostic tool source](../diagnostics/inspect_font.m)

## Project layout — 过时，更新请看 GLOSSARY §9

```text
GlyphAtlas/
  Resources/Info.plist
  README/
    PRODUCT-LOG.md
    COLLABORATION-NOTES.md
    GLOSSARY.md
  Sources/
    GAAppDelegate.{h,m}           app lifecycle, menus, open panels, recent fonts
    GAFontTypes.{h,m}             shared font UTType helpers
    GAFontEngine.{h,m}            CTFont/CTFontDescriptor wrapper, GSUB parser, shaping
    GAMainWindowController.{h,m}  window, scan-model wiring, selection runs
    GATextScanModel.{h,m}         incremental text scan model, content cache and queue
    GASidebarViewController.{h,m} input field, glyph table, shortcuts
    GAGlyphViews.{h,m}            glyph thumbnails, Unicode badges, row views
    GAViewMode.h                  all/multi/single mode enum
    GABoundingBoxView.{h,m}      single-glyph bounding box view
    GAMultiGlyphView.{h,m}        wrapping multi-character bounding box view
    GAAllGlyphsView.{h,m}         all-GID collection grid
    GADetailViewController.{h,m}  mode container
    GAUnicode.{h,m}               ICU character names, scalar-to-string conversion
```

### Shift activation and modifier validation (2026-10-24)

- Universal build had 0 warnings. Howl Teochew `1` (GIDs 18/538/121) was tested with Shift+double-click and Shift+Enter; Arial, PingFang HK and Hoefler Text were also tried; the `/tmp` harness confirmed encoded insertion stores no run.
- Howl Teochew `…` (GIDs 517/5868) was tested with Shift+Enter, Shift+double-click, Return and double-click; `1` with Return/double-click; ⌘C copied encoded text and beeped without encoding; field ⌘←/⌘↓ insertion positions and table ⌘↑/⌘↓ group navigation were correct. Shift came from synthetic event flags, confirming the event snapshot rather than current keyboard state.
- Shift insertion on Howl Teochew `…`’s locl row produced `……`, kept the locl row selected and did not jump to the new seed; normal Return/double-click still selected the activated glyph. An earlier false negative came from testing an un-rebuilt process; force quit and retest passed.
- Search field: 14.8.7 verified the placeholder, typing and ⌘A/Delete with the 9 pt inset; macOS 27.2 field-editor follow-up remained pending.
- Performance: 1,000 different CJK characters, one per line, changed `updateText` from about 220–225 ms to about 160 ms. A 1,000-character single paragraph was not run because the initial multi-context scan is slow.

## 13 語系本地化與原生介面驗證 — 2026-10-24

初版本地化以 macOS 的 bundle 語言選擇套用 13 套語系資源，涵蓋原生選單、對話框、輔助使用標籤、文件類型、說明與複數格式。香港繁中對齊命令採「靠左／靠右／靠上／靠下／兩端」。阿拉伯文說明以方向隔離字元保留快捷鍵順序。對應提交為 `0a6faf9`。

在 macOS 14.8.7 的驗收記錄中，13 套資源各有 74 個介面字串及一筆複數項，18 次原生檢查通過，涵蓋語言選擇、英文回退、複數、複製快捷鍵及橫直排對齊選單。可見介面另抽查香港繁中、日文、韓文及阿拉伯文。Universal 封裝解壓後通過嚴格簽章驗證。見 [本地化驗收記錄](../diagnostics/localization-13-catalogs-2026-10-24/pr-body.md)。

## Variable font resources, discovery and controls (2026-10-25)（部分过时；面板/控件更新见后续 VF 条目与 GLOSSARY §8）

Variable-font instance descriptors collapse into resources using a pure CoreText comparison: common non-default coordinates, then all defaults, then CFEqual. One resource opens directly at its defaults; multiple resources still present the style chooser. Static collection faces remain separate.

The toolbar button is called Variable / 可變. Its actual outer frame is square (26×26 pt on this machine, including native alignment insets), with secondaryLabelColor and AppKit's native pressed appearance. The popover has the resource's presets, followed by 48pt axis rows. Labels and numeric fields align left/right; popup and slider alignment edges match. Numeric fields grow with displayed or edited digits (tested 39→72pt). Constraints let controls follow panel width. The attached NSPopover has no native user resize affordance, so no custom resize handle was added. Public detachment delegation supplies a separate native horizontally resizable NSPanel, minimum width 240pt and fixed height, with live controls and normal close lifecycle.

The inspector shows all substitutions, rather than applying conditional substitutions to the selected single-glyph page. Discovery scans the default coordinates and representative points of every supported reachable FeatureVariations branch, merges the results, and caches the union by text content. Condition-only single/alternate lookup outputs are also collected directly. The selected literal GID remains fixed as axes change: k stays k; selecting k.jump explicitly keeps k.jump even below the condition threshold. Multi-character layout still follows CoreText at the current coordinates.

Coordinate changes rebind the existing glyphs and metrics. They do not change the list's members/order, rescan content, reload the table or issue a selection-restoration jump. Existing visible cells receive new fonts, and offscreen row models are updated. Input changes, activation and newly discovered rows retain the established list-update rules. The all-glyph inventory is installed once per window; the old resource-switch/reset-to-top path was removed. Its font metrics cache is invalidated without moving the scroll origin.

Validation:

- Futura100CHI-Var 6 descriptors → 1 resource; temporary Futura/New York TTC 20 descriptors → 2 resources; Helvetica retains 6 faces.
- k/Q/e and their .jump counterparts are present at default coordinates. After incremental typing, every axis region retains identical inventory/order/base GIDs; coordinate changes perform zero new raw scans.
- Native window instrumentation: changing 400→650 retains selected k, and explicitly selected k.jump remains selected at 300. Zero raw scans, zero NSTableView.reloadData calls and zero selectRowIndexes calls during the coordinate refresh; sidebar and all-glyph scroll positions are unchanged.
- Panel programmatic widths 320→480 and native detached width 560 retain aligned controls; input width follows digits; detach controls and closing are connected. Attached native resizable flag is false.

Representative-point evaluation currently covers Condition Format 1 and avar 1. Direct single/alternate rules remain enumerable for other formats, but their conditional contextual branches are not guaranteed to be discovered. Existing long-text/context and cache-growth limits remain.

### Native Popover detachment correction (2026-10-25)

The user rejected the custom detached NSPanel: the original request allowed skipping width resizing when AppKit does not support it. Removed detachableWindowForPopover: and the separate panel/content-controller lifecycle. Only popoverShouldDetach: remains; AppKit supplies the native detached popover with its original appearance and content. The Variable button brings an already detached popover forward, and closing the main window closes the popover. No window style overrides or custom resize affordances are added. This supersedes the custom-panel behavior and validation described above.

The user will perform testing from now on. This correction is built and packaged without automated tests or UI verification.

### VF control layout follow-up (2026-10-25)（部分过时；字段宽度/间距更新见 2026-10-27 条目）

The numeric fields return to a fixed 64pt width. The field editor handles Up/Down as ±1 and Shift+Up/Down as ±10, using the edited number and the existing axis bounds and coordinate publication path. Named-instance titles now use CoreText's localized style name instead of the full font name.

The native popover keeps an empty title. Before detachment its content reserves the system titled-window height; after native detachment its outer frame keeps the attached window height, and the layout consumes the corresponding reservation. No custom detached window or window-style change is introduced.

Axis rows use native control intrinsic heights, baseline alignment, and system spacing. The scroll document's layoutMarginsGuide protects slider/field edges from clipping. The Variable button uses a native toolbar bezel in a fixed 26×26pt wrapper; its frame directly fills that wrapper, independent of alignment-rect constraints. Its image is unchanged.

Per the user's instruction, this follow-up is built and packaged only; no tests or UI verification are performed.

### VF appearance correction (2026-10-25)（部分过时；字段宽度/间距更新见 2026-10-27 条目）

At the user's request, the Variable button returns to its original borderless native appearance. The fixed square wrapper, explicit toolbar bezel, and forced button dimensions are removed. The numeric field width changes from 64pt to 66pt. Presets use CTFontCopyName with kCTFontStyleNameKey rather than CTFontCopyLocalizedName, so the app does not request system-localized style names. The space above the preset popup is reduced by 18pt in the attached and native detached layouts.

This change is built and packaged without tests or UI verification, as requested.


## 2026-10-25 — Isolated GSUB and AAT discovery replacement (historical HarfBuzz branch)（过时，HarfBuzz 分支未采用；见「Self-written GSUB/AAT branch」）

The experimental copy replaces CoreText feature-font scanning with statically linked HarfBuzz 14.5.0. The resource index reads GSUB lookup widths, nested lookup references, GDEF filtering data, FeatureVariations replacements and AAT chain feature masks. Execution covers all GSUB lookup types and morx/mort state machines; Unicode preparation, clusters and positioning come from the same engine. CoreText remains the font-table and drawing API; native TextKit remains responsible for the multi-character layout.

Each paragraph is one model query. Additional GSUB windows are derived from lookup context; AAT windows stay inside unsafe-to-break dependency islands. Default execution, each feature/selector value and every FeatureVariations record contribute options. Optional setting combinations are not exhaustively enumerated. Axis changes preserve the discovered GIDs and order, only rebinding fonts and literal positions. Literal layout removes substitution tables and verifies that positioning does not change the selected sequence.

The replacement also fixes related data loss: multi-GID seeds now execute as complete sequences and expand into per-GID NSGlyphInfo runs in the private display string; their hit map still points to the original input. Activating a multi-GID result preserves the sequence. Zero-output substitutions have an explicit empty row. Equal output GIDs with different ligature source spans remain distinct from each other and from the final character's base.

CLI verification includes explicit-format original fixtures for GSUB 1/2/3/4/5/6/7/8, nested alternate values, filtering flags, mark sets, mark attachment classes, three FeatureVariations records, variable advances, both static and multi-VF TTC resources, and malformed tables. morx/mort each exercise rearrangement, contextual substitution, ligature, noncontextual substitution and insertion. Model checks cover repeated text, supplementary UTF-16, combining marks, edits, clear/restore, axis rebinding and shared output GIDs. Display-data checks inspect actual CoreText output and the source map without creating a window or NSApplication.

The requested installed fonts are checked directly: ThemeX Hiragino Sans alternates, LucidaSubmono contexts, and Zapfino's morx ligatures. Representative whole-sequence GIDs agree with the independent CoreText CLI oracle. Actual Futura100CHI-Var FeatureVariations are additionally checked. Old-vs-new per-group GID/range comparison on Hiragino `邊`, Lucida `Objective-C`, Zapfino `ffi fi st`, and a plain 26-letter fixture loses no options. Model query counts change 65→11, 38→6 and 351→27 respectively. Query reduction does not imply every short case is faster: an early cold Zapfino run took roughly 34 ms versus 17 ms in Old.

Measured CLI examples before GUI validation: 1000 distinct characters in a plain fixture completed in about 80 ms; 190 Lucida characters about 1.3 s; 105 Zapfino characters about 0.2 s. These are model/engine measurements, not app end-to-end timings, and remain font dependent. Pathological AAT state machines can make an entire run interdependent; there is no arbitrary context cutoff.

All GUI/visual acceptance remains with the user. Horizontal/vertical TextKit rendering, wrapping, click selection, VF selection retention and Popover interactions were not exercised by automation.

**本次决策：** 用户保留原 Glyph Atlas 工作目录自行修改，实验只在 GSUB 副本进行；Old 保持复制时状态供后续三方合并。后来明确加入 morx/mort 支持。没有对原目录回写，也没有推送远端。


Final CLI record for this experiment: 331 engine/resource assertions, 27 model assertions and 7 seed-display data assertions passed. Forty original fixture fonts passed AddressSanitizer and UndefinedBehaviorSanitizer. Thirteen localization catalogs and README Help remained consistent. Universal arm64/x86_64 compilation produced no warnings, minimum deployment target is macOS 12.0, and the clean ZIP extraction passed strict code-signature verification. Runtime CLI checks ran on arm64; x86_64 was compiled but not executed. Old's 81 baseline files were checked byte-for-byte unchanged.


## 2026-10-25 — Strip unused HarfBuzz code from the release（过时，HarfBuzz 分支未采用）

Keep HarfBuzz in its upstream single-translation-unit amalgamation and compile it with size optimization, full LTO, function/data sections and hidden inline visibility. The app participates in LTO and links with dead stripping; release local symbols are removed. The shaping configuration is unchanged. This reduces the unsigned universal link output from 3,766,992 to 1,899,136 bytes (49.6%) and the ZIP from 1,727,167 to 1,173,542 bytes (32.1%). The two native executables are 883,328 bytes for arm64 and 1,000,112 bytes for x86_64. Before local-symbol removal, unused Math, Meta, buffer-serialization, face-builder and style entry points were already absent, confirming actual unused implementation removal. Link maps and before/after measurements remain under `.build/`.

The use of HarfBuzz is an implementation choice, not a requirement for Glyph Atlas. The old parser can be extended into a dedicated GSUB/AAT interpreter; doing so transfers lookup execution, state-machine handling, source tracking, malformed-table handling and compatibility maintenance to this project. Our own discovery policy, range/index/cache logic and FeatureVariations union remain separate from HarfBuzz's shaping execution.

The signed executable in the delivered app is 1,950,048 bytes; this includes the final signing data. All 331 engine/resource, 27 model and 7 display-data assertions passed with the optimized CLI build. Both release architectures compiled without warnings; no GUI or ZIP extraction checks were performed for this change.


## 2026-10-25 — Self-written GSUB/AAT branch and literal neighbor queries

Work is isolated on local `experiment/self-written-substitution`, based on `73a999d`. The preceding HarfBuzz implementation remains on `experiment/gsub-aat`. This branch removes its vendored source, compilation and license-copy path. No changes were pushed or copied into the user's active project or Old.

The new C++17 core separates checked immutable byte views, cmap/GDEF, OpenType programs, GSUB execution, AAT execution, glyph/source tracking, variation data and positioning. Objective-C++ adapts selected-resource table bytes and native CoreText advances. System ICU supplies Unicode properties and bidi levels. There is no production CTLine/CTRun discovery or external shaping engine. All code participates in size optimization, LTO and dead stripping.

GSUB lookup types 1–8, all contextual formats and nested length-changing actions execute in our interpreter. AAT supports both morx/mort and all legal substitution types, including all 16 rearrangement verbs and end-of-text mark/ligature/insertion actions. GSUB discoveries keep the union of all FeatureVariations branches; axis changes rebind native metrics and positioning without rescanning or changing literal selections.

The user's additional requirement is implemented through the full data path: a selected unencoded GID participates in paragraph discovery with its neighbors. Text, relative source ranges and complete selected GID sequences define query/cache identity. A selection change with unchanged text schedules the affected paragraph; stale work from an earlier GID cannot populate the new query. When one part of a multi-GID seed ligates with a neighbor, overlapping sources form one atomic candidate and preserve the surviving GIDs. No Unicode placeholder or temporary cmap is needed.

`GADisplayGroups` now builds the same row data for the UI and CLI tests, independently of windows. The old exclusion of any ligature intersecting a selection has been removed. New combinations crossing a selected source and contextual changes on the selected glyph itself appear in the list. Only identical output/source identities are deduplicated; CoreText's old reachability is not a display filter. Optional feature settings remain individually enumerated; this is not an exhaustive Cartesian product of every glyph alternative and feature combination.

Validation: 331 engine/resource assertions, 373 additional layout assertions, 46 model assertions and 7 display-data assertions passed. Pure C++ checks include 31,756 assertions over 24,731 truncated/mutated table executions. AddressSanitizer and UndefinedBehaviorSanitizer passed 103 self-generated fixture fonts and the literal-neighbor row path. The requested Hiragino Sans, LucidaSubmono, Zapfino and actual Futura FeatureVariations samples pass. An additional 147 same-resource real-font strings agree with CoreText; one Lucida case that invokes another font's fallback is excluded from that comparison. A separate earlier 148-string comparison with the saved HarfBuzz executable had no GID differences. The original CoreText scanner comparison loses no options on the recorded samples; it is a regression oracle, not an output filter.

Performance findings: reverse alternate-family lookup is indexed once per resource rather than scanning all alternate sets on every query. The Hiragino 60-character example improved from about 2.3 seconds in the initial own-engine draft to about 107 ms. Query identities are immutable and cached per subitem, avoiding repeated allocation during queue completion. Current CLI model examples: 1,000 distinct plain characters about 74 ms, 190 Lucida characters about 80 ms, and 105 Zapfino characters about 218 ms. These are font-dependent model timings, not GUI end-to-end measurements.

Universal arm64/x86_64 builds complete without warnings, targeting macOS 12.0. Final unsigned universal link output is 1,027,776 bytes, signed app executable 1,078,688 bytes, and ZIP 706,289 bytes. The previous optimized HarfBuzz branch measured 1,899,136 / 1,950,048 / 1,173,542 bytes respectively. Both linker maps and exported symbols contain no HarfBuzz. Old's 81 baseline files remain byte-for-byte unchanged.

Runtime tests ran on arm64; x86_64 was compiled only. No GUI, NSApplication smoke test, app launch, installation or ZIP extraction verification was performed. GUI acceptance remains with the user. Full specialized script shaping and advanced positioning formats have explicit limits in GLOSSARY; supported lookup types are not a claim of complete HarfBuzz behavior equivalence.


## Context-independent glyph candidates and sidebar fixes — 2026-10-25

A GSUB catalogue now follows feature-reachable lookup actions for each queried input GID, across every FeatureVariations branch. Context actions retain the affected input position: LucidaSubmono `W` lists `W.w0` and `W.w1` without typing `i`, with `calt` provenance, and excludes the neighboring `i.t1`. Literal unencoded seeds use the same catalogue. Potential single-glyph candidates keep a single source range; actual cross-character combinations still require execution against the real paragraph/selected GIDs. This is a table-edge catalogue, not general symbolic execution of every combination; complex ambiguous nested length-changing programs and AAT state machines still depend on the actual-context executor. The detailed boundary is recorded in GLOSSARY.

Default/base results retain recorded feature sources through discovery, model merging and selection display. Known tags replace synthetic `actual`, and source labels are displayed verbatim in all languages. The old `actual` localization key was removed from all thirteen catalogs. `actual` is an application fallback, never a claimed GSUB feature.

The sidebar table uses a frame-sized document view, invalidates delegate row heights after reload, realizes its last row, and uses NSClipView's own bounds constraint for scrolling. No GUI was used; the user will verify actual long-list scrolling.

CLI validation: 351 substitution/resource assertions, 373 additional layout assertions, 46 model assertions, 7 display-data assertions, and 31,751 core checks over 24,731 deterministic truncated/mutated executions. ASan/UBSan passed 103 fixture fonts and selected-GID neighbor paths; mutation tests now exercise the new catalogue too. All thirteen localization catalogs pass with 75 strings plus one plural entry. Old's 81 baseline files remain unchanged.

The universal release built without warnings for arm64 and x86_64 (only arm64 execution was tested). Unsigned executable: 1,044,448 bytes; signed bundle executable: 1,111,744 bytes; ZIP: 717,817 bytes. The temporary staging bundle passed strict signing verification before archiving. After copying back to this FileProvider directory, FinderInfo metadata is reattached to the loose app root and a second strict check there rejects that metadata; clearing it did not prevent reattachment. The ZIP was created directly from the verified staging app; no extraction validation was performed, as requested. No GUI, installation or push occurred.

A separate optional cleanup audit was prepared; the four items were awaiting the user's selection and were not silently folded into these fixes.


## Four approved cleanup items — 2026-10-25

The user approved all four items in the cleanup review. Removed the unused hasFeatureVariations properties/getters. The scheduler now allocates only occupied query-length buckets in ascending order, retaining in-flight identities, old-batch priority and content caches; a 10,000-character paragraph allocates two buckets rather than 10,000.

Removed OpenType::family and both duplicate feature/lookup walks in the facade. Forward single/alternate mappings and reverse alternate siblings now share the per-GID catalogue/cache. A directFamily classification preserves direct-family queries on default-shaped base GIDs without treating nested contexts as an arbitrary transitive closure. Alternate index provenance, original-input GDEF filtering and the queried sequence's other components remain intact. A previously missing sibling option on a multi-GID text seed is now consistent with literal-GID discovery.

CLI-only featureSpecifications and shapeText methods, plus their AAT source-name adapter, are conditionally compiled under GA_FONT_LAYOUT_TESTING. CLI/sanitizer builds use explicit test mode and separate object directories; release defaults to production mode. The compile configuration fingerprint also invalidates reused objects when flags/mode change. A failed configuration transition invalidates the old fingerprint before compilation. Both actual release slices lack the three removed/test-only Objective-C selectors; the CLI retains its two test interfaces. Tests/check-release.py records this artifact-level check.

Validation: 129 before/after queries lost no candidates or sources (128 unchanged, one gained the correct prefixed sibling); 352 substitution/resource assertions, 373 additional layout assertions, 52 model assertions, 7 display-data assertions and 31,755 core checks over 24,731 truncated/mutated executions passed. ASan/UBSan passed 103 fixture fonts. Same-directory release → test → release compilation correctly changed method availability. All thirteen catalogs still pass; Old's 81 baseline files remain unchanged.

Universal arm64/x86_64 build completed without warnings. Unsigned executable: 1,027,744 bytes (was 1,044,448); signed executable: 1,078,656 (was 1,111,744); ZIP: 708,137 (was 717,817). The staging app passed strict signing verification before ZIP creation. The existing FileProvider metadata behavior of the copied loose app is unchanged; the ZIP comes from the verified staging bundle. Only arm64 was executed. No GUI, installation, ZIP extraction or push was performed.

### Cleanup review detail (2026-10-25)

用户已选择“四项都清理”，以下四项均已完成。最初的候选发现、来源标签与滚动修复保存在前一提交 a031fc2；本次单独提交清理。

| 项目 | 当前证据 | 建议与验证 |
| --- | --- | --- |
| 1. 未使用的 FeatureVariations 布尔接口 | `GAFontDocument.hasFeatureVariations` 只有 getter；引擎同名 getter 也只被它转发，Sources/Tests 无其他调用。现在直接沿用所有分支的并集，不需要依据此布尔值决定重扫。 | 删除两层声明/getter；保留真实分支解析、并集与 VF 测试。低风险。 |
| 2. 按所有长度分桶的旧任务结构 | `GATextScanModel.updateText:selections:` 从 1 到段长建立空 `GATextScanGroup`；当前只产生单字和完整段落任务。`GATextScanItem` 的批次层仍供更新/复用使用，并非死代码。 | 仅建立实际存在长度的有序桶，保留短任务优先、旧任务优先、单字完成判定和缓存身份；不改成全子串扫描。验证重复文字、编辑中任务、长文本和 GID 种子。中等风险。 |
| 3. 新目录与旧 family 正向查询重复 | `relatedOutputs:` 已覆盖 feature 可达的直接 single/alternate 输出；`discoverContent` / `discoverGlyphIDs` 后面仍逐 feature/lookup 再调用 `family`。但 family 的 alternate 输出反查有独立价值，不能整段删除。 | 将正向查询与反向兄弟选项统一在同一查询入口；保留未编码 alternate 兄弟、语言分支、索引值及 GDEF 过滤。避免反查把自己的字形重新标记为替换结果。中等风险。 |
| 4. 测试接口随产品一起编译 | `shapeText:features:script:language:branch:` 和 `featureSpecifications` 只供 `Tests/GSUBCLI.m` 调用；release 也编译这些 Objective-C 方法。不能假定 dead stripping 会删除可被 runtime 发现的方法。 | 把 CLI 适配放在明确测试构建条件下；保留其共用执行核心、定位、诊断和独立 CoreText oracle。风险较低，但会增加构建条件，收益需看最终二进制。可晚些处理。 |

没有发现生产 Sources 中残留 CTLine/CTRun 扫描或 HarfBuzz 调用。Tests 中的原生排版比较是独立验证工具，应保留。字体程序缓存、每 GID 目录缓存、模型范围绑定缓存承担不同工作，不能只因都叫 cache 就合并。

旧 README 的历史章节仍引用旧方法和旧架构，当前架构位于 GLOSSARY 后部。历史记录不建议批量删除；可以另作一次文档整理，不混入本次代码清理。

#### Completion results

1. 删除 `GAFontDocument` 和 `GASubstitutionEngine` 的 `hasFeatureVariations` 两层接口；VF 分支解析和所有条件候选并集保留。
2. 调度器只建立实际所需长度的分组并升序排列。10,000 字的单段只建立 1 和 10,000 两个桶；编辑仍保留进行中对象/旧批次优先，段落缓存复用不变。
3. 移除 `OpenType::family` 及 facade 的逐 feature/lookup 重复遍历。直接输出、未编码 alternate 兄弟的反查统一到 `relatedSubstitutions` / `relatedOutputs:` 及每 GID 缓存；明确标记 directFamily，使默认 shaping 后的查询不会误作任意上下文传递闭包。反查仍只作用于 feature 根的 alternate 索引，并检查原始输入的 GDEF 过滤、保留 alternate 索引且排除自身。
4. `featureSpecifications` / `shapeText:...` 和对应 AAT source-name 适配只在 `GA_FONT_LAYOUT_TESTING=1` 中编译。CLI/sanitizer 显式使用 test 构建及独立物件目录；release 默认为 0。编译配置指纹防止同一物件目录切换模式时复用旧物件；失败的配置转换不会留下有效旧指纹。最终两个架构均未包含上述 Objective-C selectors；CLI 保留测试接口。

清理前后 129 组 fixture、字面种子和真实字体查询无候选/来源丢失。128 组完全一致；另一组 alternate.ttf 多 GID 文本种子 [9,19] 新增 [9,18] 兄弟候选（保留前缀），与字面 GID 查询一致，已补回归测试。

CLI 验证现为 352 个替换/资源断言、373 个布局断言、52 个模型断言、7 个显示数据断言、31,755 个 core checks/24,731 次变异执行；ASan/UBSan 103 个字体通过。构建模式还验证了同一物件目录 release → test → release，最终产物检查入口为 `python3 Tests/check-release.py`。没有运行 GUI、安装或 ZIP 解压验证。

## Contextual forms versus ligatures — 2026-10-25 user clarification

Only the queried glyph's contextual forms should appear without typing their surrounding context. Ligatures require the complete consumed input sequence. Removed type 4 output enumeration from the per-GID catalogue, including extension and nested-context calls; actual GSUB/AAT execution continues to discover matching ligatures with complete source ranges. No glyph-name or feature-tag heuristic is used. LucidaSubmono W still lists its W.w0/W.w1 calt forms without i; Zapfino f/i alone do not list fi, while fi input does. Literal and unencoded GID seeds obey the same rule.

Added CLI tests for incomplete/complete direct and extension ligature input, AAT morx/mort fi, literal GID sequences, and actual Zapfino. A pure-core test constructs a contextual root calling a nested ligature, proving single-glyph catalogue exclusion while complete input still executes. Model checks again require no ligature candidate at all before selecting the necessary unencoded input; the earlier weaker combination-only helper was removed.

Validation: 378 substitution/resource assertions, 373 layout assertions, 52 model assertions, 7 display-data assertions, 31,759 core checks and 24,731 deterministic mutations passed; ASan/UBSan passed 103 fixture fonts. Thirteen localization catalogs and the release-selector audit pass. Universal arm64/x86_64 build has no warnings; unsigned executable 1,027,744 bytes, signed 1,078,656 bytes, ZIP 707,818 bytes. Staging-signature verification passed; the ZIP comes directly from staging. No GUI, installation, extraction check or push was performed. The four approved cleanup items remain complete in fbf61ae; the clarification is a separate following commit.

### VF numeric field width (2026-10-25)

The user increased the fixed numeric field width from 66pt to 70pt. No other behavior changed. Built and packaged only; no tests or UI verification.

### VF spacing adjustment (2026-10-25)

Set the toolbar stack spacing between the Variable button and font name to 0pt. There is no separate NSStackView spacing for glyph names; their existing constraints are unchanged. Reduce the bottom whitespace inside the variation-axis scroll document by 18pt, through the last row's bottom-margin constraint so the content fitting height shrinks accordingly. Built and packaged only, without tests or UI verification.

### VF zero vertical spacing (2026-10-25)

Set both the numeric-field-to-slider vertical spacing and the slider-to-next-axis vertical spacing to 0pt, replacing their previous half-system-spacing constraints. Other spacing remains unchanged. Built and packaged only; no tests or UI verification.

### VF fractional system spacing (2026-10-25)

Set numeric-field-to-slider, slider-to-next-axis, and scroll-document-top-to-first-axis spacing to 0.25 times system standard spacing. Set last-axis-to-document-bottom spacing to 0.5 times system standard spacing, replacing the previous bottom margin minus 18pt. Horizontal margins and the preset popup top reservation are unchanged. Built and packaged only, without tests or UI verification.

### VF document edge margins (2026-10-25)

Set the first axis top to the document layoutMarginsGuide top minus 10pt, and the last axis bottom to its bottom plus 10pt, reducing both system document edge margins by 10pt. The two internal vertical gaps remain 0.25 times system standard spacing. Built and packaged only, without tests or UI verification.

### VF bottom and toolbar spacing (2026-10-25)

Reduce the last-axis-to-document-bottom gap to the system bottom margin minus 15pt. Restore the toolbar stack spacing between the Variable button and font name to 5pt. Other spacing remains unchanged. Built and packaged only; no tests or UI verification.

### Independent VF button spacing (2026-10-25)

Set the font title stack default spacing to 0pt and override only the spacing after the Variable button to 5pt with NSStackView setCustomSpacing:afterView:. No additional stack or button styling is introduced. Built and packaged only; no tests or UI verification.

### Revert independent VF button spacing (2026-10-25)

The user requested the immediately previous version. Restore the font title stack spacing to 5pt and remove the custom spacing override after the Variable button. Other changes, including the document bottom system margin minus 15pt, remain unchanged. Built and packaged only; no tests or UI verification.


## Complete query pipeline, native display controls, and source consolidation — 2026-10-25

Replaced per-character/paragraph jobs and text-window rediscovery with one complete query and one publication. GSUB collects overlapping/nested matches directly; AAT enumerates productive state origins/end actions and propagates candidates through subsequent subtables. The 220-case pre-refactor comparison initially found four Zapfino misses; targeted fixes restored all outputs/sources in those four cases. Full-input discovery can still be expensive: the recorded Zapfino 105-character case rose from about 237 to 555 ms, while plain 1000 characters improved from about 78 to 21 ms. These are CLI measurements, not GUI timing guarantees.

Both native display switches default OFF (context ⌘5, ligatures ⌘6, vertical ⌘7). Context menus hide unsupported text/alignment controls. TextKit 2/NSTextView is unchanged. Click prediction executes our own rules using TextKit line boundaries, then selects by exact GID sequence plus consumed source range. Fixed NSGlyphInfo seeds remain atoms; existing vertical curly-quote overrides remain. Runtime CoreText shaping was rejected by the user and is absent from production; CLI references retain it. The quote check tests source/GID projection, not raster equivalence to a standalone vertical CTTypesetter.

Sidebar structural updates preserve the visible row anchor; width changes do not reveal old selections. All-glyph append still selects and reveals its exact result. Removed the synthetic actual fallback after it accidentally labeled every base in the unified pipeline; missing provenance is now empty, known feature/selector sources remain.

Merged the user's original VF panel changes with Old as baseline (0514c8f). Sources is flat including former FontLayout core files. GATextDisplay combines seed-display and native-font settings; GASidebarInput owns input editing/marker conversion/normalization separately from the list controller. Removed empty Vendor metadata remnants. Tests and scripts remain development/build support and are not copied into the app. This snapshot still uses a C++ core; the user subsequently requested a pure Objective-C rewrite, which follows from this checkpoint.

Targeted validation: 327 layout/hit checks (including four own-only vertical quote projection checks), 74 atomic model checks, 16 sidebar/input checks, 7 seed-display and 13 native display-setting checks; 13 catalogs with 77 strings/plural each. Earlier in this refactor, ASan/UBSan passed 103 fixtures and 31,675 core checks over 24,731 mutations; not rerun after source-only consolidation. Universal build and release-selector audit pass without warnings. Old's 81 files and original merge snapshot hashes are unchanged. No GUI, installation, ZIP extraction or push.


## Pure Objective-C core — 2026-10-25（過時，見下節「Restore C++ performance baseline and preserve Objective-C backup」）

At the user's explicit request, the complete parsing/execution core is now Objective-C. Replaced every .cpp/.mm with .m, using typed table/rule/state objects, bounded NSData views, explicit deep copies of mutable glyph items, and request-local runners. Resource parsing and shared derived caches are separated into GAFontProgram; discovery, coordinate handling and native metric adaptation remain in GASubstitutionEngine. There is no C++ facade, hidden C++ implementation, clang++ invocation or libc++ link. Simple C scalar/span/entry types remain ordinary parts of Objective-C.

Retained GSUB 1–8, contextual catalogue ownership, all FV discovery branches, morx/mort state behavior, GPOS/kerning, explicit GID seeds, atomic source ranges and native display choices. No synthetic actual label was restored. The upstream VF panel merge and flat Sources layout remain intact. Sources/GAVariationViewController.m is byte-for-byte equal to the merged original. Old's 81 baseline files and the original merge snapshot hashes remain unchanged.

Necessary checks only: 100 representative pre/post CLI cases agree on GIDs, source spans, provenance and positions; 47 core checks, 74 atomic model checks and 327 existing layout/hit checks pass. The former C++ core test is now Objective-C and preserves its binary/cmap/variation/catalogue/nested-ligature tests; full mutation remains opt-in. Quick ASan/UBSan passed 253 assertions across 220 deterministic truncated/mutated executions plus six fixture fonts and selected-GID neighbor cases. The two output reference executables live only in ignored .build; comparison requires the saved pre-port CLI, not a product dependency. No repeat of the earlier broad native-shaper differential suite or full 24k mutation matrix. Runtime checks ran on arm64; x86_64 was compiled.

The universal arm64/x86_64 release builds without warnings for macOS 12.0. Both actual slices have no libc++ dependency, C++ exception runtime imports or CLI-only test selectors. Unsigned executable: 1,303,472 bytes; signed executable: 1,370,768 bytes; ZIP: 829,006 bytes. The temporary staging bundle passed strict signing verification before packaging. Thirteen catalogs remain valid with 77 strings plus one plural entry each. No GUI, app launch, installation, ZIP extraction or push.

封存分支為 `codex/legacy/backup/objective-c-core-2026-10-25`。歷史測試及比較結果見 [objective-c-core-comparison-2026-10-25](../diagnostics/objective-c-core-comparison-2026-10-25/)。

## Restore C++ performance baseline and preserve Objective-C backup — 2026-10-25

The user reported a stall at roughly 100 characters and explicitly selected restoring the C++ core, while retaining the complete Objective-C version as a backup. The prior Objective-C rewrite is preserved in local branch backup/objective-c-core-2026-10-25 (c9788b5), plus the sibling outputs/Glyph Atlas ObjC Backup directory containing all tracked source and the original ZIP. BACKUP.json records the commit and ZIP SHA256. Backup contents and archive hash were verified without extracting the ZIP.

Current Sources exactly match a5ebe1a: C++17 parsed core, Objective-C++ adaptation, Objective-C App/UI, all flat. This keeps the original VF panel merge, complete query publication, TextKit 2 click mapping, SidebarInput/TextDisplay consolidation and empty missing-source labels. Build configuration changes now discard obsolete .o files before recompiling, so Objective-C-only translation units cannot leak into the restored C++ link.

Measured model query for Zapfino “office affine flower ” repeated five times (105 characters): the pure Objective-C version took 4379.4ms; restored C++ took 541.5ms with the same 785 variant rows. Earlier C++ measured 549.5ms on the same sample. This corrects the language-port regression; it does not resolve all long-input algorithm costs. The 420-character version exceeded a 12-second bound in both implementations. No claim that C++ alone makes every long query immediate.

Necessary validation only: 74 atomic model and 16 sidebar/input checks pass, restored-source/backup/Old hash checks pass, release selectors absent in both actual architectures. Universal arm64/x86_64 build completes without warnings. Signed executable 1079296 bytes; ZIP 712012 bytes. No GUI, native-shaper matrix, full mutation scan, installation or ZIP extraction verification. All changes and backup branches remain local.


## Native display defaults, vertical hits, and minimal row reveal — 2026-10-25

Both contextual alternates and ligatures now default ON in the main-window state and the multi-character view. Contextual alternates configure the displayed font descriptor's OpenType calt feature (kCTFontFeatureSettingsAttribute), used by NSFontAttributeName. Ligatures use NSLigatureAttributeName 0/1 on the attributed display string. TextKit 2/NSTextView remains the display engine.

Vertical text always takes the existing rule-based layout-hit path, even when both optional switches are off; this fixes the ordinary vert/vrt2 GID link previously bypassed by the base-glyph fast path. Explicit fixed-GID seeds and curly-quote display overrides are unchanged.

The user superseded the earlier scroll-unification approval with a narrower requirement. Preserve all original group scrolling and activation policies. Only after selectGlyphIDs:textRange: completes its existing group reveal, check whether the selected row's bottom is below the visible bottom and align that row bottom if necessary. No new global scrolling policy, removal of SelectedToTopIfNeeded, or anchor-refresh change is included.

Option+Enter was investigated only. The user confirmed inserting at the front or middle. Hiragino's ten-character example retains exactly 49 rows and identical GID/provenance/name/Unicode metadata after newline insertion; only source ranges shift (10 groups for front insertion, 5 for middle, 0 for trailing insertion). updateGroupsWithSameRows: rejects changed ranges. restoreScrollAnchor: then searches the old range, can resolve the preceding group, and falls back to that group's base row. The controller test double reproduced viewport y 1638 → 1330 with identical row counts and no explicit reveal; trailing insertion stayed 1638. The cause is stale source-range identity, not newly added glyphs. The user requested no fix yet, and these paths remain untouched.

Necessary checks: 20 sidebar/input state assertions, including unchanged legacy group and activation rules plus the new tall-group TextView link, pass. Existing 327 targeted layout/hit checks pass; the broad native-shaper matrix and mutation suite were not rerun. Universal arm64/x86_64 build has no warnings and release-selector audit passes. GUI behavior remains for the user to verify; no app launch, installation or ZIP extraction.


## Independent native-feature trial and range-only sidebar updates — 2026-10-25 (source only)（过时，更新请看「Native GID mapping integration and corrected menu groups」）

At the user's request, keep the native NSLigatureAttributeName channel at 1 and move both optional switches into the displayed font. OpenType fonts receive separate calt and liga/clig values. AAT fonts receive explicit ContextualAlternates and CommonLigatures selectors, selected by CTFontHasTable without reading table data. This is a trial of native-feature precedence, not a claim of verified independence on all fonts. Defaults remain ON; explicit glyph seeds and layout prediction are unchanged.

Fixed the reported unchanged-list case of Option+Enter: absolute source locations no longer force a table reload. The rebind gate still checks relative group boundaries, source text/range lengths, seed/combination/base/ligature flags and visual row metadata. It installs new source ranges and updates the selected range without selecting or scrolling. A different source/structure still triggers normal publication and existing pending activation behavior. The previous minimal TextView bottom-reveal addition is preserved verbatim.

Updated all test callers for the display-font signature and added range-shift/repeated newline insertion/removal assertions. The user explicitly deferred builds to the next round: no compiler invocation, binary test, GUI, app build or ZIP packaging was performed. Existing dist artifacts belong to the preceding revision. Source diff and SDK identifier checks only; tests are prepared, not passed.

Research on vrt2 found the current OpenType definition and first-hand 2019 reports of NSTextView/TextEdit using vrt2 in preference to vert. This is historical evidence, not a current-machine TextKit 2 verification. Existing vertical-only fixture tests cannot establish that priority; a discriminating font is needed next round. No change to the existing vrt2 prediction policy was made during this source-only round.


## Local NSTextView vrt2 discrimination — 2026-10-25

At the user's request, ran one small offscreen NSTextView/TextKit 2 probe on macOS 14.8.7 (23J520). Two original TTFs distinguish default rectangle, vert triangle and vrt2 double bars. Native line-fragment alpha masks match vrt2 when both features exist and vert when only vert exists; horizontal control retains the default. References are encoded output glyphs rendered through the same TextView path, not CoreText reconstruction. Probe/results: .build/vrt2-probe. No product source change or App/ZIP build; the earlier source-only trial still awaits its next-round validation.

### Independent GSUB/AAT test infrastructure (2026-10-25)

- The user authorized replacing CoreText single, contextual and ligature scanning entirely; AAT was first excluded, then explicitly required for morx/mort. This superseded per-logic confirmation for that experiment.
- Merge scope: replace the scanning part of `GAFontEngine.m`; merge `GATextScanModel.m` paragraph queries; keep main-window changes limited to multi-GID/delete activation; keep multi-view changes limited to multi-GID expansion and click index mapping; add `GASubstitutionEngine.h/.mm`, `Sources/FontLayout/`, `GASeedDisplay.*`, `scripts/compile-font-layout.sh` and build linkage. Do not revert later VF-panel visual adjustments.
- `Tests/Fixtures` held self-built test fonts; no installed commercial font was packaged. Regenerating fixtures needed fontTools >= 4.60.2; the local `ttx` (fontTools 3.0) was unsuitable.
- CLI checks: `bash Tests/build-gsub-cli.sh`, `python3 Tests/check-substitutions.py`, `.build/gsub-model-tests Tests/Fixtures`, `.build/seed-display-tests`, `bash Tests/check-sanitizers.sh`, `python3 Tests/check-catalogs.py`; optional `bash Tests/compare-old.sh`. Machine font paths could be overridden with `GA_HIRAGINO`, `GA_LUCIDA`, `GA_ZAPFINO`, `GA_FUTURA`. Reports were written to `.build/substitution-results.json`, `legacy-comparison.json`, `sanitizers.log` and `universal-build.log`.
- `Tests/Fixtures/multiple.ttf` reproduced one-to-many substitution: input `a`, choose the `test` row `a.alt / b.alt`, and the single and multi views show two rectangles. All glyphs in that fixture are test rectangles.
- `NSGlyphInfo.glyphID` returned 0 even for a valid override; the actual CTLine GID output confirmed it. File Provider could reattach FinderInfo/fpfs attributes to the app root, so the build assembled, signed and verified the app in a mktemp staging directory and copied it to `dist`; the ZIP explicitly carries no extended attributes. The sandbox `iconutil` false “Invalid Iconset” report was not a corrupt iconset. `.gitattributes` marked only the upstream Vendor tree as vendored.
- This copy has no `Tests/` directory; the commands and fixtures above are historical records, not runnable here.


## Per-glyph vertical fallback follow-up — 2026-10-26

Added a distinct-glyph control: vrt2 actively substitutes U+3002 but does not cover U+3001; vert covers U+3001. Native offscreen NSTextView/TextKit 2 leaves U+3001 at its default shape when vrt2 exists, whereas the vert-only control substitutes it. This disproves automatic per-glyph vert fallback for this local TTF case. The four curly quotes remain identical to a no-GSUB control in all font variants, so this probe does not justify imposing the upright-punctuation behavior on the app's manual quote compensation. No product code change; retain the existing quote rule. Raw results: .build/vrt2-probe/quote-fallback-results.json.


## Unified quote vertical-feature priority — 2026-10-26

At the user's request, general layout prediction and the curly-quote helper now share Resource::verticalFeature(branch): select vrt2 when present, otherwise vert. An uncovered glyph no longer triggers a per-glyph vert fallback. Existing AAT handling and the quote display override remain in place. A targeted command-line probe reused the four earlier TTFs and passed 40 assertions comparing helper and layout results for upright punctuation and all four quotes. Only the changed adapter and probe were compiled; no App/ZIP build or broad suite rerun. The earlier feature-switch trial and newline-preservation changes still await their deferred integrated validation.

## Core organization, localized Help and optimized icon — 2026-10-26

Moved the C++/Objective-C++ core, its headers and compile-font-layout.sh into Sources/FontLayout at the user's request; removed the now-empty top-level scripts directory and updated build/test entry points. Kept the user's current direct-to-dist build workflow and O2 preference, restoring the missing core compilation/link and retaining LTO/dead stripping.

Synchronized English README with the user's Chinese revision. All 13 locale catalogs now describe the default-enabled layout switches and variable-font panel; Help includes 13 paragraphs. Removed the Use prefix in every menu localization. Apple CoreText's local OpenType.loctable supplied the feature names; the user explicitly chose the clearer Chinese overrides 上下文替代 (Taiwan/Hong Kong) and 上下文替换 (Simplified Chinese).

Preassembled Resources/AppIcon.icns from the seven supplied size-specific PNGs without resampling. Verified all ten standard/Retina slots preserve their source bytes and that iconutil extracts ten images. Builds now copy the committed icon instead of regenerating it. Catalog/README consistency, CLI compilation and 74 model, 13 display and 29 sidebar checks passed; no App/ZIP build.

## Final icon asset — 2026-10-26

Regenerated Resources/AppIcon.icns from the user's revised size-specific PNGs. Verified all ten standard/Retina slots preserve the supplied PNG bytes and that macOS iconutil extracts ten images. Removed Resources/AppIcon after successful verification, as requested; builds continue copying the preassembled icns. Temporary 1024-only and 2318.png comparison outputs are not production assets. No App/ZIP build was needed for this asset-only update.

## Stable contextual candidate order — 2026-10-26

Reproduced LucidaSubmono Wi versus Wim changing W.w1/W.w0 row order. Candidate contents were complete, but whole-text trace results entered the result array before the context-independent catalogue. Moved catalogue insertion before whole-text matching and made the final range/base sort stable, preserving catalogue order for equal sort keys. Whole-text execution remains available for input-dependent ligatures and AAT state-dependent results; duplicate candidates still merge feature sources without moving rows.

Targeted CLI verification passed: six LucidaSubmono contexts share W, W.w1, W.w0 order; all candidate identities, source ranges and feature-source sets are unchanged across eight before/after cases including GSUB and AAT ligatures. Layout prediction for Wi and Wim remains unchanged. Only the affected adapter and CLI were rebuilt; no App/ZIP build or GitHub push in this round.

## Sidebar centering and source-aware viewport restoration — 2026-10-26

Applied the user's final navigation rule: center the whole character group, then minimally reveal the selected row at either edge. Removed the separate TextView-only bottom reveal; normal group navigation shares the same helper. The activation-only invisible-row-to-top policy is unchanged.

Refresh previously anchored only the old UTF-16 range and GID; inserting characters before it made that range identify another group. Sidebar publication now receives the snapshot's source text. It maps unchanged source spans across the common-prefix/suffix edit before restoring selection and viewport. The viewport captures visible row identities and pixel offsets, so a deleted first visible group can fall back to another surviving visible row. The existing no-reload path for identical row sequences remains in place, including range-only newline edits.

A targeted CLI build and 44 sidebar state assertions passed, including whole-group centering, top/bottom selected-row visibility, unchanged activation behavior, insertion/removal before the viewport, UTF-16 surrogate pairs and fallback after deletion of the first visible group. These use test doubles with no GUI. No App/ZIP build or push.

Investigated ThemeX Shin Go ffi without changing candidate discovery: ff (9358/9678) and fi (112/9555) remain in the inventory, while their vrt2 outputs 12874 and 8831 are absent in that input. Each appears when querying ff or fi separately. The main execution consumes ffi (9359/9679), whose vertical output 12875 is collected; alternative overlap previews collect ff/fi but do not run those branches through later lookups. This is a discovery-path limitation, not UI filtering. All four installed ThemeX TTC first resources reproduced the same ffi inventory.

## Candidate continuation and final navigation rules — 2026-10-26

The user authorized refactoring GSUB candidate discovery after reviewing the old deterministic-execution-plus-local-preview arrangement. GASubstitution now separates deterministic execution from inventory execution. Inventory carries complete candidate buffers and source ownership across lookup stages; nested lookup choices replay the entire contextual action list before producing a state. Focused branching considers the matched rule's full backtrack/input/lookahead scope, so a changed preceding candidate can enable another rule even when its output lies outside the original span. Independent character alternatives are not multiplied into arbitrary paragraph permutations. State deduplication merges feature provenance; queued glyph storage and execution use explicit budgets. The parsed tables and deterministic hit-prediction path remain shared. Existing AAT inventory was not rewritten in this GSUB change.

ThemeX Shin Go ffi now includes ff/fi/ffi vrt2 outputs (12874, 8831, 12875) with liga/vrt2 provenance. Original fixtures additionally verify nested choices followed by further parent actions, then vrt2; a chained-context fixture verifies a non-default earlier branch enabling alternative ligatures in another source span. All passed. A 100-character query measured about 0.12s for LucidaSubmono and 0.61s for ThemeX on this machine; the latter verifies all 25 occurrences of each of the three vertical ligature outputs. No native shaping oracle reruns.

Final scrolling rule supersedes the briefly considered oversized-group special case: if the entire group is already visible, do nothing; otherwise center the group, then minimally reveal the selected row (above -> viewport top, below -> viewport bottom, already visible -> unchanged). Activation's invisible-selected-row-to-top policy is unchanged. Resolve pending parent layout after resize, use the clip view's documentVisibleRect as the viewport, and convert document Y to clip Y by a delta rather than assuming equal coordinate origins. Source-aware viewport preservation remains intact.

Validation: 47 sidebar state assertions, 74 model assertions, candidate-continuation fixtures, eight candidate-content/layout parity cases and six stable-order contexts passed. An offscreen native geometry probe (no displayed windows or Computer Use) checked ThemeX group centering and the 0 base row at window heights 400/800/1000; the base row remained at the viewport top when its group exceeded the viewport. Sources built only for CLI tests; no App/ZIP build, GUI acceptance or GitHub push. Tests and handoff documents remain local and ignored as requested.

## Zoom preserves scrollbar positions — 2026-10-26

Changed Multi-Character and All Glyphs zoom to preserve normalized scrollbar positions on both axes. The capture/restore helpers share the existing bounding box geometry module and ask NSClipView for constrained scroll limits; an axis without a scroll range is represented by 0.5, so the first overflow is centered. Keyboard zoom, magnification gestures and Actual Size use the same setters. Multi-Character page-inset changes also preserve position, and its compound reset captures one outer position across resetting both text scale and inset.

Removed the obsolete onTextScaleChanged callback and centerMultiScrollOnPage helper, which forced every text zoom back to the page center. All Glyphs now captures position before changing cell size and restores it after grid reflow. Unchanged clamped scales return without relayout. The user's latest instruction is no more builds or tests; this update was reviewed in source only, with no compilation, test execution, App/ZIP build or push.

## Shared zoom-position transaction for all three views — 2026-10-26

Unified Single Glyph, Multi-Character and All Glyphs scale setters through GAPreserveScrollPosition(scrollView, changes). Capture/restore are now private implementation helpers, leaving one shared public entry point. The Multi-Character compound Actual Size reset also uses it. Single Glyph currently has no enclosing scroll view and always fits page/ink within its viewport, so it uses the centered/no-scroll fallback; its scale limits, fit rules and drawing remain unchanged. No scroll container or overflow zoom was added. Per the user's instruction, no compilation or tests were run.

## Variable button hit margin — 2026-10-26（已撤回，见下条「Reverted variable button hit margin」）

Created branch fix/variation-button-hit-area, carrying the existing uncommitted engine/navigation/zoom work. Expanded the variable-font button's click/tracking margin by 5 pt on all sides. The private window forwards mouse-down events only in that extra margin because toolbar ancestors may clip ordinary view hit testing; a private NSButtonCell supplies the corresponding native tracking rectangle. Existing button frame, intrinsic size, stack spacing, symbol and popover anchor are unchanged. The font-name field and standard close/minimize/zoom buttons take priority where regions meet. Hidden/disabled buttons do not receive the added region. No compilation, tests, packaging, commit or push was performed.

## Reverted variable button hit margin — 2026-10-26

The user reported the 5 pt experiment ineffective and requested rollback. Removed only its custom button/cell, window event forwarding and hit-region references, restoring the original NSButton. Earlier engine, sidebar and shared zoom-position changes remain intact. Kept the existing branch; no build, tests, commit or push.

> **迭代说明：** 以下 2026-10-27 工具列/Popover/焦点条目是试验记录；最终布局见 GLOSSARY §8，最终焦点行为见 §7.1。被后续条目取代的试验保留正文。

## Title toolbar glass and native Popover audit — 2026-10-27

Work continues exclusively in Glyph Atlas 2. The user's macOS 27 screenshot shows a glass capsule around the Variable button and font title. The inner NSButton already disables its border; the containing GAFontName NSToolbarItem now explicitly sets bordered to NO, following Apple's documented toolbar-glass opt-out. Button geometry, spacing and Popover anchoring are unchanged. The macOS 27 result awaits the user's friend.

The Popover's fields, popup, sliders and scroll view are standard AppKit controls, with no custom field background or cell. Retain native field rendering. Layout combines system metrics with earlier manual margin/titlebar offsets; screenshot differences alone do not establish whether those offsets need revision. No layout values or compact-control settings changed. Ask the friend to check capsule removal, button interaction, native field appearance in light/dark mode, attached/detached margins and clipping, and scrolling with more than five axes. Per the user's explicit instruction, no compilation, build, test or App operation was performed; dist remains unchanged.

## Explicit square-bezel numeric fields — 2026-10-27

At the user's request, try a native field configuration closer to the macOS 14 reference: bordered = NO, bezeled = YES, bezelStyle = NSTextFieldSquareBezel, drawsBackground = NO. This requests a square bezel without additional background-color drawing; the OS still controls bezel rendering, so transparency and macOS 14 parity are unverified. Field width, formatting, keyboard handling and layout constraints are unchanged. No compilation, build, tests or App operation; the friend should compare focused/unfocused fields in light and dark appearances on macOS 27.

## Left-aligned title-content trial — 2026-10-27

The user requested moving the existing toolbar content as far left as possible inside its current arrangement. The stack already has zero edge padding and leading-gravity content. A private NSStackView subclass now reports an alignment rectangle excluding the native button's leading image padding, calculated from its intrinsic size, cell image rect and button alignment insets. This asks the toolbar to align the image itself at the item boundary, moving the button and font name together without a guessed fixed offset. Static-font titles retain the original alignment. Native button rendering, the 5pt gap and Popover anchor are retained; no accessory controller or event forwarding was added. No compilation, build, tests or App operation. Toolbar adoption of this alignment adjustment, clipping and left-edge clicking await the friend's feedback; the actual maximum shift has not been measured.

## Reverted left-aligned title-content trial — 2026-10-27

The user reported no effect and requested rollback. Removed GATitleStackView and restored the ordinary NSStackView, preserving the toolbar-glass opt-out and numeric-field appearance settings. Popover margins remain unchanged. No compilation, build, tests or App operation.

## Explicit Popover vertical edges — 2026-10-27

Applied the user's four-row spacing table. The preset popup now anchors directly to the content view's top with only the native title-bar reservation while attached; didDetach sets that reservation to zero. The first axis anchors directly to the scroll document's top and the last slider row to its bottom, both at zero. The scroll view still ends at the content safe-area bottom with zero extra spacing. Removed the former vertical margin offsets and partial-consumption calculation, including its obsolete previous-content-height argument/storage. Detached window height preservation, horizontal margins, 70pt fields and 0.25-system-spacing internal gaps remain. These are alignment constraints, not a claim of zero visible bezel/focus-ring clearance. No compilation, build, tests or App operation.

## Preset-to-first-axis spacing — 2026-10-27

Changed only the popup-to-scroll-view top constraint to AppKit system spacing with multiplier 0.25, as requested. The first axis remains flush with the document top, giving the requested preset-to-first-field gap. All other edge settings remain; no compilation, build, tests or App operation.

## Zero horizontal axis margins — 2026-10-27

For the user's verification, axis rows now anchor directly to the scroll document's leading/trailing edges with zero spacing instead of its layoutMarginsGuide. Removed the unused axisMargins reference. Popup horizontal margins and all other settings remain. No compilation, build, tests or App operation.

## Revised Popover margins and 4pt row gaps — 2026-10-27

Applied the user's latest two tables. Popup top and horizontal edges use the content view's layoutMarginsGuide in both attached and detached presentations. Removed custom title-bar reservation, its size estimate and the now-unused didDetach interface/call; native detachment and existing outer-window-height preservation remain. Scroll top again meets popup bottom; the first axis starts at the document's top layout margin minus 10pt. Axis horizontal edges and the last slider row's bottom use the document layoutMarginsGuide with zero added offsets. Scroll horizontal/bottom edges still meet the content safe area. Field-to-slider and inter-axis gaps are fixed at 4pt; label-to-field minimum system spacing and 70pt fields remain. No compilation, build, tests or App operation.

## Fixed 40pt axis edges — 2026-10-27

Changed the first-axis top offset to document top layout margin minus 8pt. Axis left/right edges and the final slider's bottom now inset directly from the document edges by 40pt, replacing system margins at those three edges. Field-to-slider and inter-axis gaps remain 4pt. All other settings remain; no compilation, build, tests or App operation.

## Fixed 20pt outer edges and 12pt first-axis gap — 2026-10-27

Applied the user's latest values: content-view top to popup is 20pt in attached and detached presentations; first-axis top is 12pt from the document top, following the popup; axis horizontal edges and the final slider's bottom inset 20pt from document edges. Removed the unused axisMargins reference. Popup horizontal system margins, scroll safe-area constraints and 4pt internal/inter-axis gaps remain. No compilation, build, tests or App operation.

## 18pt bottom margin and 75pt numeric fields — 2026-10-27

Changed only the final slider-to-document-bottom inset to 18pt and numeric-field width to 75pt, as requested. Other settings remain. No compilation, build, tests or App operation.

## Borderless editable numeric text — 2026-10-27

At the user's request, disabled the numeric fields' bezel and removed the square-bezel setting. Border and background drawing remain disabled. Fields remain editable with 75pt width, right alignment, number formatting and existing keyboard handling. No layout constraints changed; native intrinsic heights may differ with the new style. No compilation, build, tests or App operation.

## Restored bezel and explicit numeric-field focus — 2026-10-27

Restored the preceding square-bezel field configuration at the user's request, preserving 75pt width and current spacing. On show and native detachment, the background becomes the initial/current first responder rather than a numeric field. Root and scroll-document background views accept focus on mouse-down and continue superclass event handling. Return/Enter moves focus to the background through native end-editing validation and the existing action-on-end-editing path; Escape aborts the pending edit, restores the current coordinates and moves focus without forwarding that Escape to the transient Popover. Invalid entries retain native validation; Escape can discard them. Existing arrow-key adjustment remains. No compilation, build, tests or App operation; real focus, blank-area clicks and native background dragging await user verification.

## Minimal focus-loss requests — 2026-10-27

The user requested native default editing behavior, then clarified that focus loss is still required. Enter, Escape and background clicks now only request makeFirstResponder:nil, leaving validation and ending editing to AppKit and the existing action-on-end-editing path. Removed explicit abort/restore on Escape, background first-responder acceptance and initial-focus assignments on show/detach. Invalid entries may still prevent resignation through native validation. The square bezel, 75pt width, layout and arrow-key adjustment remain. No compilation, build, tests or App operation.

## Shared default and explicit focus clearing — 2026-10-27

The user clarified that default unfocused fields must also remain. Added one shared GAClearVariationInputFocus helper for default presentation, Enter, Escape and background clicks. It makes the background the initial responder and requests makeFirstResponder:nil; background views accept first responder status. The controller's clearInputFocus forwards to the helper and is called on show/detach and keyboard commands; blank-area mouse-down calls the same helper before superclass handling. Validation and ending editing remain native, with no explicit cancellation or value restoration. Other appearance/layout settings remain. No compilation, build, tests or App operation.

## Bounding Box terminology across all locales — 2026-10-27

At the user's request, renamed Show Metrics and Metrics Zoom In/Out to Show Bounding Box and Bounding Box Zoom In/Out, including localization lookup keys and English fallback titles. Traditional Chinese and Hong Kong use 顯示邊界框／放大邊界框／縮小邊界框; Simplified Chinese uses 显示边界框／放大边界框／缩小边界框. All 13 locale catalogs also synchronize Help.10's zoom terminology and Help.11's bounding-box/shadow description. Updated the menu/shortcut documentation. Internal metrics symbols, actual font metrics, actions, shortcuts and rendering/zoom behavior remain unchanged. Source review only; no compilation, build, tests or App operation.

## Native Popover dragging follow-up — 2026-10-27

The user reports inability to detach the new Popover on macOS 27; their local system is macOS 14. The native popoverShouldDetach permission remains enabled. As a source-based correction for possible interference from background focus handling, removed the background mouseDown override, moved its shared focus-clear call to mouseUp and explicitly return YES from mouseDownCanMoveWindow. Native press/drag processing is left to AppKit; no manual drag loop, custom detached window or event forwarding was added. Default/Enter/Escape/background focus clearing still shares the same helper. No compilation, build, tests or App operation. The cause and macOS 27 behavior remain unverified; ask the friend to check background detachment and click-to-blur together.

## Removed redundant background-drag declaration — 2026-10-27

Removed the mouseDownCanMoveWindow override at the user's request, returning to the native default. The mouseUp focus-clear change remains. No other source behavior changed; no compilation, build, tests or App operation.

## Sidebar input focus on window mouse-down — 2026-10-27

The user clarified that only sidebar text-input focus loss should use mouseDown; Popover background focus loss stays on mouseUp. Extracted the sidebar's duplicated Enter/Escape transfer into focusGlyphList. The existing GADropWindow now notifies its controller before native left-mouse-down dispatch; handleWindowMouseDown transfers focus through that same helper only while the sidebar field editor is first responder and the click lies outside the input field. In-field clicks continue editing. The original event is always dispatched through super, preserving clicked-control behavior and native dragging; another control may take focus normally. No global monitor, other-window interception or Popover event change. Option+Enter remains unchanged. No compilation, build, tests or App operation; user/friend should verify input editing, outside-click focus transfer, bounding box interactions and window/divider dragging.

## Shared glyph-list focus destination — 2026-10-27

Popover and sidebar input now share focusGlyphListFromWindow:activateWindow: as the final focus-transfer implementation. Cross-window requests first let the source field editor resign through native validation; only on success does the main window select its glyph table as first responder. Explicit Enter/Escape/background-click requests activate the main window so the list can receive keyboard input. Same-window sidebar requests use this same implementation.

Popover background mouseUp and numeric-field commands route through clearInputFocusActivatingGlyphList: and an owning-window callback to the shared method. Background views weakly reference their controller; the callback weakly references the main controller. Removed the old GAClearVariationInputFocus helper. Initial show/detachment also uses this path with activation disabled, preserving unfocused fields without immediately taking keyboard focus away from the presented Popover. Sidebar outside-click handling remains on mouseDown. Field appearance/layout, native validation, transient Popover closing policy and native detachment remain. The effect of actual cross-window focus on attached Popover visibility awaits user/friend verification. No compilation, build, tests or App operation.

## Simplified shared glyph-list focus — 2026-10-27

The user verified that native clicks already move focus between the old Popover fields and the main glyph list, and approved removing the added window-activation management. Restored focusGlyphList to one makeFirstResponder:tableView call. Removed sourceWindow/activateWindow parameters and makeKeyWindow; the Popover callback now directly requests this shared destination without arguments.

Popover clearInputFocus uses its local native end-editing helper, then calls the destination callback only if validation succeeds. Enter/Escape and background mouseUp share this path. Initial show/detachment instead calls prepareInputFocus, which keeps fields unfocused without invoking the glyph-list callback; both reuse the same local validation helper. Sidebar outside-click mouseDown, appearance and spacing remain. Normal control clicks, window activation and Popover closing/detachment stay native. No compilation, build, tests or App operation; explicit programmatic focus behavior remains for the user to verify.

## Field-owned blank-click focus routing — 2026-10-27

Applied the user's revised three rules. Removed the main window's sendEvent override/callback and the Popover background's mouse handler. GAInputFocus now attaches a shared local-event observer to the sidebar text field and each numeric field. The input owns its observer, references are weak where needed to avoid cycles, and deallocation removes the monitor. Editing state is checked on blank-area mouse-down; the matching mouse-up remains eligible even if native handling has already ended that edit. Events are always returned unchanged; interactive controls/editable text are excluded from blank-area handling, and unrelated windows are ignored.

The owning main controller routes by clicked window, regardless of the source input: main-window blank clicks focus the sidebar glyph list on mouse-down; attached/detached Popover blank clicks focus that Popover's NSWindow on mouse-up. When a source editor remains active in the other window, native resignation must succeed before the destination request. No explicit window activation or manual dragging was added. Keyboard Enter/Escape rules and initial unfocused numeric fields remain. The numeric fields currently have no explicit border/background overrides in source; this round preserves that state and the existing layout. No compilation, build, tests or App operation. User/friend should check both cross-window directions, in-field editing/control interaction and native Popover detachment.

## Restore list focus after Popover closure — 2026-10-27

Added popoverDidClose: to reuse the existing sidebar focusGlyphList method after this Popover closes. The callback checks the notification source and skips NSPopoverCloseReasonDetachToWindow so detachment does not trigger the closing focus transfer. No new focus helper or explicit window activation was introduced.

Source review confirmed shared blank-area filtering and destination routing, weak references to avoid ownership cycles, monitor removal with the input-owned observer, and unchanged native event delivery. Per-input ownership improves lifetime management and reuse; each input still has a local monitor receiving matching application events, with early returns while idle. No measured performance improvement is claimed. Updated the handoff documentation. No compilation, build, tests or App operation.

## Limit mouse monitoring to editing sessions — 2026-10-27

GAObserveInputClicks now associates an idle observer without immediately registering a mouse monitor. Thin native cell subclasses report edit/select and endEditing through the shared GAUpdateInputEditing function. A monitor is installed only after the input's field editor becomes first responder, and explicitly removed when that editing session ends. This also covers focusing without changing text. The sidebar's existing inset cell inherits the shared search-cell hooks; numeric fields use GAInputTextField and its cell. Native rendering, delegates, validation, keyboard commands and destination routing are preserved.

If a blank-area press is already pending when native mouse-down ends editing, the editing monitor is removed and a one-click completion monitor handles the matching mouse-up. It removes itself on release or cancels on the next press if native tracking consumed release; it ignores the press that created it. This preserves the existing Popover mouse-up rule across windows without retaining a permanent monitor for every idle field. Destruction still removes any remaining monitor. Source review only; no compilation, build, tests, App operation or performance measurement. User/friend should check click/Tab focus before typing, Enter/Escape and outside-click resignation, both cross-window directions, and native Popover detachment.

## Single shared mouse monitor without input registration — 2026-10-27

Applied the user's simpler request: native cells send argument-free begin/end signals. Begin installs the one application-wide local mouse monitor, or does nothing when already installed. End defers its check until AppKit completes the focus transition, then queries visible windows for a field-editor first responder and removes the monitor if none remains. No input identity, input registry, editing counter or per-input observer is retained. A pending blank-area press uses the same monitor through its release before the idle check; no second completion monitor is created.

Removed GAObserveInputClicks, associated-object ownership, input-specific mouse callbacks and both onInputMouseEvent properties. The shared monitor posts qualified blank clicks through GAInputBlankClickNotification; each main controller handles only its own main/Popover windows and removes its notification subscription on deallocation. Cross-window validation reuses GAWindowHasEditingInput through GAEndInputEditingOutsideWindow rather than retaining a source input. Original event delivery, main mouse-down versus Popover mouse-up destinations, keyboard behavior, initial unfocused state, close focus restoration, native rendering and layout remain. Source review checked the single registration site, removal/token clearing, all removed call sites, and shared begin/end hooks. No compilation, build, tests, App operation or performance measurement. User/friend should focus on rapid switching and Tab between fields, both cross-window blank-click directions, and Popover drag/close.

## Preserve sidebar input on close and localize Popover keyboard focus — 2026-10-27

Popover closure now skips glyph-list focus restoration while the sidebar input owns its window's first responder. The sidebar exposes inputFocused using its current field editor and an explicit first-responder comparison; the existing notification-source and detachment guards remain.

Enter/Escape inside the Popover now request makeFirstResponder:nil only on the Popover's own NSWindow. Removed onFocusGlyphList and its main-controller callback. Initial show/detach shares clearInputFocus directly, removing the redundant static wrapper. Native validation, sidebar keyboard behavior, shared mouse monitoring, layout and appearance remain. Source review only; no compilation, build, tests or App operation.

## Reuse the Popover focus method for mouse release — 2026-10-27

The Popover blank-click mouse-up destination now calls the existing GAVariationViewController.clearInputFocus, sharing the exact method used by Enter/Escape and initial show/detach. No new helper was added. The mouse path retains its preceding cross-window native validation. Source review only; no compilation, build, tests or App operation.

## Clarify focus names and remove unreachable cleanup — 2026-10-27

Renamed clearInputFocus to focusWindow and prepareInputFocus to prepareWindowFocus so destination names align with focusGlyphList and focusInput. Updated all declarations, implementations, call sites and current handoff references without compatibility aliases. The private application-wide monitor is now GAInputClickMonitor with sharedMonitor and handleMouseEvent; focused-input and blank-area predicates now describe what they inspect.

Removed the process-lifetime singleton's unreachable dealloc cleanup. Explicit idle monitor removal and token clearing, and each main controller's notification cleanup, remain. Reviewed the focus module and native callback entry points; retained the initial focus background view and both native cell hooks because they are still used. Confirmed no source references remain to the old focus names or previously removed input observers/callbacks. Focus behavior and timing remain unchanged. No compilation, build, tests or App operation.

## Remove mouse-release retention from monitor lifetime — 2026-10-27

At the user's request, removed the pending-press condition that kept mouse monitoring alive after editing ended. The input's end-editing signal still checks actual focus after the native transition; if no input is focused, the monitor is removed and its token and click-pair state are cleared without waiting for mouse-up. Mouse handlers no longer initiate idle checks or monitor removal. Press/release pairing remains solely to qualify blank-area clicks while the monitor is active; it does not extend monitor lifetime. The existing main-window mouse-down and Popover mouse-up destination branches remain. Source review only; no compilation, build, tests or App operation.

## Review and simplify the current focus implementation — 2026-10-27

Reviewed the recent focus/monitor module, native cell hooks, destination methods, close guard and notification subscriptions. No additional unused focus functions or legacy callbacks were found. Consolidated duplicate mouse-down/up blank-area filtering and notification posting into one path, preserving same-window press/release qualification. Removed the single-call removeMonitorIfIdle wrapper and placed its condition directly in the existing deferred end-editing block.

Retained both native cell families, the initial focus background view, inputFocused, native validation, notification cleanup and the single shared monitor because their call sites remain active. The user confirmed keeping the main-queue deferred check; clarified its comment/documentation as a later check rather than a system focus-completion notification. Monitor lifetime and focus destinations are unchanged. Source review only; no compilation, build, tests, App operation or performance measurement.

## Unify blank-click focus transfer on mouse-down — 2026-10-27

At the user's request, Popover blank clicks now use mouse-down, matching main-window timing. The shared local monitor subscribes only to left-mouse-down. Removed the mouse-up mask, pressedWindow state and press/release qualification, and the destination-dependent event-type filter in the main controller. Qualified clicks still return the original event unchanged; main clicks focus the glyph list and Popover clicks reuse focusWindow after native cross-window validation. Begin/end monitoring signals, the deferred end-editing check, keyboard and close focus rules remain.

The user suspects that using a local monitor instead of a background view mouseDown override avoids the macOS 27 detachment conflict. This is unverified; the friend should check native Popover detachment while a numeric field or the sidebar input is focused, plus ordinary blank-click focus transfer. Source review only; no compilation, build, tests or App operation.


## Vietnamese and Thai localization — 2026-10-27

Replace the Arabic localization with Vietnamese and Thai, bringing the declared locales to 14. Both new catalogs include all 78 current UI strings, 13 Help paragraphs, Finder document-type text, About copyright and the collection-font plural message. Standard commands and OpenType feature labels use the machine's Apple localization resources; application-specific text follows the current English catalog, including Bounding Box terminology and existing shortcuts. Vietnamese and Thai use the other-only plural category.

Catalog syntax, key coverage, Help shortcut sequences and format placeholders were checked. No App build, packaging or GUI validation. This resource update does not include any of the previously discussed feature-switch implementation changes.


## AAT display switch trial in a writable copy — 2026-10-27（过时，菜单分组已更正；见「Native GID mapping integration and corrected menu groups」）

Created a complete writable copy in this chat's outputs/Glyph Atlas 2. The original source/resource/document files were hashed before changes and remain untouched. Applied the previously prepared localization update here: ar is removed, vi/th are installed and CFBundleLocalizations declares 14 locales.

Native display now uses AAT feature selectors for every font. Per the user's explicit assignment, the Contextual Alternates menu controls all eleven type-1 ligature categories (Required, Common, Rare, Logos, Rebus Pictures, Diphthong, Squared, Abbreviated Squared, Symbol, Contextual and Historical); the Ligatures menu controls the three type-36 alternate categories (Contextual, Swash and Contextual Swash). A disabled group adds its Off selectors. An enabled group omits all of its selector settings, preserving font defaults rather than forcing features on. The old OpenType calt/liga/clig display-setting branch and explicit NSLigatureAttributeName attribute are removed. No All Typographic Features master switch is set.

Scope: display font settings only. The existing own-engine sidebar hit prediction, including its previous feature policy and both-disabled fast path, is unchanged while direct native GID retrieval is being discussed. It may disagree with this trial's native display controls; do not claim that side-bar mapping has been synchronized. TextKit 2 has not been replaced. No compilation, App build, runtime test or GUI acceptance was performed for this source change; dist and .build were copied from the baseline and are not new deliverables.


## 原生 TextKit 2 的必要特性及註冊特性開關測試 — 2026-10-27

macOS 14.8.7（23J520）以自製字體和去除 GSUB 的參照比對原生 `NSTextLineFragment` 的輸出。必要特性探針在 19 組案例中交叉測試 114 種設定。樣本裡拉丁文的 `rclt`、`rlig`、`ccmp`、`locl` 在連字屬性為 0 時不執行，為 1 時執行，即使明確把該 tag 設為 0；阿拉伯文的對應案例則在兩種連字設定下均執行。結果限於該版系統、測試字體和文字腳本。見 [必要特性實測](../diagnostics/textkit2-feature-probes-2026-10-27/required-feature-test-report.md)。

註冊特性探針先以 219 個 tag、438 份字體做 1,314 次橫排拉丁文渲染，按本輪範圍排除 `dlig`、`hlig`；再以其餘 217 個 tag 做 2,604 次渲染。兩種測試規則是上下文單字替換與連字，兩者得到相同的逐 tag 開關矩陣。這是原生顯示的歷史測量，產品程式當時沒有改動。見 [註冊特性總表](../diagnostics/textkit2-feature-probes-2026-10-27/feature-switch-total-table.md)。

## Native TextKit 2 private GID readback research — 2026-10-27

2026-10-27；本機 macOS 14.8.7，Build 23J520。這是獨立原生 NSTextView 探針的結果；後續已接入產品，見本條目末尾的接入狀態。macOS 27 仍未驗證。

### 已確認的入口

| 類別 | 私有 selector | 本機 runtime 型別 |
| --- | --- | --- |
| NSTextLayoutManager | requiresCTLineRef | `B16@0:8` |
| NSTextLayoutManager | setRequiresCTLineRef: | `v20@0:8B16` |
| NSTextLineFragment | lineRef | `^{__CTLine=}16@0:8` |
| NSTextLineFragment | numberOfGlyphs | `Q16@0:8` |

`lineRef` 回傳該 line fragment 已持有的 CTLine，無需自行 CTLineCreateWithAttributedString。由此接公開的 CTLineGetGlyphRuns、CTRunGetGlyphs、CTRunGetStringIndices、CTRunGetPositions 及 CTRunGetAttributes，即可拿到原生排版 GID、UTF-16 索引、位置和每個 run 的實際字體。它不是從 Unicode 重新查 cmap，也不是重新套用自己的 GSUB 規則。

TextKit 2 預設可能採用簡單文字的 glyph buffer 路徑，該 line fragment 的 lineRef 為 NULL。私有 requiresCTLineRef 在本機預設為 NO；設為 YES 後重建排版，測試中的所有 line fragments 均有 CTLine。全程未讀取 textView.layoutManager。

最小流程（私有方法僅作研究示意，尚未加入產品）：

```objc
@interface NSTextLayoutManager (PrivateGlyphReadback)
@property BOOL requiresCTLineRef;
@end
@interface NSTextLineFragment (PrivateGlyphReadback)
@property(readonly) CTLineRef lineRef;
@end

NSTextLayoutManager *manager = textView.textLayoutManager;
manager.requiresCTLineRef = YES;
// 若已完成排版，只改旗標不會更新舊 fragment：
[manager invalidateLayoutForRange:manager.textContentManager.documentRange];
[manager ensureLayoutForRange:manager.textContentManager.documentRange];
// 枚舉 manager 的現有 layout fragments / textLineFragments：
// CTLineRef line = lineFragment.lineRef;
// CFArrayRef runs = CTLineGetGlyphRuns(line);
// 逐 run 讀 CTRunGetGlyphs / CTRunGetStringIndices / CTRunGetAttributes。
```

正式整合需檢查 selector 存在與方法簽名。lineRef 是借用引用；同步複製所需資料，或在跨生命週期保存時自行管理 CF retain。不要硬編碼 ivar offset，也不要把 NSGlyphInfo seed 或缺字當成一般一字符一字形。

### 原生測量結果

共 18 個隔離 TextView 案例，包含「长沙」四種菜單組合、拉丁連字、軟換行與第二段、fallback 字體與 emoji、豎排標點、明確 NSGlyphInfo GID seed；各比較原生預設與 requiresCTLineRef=YES。

- 18 個案例結束時皆保持相同 TextKit 2 manager，TextKit 1 切換通知總數為 0。
- 啟用旗標後共 14 個 line fragments，全部能讀取 CTLine，其 glyph count 與 line fragment 一致。
- 14 對 line fragment 的原生繪圖，在啟用旗標前後皆有相同的裁切二值 alpha 遮罩、尺寸和墨跡量。這是測試案例的結果，不是所有字體的普遍保證。
- 13 個橫排 fragments 的 CTLine 直接繪圖與 NSTextLineFragment 原生繪圖也有相同的上述遮罩。
- 豎排可讀取 GID，且旗標前後原生繪圖一致；探針的簡單 CTLineDraw 座標轉換未重現 TextKit 的豎排繪圖，兩者遮罩不同。不能宣稱已驗證豎排繪製／點擊幾何完全等價。
- fallback run 保留實際字體：Times-Roman、STSongti-TC-Regular、AppleColorEmoji。GID 必須連同 run 字體辨識，不能全部當作文件字體的 GID。
- 第二段的 run 索引重新從 0 開始；同一段的軟換行 run 索引延續該段。需加上 fragment 的內容起點，再套用產品現有 display-to-source 索引表。不能再多加 line.characterRange.location。
- NSGlyphInfo 明確指定的 Wing-OPPO GID 37310 仍可在 CTLine 中讀到。

快取測量的 lineRef 存在順序：預設 NO → 改 YES 但未 invalidation → invalidation 後 → 改 NO 但未 invalidation → 再 invalidation，分別為 `NULL、NULL、非 NULL、非 NULL、NULL`。各步原生繪圖遮罩相同。

### Wing-OPPO 與現有 AAT 開關

使用的顯示字體設定 helper 直接擷取自本副本 Sources/GATextDisplay.m，沒有另寫一份不同的開關規則。

| 上下文替換菜單 | 連字菜單 | 「长」GID | 「沙」GID |
| --- | --- | --- | --- |
| 省缺 | 省缺 | 37310 | 13966 |
| 省缺 | Off | 37310 | 13966 |
| Off | 省缺 | 37310 | 13966 |
| Off | Off | 37310 | 13966 |

這表示目前的 AAT selector 組合，在此字體及本機 TextKit 路徑上仍未關掉「长」的 ccmp 替換。直接讀 GID 能解決側欄誤判顯示結果的問題，本身不會改變哪些替換被啟用。

### 另一條找到但不建議優先整合的路徑

runtime 中也有 `_glyphs`、`_advances`、`_glyphCount`、`_font` ivars。當 lineRef 為 NULL 時，實測 `_glyphs` 已含真實替換結果，例如「长沙」為 37310、13966。

但 Times 的 `office ffi AV` buffer 有 13 個槽，其中兩個是 65535 佔位；完整 CTLine 實際只有 11 個 glyph。不能把 buffer 長度、numberOfGlyphs 或每個槽直接當作最終 GID／cluster。以 requiresCTLineRef + lineRef 取得完整 runs，能避免依賴這些結構細節。

### 對產品的含義

這提供了保留 TextKit 2、直接讀取其原生排版結果的可行實驗入口。可取代 GAPredictDisplayGlyphRuns 裡自己決定顯示字形的部分；仍需處理來源範圍、連字 cluster、fallback 字體與現有明確字形種子對應。候選清單的發現不因此自動被取代。

產品 Sources 本輪未修改。未構建 App、未打包、未做完整介面驗收；macOS 27 私有 selector 的存在與行為仍待該系統驗證。

### 探針與重現

所有探針保存在本專案 `.build/private-textkit2-probe/`：

- Runtime.m / runtime-dump.txt：類別、ivars、方法及型別。
- GlyphReadback.m / glyph-readback.json：完整原生讀取與遮罩資料。
- DisplaySettings.m：本輪擷取的產品顯示設定 helper。
- CacheProbe.m / cache-results.json：同一 TextView 的旗標／快取測量。
- verification-summary.json：斷言通過的摘要。

在該資料夾編譯獨立探針（不是 App build）：

```sh
clang -fobjc-arc -framework Cocoa -framework CoreText Runtime.m -o runtime-probe
./runtime-probe > runtime-dump.txt
clang -fobjc-arc -framework Cocoa -framework CoreText GlyphReadback.m DisplaySettings.m -o glyph-readback
./glyph-readback > glyph-readback.json
clang -fobjc-arc -framework Cocoa -framework CoreText CacheProbe.m DisplaySettings.m -o cache-probe
./cache-probe > cache-results.json
```

公開 API 的邊界仍如 Apple 在 [WWDC22](https://developer.apple.com/videos/play/wwdc2022/10090/) 所述：TextKit 2 不公開 glyph API。本報告的新發現是本機 runtime 的私有入口，並非 Apple 對這些 selector 的支援承諾。


### 後續產品接入狀態 — 2026-10-27

使用者已授權實作 1–3：現已在產品 TextView 建立時開啟 requiresCTLineRef，並於排版刷新後讀取 GID／字符索引，供點擊映射使用。沒有收集 run 字體資訊。舊預測、兩層 layoutRunsForText、預測用 pins 及 both-off 本項捷徑已刪除。

同時更正菜單分組：上下文替換控制三種 Contextual/Swash Alternates，連字控制十一種 Ligatures；開啟仍省缺。上文四種開關表是更正分組前的歷史探針結果，不能當成本次改碼後的測試。

本次接入未編譯、未構建、未執行測試，交由使用者驗證。先前「產品尚未接入」的描述是研究當時狀態，已由本節取代。ccmp 關閉與 WebKit 研究留待後續。

## Native GID mapping integration and corrected menu groups — 2026-10-27

The multi-character TextView now requests CTLine retention at creation. Every layout rebuild reads native GIDs and character indices into the source-range hit list; clicks use that saved result. Run font information is intentionally not collected, following the existing missing-character filter and the user's requested scope. Explicit GID display seeds retain their source-index and atomic-range mapping.

Removed the display GSUB/AAT prediction helper, its two facade methods, lazy click-time resolution, seed prediction pins, and the both-menu-items-off shortcut. Native run indices and boundaries define clusters, with source mapping preserving composed characters and explicit multi-GID selections. Candidate discovery and vertical display substitutions remain in use.

Corrected the user's earlier reversed grouping: Contextual Alternates now controls the three contextual/swash alternate selectors, and Ligatures controls the eleven ligature selectors. Enabled still omits feature settings; disabled sends Off selectors. No NSLigatureAttributeName was reintroduced.

Source/diff/call-site review only: no compiler, build, probe execution, packaging or App test in this integration turn. The user will test items 1–3. Item 4 (ccmp, possible undocumented Required Alternates and WebKit implementation) remains pending.

## Native GID cleanup after readback integration — 2026-10-27

本輪只做來源／呼叫關係覆核，使用者自行測試，不編譯、不構建。

- 刪除 GAPredictDisplayGlyphRuns 及 GAFontDocument/GASubstitutionEngine 的 layoutRunsForText 聲明、轉發與自行 shaping 實作：唯一產品呼叫已被原生 CTLine 讀取替代。
- 刪除點擊時的 resolvedGlyphHits 延遲計算，以及兩個開關同時關閉便強制回本項的分支；glyphHits 於每次排版刷新時重建。
- 刪除 displayGlyphSelections、pins、為預測而建立的 GAGlyphSelection／components；NSGlyphInfo 顯示、displaySourceIndices 和種子原子範圍仍有用途，保留。
- 移除 GAMapGlyphLayoutRuns 進入時多餘的排序，沿用 MergeHits 的範圍排序並保留原生 glyph 次序；GATextDisplay 不再依賴 GAFontEngine。
- normalizedCoordinates、clusters、AAT::applyFeatures、verticalFeature 仍供候選發現、定位或豎排顯示使用，沒有因移除一個呼叫就刪除共用核心。

## User verification and separate ccmp investigation — 2026-10-27

The user reports no apparent issues after manually testing the native-GID mapping, cleanup and corrected menu groups. No further production source edits followed that handoff. The conditional ccmp experiment branch has not been created because no working independent switch has been found. Failed candidates are confined to diagnostics/ccmp-control; see the ccmp control research entry below for measured negative results, pinned WebKit sources, local feature-map evidence and unresolved scope. Only isolated research probes were compiled/executed; no App build.

完整的 ccmp 负结果、WebKit 来源和 CoreText 内部证据见下一条目。

## ccmp control research — 2026-10-27

2026-10-27；macOS 14.8.7，Build 23J520。

使用者已回報前三項整合手測未發現問題。最新要求為：找到有效 ccmp 方法後才建立分支、修改產品，不 build。本報告記錄第四項的隔離研究，沒有將失敗的設定加入產品，也尚未建立該實驗分支。

### 已測的候選

33 種設定組合，六個字體案例：Wing-OPPO、拉丁 ccmp context／compose／decompose，以及 calt／liga 對照。每組比較原生 TextKit 2、直接 Core Text、套用 WebKit CompositionLanguage=None 段落設定的 Core Text，共 594 次排版 GID 讀取。不是產品 App 測試，也不是 Safari 介面測試。

| 候選 | 本機結果 |
| --- | --- |
| 猜測 Required Alternates：type 36，selector 6／7 | 未關掉 ccmp；這兩個數值沒有被確認為有效私有定義 |
| Contextual Alternates Off：36／1 | 可關掉 calt 對照；不關 ccmp |
| Required Ligatures Off：1／1 | 不關 ccmp |
| Common Ligatures Off：1／3 | 可關掉 liga 對照；不關 ccmp |
| All Typographic Features Off：0／1 | 在這些 GSUB 字體案例中沒有關掉 ccmp，亦未關掉 calt／liga 對照；不能把 AAT morx 規範的 master-off 行為直接推廣到這個 OpenType 路徑 |
| Unicode Canonical／Compatibility／Transcoding Composition Off | 不關 ccmp |
| Linguistic Rearrangement Off／Diacritics 候選 | 不關 ccmp |
| OpenType ccmp=0 字典、平面寫法、巢狀 pair | 不關 ccmp |
| WebKit 使用的 CTFontCreateCopyWithAttributes 路徑 | 不關 ccmp |
| 私有 NSCTFontFeaturesInternalAttribute、CTFeatureSetting 物件及混合 AAT／OpenType 字典 | 試過的組合不關 ccmp |
| 指定額外 Required Alternates feature metadata | 試過的組合不關 ccmp |

四個 ccmp 案例在全部 33 組設定下均維持：

| 案例 | 讀到的 GID | 若取消該替換應回到的本項 |
| --- | --- | --- |
| Wing-OPPO「长沙」 | 37310、13966 | 24430、13966 |
| Latin context「ab」 | 1、4 | 1、2 |
| Latin compose「ab」 | 5 | 1、2 |
| Latin decompose「a」 | 2、3 | 1 |

已知 calt／liga Off 對照有作用，故不是所有 feature 設定均被測量工具忽略。三種被測排版入口的 GID 也一致。

### WebKit 來源追蹤

固定閱讀 commit `866f81b6b915730b1d136aa8c8b2cf5b4e239e9c`，以下檔案完整保存於 diagnostics/ccmp-control/webkit/，保留原授權頭：

- [UnrealizedCoreTextFont.cpp](https://github.com/WebKit/WebKit/blob/866f81b6b915730b1d136aa8c8b2cf5b4e239e9c/Source/WebCore/platform/graphics/cocoa/UnrealizedCoreTextFont.cpp)：appendOpenTypeFeature／applyFeatures 將 tag、value 放進 kCTFontFeatureSettingsAttribute，realize 使用 descriptor 建立或複製字體。所查到的這段程式沒有 Required Alternates 私有 selector。
- [ComplexTextControllerCoreText.mm](https://github.com/WebKit/WebKit/blob/866f81b6b915730b1d136aa8c8b2cf5b4e239e9c/Source/WebCore/platform/graphics/coretext/ComplexTextControllerCoreText.mm)：複雜排版使用 CTLineCreateWithUniCharProvider 或 CTTypesetterCreateWithUniCharProviderAndOptions；不是 NSTextView。支持 AAT 字體不等於此處提供 ccmp 的獨立開關。
- [SimpleFontDataCoreText.cpp](https://github.com/WebKit/WebKit/blob/866f81b6b915730b1d136aa8c8b2cf5b4e239e9c/Source/WebCore/platform/graphics/coretext/SimpleFontDataCoreText.cpp)：getCFStringAttributes 使用 CompositionLanguage=None。已將這個段落設定加入隔離 Core Text 對照，仍未關掉 ccmp。
- [CoreTextSPI.h](https://github.com/WebKit/WebKit/blob/866f81b6b915730b1d136aa8c8b2cf5b4e239e9c/Source/WebCore/PAL/pal/spi/cf/CoreTextSPI.h)：列出 WebKit 使用的私有 shaping／provider 入口；所查到的宣告沒有名為 Required Alternates 的特性開關。
- [FontCoreText.cpp](https://github.com/WebKit/WebKit/blob/866f81b6b915730b1d136aa8c8b2cf5b4e239e9c/Source/WebCore/platform/graphics/coretext/FontCoreText.cpp)：另有特性查詢、small-caps 等處理，以及字體複製使用的設定形式。沒有把這些不同用途的方法當作已證實的 ccmp 關閉方法。

此來源閱讀和隔離測量不等同於完整 Safari CSS／私有 provider 路徑的行為驗證，也不是「不存在其他辦法」的證明。

### 本機 Core Text 內部表

Exports.m 只讀取本探針行程已載入的 Core Text Mach-O symbol table、選定函數碼與靜態 feature map，沒有修改系統框架或其記憶體。找到了 kMasterFeatureMap、FindMasterFeatureMapEntry、ConvertOTFeatureToAATFeature、TFont feature 正規化相關函數。

靜態表的原始記錄如下；flags 未完整還原定義，不能單憑此欄推導所有語義：

| tag | type | selector | flags |
| --- | --- | --- | --- |
| calt | 36 | 0 | 0x2 |
| ccmp | 0 | 0 | 0xE |
| liga | 1 | 2 | 0x102 |
| locl | 0 | 0 | 0xE |
| rclt | 0 | 0 | 0xA |
| rlig | 0 | 0 | 0x8A |

ConvertOTFeatureToAATFeature 另有 ccmp 的 type 27 特殊轉換，但實際用 Canonical Composition Off 的測量仍失敗，不能把內部轉換記錄當成可用的設定開關。

### 檔案與重現

研究保存在 diagnostics/ccmp-control/，避開會被清理的 .build：

- Probe.m、results-internals.json：目前全部 33 種候選與三種排版入口的結果。
- fixtures/：本輪使用的五個拉丁合成字體及無 GSUB 參考字體；Wing-OPPO 使用本機原字體，未修改。
- webkit/：上述固定 commit 的五個來源檔。
- Exports.m、coretext-symbols.txt、feature-internals.json、function-*.asm：本機內部表與唯讀反組譯證據。
- NativeFeatures.m、native-features.json：輔助觀察原生連字屬性處理後的 feature metadata；不把這條舊屬性路徑加入產品。

在 diagnostics/ccmp-control/ 目錄執行獨立探針：

```sh
clang -fobjc-arc -framework Cocoa -framework CoreText Probe.m -o probe
./probe "$PWD/fixtures" > results-internals.json
```

下一個尚未釐清的邊界是 Core Text 的 feature 正規化／預設特性處理；目前沒有證據可把任一失敗候選加入產品。前三項產品程式維持使用者已測試的版本，沒有 App build。

## locl control research — 2026-10-27

2026-10-27；macOS 14.8.7，Build 23J520。ccmp 研究依使用者指示到此結束，不建立其實驗分支。本輪只針對 locl 問題作隔離測量，沒有更改產品 Sources 或構建 App。

### 結果

在目前原生 TextKit 2 路徑上，直接指定 OpenType locl=0 沒有停用測試中的 locl。文字語言可以改變選用的語言分支，但不是整個特性的 Off 開關。

36 個案例使用兩個拉丁字體、locl 不指定／0／1，以及文字語言不指定／tr／en／und／zxx；另加字體 descriptor 的 languages=und 對照。每次從現有原生 CTLine 讀 GID，確認 TextKit 2 manager 沒有切換。

| 字體規則 | 文字語言 tr | 文字語言 und | 額外指定 locl=0 |
| --- | --- | --- | --- |
| 預設語言系統也有 locl：a → alt | GID 4 | GID 4 | 仍是 GID 4 |
| 僅 latn/TRK 有 locl：a → alt | GID 4 | 本項 GID 1 | tr 下仍是 GID 4 |

因此，可以用明確語言設定控制語言專用替換；本例 und 不會觸發土耳其語支線。但不能承諾 und 能全面關閉 locl，也不能從這個 Latin 測量推論所有字體、文字與系統版本的語言選擇行為。

[OpenType locl 規範](https://learn.microsoft.com/en-us/typography/opentype/spec/features_ko#tag-locl) 建議始終套用 locl，並以文字語言 metadata 選擇相應語言系統；[Apple kCTLanguageAttributeName](https://developer.apple.com/documentation/coretext/kctlanguageattributename) 是文字語言屬性。這是規範與 API 說明，不代替本機行為測量。

### 證據

diagnostics/locl-control/ 包含 Probe.m、兩個合成字體及 results.json。locl-default.ttf 沿用前輪拉丁 locl fixture；locl-turkish.ttf 保留相同 GID／規則，只把 locl feature 放入 latn/TRK 語言系統，清空 default language system 的 feature 索引。輸入皆為 a，本項 GID 1，替換項 GID 4。

在該資料夾重現：

```sh
clang -fobjc-arc -framework Cocoa -framework CoreText Probe.m -o probe
./probe > results.json
```

這不是對所有私有 API 的不可行性證明；本輪沒有啟動另一輪無界的私有 API 搜索。

### 補查 AAT：Language Tag

依 [Apple Font Feature Registry，Type 39](https://developer.apple.com/fonts/TrueType-Reference-Manual/RM09/AppendixF.html#Type39)，Language Tag 是互斥的語言選擇特性；非 0 selector 對應字體 ltag table 的索引加 1。它不是一個通用的 OpenType locl On/Off。

補做 12 個 TextKit 2 案例：兩個上述 OpenType 字體、AAT type 39 selector 不指定／0、文字語言不指定／tr／und。加入 39/0 前後 GID 全部相同：預設語言系統內的 locl 仍替換；TRK 專用規則在 tr 下仍替換，在 und 下仍為本項。因此不能用這個 AAT 設定來預設關閉目前路徑的 locl。

沒有在這輪測量純 AAT morx 字體，不能把結果擴張成所有 AAT 字體不支持選擇語言字形。純 AAT 字體的替換及預設效果仍取決於其 feature/selector 與字體程式設計。

證據為 diagnostics/locl-control/results-aat.json；重現指令為 `./probe aat > results-aat.json`。產品 Sources 未改，未 build App。

## Copy to Font Book — 2026-10-28

The File menu now includes Copy to Font Book immediately below Open Recent. Following the user's clarification, it simply copies the current window's original font file, under its original filename, into ~/Library/Fonts. NSFileManager creates the directory if needed and reports errors through the standard AppKit error UI; an identical source/destination is skipped, and existing files are not overwritten. The earlier Font Book launch code has been removed. The command requires a loaded font file. All 14 menu labels are localized, while the earlier Help.01 additions have been reverted. The Traditional Chinese title follows the user's requested 拷貝到字體簿.

A brief source review of native GID mapping and layout reentry found no clear infinite loop or reproducible cause of the previously reported window freeze. No speculative layout change was made. Validation is limited to source/call-site review and resource format checks: no compiler, App build, font copy or UI test.

## Additional Open Font shortcut — 2026-10-28

Command-N now invokes the same Open Font command as Command-O. A hidden copy of the existing menu item enables allowsKeyEquivalentWhenHidden and retains the original title, target, action and modifiers. The visible menu still shows Command-O. Source review only; no build or runtime test.


## Internal display and menu cleanup - 2026-10-28

Unified fixed-GID display assembly for literal selections and vertical quotes, confined native GID/source mapping to GATextDisplay, and removed unnecessary descriptor construction when no display features are overridden. Removed redundant AAT and positioning adapters and reused NSMenu's native item construction instead of the default-modifier wrapper. Menu grouping, default-on omission, glyph order and source spans are intended to remain unchanged.

Source/call-site and resource-format review only; no compiler, build or runtime tests. The user subsequently postponed commit/push, so these edits remain local.

### Cleanup review detail (2026-10-28)

Reviewed production declarations and call sites against the pre-cleanup source snapshot. Eleven source files changed, with a net reduction of 62 lines.

- Single-GID selections, multi-GID seeds and vertical quotes now share GACreateGlyphDisplayString and the existing source-index replacement helper. Removed duplicate NSGlyphInfo assembly and redundant base-string fallback checks.
- GAReadDisplayGlyphRuns now returns source-mapped hits directly. MapGlyphLayoutRuns is private; GAGlyphLayoutRun belongs to GATextDisplay rather than persistent selection metadata. Native glyph order, composed-character merging and seed atomic ranges are preserved.
- Enabled display groups add no feature attributes. A size-only CTFont copy handles both enabled; disabled groups supply only their existing AAT Off selectors. Removed an intermediate descriptor copy and its unnecessary failure branch, following the SDK's nonnull copy contract.
- Removed AAT::applyFeatures: production only selected zero or one selector through substitute. Folded that implementation into substitute and removed vector construction and searches. The actual AAT execution, trace and discovery logic remains in use.
- Removed the one-argument positionsForGlyphIDs convenience method; its sole caller now uses the existing content-taking method with empty content.
- Menus use NSMenu's native addItemWithTitle:action:keyEquivalent: API. Removed the custom construction wrapper and explicit Command/default or irrelevant empty-shortcut modifier masks; Redo retains its explicit Command-Shift mask. Open Font's hidden Command-N alias remains.

No remaining old prediction/test selectors were found in Sources. Existing diagnostics are local research evidence and are excluded from Git. Reviewed differences, declaration/call relationships and resource formats only: no compiler, App build or runtime tests. All 14 localization catalogs have matching 79-key sets.


Concurrent-edit boundary: after the cleanup review, other edits appeared in GAMainWindowController (collection prompt/cancel behavior) and GAAppDelegate (same-name copy suffixes and Help bullet character). They were not made by this cleanup and were preserved. The 11-file/net-62 figure describes this cleanup only, not the entire current directory diff. Re-read current copy/chooser behavior before relying on older handoff descriptions.

## Font Book copy conflict sheets - 2026-10-28

Copy to Font Book now asks before handling a duplicate filename: Keep Both adds the next available numeric suffix, Stop cancels, and Replace replaces the installed item while retaining the opened source file. A font already located in the user Fonts directory shows an informational sheet instead. All 14 languages include both messages and native Finder button labels. Source/resource review only; no build or runtime test. No commit or push.


### Font copy button order and default - 2026-10-28（重复记录，见上方同名条目）

Latest user instruction supersedes the previous conflict-button order: add Keep Both, Replace, Stop, in that order for the native stacked presentation. First response keeps both, second replaces, and third/cancellation stops. Clear Keep Both's automatic key equivalent, lay out the alert, and assign Stop as window.defaultButtonCell; Stop retains Escape. Source review only; no build/runtime test, commit or push.


### Font copy button order correction - 2026-10-28（重复记录，见上方同名条目）

Latest order: Replace, Keep Both, Stop, from top to bottom. First response replaces; second keeps both. Stop remains the default button and Escape action. The first button's automatic key equivalent is cleared. Source edit only; no build, runtime test, commit or push.

## File-by-file menu cleanup and immediate launch picker - 2026-10-28

With separate user confirmations, continued menu construction cleanup in GAAppDelegate: the three recent-menu sites and the remaining 24 main/View/alignment-menu sites now use NSMenu's native item-creation API. Existing titles, actions, targets, shortcut masks and menu order are preserved. Pragma sections now identify the delegate, construction, active-window lookup, actions and validation.

Removed the 0.15-second launch-picker timer after a separate user confirmation. Launch completion opens queued font URLs and returns; with no queued files it presents the existing open panel immediately. Startup file queuing and Dock reopen handling remain. Apple's documented Finder callback order supports this change: [openFile](https://developer.apple.com/documentation/appkit/nsapplicationdelegate/application(_:openfile:)?language=objc), [openFiles](https://developer.apple.com/documentation/appkit/nsapplicationdelegate/application(_:openfiles:)?language=objc). Only source/diff and documentation review; no compiler, build, runtime test, commit or push.

## All-glyph grid cleanup and timer teardown - 2026-10-28

With individual confirmations, replaced linear GID lookup with direct indexing into the complete GID-ordered inventory, removed placeholder containers and redundant settings, and folded the single-use minimum-height query into layout. Added grid teardown that invalidates an unfinished highlight timer, so releasing the grid cannot leave the weak callback repeating without its owner. Existing animation timing, grid spacing, page metrics and scroll behavior are preserved. Source/diff and lifetime review only; no build or runtime tests, commit or push.

## Multi-character display consolidation - 2026-10-28

After separate confirmations, unified character-to-GID lookup in the multi-character view, retaining the distinct existence/exact-GID predicates for vertical orientation and quotes. Merged the view's sole-consumer GATextDisplay.h/.m helpers into GAMultiGlyphView.m and removed those two source files. Display settings, explicit-GID assembly and native readback remain sectioned internally; their moved function bodies are unchanged, and ownership/nullability contracts are preserved. Candidate discovery and native TextKit drawing are unchanged. Source/call-site/body comparison only; no compiler, App build, runtime tests, commit or push.


## Include supplied asset catalog - 2026-10-28

The build now packages Resources/Assets.car alongside AppIcon.icns before signing, matching the existing CFBundleIconName=AppIcon. Optional ZIP packaging includes the catalog through the assembled app. Source and shell-syntax review only; no App build or runtime appearance test.

## Synchronize README usage and localized Help - 2026-10-28

Synchronized English Usage with the user's Chinese 使用 section, preserving the Chinese README verbatim. All 14 locale catalogs now contain 14 Help paragraphs in the same order, including copying the current window's font to the user Fonts folder, moving variable-font controls to third place, and the revised margins/shadow descriptions. Added Help.14 to the existing showHelp: paragraph array so dark-mode guidance remains visible. Existing menu strings and Help presentation are preserved.

Static resource review confirmed valid strings syntax, matching catalog keys, paragraph ordering, shortcut coverage and exact English/Traditional Chinese README-to-Help text parity. Non-Help catalog entries are unchanged. No compilation, App build, runtime tests, commit or push.

## File-by-file cleanup continuation — 2026-10-28

Active copy: this chat's `outputs/Glyph Atlas 2`. Each code change requires its own user confirmation with a plain-language example; comments can be corrected directly. At item 52, the user superseded that confirmation rule inside Sources/FontLayout only, authorizing direct cleanup with repeated source/equivalence checks. No compilation, build, runtime tests, commit or push in this pass.

- `main.m`: reviewed; no cleanup proposed.
- `GAAppDelegate.h/.m`: first pass completed. Item 1 approved and applied: the three item-construction sites in `rebuildRecentMenu` now use NSMenu's native `addItemWithTitle:action:keyEquivalent:`. Targets, represented URLs, tooltips and the empty item's disabled state are preserved. Source diff reviewed only.
- Item 2 approved and applied: removed the redundant launched/pending-URL checks from the launch-delay block; retained the window-count check and 0.15-second delay.
- Item 3 approved and applied: used the same native menu-item creation API at the remaining 24 construction sites in the main, View and alignment menus. Retained all targets, tags, submenu assignments, shortcut masks and alternate/hidden items; removed the now-unnecessary local variable for Close Window. No new wrapper was added.
- Item 4 approved and applied, superseding item 2's delayed block: removed the whole 0.15-second launch timer. `applicationDidFinishLaunching:` opens queued font URLs and returns, or calls `showOpenPanel` directly when the queue is empty. Existing startup queue, Dock-reopen handling and panel lifecycle remain. Apple documents Finder's launch-time open-file callback before did-finish-launching, with openFiles sharing the openFile behavior; this was a documentation/source check, not runtime validation.
- Item 5 approved and applied: About now targets NSApp's `orderFrontStandardAboutPanel:` directly. Removed `showAbout:` and its app-delegate menu-validation branch; standard bundle-derived About content is unchanged.
- Item 6 approved and applied: moved the existing open-panel implementation into `openFont:` and removed the forwarding wrapper/old `showOpenPanel` selector. Startup, Dock reopen and both menu shortcuts now share `openFont:`; panel deduplication, activation and completion handling are preserved.
- Item 7 approved and applied: removed the nil guard around `cancel:` in Finder file opening; messaging nil already does nothing. The panel-reuse condition in `openFont:` remains necessary and unchanged.
- Comment-only organization: corrected/added pragma sections for the menu delegate, construction, active-window lookup, view actions, validation, and file/application actions. No methods were moved.

`GAAllGlyphsView.h/.m`: first pass completed. Item 8 approved and applied: replaced the linear GID search with direct indexing. `GAFontDocument.allGlyphEntries` constructs every GID in contiguous ascending order; the grid's only inventory assignment uses that array, and the controller excludes empty glyph selections before revealing. Retained the bounds check and existing reveal/flash behavior.

Item 9 approved and applied: removed the grid initializer's empty entries array and two zero-length metric buffers. `setEntries:` installs the inventory and creates both buffers before nonempty drawing; empty drawing/redraw paths return before buffer access. Scale, columns and highlight-index initialization remain.

Item 10 approved and applied: removed the ordinary fill-color assignment immediately before `drawRect:`'s glyph loop; both branches inside the loop set the actual glyph color before drawing, so the earlier assignment was overwritten. Source diff reviewed only.

Item 11 approved and applied: removed the inner grid's duplicate `cellScale = 1.0` initialization. The sole grid creator initializes the outer view's scale and assigns it to the grid before installing the grid as the scroll document. The default remains 1.0, now specified once.

Item 12 approved and applied: inlined the single-use `minimumHeight` method into `updateLayoutForWidth:`. Retained the missing-scroll-view result of 0 and the existing target-height formula, including its minimum >= 1 condition.

Item 13 approved and applied: removed the animation-end `highlightAppendStyle = NO` assignment. The timer is invalidated immediately afterward; every new flash assigns the requested style before starting its timer. Alpha, highlight index and timer cleanup remain unchanged.

Item 14 approved and applied: invalidate the grid's repeating highlight timer in `dealloc`. The run loop retains scheduled timers, while the timer's callback references the grid weakly; if the grid is released before animation completion, its callback can no longer execute the normal end-of-animation invalidation. The new teardown prevents that orphaned timer. Source/lifetime review only, not a reproduced or runtime-verified result; normal animation timing is unchanged.

Item 15 approved and applied: simplified target height to `MAX(height, minimum)`. Content height is at least its two 14pt margins, with nonnegative top inset and row contributions; treating viewport heights below 1pt as zero could not affect the maximum. The scroll-view absence handling is unchanged. This supersedes item 12's retention of that threshold.

Comment-only corrections in the grid clarify page height as `(ascent + descent)` and describe its horizontal baseline without equating it to the single-glyph bounding box view's optional vertical-metric baseline.

`GADetailViewController.h/.m`: first pass completed. Item 16 approved and applied: the outer container shares the existing bounding box view context menu via its native `menu` property. Removed `menuProvider`, its setup block and the forwarding `menuForEvent:` override. Existing menu-delegate updates still refresh the visible/enabled items on opening; resize and scroll-position handling are unchanged. Reviewed the native NSView default-menu behavior against Apple documentation, without UI testing.

Item 17 approved and applied: moved `scrollMultiToPoint:` and `setMultiText:groups:` unchanged into the multi-character operations section. Added pragma sections for view creation, layout, shared display state, page zoom, all glyphs and multi-character operations. No method bodies or call relationships changed in this item.

The former single-glyph view files: first pass completed, with items 18/19 unchanged. Item 18 declined: keep the page-fraction magnification helper public as-is. Do not change its declaration/linkage or re-propose privatizing it without new user direction.

Item 19 deferred; source unchanged. The user requires an actual case before deciding whether to replace the empty-content-rect fixed 80pt fallback with an immediate return. Source and existing diagnostics review found no reproduced call into this branch. The bounding box view is created with NSZeroRect, but subsequent constraints size it; zero-sized initialization alone does not prove `drawRect:` runs at that size. The proposed pre-layout example was a boundary-condition inference, not an observed case. Keep the fallback and do not present that inference as runtime evidence or apply this proposal without further user approval.

Retained the bounding box view's explicit `NSViewLayerContentsRedrawOnSetNeedsDisplay` policy: Apple documents `DuringViewResize` as the AppKit-created backing layer's default, so this is an effective setting, not a redundant default. The explicit redraw in `setFrameSize:` remains paired with that policy. Documentation/source review only.

`GAMultiGlyphView.h/.m`: first pass completed. Item 20 approved and applied: consolidated the two character-encoding query methods and the ideograph lookup in `glyphIsFullWidth:` into private `glyphForCharacter:font:`. A failed mapping returns 0; callers retain separate nonzero/exact-GID predicates. The vertical-quote caller already excludes a zero target GID, so failure cannot match it. No changes to vertical orientation, full-width thresholds, lookup order or quote feature selection. Source review only.

Item 21 approved and applied: merged `GATextDisplay.h/.m` into `GAMultiGlyphView.m` (828 lines after this item) and deleted the two former files. All product consumers were already confined to this view. The four former exported C functions now have static declarations/definitions; ownership and nullability declarations, GAGlyphLayoutRun, and both private TextKit categories remain local to the implementation file. The moved implementation was compared with the pre-merge source after removing only the added static prefixes; bodies are unchanged. The build already compiles Sources/*.m, so no script edit was needed. No compiler/build/runtime tests.

Item 22 approved and applied: removed the single-use `fontAtSize:` forwarding method. `rebuildLayout` directly calls the existing GACopyTextDisplayFont under the same document/text/viewport preconditions, with the same point-size expression, feature flags and bridge-transfer ownership.

Item 23 approved and applied: removed initializer-only empty text, group-array and glyph-hit-array assignments. Before text arrives, the length guard and hidden text view prevent nonempty layout/hit handling; setText:groups: still copies and normalizes incoming data, and rebuildLayout still resets/rebuilds hits. Font-size, page-inset and feature defaults are unchanged.

Item 24 approved and applied: removed two explicit nil checks from vertical quote handling where the following unsignedShortValue == 0 check already covers nil. Zero-GID and unchanged-GID rejection remains intact.

`GAGlyphViews.h/.m`: first pass completed. Item 25 approved and applied: removed GAUnicodeCodesView's duplicate setBackgroundStyle: declaration, already supplied by its backgroundStyle property. The setter implementation and all style propagation remain.

Item 26 approved and applied: removed the variant row initializer's regular 12.5pt name-font assignment. The table's sole creation/reuse path always calls configureWithVariant: before returning the cell; that method still fully specifies the same point size and base-dependent font weight. Comment-only correction: removed the misleading word native from the custom-drawn Unicode badge-column description.

Item 27 approved and applied: removed the redundant MAX(5.0, ...) from name-top positioning. rowHeightForVariant: already ensures at least 5pt padding on each side of the maximum content height, so half the remaining space above the name block cannot be below 5pt. The centering formula is unchanged (44pt row / 16pt name -> 14pt; 44pt row / 30pt name+source -> 7pt).

Item 28 approved and applied: removed GAUnicodeCodesView's intrinsicContentSize override and its invalidation call. Its sole parent already computes width/height through the same class methods and applies active equality constraints. Badge layout, dimensions, accessibility and tooltips remain; the parent is now the single sizing path. Source review only; no UI verification.

`GASidebarViewController.h/.m`: first pass completed. Item 29 approved and applied: removed the two-argument pending-selection convenience interface and its forwarding method. The sole short-form caller in GAMainWindowController now supplies scroll:Group explicitly; activation retains SelectedToTopIfNeeded. Both scroll policies and their implementations are preserved.

Item 30 approved and applied: selectedGlyphSourceText obtains the model text once for a validly located ligature, then uses that local string for both the bounds check and substring. Previously each self.text read normalized attributes and converted line-break markers again. The non-ligature path, bounds checks and group-text fallback are preserved.

Item 31 approved and applied: removed inactive pending-range/pending-scroll resets from successful resolution and manual-selection cancellation (four assignments). Both paths still clear the pending glyph key; range/policy readers remain guarded by that key, and the sole request setter always writes all three fields. Actual selection metadata and both scroll implementations are unchanged. Comment-only correction replaces the obsolete streamed-snapshot wording with list snapshots.

Item 32 approved and applied: merged restored-selection group discovery and subsequent row lookup into rowForGlyphKey:textRange:. It scans the existing flattened row order for the first exact range/key match and retains the zero-length-range rejection. Removed group:containsGlyphKey: and groupForGlyphKey:textRange:, whose only role was that two-stage path. The group-identity row lookup used by pending resolution/viewport restoration and the first-base fallback remain unchanged. Source comparison only.

Item 33 approved and applied: selectedGlyphHasEncoding and copySelectedGlyphEncoding rely on the scalar count to cover an absent selected row; removed the redundant explicit row-nil checks. Menu disablement, the no-encoding beep and the empty-conversion check remain unchanged.

Item 34 approved and applied: prepareFieldEditor obtains its input font/color once per invocation and reuses the locals for typing attributes, attribute validation and normalization. No cross-call cache is introduced. Default getters, line-break exceptions, callback suppression and selection restoration are unchanged.

`GASidebarInput.h/.m`: first pass completed. Item 35 approved and applied: shared the identical attribute-copy loop used by the two field/model conversion functions through file-private GACopyAttributesWithoutLineBreakMarker. The helper keeps all attributes except the old line-break marker; directional string conversions, one-unit range mapping and marker reapplication are unchanged. Removed the reverse conversion's now-unused local range. Source diff reviewed only; no compiler/build/runtime tests.

`GAInputFocus.h/.m`: first pass completed. Item 36 approved and applied: moved the single-use handleMouseEvent: body into the local mouse-monitor block, then removed that private method/declaration and the block's unnecessary weak-self reference. Blank-click detection, notification and returning the original event are unchanged. Source diff reviewed only; no compiler/build/runtime tests.

Item 35 follow-up: the reverse field-text conversion is used by setAttributedText:, not a separate user-facing conversion command. Current production callers write back after all-glyph append, sidebar glyph activation/insertion, and dissolution of outdated explicit-GID selection runs during analysis. Internal text contains real LF characters; writeback restores marked U+23CE so these existing operations retain the single-line field's visible line-break representation. Verified current source call sites, not runtime behavior.

Completed first-pass count through GAInputFocus: 21 original files (main.m, nine header/implementation pairs, and the two merged/deleted GATextDisplay files), corresponding to 19 current files. Incidental caller/reference reads do not count toward this total.

`GAVariationViewController.h/.m`: first pass completed. Item 37 approved and applied: create each named-instance menu item through NSMenu's addItemWithTitle:action:keyEquivalent: directly, instead of allocating an item and adding it separately. Still uses the underlying menu, not NSPopUpButton's duplicate-replacing addItemWithTitle:. Clarified that distinction in the adjacent comment. Source diff reviewed only; no compiler/build/runtime tests.

`GAGlyphSelection.h/.m` and `GAViewMode.h`: first pass completed without changes. Selection metadata is consumed by input handling, display/query projection and text preparation; query identity is also used by the substitution engine's NSCache. Mode predicates are used by context-menu state and main-menu validation. Completed first-pass count is now 26 original files, corresponding to 24 current files.

`GATextQueryModel.h/.m`: first pass completed. Item 38 approved and applied: removed initializer-only `_text = @""`. The first accepted query assigns `_text` before projection; font-document updates read it only when `_result` exists, which is assigned after the query text. Kept the public groups array's initial empty value and all cancellation/cache behavior. Source diff reviewed only; no compiler/build/runtime tests.

Item 39 approved and applied: removed SelectionGroup's loop that reassigned each stored variant's base flag. discoverGlyphIDs inserts the original sequence first with base=YES, merges all later sequences with base=NO, and preserves the first sequence's flag when a duplicate merges. analyzeGlyphIDs copies those flags and the order into fresh variants. Empty/failing discovery already returns before the redundant loop. Kept the separate ligature-group base assignment, which follows a different construction path. Source diff reviewed only; no compiler/build/runtime tests.

`GAFontResource.h/.m` and `GAUnicode.h/.m`: first pass completed without changes. Resource APIs all have production callers; preserved the common-probe/default normalization used to group variable-font descriptors. Unicode name, scalar-string conversion and vertical-orientation helpers all remain in use. Completed first-pass count is now 32 original files, corresponding to 30 current files.

`GAFontEngine.h/.m`: first pass completed. Item 40 approved and applied: removed the unused GAUnicode.h import from GAFontEngine.m. None of the three declarations in that header are used here; GAScalarsForString is a separate file-local function. Foundation is already imported by GAFontEngine.h. Source diff reviewed only; no compiler/build/runtime tests.

Item 41 approved and applied: removed the count==0 early returns in private inkBoundsForVariant: and advanceInFontUnitsForVariant:. Their only caller is pageForVariant:usesVerticalMetrics:, which returns its zero page before either helper is reached when glyphIDs is empty. Kept the public entry guard, ink/advance calculation and all other fallback checks. Clarified the private methods' nonempty-input contract in comments. Source diff reviewed only; no compiler/build/runtime tests.

Item 42 approved and applied after the user's requested equivalence recheck: compare variant.glyphIDs and candidate.glyphIDs directly with isEqualToArray: in applyRawResult:'s existing-variant lookup, removing the temporary serialized candidate key. Actual data flow: Glyph is uint16_t; glyphArray boxes every element into a real array; merge stores it on the match; rawScanContent copies it to the candidate; rebindResult preserves it. projectResult creates fresh groups with empty variant arrays, and applyRawResult creates existing variants from those same candidates. Thus both sides are nonnil arrays of integer GIDs, including valid empty sequences. Count/order/value comparison has the same result as the previous comma-delimited decimal serialization; empty/empty still matches, and empty/[0] remains different. Ligature flag/range predicates and the public glyphKey getter are unchanged. Source/data-flow review only; no compiler/build/runtime tests.

Item 43 approved and applied: GAGlyphKeyForGlyphIDs had only the glyphKey getter as a caller after item 42. Moved its existing serialization body into that getter and removed the file-private helper. A local glyphIDs retains the prior single getter evaluation. The public property, comma formatting, ordering and empty-sequence sentinel are unchanged. Source diff reviewed only; no compiler/build/runtime tests. Completed first-pass count is now 34 original files, corresponding to 32 current files.

`GAMainWindowController.h/.m`: first pass completed. Item 44 approved and applied: create the font-style chooser's menu items directly through NSMenu's addItemWithTitle:action:keyEquivalent:. Preserved title disambiguation, menu order and sheet completion/cancellation paths in this item; item 45 supersedes numbering/index lookup. Source diff reviewed only; no compiler/build/runtime tests. GAMainWindowController.m already has a pre-pass backup from item 29; do not overwrite it.

Item 44 follow-up: the user recalls numbering was added to prevent duplicate-name menu loss and selection/resource mismatch, and wants the numbering removed if that mechanism can be addressed. Apple documents that NSPopUpButton addItemWithTitle: removes an existing same-title item and recommends adding directly to its menu to avoid its duplicate-title search. The current chooser already used the underlying menu before item 44. Its indexOfSelectedItem identifies the selected item, not a title lookup. This supports removing numbering; the historical cause has not been independently reproduced. API/source evidence: https://developer.apple.com/documentation/appkit/nspopupbutton/additem(withtitle:) and https://developer.apple.com/documentation/appkit/nspopupbutton/indexofselecteditem . No UI tests.

Item 45 approved and applied: removed the chooser's counts/seen dictionaries and appended (1)/(2) titles; add each resource.name directly through the underlying NSMenu. Store the actual GAFontResource in each item's representedObject and load popup.selectedItem.representedObject on confirmation, replacing the parallel-array index lookup. This binds the selected item directly to its font resource while retaining same-name items. Menu order, sheet wording and cancellation behavior are unchanged. Source diff reviewed only; same-name UI selection has not been runtime-tested.

Item 46 approved and applied: removed GAGroupIsMissing's repeated inserted-ligature/range checks and its text argument. The helper's only caller, buildMultiDisplayWithText:, skips inserted-ligature groups and validates the same source range before calling it. Kept the caller's guards and the helper's seeded/line-break exceptions and GID-0 predicate. Clarified the precondition in a comment. Source diff reviewed only; no compiler/build/runtime tests.

Comment-only organization in GAMainWindowController: added/adjusted pragma sections for view actions, window/input focus, toolbar, variation controls, font loading, selection runs/activation and errors. No methods were moved.

Item 47 approved and applied: toolbarDefaultItemIdentifiers: returns the existing toolbarAllowedItemIdentifiers: result instead of repeating the same two-item array literal. Both native delegate entry points and the current identifiers/order remain, without another helper. Source diff reviewed only; no compiler/build/runtime tests.

Item 48 approved and applied: removed the unused math.h import from GAMainWindowController.m. The current file uses ordinary arithmetic and Foundation/AppKit types/macros, with no math-library function or constant references. GAVariationViewController's math.h import remains needed and unchanged. Source diff reviewed only; no compiler/build/runtime tests.

Item 49 approved and applied after the user's requested safety recheck: removed activationPayloadForVariant:sourceText:selection:'s three outSelection != NULL checks. A full Sources search found exactly two call sites; both pass &selection for a local GAGlyphSelection *selection = nil. The calls and output writes are synchronous while those local variables are alive, so neither path supplies a null output address. A nil value stored in that variable is separate from its nonnull address. All existing output assignments and return paths remain at their original positions, including the encoded-conversion failure path. Documented the required output-variable contract in a comment. Source/data-flow review only; no compiler/build/runtime tests.

Item 50 approved and applied: replaced the single-use buildMultiDisplayWithText:groups:multiText:multiGroups:sources: out-parameter interface with buildDisplaySnapshotWithText:groups:, returning the existing GAScanDisplaySnapshot class. Moved the existing snapshot construction/assignments into the builder; publishWorkerSnapshotWithText: consumes its result directly. The builder receives the original text/display groups and constructs the same three multi-view outputs; no new data model was added. Filtering/range mapping, text copying, group/map ownership and queued publication checks are unchanged. Removed three intermediate output variables, three output parameters and their conditional assignments. A separate before-item-50 source snapshot supports an isolated diff; source diff reviewed only, no compiler/build/runtime tests.

Item 51 approved and applied: marked the snapshot's multiText, multiGroups and multiGroupSources properties nonnull and removed applyScanSnapshot:'s nil-coalescing empty text/group fallbacks. The sole snapshot creator is the builder, which always supplies a real text string, array and source map before returning, including empty-input results. Their construction/copying and consumer updates are unchanged. Source diff reviewed only; no compiler/build/runtime tests. All 34 current top-level Sources files have completed a first pass (36 original files including the two merged/deleted files).

`FontLayout/GABinary.h`: first pass completed without changes. Its bounded View readers/offset helpers, Coverage presence/index/enumeration and ClassDef lookup all have production uses. The workspace currently has no Tests directory; historical test references are not proof of current files. Completed first-pass count is 37 original files, corresponding to 35 current files.

`FontLayout/GAGlyphBuffer.h/.cpp`: first pass completed. Item 52 approved and applied: Trace::changed finds old clusters directly with lower_bound in the sorted clusters(before) vector instead of copying spans/glyph vectors into an intermediate std::map. Checked that clusters sorts source spans and preserves their ordering while merging overlaps, Span equality agrees with the ordering, lower_bound preserves map::emplace's first-equal-span behavior, and the end-iterator check short-circuits before dereferencing an empty/missing result. Emitted change order and the later deletion/prefix-maxima calculation are unchanged. Source/diff review only; no compiler/build/runtime tests.

At item 52 the user also authorized direct subsequent cleanup inside FontLayout with repeated safety review, without further per-change popups. The prior confirmation rule still applies outside that folder.

`FontLayout/GAAAT.h/.cpp`: first pass completed. Item 53 applied under that authorization: inlined Runner::merge's span-union/assignment body at its sole call inside rearrange and removed the private method. The existing first_/last_ validity check and head/tail-length check still precede all accesses; the same indices, union order and assignments run at the same point before copying/reordering items. The verb comes from entry.flags & 15, keeping the fixed head/tail arrays in range. No changes to AAT state transitions, flags, discovery or output order. Source/call-site/diff review only; no compiler/build/runtime tests.

The remaining FontLayout files have completed their first pass without changes: GACmap.h/.cpp; GAVariation.h/.cpp; GAOpenType.h/.cpp; GASubstitution.cpp; GARelatedSubstitutions.cpp; GAPositioning.cpp; GATextPreparation.h/.mm; GASubstitutionEngine.h/.mm; compile-font-layout.sh. Reviewed the current production consumers and retained the mapping formats, defaults, Unicode/ICU preparation, context replay, provenance merging, budgets, table checks, caches and compilation rules. Core parser/executor/catalogue/positioning files retain their separate responsibilities. No current unconsumed product interface was established in this review.

This file-by-file first pass is complete: 53 current files under Sources (34 top-level source files and 19 FontLayout files, including its compile script); 55 original files if the two merged/deleted GATextDisplay files are included. This count means source review, not runtime verification or proof that every possible further simplification has been exhausted. Item 18 remains explicitly retained; item 19 remains deferred pending an actual case. The isolated core diffs and equivalence notes are in diagnostics/cleanup-file-review-2026-10-28/font-layout-cleanup.diff and FontLayout-source-review.md.

Pre-pass files are saved under `diagnostics/cleanup-file-review-2026-10-28/before/Sources/`, separate from the earlier cleanup snapshot: GAAppDelegate.m, GAAllGlyphsView.m, GADetailViewController.m, GAMultiGlyphView.m (before item 20), GAGlyphViews.m (before item 25), GASidebarViewController.h/.m and GAMainWindowController.m (before item 29), GASidebarInput.m (before item 35), GAInputFocus.m (before item 36), GAVariationViewController.m (before item 37), GATextQueryModel.m (before item 38), GAFontEngine.m (before item 40), FontLayout/GAGlyphBuffer.cpp (before item 52), FontLayout/GAAAT.cpp (before item 53), and the deleted GATextDisplay.h/.m. A separate before-item-50 snapshot isolates that refactor. Existing snapshots were not overwritten.

## Prefer non-C0/DEL encodings when appending from All Glyphs - 2026-10-29

Plangothic P2 maps control codes and visible control pictures to shared GIDs, such as U+001F/U+241F for GID 31. Double-clicking previously appended the lower control code, leaving text present but invisible in the user's screenshots. At the user's request, All Glyphs insertion now searches later encodings only when the first mapping is one of the 32 C0 codes or DEL; otherwise it uses the first immediately. The search retains the original first mapping if no alternative qualifies. No new fallback, shared interface or cached field was added. Unencoded glyphs and other insertion/copy paths retain their existing behavior. Source review only; no compilation, App build, runtime tests, commit or push.


## Replace legacy single-glyph terminology with Bounding Box - 2026-10-29

At the user's request, replaced the single-glyph accessibility label with "Bounding Box" and synchronized its 14 locale translations with the existing Bounding Box menu nouns. Renamed the former single-glyph view files and class to GABoundingBoxView, updated imports, and renamed the associated view/inset/zoom/shared drawing identifiers and comments. The build already discovers Sources/*.m and requires no filename-list change. Drawing, zoom limits, shortcuts and interaction bodies are unchanged apart from names. Source/resource review only; no compilation, App build, runtime tests, commit or push.

## Preserve original VF instance names for display - 2026-10-29（过时，更新请看「Remove font-name matching and use system names directly」与「Use unique localized VF family names」）

Native font-object diagnosis on Futura, New York and Skia showed that rebuilding named coordinates from the normalized default descriptor changes coordinates/PostScript names but can retain a Regular full/style name. Original named-instance descriptors return their intended names. Raw metadata and the standalone Python/CoreText readback are retained in diagnostics/vf-name-readback; these did not exercise the App UI.

The user approved preserving each original instance full name and choosing the display name by current coordinates. The Popover's existing matching rule is now shared by the resource and main controller, so selecting a preset or manually returning to its coordinates selects the same display name. Custom coordinates display the family name plus localized Custom. The window title, visible font name and tooltip use one result. No descriptor retention, new parsing, rendering change or localization key was introduced; the existing 14 Custom translations are reused. Source review only; no compilation, App build, runtime tests, commit or push.

## Localize font display names and simplify custom titles - 2026-10-29（过时，更新请看「Remove font-name matching and use system names directly」与「Use unique localized VF family names」）

At the user's request, resource/instance/document display names now use CTFontCopyDisplayName. Resource family names use CTFontCopyLocalizedName with kCTFontFamilyNameKey, keeping the ordinary family name only when the requested name entry is unavailable. Popover style names retain the original CTFontCopyName style string. Custom coordinates now show only the localized family name, removing the separator and Custom suffix from titles/tooltips while keeping the Popover Custom item. Static fonts and collection choices use localized display names as well. The user confirmed the Futura anomaly is font data and requested no special handling.

Language research: Apple's documented AppKit displayName/font-manager APIs provide localized user-facing names. CoreText's localized-name function has no input language parameter. A standalone CoreText metadata readback using Apple's documented AppleLanguages launch argument changes PingFang family 蘋方-港 → PingFang HK under an English process override. This confirms process-level language preferences can affect font naming; it does not claim that every Apple app or the running Glyph Atlas UI was tested. Results and sources are in diagnostics/vf-name-readback/LANGUAGE-NOTES.md. Source review only; no compilation, App build, App runtime tests, commit or push.

## Remove font-name matching and use system names directly - 2026-10-29（部分过时；唯一 VF 家族名例外见「Use unique localized VF family names」）

After checking SFNS and the newly installed multilingual Source Han Serif VF collections, the user explicitly withdrew the instance-name matching approach. Removed the stored instance fullName, resource familyName, shared index lookup and main-controller named/custom title override. Restored the Popover's original local coordinate matcher exactly; its original style names and Custom option remain. The window title, visible font name and tooltip now directly use document.fullName from CTFontCopyDisplayName. Resource chooser names keep the same native localized display-name API. No name composition, per-font exception or replacement matching layer is retained.

The user also accepted Source Han Serif's default-weight chooser labels (default wght=250) and requested no change there. An isolated English-language CoreText readback confirmed that the tested original VF descriptors can likewise return one localized full name across instances; names from the product's normalized-descriptor path may retain the default style. The user accepts these system-provided results. Earlier naming proposals above are superseded by this decision. Source/snapshot comparison only; no compilation, App build, App runtime tests, commit or push.


## Use unique localized VF family names - 2026-10-29

At the user’s request, after named-instance descriptors are merged into resources, each VF whose native localized family name is unique among the remaining options displays that family in the opening chooser and the opened font’s sidebar name. One remaining VF satisfies the same rule automatically. Static resources participate in duplicate-family detection but retain native full/display names; VFs with duplicate or unavailable family names do likewise. GAFontResource chooses its name once and exposes usesFamilyName so the window title, visible font name and tooltip share it across preset and arbitrary axis changes. No coordinate-to-name matching, composed name, custom-coordinate naming branch or new localization strings were added.

Also confirmed that Custom survives only as the Popover’s original disabled status item for unmatched coordinates; the old font-title Custom suffix and instance-name matching additions remain removed. Source/diff review only; no compilation, App build, runtime tests, commit or push.


## Recent-change cleanup - 2026-10-29

Reviewed recent localization, control-code insertion, Bounding Box renames and VF naming work. Applied only popup-approved item 54: grouped VF resource merging and instance construction under one existing axis check, and scoped the member list/default-instance tracker to that branch. Static resources retain their empty instance array and no longer allocate a member list they never consume. Updated the usesFamilyName header comment directly as authorized. No remaining unused product interface from these naming iterations was established. Isolated source/snapshot and whitespace review only; no compilation, App build, runtime tests, commit or push.


### Cleanup review detail (2026-10-29)

Scope: README/Help synchronization, All Glyphs C0/DEL insertion preference, Bounding Box terminology, withdrawn VF instance-name matching, and the latest unique-localized-family naming rule. Rechecked current production call sites and the relevant before-change snapshots; preserved all concurrent/uncommitted work. No compilation, App build, runtime tests, commit or push.

The user's latest instruction requires a separate popup approval before each code change, including any new FontLayout changes; it supersedes older blanket cleanup permission. Comment corrections need no approval.

Findings: no unconsumed interface from these naming iterations was established. GAFontResource public properties/methods and both Popover focus entry points have product callers. Saved instance fullName, familyName and shared name matcher remain absent. Popover Custom is a live unmatched-coordinate state, usesFamilyName is consumed by the title update, and native display-name fallbacks handle nullable API results. The variation controller implementation matches the snapshot before the withdrawn naming work. Bounding Box changes contain the intended renames/accessibility replacement; no legacy identifier remains in current Sources/Resources. Help.14 is consumed by showHelp:. The C0/DEL branch retains its original first-mapping path and only searches alternatives for those 33 control codes.

Comment-only correction: clarified that usesFamilyName describes a VF using a localized family name unique among remaining resources.

Item 54 approved via popup and applied: consolidated the two axes.count > 0 blocks in GAFontResource.resourcesFromDescriptors:. The member list and default-instance tracker are now created only inside that VF branch; static resources no longer allocate an unused member list. The instances array remains outside the branch so static resources still publish an empty array. Normalization, comparison/removal, instance order/default detection, family-name selection and output assignment bodies are unchanged. An isolated snapshot comparison confirmed that the implementation contains exactly the approved declaration/block rearrangement; the other snapshotted source files are unchanged except for the documented header comment. Diff whitespace checks passed. No compilation or runtime verification.

Pre-change snapshot: diagnostics/cleanup-recent-2026-10-29/before.json.

This recent-change pass is complete. No additional confidently removable interface, obsolete naming branch or redundant default assignment was established in this scope. Existing native-control settings, normalization and meaningful nullable-name handling were retained. Do not expand the one approved item into unapproved code changes.

## Sidebar VF width preview investigation — 2026-10-29（过时，更新请看「Fix PingFang UI VF sidebar preview clipping」）

Item 55 was separately approved and applied as one added [self.superview setNeedsDisplay:YES] in GAGlyphView.setVariant:, preserving its existing self invalidation. The user tested a new build and reported the clipping unchanged, then explicitly requested rollback. Removed that one line; the full GAGlyphViews.m matches the before-55 snapshot exactly. Do not retain or repeat this failed patch.

The user's precise report is right-side-only clipping after increasing PingFangUISC-Medium.ttf wdth, with full glyphs restored by scrolling out and back. The app's existing overflow policy is intentional. Initial fixed-thumbnail-clipping/parent-dirty-area explanations were hypotheses, not validated root causes. Further diagnosis and the proposed temporary-log approval are tracked in diagnostics/pingfang-ui-width/README.md. No agent App compilation/build/GUI test.


Item 56 explicitly approved via popup and applied: added one temporary [GA Preview] NSLog block in GAGlyphView.drawRect: to capture the font coordinates, current view geometry, dirty rectangle, actual CGContext clip bounding box, projected ink and clipping/layer-preference flags before the existing drawing transforms. The isolated diff contains only that block; removing it exactly reproduces before-diagnostic-56.json. Item 55 remains reverted. No behavioral fix is claimed. Await the user’s manual reproduction and remove item 56’s marked block after diagnosis; no public test interface, App build or agent UI test.


VF investigation final source cleanup: at the user's stop request, removed item56 logging and all items57–60 render experiments. GAGlyphViews.m exactly matches before-diagnostic-56.json. Items55/58/59/60 failed in the reported/live tests;57 outline filling succeeded only as a diagnostic. No permanent fix was adopted. Compilation and Computer Use were explicitly authorized by the user for this investigation, superseding its earlier source-only boundary. See diagnostics/pingfang-ui-width/README.md for the confirmed head.xMax experiment and unresolved renderer details.

> **迭代说明：** 以下 2026-10-29/30 的 Zoom、标题栏、边距、字号、定位条目包含多次试验；最终值见 GLOSSARY §5/§6/§7。

## Suppress title-bar double-click Zoom (trial) - 2026-10-29

At the user's request, the main window's native windowShouldZoom:toFrame: delegate callback now rejects Zoom requested by a left-mouse double-click above the window's unobscured content area. Other Zoom entry points retain their existing behavior. All Glyphs double-click handling and font-title controls are unchanged. This callback covers Zoom, not every possible system title-bar action. Source review only; the user will test the trial. No compilation, App build, runtime verification, commit or push.


## Limit the Zoom veto to All Glyphs cells (trial) - 2026-10-30

The user confirmed that the initial native Zoom veto worked but requested normal behavior in other views and outside glyph cells. Replaced the title-bar-position test with an active-All-Glyphs check and the existing grid indexAtPoint: hit test, restricted to visibleRect. System event clickCount still identifies the double-click. No timer, first-click state or glyph mouse-handler change. Other views, gaps and empty cells now pass the Zoom decision through. Source review and git diff --check only; no build or runtime verification. The user will test.


## Font title click-through (trial) - 2026-10-30

After confirming the All Glyphs cell-only Zoom veto, the user approved making the font-name area pass mouse hit testing through. A private GAFontTitleView stack subclass returns native button hits and nil for the label/background. The VF button keeps its normal hit handling. Font-name rendering, layout and the existing Zoom veto are unchanged. Source review and whitespace check only; no compilation or runtime verification. Native title-bar double-click behavior at this location is pending the user's test.


## Symmetric All Glyphs margins outside full screen - 2026-10-30（过时，更新请看「18pt All Glyphs vertical margin」）

At the user's request, All Glyphs now uses its existing 14pt bottom margin at the top in ordinary windows. Only full-screen windows retain the previous title-bar clearance: total top spacing is MAX(14pt, safeAreaInsets.top). The existing layout pass checks the native full-screen style mask. Multi-Character layout is unchanged, as explicitly clarified by the user. Source review and git diff --check only; no compilation or runtime verification.


## Set All Glyphs vertical margins to 16pt - 2026-10-30（过时，更新请看「18pt All Glyphs vertical margin」）

The user revised the prior margin rule: ordinary-window top spacing and bottom spacing are 16pt; full-screen top spacing directly uses the existing titlebar clearance (safeAreaInsets.top), without MAX against the ordinary margin. Side margins retain their 14pt minimum and horizontal centering. Grid geometry, drawing and hit testing share the same total topInset. Multi-Character is unchanged. Source review and git diff --check only; no build or runtime verification.


## 18pt All Glyphs vertical margin — 2026-10-30（现行）

Latest margin revision (2026-10-30): the user changed 16pt to 18pt. Ordinary-window top and all-window bottom spacing now use GAAllGlyphsVerticalMargin = 18pt. Full-screen top remains exactly safeAreaInsets.top; horizontal minimum remains 14pt. No build or runtime verification.


## Multi-Character 48pt default — 2026-10-30（过时，更新请看「Multi-Character 51pt default」）

Multi-Character default font size (2026-10-30): at the user's request, GAMultiBaseFontSize changed from 32pt to 48pt. Initial/reset textScale remains 1, and zoom factors/limits and All Glyphs remain unchanged. Source/whitespace review only; no build or runtime verification.


## Multi-Character 50pt default — 2026-10-30（过时，更新请看「Multi-Character 51pt default」）

Multi-Character font-size revision (2026-10-30): the user changed the default from 48pt to 50pt. GAMultiBaseFontSize is now 50pt; initial/reset textScale remains 1. No build or runtime verification.


## Multi-Character 52pt default — 2026-10-30（过时，更新请看「Multi-Character 51pt default」）

Multi-Character font-size revision (2026-10-30): the user changed the default from 50pt to 52pt. GAMultiBaseFontSize is now 52pt; initial/reset textScale remains 1. No build or runtime verification.


## Multi-Character 51pt default — 2026-10-30（现行）

Multi-Character font-size revision (2026-10-30): the user changed the default from 52pt to 51pt. GAMultiBaseFontSize is now 51pt; initial/reset textScale remains 1. The user confirmed twenty zoom steps for the shrink limit. The scale range is now 1 / 1.12^20 through 1.12^20, preserving the existing twenty-step enlargement limit. No build or runtime verification.


## Align Multi-Character text using its actual container origin - 2026-10-30（过时，更新请看「Text positioning trials reverted」）

At the user's request, horizontal and vertical text positioning now aligns the native textContainerOrigin to the page's top-leading corner on both axes (top-left horizontally, top-right vertically). Coordinates are converted into the parent view before calculating the translation. Page geometry, font size, text-container width, inset and existing frame sizes are retained. No fixed 0.5px/pt compensation or native origin override.

Standalone TextKit 2 coordinate readback verifies the translation removes the sampled horizontal X/Y discrepancy and preserves the already-aligned vertical sample. The product UI, particularly the user's reported vertical displacement, remains unverified. No product compilation, runtime UI tests, commit or push.


## Direct Multi-Character positioning trial; offset remains unresolved - 2026-10-30（过时，更新请看「Text positioning trials reverted」）

The user clarified that both writing orientations still show displacement, although appearance changed slightly. They approved trying size-first positioning. The text view now receives its existing intended size, then its actual container origin is converted to parent coordinates and its final frame origin is assigned once. It no longer receives an intermediate frame origin. Existing frame dimensions, top-leading targets, page geometry and text-container settings are retained. Earlier isolated coordinate probes are not App UI evidence, and this simplification is not claimed to fix the reported displacement. Source review and git diff --check only; no build or runtime verification of this revision.


## Text positioning trials reverted — 2026-10-30

The user confirmed the latest trial also failed and explicitly stopped work on this offset. Reverted both the actual-origin X/Y alignment addition and the subsequent size-first simplification. positionTextView is restored to its original body: vertical frame = pageRect; horizontal frame = pageRect expanded by the existing inset. No extra origin correction remains. The 51pt default, twenty-step shrink range, grid margins and other previously approved changes are preserved. Diagnostic artifacts remain historical evidence, not an active implementation or proof of a fix. Source/whitespace review only; no compilation or runtime verification. Do not resume this bug without a new user request.


## Fix PingFang UI VF sidebar preview clipping — 2026-10-30

The user selected and explicitly authorized the final workaround after controlled independent-app tests. `GAGlyphView.drawRect:` now fills the supplied `dirtyRect` with exactly transparent color under Normal / Source Over before each original glyph draw, with separate graphics-state save/restore. Glyph size, position, overflow policy, native row appearance and text rendering are preserved. No additional invalidation, view/layer, outline renderer, geometry calculation or one-time state is added.

PingFangUISC-Medium.ttf clips right-side preview strokes as wdth increases, while scrolling away/back restores them. The user verified full-product copies 71 (projected ink union) and 72 (clip bounding box), then standalone 73 modes self.bounds / dirtyRect / clip bounds. Diagnostic 74 established that filling only on the first thumbnail or parent-cell draw does not persistently work; only filling dirtyRect before every glyph draw passed. The chosen implementation follows that successful operation directly. No comparative performance measurements were taken.

A private-font head.xMax experiment establishes dependence on design-wide bounds, but OpenType permits nondefault VF outlines beyond those bounds. The precise internal CoreText/CoreGraphics/AppKit mechanism remains unconfirmed; the fix is a tested compatibility workaround, not proof of malformed font data or a particular cache bug. The installed font was never changed.

The integrated product compiled for arm64 + x86_64 and passed ad-hoc signature verification after removing Finder metadata from the generated app. That build was not subjected to a new product UI test; behavioral acceptance above refers to the user's reported diagnostic tests. No commit/push. See [collaboration lessons](COLLABORATION-NOTES.md) and [diagnostic artifacts](../diagnostics/pingfang-ui-width/README.md).


## OS/2 typographic page metrics — 2026-10-30

Without `vmtx`, the sidebar thumbnail, All Glyphs cell and single-glyph page (when the font has no vertical metrics) now use OS/2 typographic metrics instead of CoreText ascent + descent: page height = `sTypoAscender + |sTypoDescender|`, baseline = `|sTypoDescender|` in font units. `sTypoLineGap` is not included. The glyph's advance width, ink and the single-glyph page for fonts with `vmtx` are unchanged; Multi-Character and TextKit layout are not touched.

MVAR `hasc`/`hdsc` are applied at the current axis coordinates (fvar/avar normalization already used for FeatureVariations and GPOS). The metrics are calculated once per coordinate document and stored on its `GAFontBox`; axis changes rebuild the document and invalidate the page caches. No per-glyph table reads or extra caches were added. Fonts without usable OS/2 (shorter than 72 bytes, or a non-positive typographic height) keep CoreText ascent + descent; malformed MVAR data leaves the static OS/2 values. No local MVAR font has `hasc`/`hdsc`, so that path was verified with a synthetic MVAR font.

Representative page heights before → after (font units): Helvetica 2048 → 1884; PingFang 1400 → 1000; Hoefler Text 2000 → 2500; Source Han Serif 1437 → 1000; Arial Black 2888 → 1900; ZapfDingbats 2029 → 2048; Wingdings 2273 → 1999; Futura100CHI and I.Ming unchanged. A survey of 898 local faces found seven without OS/2 (Courier, AppleGothic, AppleMyungjo, LastResort and other Courier faces) and seven with a positive `sTypoDescender` (Arial Black 434, Wingdings 420, Kailasa 1366, ZapfDingbats 492 and others). Positive descenders are treated as depth (`|desc|`); the literal `asc - desc` would give Arial Black a 1032-unit page.

CoreText itself applies MVAR `xhgt`; it applies `hasc`/`hdsc` only when `fsSelection` bit 7 (USE_TYPO_METRICS) selects OS/2 typo metrics. With a synthetic MVAR font and that bit set, CoreText reports 1060/−190 units at wght 900, matching this implementation. `vmtx` vertical advances still come from CoreText at the current coordinates, and CoreText applies VVAR to them (verified with synthetic VVAR fonts in TTF and CFF2); our TSB still reads raw table bytes and does not follow VVAR `tsbMap` (sampled fonts have tsbMap 0).

Verification: universal arm64 + x86_64 build with 0 warnings; a standalone CLI probe checked the listed fonts, the vmtx path and the synthetic MVAR font at wght 100/500/900. No product UI test was run; GUI acceptance remains with the user. No commit or push.


## Cache the single-glyph page at variant changes — 2026-10-30

`GABoundingBoxView` now computes `pageForVariant:usesVerticalMetrics:YES` in `setVariant:` and keeps the resulting `GAGlyphPage`; `drawRect:` uses that value. The page is in font units and depends only on the variant's font instance and glyphs, not on view size, zoom, inset or metrics visibility. Axis and selection changes supply a rebound or new variant object, so the cache refreshes at the same points as before without per-frame page computation.

Measured cost of the removed call (warm, 200 repetitions, this machine): PingFang 4.7µs/call, Source Han Serif 1.8µs, PingFangUISC 1.5µs, Helvetica 0.9µs. CoreText's table access is much cheaper than the table size suggests, so the earlier concern about copying the whole 198KB vmtx on every frame was overstated: this is a small structural improvement, not a performance fix. No behavior or visual change.

Verification: universal arm64 + x86_64 build with 0 warnings; ad-hoc signature verified. No GUI test. No commit or push.


## VVAR tsbMap and vertical translations — 2026-10-30 (probe)

Built synthetic VVAR `tsbMapping` variants on PingFangUISC (TSB delta +100 at wght 900, −50, and a zero control) plus a static-TSB +300 copy; verified the modified tables at runtime with `CTFontCopyTable` (VVAR present, patched vmtx TSB visible). `CTFontGetVerticalTranslationsForGlyphs` returned `(-advance/2, -sTypoAscender)` in every case: static TSB 147 → 447 did not change it, and VVAR tsb deltas +100/−50 did not change it. The API is TSB-agnostic — its vertical origin is font-wide, not per-glyph TSB. It therefore cannot be used to read varied TSB, and it cannot establish whether CoreText's vertical layout applies `tsbMap`; that would need an offscreen vertical-layout or rendering comparison.

The same VVAR builder's `advanceHeightMapping` was previously confirmed to change vertical advances (1000 → 1200 units), so CoreText does read VVAR. The local VVAR faces (six) all have `tsbMap` 0. No product change.


## VVAR tsbMapping for the single-glyph page — 2026-10-30（过时，更新请看「Single-glyph page uses CoreText's vertical origin」）

After the VVAR probe, the user approved the TSB-only scope. The single-glyph vmtx page now adds the VVAR `tsbMapping` delta to the vmtx top side bearing before computing the baseline. Vertical advance still comes from CoreText, which applies VVAR; `vOrgMapping`, `bsbMapping` and `advanceHeightMapping` are not parsed by us. The delta uses the current axis coordinates with the same fvar/avar normalization and ItemVariationStore evaluator as MVAR/GPOS, for the variant's first GID (the page's TSB source). No local font has a nonzero `tsbMap`, so existing fonts are unchanged.

Implementation: a DeltaSetIndexMap format 0/1 reader in `GAVariation.cpp`; VVAR header, `tsbMapping` and store parsing in the engine `Resource`; `GAFontBox` retains the engine and exposes `topSideBearingDeltaForGlyph:`; `pageForVariant:` adds the delta. The engine does not retain `GAFontBox`, so there is no cycle.

Verification: synthetic `tsbMapping` +100/−50 at wght 900 moved the page baseline 139 → 39 / 189 units; wght 100/500 and the zero-delta control stayed 139; Source Han Serif (`tsbMap` 0) stayed 120/58; an advance-only VVAR font kept page height 1200 and added no TSB delta. Universal build 0 warnings; the ZIP's extracted app passes strict signature verification. No GUI test; no commit/push.


## GAFontBox API encapsulation — 2026-10-30（过时，更新请看「Single-glyph page uses CoreText's vertical origin」）

The typo metrics, five-argument initializer and `topSideBearingDeltaForGlyph:` are page internals used only by `GAFontDocument` and `pageForVariant:` in `GAFontEngine.m`; external views use `GAFontBox.font` only. They moved to a private class extension, and the public `GAFontBox` header now exposes just `font`. `pageForVariant:` also reads `hasTypoMetrics` and the absolute typo descender once instead of repeating them.

No behavior or page-value change. Verification: universal build 0 warnings; the probe still reports PingUISC `H` 139, synthetic tsb +100/−50 39/189, SHS 120/58, Helvetica 1884/348, Hoefler 2500/636, Arial Black 1900/434, Courier 2048/504, and the advance-only VVAR font 1200/339. The ZIP's extracted app passes strict signature verification. No GUI test; no commit/push.


## Single-glyph page uses CoreText's vertical origin — 2026-10-30

Following the VVAR probe, the user approved replacing the TSB-derived page origin. The single-glyph page now uses the current CoreText vertical advance for height, `CTFontGetVerticalTranslationsForGlyphs` for the vertical origin, and `baseline = height - origin`; width and ink remain current-instance. The vmtx TSB read, VVAR `tsbMapping` parser, DeltaSetIndexMap helper, `GAFontBox` engine reference and delta plumbing were removed. This supersedes the earlier 2026-10-30 VVAR tsbMapping entries in this log.

Evidence: PingUISC GID 144 has translation origin 860 at wght 100–900, while the old TSB+ink origin drifted 838→879; the new baseline is 140 at every weight, so the centered glyph stays centered. Source Han Serif exposes per-glyph VORG through the translation (GID 737 = 857, GIDs 41/22931 = 880); the old TSB+ink origin drifted to 862/904/942 at wght 900. A synthetic VVAR advance font changes the CoreText vertical advance 1000→1200 while translation and ink stay fixed; the new page uses height 1200 / origin 860 / baseline 340. Synthetic VVAR tsb +100/−50 leaves every CoreText metric identical, so the new page ignores TSB variation (baseline 140).

Behavior changes: GID 144 remains centered at all weights; Source Han Serif `永` wght 900 now uses baseline 120 instead of 58, with ink top 891 above its VORG origin 880 (the font's actual metric; the single view does not clip ink). TSB variation is intentionally not honored. Universal build 0 warnings; the ZIP's extracted app verifies. No GUI test; no commit or push.


## Bitmap-only fonts bypass OS/2 typo metrics — 2026-10-31

NISC18030.ttf (GB18030 Bitmap) has no `head`, `hhea`, `vhea` or `vmtx`; only `OS/2`, `bhed`, `bdat`, `bloc`, `cmap`, `maxp`, `meta`, `name` and `post`. CoreText synthesizes upem 2048 and ascent/descent 2304/256 units, but OS/2 `sTypoAscender`/`sTypoDescender` are 12/−4 — 16px bitmap pixel values, not design units. Treating them as font units produced a 16-unit page with baseline 4 while the glyph's advance and ink are 2048 units, so the sidebar and All Glyphs views showed the glyph far above the page.

`typoMetricsAscender:descender:` now requires a `head` table of at least 54 bytes with a nonzero upem before using OS/2 typographic metrics; otherwise it returns NO and the page falls back to CoreText ascent + descent. NISC now uses page 2048×2560, baseline 256 and ink 2048, with 256-unit top and bottom gaps. Fonts with `head` keep OS/2 typo metrics; existing values are unchanged (GID 144 1000/140, SHS `永` 120, Helvetica 1884/348, Arial Black 1900/434). Only one local face lacks `head`.


## Stable roots and lazy missing-GID resolution — 2026-11-02

The user reported that Futura100CHI punctuation changed base GID/name when Han characters were added beside it, while retaining the input Unicode badge. The checked source differed from GLOSSARY's previously claimed stable-root/temporary implementation: discoverContent shaped each baseline with default features, and applyRawResult supplied the input Unicode when that shaped base had no encoding. Missing layout GIDs had only an exact-row lookup and no resolver.

The user authorized a stable prepared cmap/UVS or literal-seed root, direct primary candidates and first-formed composition roots; subsequent outputs are resolved lazily on a missing multi-view click. Change records retain predecessor clusters. An on-demand replay captures actual input/output buffers, checks the final GIDs and full source span against the click, and finds the nearest existing ancestor at that span. Fallback traverses existing single-/multi-GID/composition sources with direction preference, then shortest path, then sidebar order. One temporary row is inserted below one parent with a secondary name; no group/query candidate is mutated. TextKit rendering was not edited.

The local Futura100CHI-Var.ttf reports 9588 = uniFF0C, 9595 = uniFF0C.loclCHI, 9590 = uniFF0C.loclCHI.jump and 9609 = uniFF0C.loclCHI.vert. The merged catalogue's rlig edge from 9595 to 9590 is specifically lookup 74, introduced by wght FeatureVariations records replacing an empty base rlig program; vert/vrt2 use lookups 71/72 from 9595 to 9609. Calling the former an ordinary default rlig output without checking FV metadata was insufficient. Historical VF discovery requirements remain recorded in the 2026-10-25 entry. No name-based or VF-specific candidate exception was introduced. After discussing alternatives, the user reported that the observed contextual .jump behavior and click-to-show temporary result were logical and accepted the current behavior.

A focused model probe found root 9588 and direct variant 9595 for comma alone and with a Han neighbor on either side; resolving 9609 selected parent 9595. The user subsequently reported manual acceptance of the interaction. No claim of tracing TextKit's own internal lookup decisions is made.

## Temporary row lifetime follows selection — 2026-11-02

The user reported that clicking elsewhere without selecting a new glyph, or adjusting an axis, could refresh the list and remove the selected temporary row. The cause was the shared invalidateLayoutLookup method cancelling background work and clearing the displayed result, plus unconditional removal on new group snapshots.

The user approved preserving the literal selected GID across axis changes, view switches, layout settings, zoom and unrelated refreshes, even when TextKit begins displaying a different GID. Background cancellation now only cancels the unfinished request. The sidebar remaps the existing source with its existing text-edit mapping, matches group text/kind and complete parent GIDs, rebinds the temporary variant with the current document, and includes it in the common row builder and same-row refresh path. Structural changes use the existing scroll anchor restoration. A persistent row for the same child takes over without duplication. Explicit selection changes/deselection, source replacement/deletion, loss of the parent, pending activation or a different font clear the temporary result. rebindVariant preserves the temporary flag.

Validation: arm64 build completed without warnings; 23 headless retention checks covered public snapshot refresh at a new axis coordinate, literal GID/selection preservation, new parent/font binding, repeated refresh without duplicates, source-range shifts, invalid sources/parents, persistent promotion, pending activation, another selection and structural refresh with source-range remapping. The structural-path probe stubbed table reload and scroll restoration to verify dispatch through the existing anchor path; it does not establish real AppKit pixel offsets. No product view/window was initialized by that probe. Actual AppKit scrolling, focus and window interactions remain for user acceptance. No commit or push.


## Commit layout-click navigation only after the target is known — 2026-11-02

The user observed a brief sidebar jump before resolving a never-seen native GID and suspected that group centering could race the result. Source review found a concrete intermediate state: selectGlyphIDs cleared the previous temporary row before searching for the target; clearTemporaryGlyph selected/notified that old row's parent and rebuilt/restored the list. The result handler later cleared/rebuilt again and selected the actual target. The centering helper itself is synchronous on the main thread; no separately queued centering task was found.

The user approved leaving rows, selection, pending state and scroll untouched on an exact lookup miss, keeping asynchronous shaping, and committing only the final target (or base after resolution fails). Existing exact hits, new temporary results and base fallback now share selectVariant:inGroup:temporaryResolution:. It generates and verifies the final row sequence before changing state, suppresses intermediate table callbacks during any replacement, restores the existing scroll anchor, selects the final row, then invokes the unchanged group-centering/minimal-reveal helper once and notifies once. Replacing a temporary row never selects its old parent. The now-unreachable parent fallback in manual temporary cleanup was removed; manual selection/deselection still clears the old temporary row. Background cancellation/generation checks and previous temporary persistence behavior remain unchanged.


Validation: arm64 build completed without warnings. A headless probe passed 41 checks of exact lookup misses, temporary-to-temporary replacement, existing-row hits with shifted indices, failed-resolution base fallback, repeated selection, manual changes and explicit deselection. It simulated table callbacks during reload/selection and recorded only the final select/navigation/notification sequence; no old-parent transition occurred. The earlier 23 retention checks also passed after introducing the shared selection helper. Reload, scroll restoration and final navigation were stubbed in these probes, so real AppKit visual smoothness remains for the user's acceptance. No App launch, commit or push.


## Combining-cluster presentation and recent-history diagnosis — 2026-11-02

The user asked about combined Thai/Latin candidate grouping, removing irrelevant native input menus, adding explicitly saved plain-text samples and recent documents disappearing after changing app copies. No product source was edited for this investigation; menu/presentation/storage proposals await scope confirmation.

Headless model/CoreText measurements (200pt): Thonburi face 0, U+0E19 U+0E49, is one composed-character group with root [53,1609] (nonuthai/maithothai.key) and AAT result [1615]. ThemeX Shin Go face 0, U+00EA U+0304, is one group with 11 rows: root [202,129], direct component substitutions retaining the companion GID, and ccmp result [23064]. Literal root positions are (0,0),(124,0), while CoreText produces one GID 23064 at (0,0). NFD input U+0065 U+0302 U+0304 prepares the same nominal GID sequence. Thus grapheme grouping, scalar counts, literal component sequences and a single composed glyph are distinct; the literal sequence preview must not silently reshape into a different GID just to resemble the final typeset result.

The user explicitly authorized crossing the Applications and workspace builds in the UI. Both are bundle ID com.zonz.GlyphAtlas, 1.4 / build 5, and use system recentDocumentURLs; the legacy GARecentFontURLs preference is unused by both binaries. Native recent history survives a same-path relaunch and a byte-identical copy to a new /tmp path (executing path verified with ps). The Applications and workspace binaries have different ad-hoc designated requirements. Unified log provides the root cause: sharedfilelistd says owner verification failed, removes all recent items, and assigns the list to the newly launched binary's cdhash. This is a change of code identity, not a general claim that moving an identical app always clears the history. Direct SFL file reads remained TCC-protected even with shell escalation; unified log and UI provided the necessary evidence instead.

The native recent entries present before the test (ThemeX King Gothic.ttc and Futura100CHI-Var.ttf) were restored by reopening the same known font files. Thonburi.ttc is the additional test entry. All new font windows were closed and the workspace build was returned to its initial open panel; the temporary copy is not left running. Evidence: diagnostics/combining-and-recents-2026-11-02/combining-metrics.txt and recent-ownership.txt.


## Input menus, saved text and persistent recent fonts — 2026-11-02

The user explicitly approved items 2–4: remove only the specified native input-menu categories; add a single Saved Text / 常用文字 submenu after the Edit/Select All group, shared with the sidebar context menu; and persist recent fonts in fixed app preferences while continuing native recent-document registration. Combining-grapheme catalogue/presentation (item 1) was not changed.

`GAInputMenus` filters native categories using public child actions for Font, Spelling and Substitutions, and AppKit's localized InputManager AutoFill title (the category exposes no public action). Sidebar `GASearchFieldEditor.menuForEvent:` removes Font/AutoFill and adds Saved Text; prepareFieldEditor sets usesFontPanel NO after native cell setup. VF numeric cells supply a retained per-cell GANumericFieldEditor through fieldEditorForView:, disable enabledTextCheckingTypes in native setup and remove Spelling/Substitutions/AutoFill. Edit filters AutoFill in menuWillOpen:. Remaining native editing actions stay intact.

Saved Text uses `GASavedTexts`, an array of exact plain model strings. It preserves Unicode sequences, spaces, tabs and LF, excluding explicit-GID attributes; the existing input pipeline's CR/CRLF-to-LF handling remains. The first item saves/removes the exact current text, then entries newest first; empty input cannot be saved, whitespace-only input can. Display previews mark whitespace/newlines, truncate on a composed-character boundary and retain full tooltip/payload. Insertion replaces the whole field through the existing native insertText path, preserving analysis callbacks and Undo. Four strings were added to all 14 existing localizations.

A real two-window test found that resolving the destination again after native menu tracking could insert into the first window instead of the window that opened Edit. The Saved Text submenu now retains a weak controller snapshot: main Edit binds at parent-menu update; context menus bind when created. Submenu data refresh does not change that target. Real retest inserted into Thonburi, leaving the earlier Futura window unchanged.

Recent menus read `GAPersistentRecentFontPaths`; first launch imports native URLs only if this key does not exist. Successful opens deduplicate/move to front and cap at the system recent count, still registering natively. Clear Menu clears both lists. Missing/non-font files remain filtered from display. The original known ThemeX King Gothic and Futura100CHI entries plus the prior Thonburi test entry were migrated before launching the changed ad-hoc signature; no legacy GARecentFontURLs import was added. After a future system clear, only the app list remains authoritative; old builds do not gain the fix.

Validation: arm64 builds completed without warnings, and diff whitespace checks passed. A headless native-menu/defaults probe passed 69 checks, covering action-category filtering/separators, the real numeric cell's custom editor and text-checking setup, exact Unicode including distinct NFC/NFD strings, whitespace, save/remove, contextual owner routing, shared defaults, recent order/dedup/filtering and independence from native-list clearing. Native URL content-type lookup required execution outside the shell sandbox. These tests construct objects and do not establish real context-menu pixel/focus behavior. UI automation could not visibly open the sidebar/numeric right-click menus; those actual context interactions remain for manual acceptance. Main Edit's AutoFill removal, save/remove preview, exact multiline/combining-text replacement, native Undo, restart persistence and two-window destination were observed in the app.

Applications/workspace cross-check: after quitting the fixed build, `/Applications/Glyph Atlas.app` displayed an empty native recent list; after quitting it and restarting `dist/Glyph Atlas.app`, all three app-persisted recent fonts were still visible. The Applications app was not overwritten. Test text was removed from Saved Text, all test font windows were closed, and the fixed build was returned to the initial open panel. No commit or push.


## Combining-group UI discussion and input-menu feedback — 2026-11-02

The user reports AutoFill remains in both sidebar and VF context menus, and asks whether to remove the separator between Paste and Saved Text. AutoFill context filtering remains incomplete despite the earlier constructed-menu tests; the exact cause has not been established. Current filtering skips items without a submenu and runs from menuForEvent:, so actual menu shape/timing needs observation before claiming a fix. No product code was changed in this discussion.

The user asks to jointly decide combining-group presentation, considering ffi-like composition nodes, differing Backspace behavior, encoded composite glyphs and side-by-side previews. Current source groups use Foundation composed-character sequences; candidate.isLigature is set only when the match crosses those groups (`first != last`). Both the Thai and Latin examples are single source groups, so two-GID roots, partial component replacements retaining the companion GID, and the merged result remain in one ordinary group. Positions are computed for those literal GIDs using the project's positioning engine, not by allowing TextKit to reshape the preview. This behavior follows the current data model; it is not evidence of a separately approved one-row/multiple-glyph UI decision.

Primary-source checks: Unicode UAX #29 distinguishes grapheme clusters from font ligatures and explicitly permits editing/deleting within a cluster. Backspace behavior and Character Viewer grouping therefore do not determine glyph grouping. Unicode lists U+1EBF as canonically equivalent to U+00EA U+0301; local normalization confirms Thai U+0E19 U+0E49 and U+00EA U+0304 remain multi-scalar under NFC. OpenType ccmp supports many-to-one composition using GSUB type 4 and one-to-many decomposition using type 2; GPOS can instead attach marks while keeping multiple GIDs. Whether a glyph has a cmap encoding affects direct character mapping, not whether a substitution result may be browsed. UI proposals remain discussion, not implementation approval. Sources: https://www.unicode.org/reports/tr29/ ; https://www.unicode.org/Public/UCD/latest/charts/nameslist/1e00/ ; https://learn.microsoft.com/en-us/typography/opentype/spec/features_ae#tag-ccmp ; https://learn.microsoft.com/en-us/typography/opentype/spec/gpos .


## Browse nominal components separately from compositions — 2026-11-02

The user agreed to the component/composition presentation proposal and, after clarifying that “source relation” means grouping and operation scope rather than invented font labels, explicitly requested implementation. This round uses branch codex/combining-glyph-components and preserves all previous uncommitted work. The sidebar/VF AutoFill issue and Saved Text separator were not changed in this round.

Previously GATextPreparation assigned every glyph in a grapheme the full grapheme span. That made a partial component substitution retain untouched companions in its row and prevented in-grapheme composition from using the existing multi-source composition path. Preparation now maps each normalized nominal scalar to the exact original UTF-16 span by matching canonical decompositions. UVS spans stay with their base. Overlapping sources remain an atomic sequence, including multiple prepared GIDs from a single unsupported precomposed input scalar; independently editable sources become separate roots. NFC/NFD font-support choice remains the existing one. A single-scalar fast path avoids per-character decomposition maps for ordinary input.

GARawScanResult retains disjoint nominal sourceRanges; raw candidate indexing and GATextQueryModel projection use GAGroupsForScanResult. Existing substitution discovery, feature order, primaryChange rules and composition construction now operate on these component sources: root/component alternates no longer retain unchanged neighbors, actual cross-component matches become composition rows, and their root's direct outputs remain browsable. True one-source/many-GID substitution outputs remain one complete candidate. The engine/catalog/source-label generators and GAVariantCellView source-label rendering were not changed; ccmp/morx/ital/vrt2 remain their actual labels with no synthetic liga/composition label.

Literal selection ranges may cover a component inside a grapheme. Preparation normalizes independently at selection boundaries, validates whole component coverage, and replaces only those inputs; a newly appended combining mark cannot absorb an existing literal seed. The existing activation source-range and payload paths then naturally target a letter, a mark, or the complete composition. Plain encoded output still inserts the glyph's first existing Unicode mapping; unencoded output stores the selected GID run, as before.

Native rendering remains TextKit 2. The snapshot builder recombines ordinary sidebar components into their original grapheme layout units for the existing missing-glyph/quote rules, while preserving partial literal-seed ranges. The raw native text is unchanged. Source mapping uses original layout ranges, allowing exact native composed GID clicks to find the new composition group. No changes were made to GAMultiGlyphView rendering/hit extraction or the asynchronous atomic-selection/temporary-row implementation.

Measured data: Thonburi น้ now has nonuthai GID 53 at [0,1), maithothai.key GID 1609 at [1,2), and a morx composition GID 1615 at [0,2), which remains unencoded. ThemeX Shin Go ê̄ has letter GID 202 and its 3 direct variants, mark GID 129 and its 6 direct variants, then composition GID 23064 (ccmp), 23079 (ital), 23090 (vrt2). For e + U+0302 + U+0304, the letter component covers [0,2), the macron [2,3), composition [0,3). ê + U+0301 continues to prepare the encoded nominal GID 23065 as one root.

Validation: arm64 build completed without warnings; 116 headless checks passed for real-font component rows, exact labels, NFC/NFD source mapping, source partitions including reorder/Hangul/emoji/surrogate/UVS/newlines, partial seeded queries, actual activation/pending ranges with a stub input, unchanged native text/grapheme snapshots, one-to-many fixtures and existing composition machinery. Earlier retention (23 checks) and atomic selection (41 checks) probes also passed; the retention probe was adapted to the new scan-projection API. These are model/snapshot checks, not real TextKit or UI validation. No app/windows launched this round; actual preview, click, scroll and native editor behavior remain for manual acceptance. Evidence: diagnostics/combining-components-2026-11-02/. No commit or push.


## ThonburiUI Sara Am sequences and non-scrolling grid redraw diagnosis — 2026-11-02

The user accepted the ê̄ component presentation, asked why Thai still has joined-looking multi-GID rows, and reported All Glyphs zoom appearing stuck/misplaced when a large window fits the inventory. This turn diagnoses both issues; production source is not changed.

The screenshot is น้ำ (U+0E19 U+0E49 U+0E33), not the previous two-scalar น้ example, and the resource is .ThonburiUI, not supplemental Thonburi. The local /System/Library/Fonts/ThonburiUI.ttc face 0 matches the screenshot: น root GID 53; ้ root GID 11 with ccmp 120/121/122; ำ root GID 82 with ccmp output [21,81]; ้ำ composition [152,81] and its ccmp alternate [153,81]. Direct parsing of this font's ccmp confirms lookup 1 type 2: 82 → [21,81]; lookup 2 type 4: [11,21] or [21,11] → 152; [122,148] or [148,122] → 153. Thus the unchanged GID 81 still belongs to the original single encoded Sara Am, partly consumed by a later ligature. Retaining it in the resulting source-scope candidate prevents dropping half the source character; this is not the old practice of appending an unrelated untouched letter beside every component alternate. The literal sidebar preview adds no dotted-circle character; it draws the selected font GIDs. CoreText measurement for full น้ำ produced [53,152,81]. The same UI font's two-scalar น้ produces [53,120], unlike supplemental Thonburi's single-GID 1615. No claim of a universal Thai glyph count is warranted. Unicode Thai rendering reference: https://www.unicode.org/versions/Unicode16.0.0/core-spec/chapter-16/ ; nameslist: https://www.unicode.org/Public/UCD/latest/charts/nameslist/0e00/ .

A concrete grid invalidation defect was found in GAAllGlyphsGrid.updateLayoutForWidth:. It always updates cell/column geometry, but only calls setNeedsDisplay:YES inside the document-frame-size change condition. A document shorter than the viewport is padded to viewport height, so zoom can change cells/columns while keeping both frame dimensions fixed and scheduling no grid redraw. This explains a stale full image and later partial redraw using newer positions; it does not establish that the main thread deadlocks.

Headless probe with a stub viewport, 250 entries, width 600pt: at viewport height 2000pt, a 1.00→1.12 scale changes cell 44→49.28pt and columns 11→10 while frame stays 600×2000pt; redraw calls = 0. At height 400pt, the same inventory changes document height 1224→1460pt and redraw calls = 1. A 20-entry, 600×800pt case likewise has 0 redraw calls. A candidate edit, compiled only from a /tmp copy, moves the existing invalidation outside the frame-change condition; all three cases then schedule one redraw. No production edit or app launch occurred. The probe records calls to setNeedsDisplay; its NSView is not in a real window, so the inherited needsDisplay property is not evidence of real painting. Actual GUI rendering remains untested. Proposed scope is this localized grid redraw change only, preserving zoom/reflow/scroll policy; awaiting the project's required code-scope confirmation. Evidence: diagnostics/thai-ui-and-grid-redraw-2026-11-02/.


## Redraw the grid even when the document frame stays fixed — 2026-11-02

The user explicitly approved the localized All Glyphs redraw scope. Branch codex/all-glyphs-redraw preserves all prior uncommitted work. GAAllGlyphsGrid.updateLayoutForWidth: now calls the existing setNeedsDisplay:YES after, rather than inside, the frame-size change condition. This is the only production source change in this round. It does not change cell scale, column/row computation, document sizing or scroll preservation, and does not modify the Thai candidate data discussed above.

The actual production source was compiled into the same isolated redraw probe: all three cases (250 entries in 600×2000pt / 600×400pt viewports, and 20 entries in 600×800pt) now issue exactly one redraw request when scale changes 1.00→1.12. Frame and column numbers remain the same as before; only missing invalidation is repaired. Arm64 build completed without warnings; diff whitespace check passed. No app or real window was launched, so real resize/zoom appearance remains for user acceptance. Evidence: diagnostics/thai-ui-and-grid-redraw-2026-11-02/grid-redraw-verified.txt. No commit or push.


## Late AutoFill menu filtering and Saved Text separator — 2026-11-02

The user asked for an opinion about the repeated U+0E32 badges in the Thai multi-GID rows, and explicitly requested completing AutoFill removal and removing the upper separator before Saved Text. Branch codex/input-menu-autofill preserves all earlier uncommitted work. Unicode badge behavior was investigated but not changed: decorateVariant unions, deduplicates and sorts cmap values across every GID in a row, so [21,81] has {0E32,0E4D}, [152,81] and [153,81] have {0E32}. The latter value belongs only to shared GID 81, not to unencoded GID 152/153 or to the whole result. The presentation loses component association. Any future adjustment must retain actual per-GID cmap mappings and must not substitute source-text encodings for unencoded outputs.

An actual NSTextView.menuForEvent: probe returned the native menu with Cut/Copy/Paste/Share/Spelling/Substitutions/Speech but no AutoFill, whereas the user sees it in the displayed popup. The existing filter therefore runs before this late system entry exists. Current AppKit InputManager.loctable contains AutoFill translations 自動填寫 for zh_HK/zh_TW. The old submenu-only guard could also miss title-only lazy items. CUA read the user's current .ThonburiUI window and menus but repeated right-click attempts via AX and coordinates could not open a context popup; no claim of end-to-end native context validation is made.

GAConfigureInputMenu now applies the early category filter and attaches a retained, per-menu GAInputMenuDelegate adapter through an associated object. The adapter keeps the original delegate weakly, forwards its optional methods, calls its menuWillOpen: first, then hides late AutoFill and redundant visible separators. GAHideAutoFillMenuItems does not remove/insert items during menuWillOpen:, respecting the current API's no-structure-change guidance. Main Edit uses the same late hiding method. The initial filter recognizes AutoFill by AppKit localization even without a submenu. Sidebar and numeric editor overrides now install this late filter. The Saved Text insertion helper no longer inserts or skips an upper separator: the custom item follows the last native editing command and existing lower separators stay below it. The explicit main Edit separator before Saved Text was removed.

Validation: arm64 build completed without warnings. A headless 68-check probe used the real native text menu, simulated late injection with/without submenu, verified unchanged item counts during late filtering, original update/open/close forwarding, adapter lifetime and repeated setup, the real numeric editor's menu hookup, and sidebar/main separator placement. This runtime used English; a bundle-wrapped localization probe aborted before results and is not counted as localization validation. No current font window was closed or input replaced. The new binary requires relaunch before testing the actual popup; user GUI acceptance remains necessary. Evidence: diagnostics/input-menu-autofill-2026-11-02/. No commit or push. Apple API references: https://developer.apple.com/documentation/appkit/nsmenudelegate/menuwillopen%28_%3A%29 and https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/MenuList/Articles/DisplayContextMenu.html .

## AutoFill follow-up: native control investigation — 2026-11-02

The user explicitly chose to retain current Unicode badges. AutoFill remains in context menus; the main Edit item is visually hidden but still appears in Help search, with an anomalous bottom-left display. No production code changed in this investigation. Current code leaves hidden items in the menu tree; this is consistent with the search symptom, but the exact Help indexing and positioning cause is not established.

Apple documents NSMenu.allowsContextMenuPlugIns as a public, default-YES control for appending contextual menu plug-ins. Disabling it is a candidate for an isolated actual-popup experiment, not a verified AutoFill fix; it can suppress other system services and is documented for context menus, not main-menu indexing. The modern NSAutoFillRequiresTextContentTypeForOneTimeCodeOnMac Info.plist key controls delivered security-code suggestions only and is not evidence of a general AutoFill menu opt-out. Local CLI SDK is 15.2, so its header inventory alone cannot establish absence of newer APIs. No specific public switch removing only these AutoFill menu entries was established. Avoid extending the failed hidden-item approach or treating headless simulated injection as GUI proof.

Sources: https://developer.apple.com/documentation/appkit/nsmenu/allowscontextmenuplugins and https://developer.apple.com/documentation/bundleresources/information-property-list/nsautofillrequirestextcontenttypeforonetimecodeonmac .

## Retain native AutoFill menus — 2026-11-02

The user decided to stop removing AutoFill and retain its native behavior. Branch codex/restore-native-autofill preserves all earlier uncommitted work. Removed only AutoFill-specific title detection, early removal, late hiding, associated-object delegate adapter, its now-unused configure wrapper and main Edit menuWillOpen: hook/import. Sidebar and numeric editors directly call the remaining category filter. Font filtering in the sidebar, spelling/substitution filtering in numeric fields, Saved Text and its approved separator placement remain. No context-menu plug-in switch was introduced; Unicode badges remain unchanged.

Arm64 build completed without warnings and git diff --check passed. No GUI launch or tests; the rebuilt dist app requires relaunch for the current process to stop applying the old hiding hooks. No commit or push.

## Saved Text usage wording in README and Help — 2026-11-02

The user supplied the final informal Traditional Chinese wording: 「，還可以點右鍵找到『常用文字』記住目前文字或快速輸入之前記住的文字。」 and authorized translating the other languages. Branch codex/saved-text-help retains all previous uncommitted work. Appended the approved clause to the existing sidebar input bullet in README.md 使用, translated it in Usage, and updated Help.04 in all 14 locale resources. Kept each locale's existing Saved Text menu title; Traditional Chinese/Hong Kong Help matches README verbatim after stripping Markdown shortcut formatting. No additional Help paragraph or application behavior change.

Arm64 build and resource lint completed without warnings; git diff --check passed. Verified all 14 Help.04 values contain the locale's exact Saved Text menu title, and English/Traditional Chinese match README. No GUI launch, commit or push.

## Stage completion pushed to GitHub — 2026-11-02

The user requested publishing this stage with Terminal git rather than the GitHub connector. Committed the 40 reviewed source/resource/README files on codex/saved-text-help as 0ff2507 (Improve glyph candidate navigation and add saved text), preserving the user's final punctuation changes. Remote main was 03bb76a before publication. Direct git push origin HEAD:main succeeded (03bb76a → 0ff2507); no PR, merge, force push or release. Internal README/ notes, diagnostics and build artifacts remain ignored. Git network access required execution outside the sandbox after sandbox DNS resolution failed.

## Next-stage community suggestions: evaluation only — 2026-11-02

The user requests independent evaluation and preliminary UI proposals for adjustable line spacing, metrics hidden by default, and preview foreground/background colors. Their earlier replies are context, explicitly not decision guidance. Production code is deferred; no proposals in this entry are authorized implementation decisions.

Current source: multi-text sets paragraph alignment but no extra line spacing; the system TextKit layout remains the baseline. The metrics toggle defaults YES per window and draws the shadow page in single/multi views, not an ink-bounds outline; all-glyph grid does not use that toggle. Sidebar uses native NSSplitViewController/source-list materials, a large NSSearchField without search/cancel buttons, fixed 9pt side constraints and text insets, and a top constraint to window.contentLayoutGuide minus1pt.

Preliminary proposals for discussion: native/default spacing plus explicitly optional additional preview spacing (0 by default, em-relative, multi-text only, vertical mode acts between columns); consider metrics initially hidden with a remembered explicit user choice and a clearly named existing toggle; opaque preview-only foreground/background customization with system/default and neutral presets, two native color wells and reset, keeping UI chrome semantic. Consider a compact View > Preview… popover for preview controls, preserving current keyboard/menu shortcuts. These are design recommendations, not commitments to implement.

Primary design reference consulted: https://developer.apple.com/design/human-interface-guidelines/materials (standard materials in the content layer). No source edits, build, tests, commit or push in this discussion.

## Preview controls follow-up: native spacing and defaults — 2026-11-02

The user prefers line spacing controlled only by Shift-Option-Command +/- with hidden alternate menu entries shown by Shift-Option, retaining the term 邊界框. They propose Option alternates for explicit persistent defaults: view modes1–3 and flags4–7 (metrics, contextual alternates, ligatures, vertical writing); view-mode defaults are exclusive, boolean defaults must remain reversible. This is still design discussion. Colors should use submenu choices for each foreground/background (system/custom) rather than a settings panel. The latest question asks to compare native line-height and line-spacing results and recommend one.

Independent native NSTextView/TextKit2 measurements on this host (macOS14.8.7, SDK15.2; no app windows):40pt system font with wrapping CJK yielded6 horizontal lines of47pt. Default usage282pt and glyphOrigin.y39; lineSpacing10pt retained47pt fragments and glyphOrigin.y39, increased line starts to57pt apart, total332pt. lineHeightMultiple1.2 changed fragments to56.4pt and glyphOrigin.y48.4, total338.4pt. Both properties changed the vertical sample as well. Recommendation refined to additional native lineSpacing for this app, since it preserves natural per-line size/origin; optional em-relative keyboard steps are an app-side conversion to pt. lineSpacing is nonnegative, so decrease returns to0 and cannot tighten below natural layout; lineHeightMultiple can go below1 but changes the line box and may overlap glyphs. Evidence:diagnostics/preview-settings-design-2026-11-02/. No production code changes.

Apple documents lineSpacing in pt and lineHeightMultiple as a natural-height multiplier, not em. Taiwan and Hong Kong macOS support use 預設/設為預設; Traditional Chinese custom UI uses 自訂. Existing menu alternates already implement Option bounding-box zoom. The '+' key may require Shift on some layouts; verify shortcut distinction before claiming the added Shift alternate works. Suggested semantics (not yet accepted):normal commands affect current window; Option alternatives edit defaults for future windows, show saved-default checkmarks, and do not alter other existing windows. Factory defaults remain as current until explicitly overridden.

Sources:https://developer.apple.com/documentation/appkit/nsparagraphstyle/linespacing?language=objc ; https://developer.apple.com/documentation/appkit/nsparagraphstyle/lineheightmultiple?language=objc ; https://support.apple.com/zh-hk/guide/mac-help/mchlp1036/mac ; https://support.apple.com/zh-tw/guide/mac-help/mh26684/mac .

## Preview settings implementation checkpoint — 2026-11-02

The user authorized line-spacing steps of0.1×(A+D+L), negative spacing and Cmd0 reset; simplified colors to four choices (system plus glyph/background/bounding-box pickers); then explicitly accepted Control-Option-Command +/- and Control-Option alternate display after native tests showed Shift-Option-Command '+' conflicts with existing Option-Command '+' (Shift is consumed by the '+' character). They approved Option-Command1–7 defaults with future-window-only semantics. Suggested adjustment limits−0.9…+2.0 were stated and implemented; no contrary bound preference arrived. The user later explicitly required preserving the multi-text context menu's entries/count, publishing the checkpoint. After completion they authorize shutdown OR sleep; choose normal sleep, preserving open documents.

Branch codex/preview-spacing-colors implements signed integer steps−9…20, converting from the current native display font's CTFont ascent+descent+leading. Native TextKit receives the spacing; glyphs are not custom-positioned. Cmd0 clears spacing from any view. An independent negative−10pt test on14.8.7 preserved47pt line fragments while reducing start-to-start spacing47→37pt; vertical also worked. This contradicts the documented nonnegative restriction and must remain an explicit cross-version compatibility caveat, not a guarantee.

Per-window GAPreviewColors supplies three separate opaque overrides to right-side single/multi/all views. Native NSColorPanel edits the weakly bound originating window; Follow System clears all three overrides. Sidebar/default colors and shadow geometry remain. Color overrides are intentionally window-local, not persisted. GAViewDefaults stores the explicitly chosen mode and four flags; native Option alternates are valid without a font window and never alter existing windows. Factory behavior remains All Glyphs, metrics/context/ligatures on, vertical off until explicitly changed. Added14 new labels to each of14 locales, matching existing localized view/feature names. Only system View gains these commands; context menu stays ten root entries including separators.

Validation: arm64 build/resource lint without compiler warnings, strict signature verified after removing file-provider-added FinderInfo, diff whitespace clean. Native integration probe passed73 checks for signed/zoom-scaled spacing in both orientations, unchanged native GIDs, Cmd0 including latent state, palette sharing and window isolation, three exclusive defaults plus flag reversibility/new-window consumption, and production native shortcut dispatch including Shift needed for '+'. A separate four-check context-only run confirms the original ten entries and no new commands. Probes ran headlessly with no test preference writes (volatile argument domain and in-memory injected preference store); Launch Services logged a sandbox notification-registration diagnostic but checks passed. CUA opened only our empty Futura100CHI test window, read real menu entries and confirmed base layout restored. Repeated submenu/keyboard actions did not yield an observable color-panel tree, so do not claim end-to-end picker GUI acceptance from these attempts. Native color-panel launch/interaction remains user verification. Evidence:diagnostics/preview-settings-design-2026-11-02/.

## Published preview checkpoint — 2026-11-02

Committed the29 source/resource files as217ebf6409e2a805296aff36e03301e8b26bbeae (Add preview colors, line spacing and view defaults), then Terminal git push origin HEAD:main succeeded0ff2507→217ebf6. All new commands are system-menubar-only; the original multi-view context menu retains its ten root entries including separators (four targeted native checks passed). README.md and14 Help paragraphs were not changed in this feature round.


## Menu refinements, native input and directional pinch — 2026-11-02

The user reported that the earlier sleep attempt did not actually sleep: a permission prompt remained. Do not record successful sleep or retry an old sleep/shutdown instruction now that the user is awake. They reported old Control-Option-Command plus decreases spacing and minus is inert. The previous idealized event probe did not establish actual physical shortcut correctness; the cause remains unconfirmed. User reiterated existing Command +/- and Option-Command +/- work in real use; preserve them and do not infer a universal plus-key limitation from theoretical modifier concerns.

Explicit approvals: simplify spacing to Control-Command +/-; save sizes only for the current view (Single box inset, Multi box/text/spacing, All grid); clearing a matching custom size default removes stored values only. User requested adding future-window-only defaults for colors/alignment/fullscreen, correcting Bounding Box Color to shadow with shared inner/outer background and mixed Follow System state, main Edit Option deletion of Saved Text, and exploration of trackpad direction. These changes are on codex/menu-defaults-refinements from217ebf6.

Built a separate native Gesture Direction Probe, source/app under diagnostics/gesture-direction-2026-11-02/, unique bundleID. It reads indirect NSTouch geometry in native touch callbacks, scales normalized coordinates by device dimensions, and locks direction at magnification start. The user physically tested horizontal/vertical/diagonal and confirmed all three recognized. The user then explicitly authorized integration: horizontal box, vertical continuous line spacing, diagonal font, lock until release, keyboard still0.1 steps, single/all unchanged. The main app now uses that classifier. No main-app real gesture acceptance is claimed yet.

Spacing uses independent menu actions and a scoped GADropWindow.performKeyEquivalent route based on charactersIgnoringModifiers (+/= increase, -/_ decrease), Control+Command with optional Shift. Old Command and Option-Command routes unchanged. Multi spacing is now continuous adjustment[-0.9,2.0], converted from current ADL; keyboard adds0.1. Size default records use lineSpacingAdjustment. At investigation time GADefaultViewSizes did not exist in real app preferences; no migration of nonexistent old size records was added. Cmd0 resets current view to its saved settings, else factory. Removed reset interfaces made obsolete by this centralized behavior.

Added Option native alternates for Default Colors and Default Text Alignment, with unchanged submenu labels, and native fullscreen/default-fullscreen. Stored defaults affect future windows only; per-mode saved sizes applied on first activation. Main Edit Saved Text Option alternative deletes individual stored strings or clears all, leaves input intact; contextual saved text and ten-entry multi-view context menu unchanged. Colors now use Background both inside/outside, shadow uses Bounding Box role with existing alpha/geometry; Follow System has checked/mixed/unchecked states. All14 locales updated, Reset to Default Size replaces Actual Size (Taiwan回復／HongKong還原).

Validation: final arm64 build completed without warnings;14 resource lints and diff whitespace passed. An isolated headless native app with unique preference domain com.zonz.GlyphAtlas.RefinementsProbe.20261102 passed61 checks: native positive/negative spacing height, raw control-character minus / plus alias / Shift-plus routing, independent actions, context count, palette roundtrip and three states, inner/outer background plus actual shadow pixels, future-only colors/alignment/fullscreen preferences, per-view save/reset/clear/new-window initialization, gesture mapping and locking with constructed contact events, saved-text insertion versus deletion. No real app preferences or current GUI windows were modified. Initial shadow probe sampled outside the rendered shadow; scanning the complete bitmap established max green0.137255 and retained evidence at /tmp/GlyphAtlasRefinements-shadow.png, no production rendering change was made to satisfy the probe. The first sandboxed native executable aborted; escalated execution succeeded. Product/probe source under diagnostics/menu-refinements-2026-11-02/. These model/offscreen checks do not replace real keyboard, main-app gesture, native full-screen transition or color-panel acceptance. Native negative spacing remains unverified outside the measured host. No commit/push this round.

Official sources consulted: Apple Handling Trackpad Events (raw callbacks versus gesture handlers), NSMagnificationGestureRecognizer, Full-Screen App Programming Guide, key equivalent masks, and localized macOS support wording: https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/EventOverview/HandlingTouchEvents/HandlingTouchEvents.html ; https://developer.apple.com/documentation/appkit/nsmagnificationgesturerecognizer ; https://developer.apple.com/library/archive/documentation/General/Conceptual/MOSXAppProgrammingGuide/FullScreenApp/FullScreenApp.html ; https://support.apple.com/zh-tw/guide/mac-help/mchlp1011/mac ; https://support.apple.com/zh-hk/guide/mac-help/mchlgtd_web01/mac .


## Whole-palette defaults, shadow opacity and gesture thresholds — 2026-11-02

User confirmed Control-Command +/- works on their hardware. Their proposed explanation (more than two modifiers fail) is not established; this version also has a new scoped raw-key route, so do not present a system modifier-count limit as fact. Existing Command +/- and Option-Command +/- remain unchanged.

User reports custom default colors work for one new window but fail for a subsequent window; arbitrary colors/fonts, no known intervening close or Follow System action. An independent headless baseline probe using old default-picker action, then constructing three consecutive controllers, passed13 checks: stored palette not consumed and all three inherit. Read-only defaults export did not show GADefaultPreviewColors at inspection time, including outside sandbox; this does not establish the cause of the reported episode. User will retest and supply additional details; do not claim the disappearance fixed by new workflow or continue speculative diagnosis. No current app window, input or app preference was modified by probes.

Explicitly approved initial per-role “Current XXX” direct-save change, shadow-only alpha slider with fully honored custom opacity (system remains light18% / dark58%), removal of default fullscreen feature retaining native command, and thresholds horizontal±30° / vertical±15° (user corrected proposed15° vertical from10°). Later user proposed one Current Colors command instead of three; explicitly approved whole-palette save and removed the proposed separator. Final default submenu is exactly Follow System, Current Colors (two entries). Current Colors saves the current palette representation atomically, retaining which roles follow system, shadow alpha, and future-window-only semantics. It replaces all previous default roles rather than merging per-role snapshots. Normal color menu remains Follow System / separator / glyph / bounding box / background, and only it opens the picker. This supersedes the previous per-role default picker in the menu-refinement entry.

On new local codex/color-defaults-shadow-refinements, preserving earlier uncommitted features, removed editingDefaultColors/editingPalette state and preference writes from NSColorPanel callbacks; only explicit Current Colors / default Follow System change saved colors. GAPreviewColors preserves alpha only for BoundingBox role; GABoundingBoxShadowColor supplies native-appearance-dependent black18%/58%. GADrawPage resolves the selected shadow under its supplied appearance, uses its full alpha without an extra multiplier, and retains existing geometry and shared inner/outer background. Fullscreen native command remains, its default alternate/startup toggle/key/helper/localizations are removed. Apple's fullscreen shortcut was observed by user as Globe-F rather than our Control-Command-F, so reliable alternate pairing was not established; no root-cause claim about AppKit rewriting behavior beyond the observed mismatch. Pinch classifies ≤30° box, ≥75° spacing, remaining font, still locks at magnification start. Fourteen locales use Current Colors (繁中「當前顏色」). No root README.md/Help change requested.

Validation: final arm64 product compile/resource lint passed without warnings; first earlier attempt used nonexecutable ./build.sh and failed before building, rerun through bash. One intermediate bundle signing failed because file provider reattached root FinderInfo; final build signed, strict verification passed after deleting that exact metadata attribute. Final independent isolated probe passed42 checks for direct whole-palette saving, consecutive3 window inheritance, preserved system roles, replacing previous snapshot (no stale merge), existing-window isolation, two-item/no-separator defaults menu, only3 current pickers, no fullscreen default action, default light/dark shadow alpha, custom opacity roundtrip and offscreen shadow pixel response (zero / quarter / half; custom independent of theme), and29°/31°/70°/74°/76° physical angle classification. Evidence diagnostics/color-defaults-followup-2026-11-02/; unique preference domain com.zonz.GlyphAtlas.ColorDefaultsProbe.20261102 cleared after checks. These are model/offscreen checks, not actual picker GUI or main-app physical gesture acceptance. Native GUI acceptance and original intermittent color disappearance remain user follow-up. No commit/push.

API reference for native opacity control: https://developer.apple.com/documentation/appkit/nscolorpanel/showsalpha .


## Color corruption of the originating window — code investigation only — 2026-11-02

User supplied two screenshots and refined reproduction: choose arbitrary font/color, save default, open other fonts; new windows retain saved colors but the original window used to save them changes incorrectly. Screenshots show black/system colors in one window alongside magenta/custom colors in others; they do not establish runtime object state. User explicitly requests code investigation only while they continue finding reproduction. No production source/resource/build changes, no current-app UI operation.

Audit: useCurrentPreviewColorsAsDefault: only serializes current overrides into fresh NSData entries and writes defaults; initWithRepresentation: creates a separate palette for each controller. No direct original-window reset found in saving/opening code. Suspect lifecycle is NSColorPanel: choosePreviewColor: stores weak originating colorOwner + role and leaves shared panel target/action installed. No panel-close observer or equivalent teardown exists. changePreviewColor: checks only originating font-window visibility, not whether the color panel is visible or its editing session remains valid. Therefore a programmatic panel color update after closure can write into the still-visible originating window even when unrelated to user choosing a new preview color. User specifically confirms the picker had already been closed in the reported episode; closure does not exclude this candidate.

Native isolated headless probe at diagnostics/color-panel-investigation-2026-11-02/native-panel-probe.m/.log confirms on14.8.7 that setting shared panel.color programmatically dispatches its target action even when invisible; after calling close on the invisible panel, another programmatic black assignment still dispatches action. Logged AppKit stack goes through NSColorPanel _forceSendAction:notification:firstResponder: and NSApplication sendAction:to:from:. No private API invoked (private names only appear in native stack). The retained original magenta NSColor remains magenta after panel black assignment, so this particular native color object was not mutated in place. Updating a detached NSTextView font panel and making it first responder of a hidden test window did NOT trigger a color action in this setup; do not claim native text focus is the established actual trigger. Initial probe compile attempted unsupported panel target/action getters; removed those reads before successful execution. Unique bundleID com.zonz.GlyphAtlas.NativePanelProbe.20261102; never showed panel/window and did not change real app preferences. Product callback does refresh palette views after a write, so this route would affect actual stored current-window colors, not merely missing repaint.

Confirmed hazard, not yet complete reproduction/root cause: still unknown what actual event during opening another font sets the shared panel color, or whether this candidate explains both screenshots. Earlier palette/window-only probes omitted the real shared color-panel lifecycle, so passing them does not rule out this route. Wait for user's additional reproduction evidence; do not patch speculatively or state full root cause/fix. Candidate future scope if authorized: terminate color-edit binding on picker closure and ensure callbacks belong to a live, explicit edit session, with initialization prevented from leaking actions; keep default persistence/current-window semantics. This investigation added only diagnostic evidence and this internal log. No commit/push.

API references reviewed: https://developer.apple.com/documentation/appkit/nscolorpanel/setaction%28_%3A%29 ; https://developer.apple.com/documentation/appkit/nscolorpanel/settarget%28_%3A%29 ; https://developer.apple.com/documentation/appkit/nscolorpanel/colordidchangenotification ; https://developer.apple.com/documentation/appkit/nstextview/updatefontpanel%28%29 .


## Close the color-panel editing session — 2026-11-02

User explicitly requests fixing the confirmed lifecycle gap first and trying it. New local branch codex/color-panel-close-lifecycle preserves all earlier uncommitted features and the separate26 stash. Only production source changed this round is GAAppDelegate.m. choosePreviewColor: registers a single panel-specific NSWindowWillCloseNotification observer (removes earlier same subscription before adding), disables action and target before initial alpha/color setup, then attaches target/action as before. New previewColorPanelWillClose: disables action/target, clears originating colorOwner, removes that panel-specific observer. changePreviewColor: now requires both sender panel and originating font window visible. Default snapshots, per-window palette ownership and menu behavior unchanged. This fixes the known callback lifecycle hole, not an established complete reproduction of the user's cross-window issue.

Arm64 product build and resource lint passed without warnings; strict signature passed after removing provider-added root FinderInfo; git diff --check passed. Independent no-visible-UI probe uses real shared NSColorPanel, actual production GAAppDelegate methods and a fake visible recipient to isolate write counts. Verified programmatic hidden-panel action arrives but product rejects it, active callback with a visible test sender still writes, actual native close notification clears originating owner and disconnects target/action, subsequent native panel color changes do not reach delegate, late callbacks cannot change old owner. A second session uses an explicitly posted close notification because the hidden diagnostic panel was not actually reopened; do not claim native reopen GUI coverage.12 lifecycle checks passed. The initial probe helper named bind conflicted with the socket API and was renamed; an intermediate test assumed close on an already-closed hidden panel sends a second notification, which it does not, so corrected only the harness to simulate a second session notification. No product code changed to satisfy that harness assumption. Evidence diagnostics/color-panel-investigation-2026-11-02/close-lifecycle-probe.m/.log, unique bundleID com.zonz.GlyphAtlas.ClosedPanelProbe.20261102. No current user app/window/preferences touched. User must relaunch dist and retry original workflow; no claim full color bug resolved. No commit/push.


## Remaining color-panel issue while panel stays open — 2026-11-02

User reports that closing the picker now appears normal and strongly believes the identified route is the cause. However, saving defaults then opening a new font WITHOUT closing the picker still corrupts the originating window's color. Current source confirms previous fix only ends session on panel close; while panel and owner font window remain visible, changePreviewColor: still writes to that owner. openWindowForFontURL: constructs and shows the next controller without ending prior color editing. New font-window windowDidBecomeKey: focuses its sidebar input on first activation; exact native setter/event stack responsible for the color update is still not captured, so do not assert a fully traced AppKit root trigger.

No code changes in this follow-up yet. Proposed product choice via async: conservative recommendation ends the color edit and closes the picker when opening/switching to another font window; alternative keeps it open following active font window, requiring more careful handling of native programmatic synchronization. User choice pending at this entry. If conservative approved, terminate old binding BEFORE new-window/open-panel initialization and prevent stale-owner callbacks during existing-font window switches, reusing prior close cleanup. Do not claim prior close-only fix covers an open picker. Current branch remains codex/color-panel-close-lifecycle, prior uncommitted edits retained.


## Trace the actual setter and apply the editor-handoff fix — 2026-11-02 (superseded by Dedicated editor panel-update opt-out below)

User rejected expanding callback suppression as the direction: investigate WHY opening a font changes the color picker. Their earlier answer “wait” did not approve auto-close or follow-active-window behavior. User then explicitly authorized opening a separate diagnostic App with real windows to trace actual changes, leaving their existing app/windows/preferences untouched. No auto-close-on-window-change or follow-active-window implementation was added.

Static audit: new font controller show/focus path does not directly assign NSColorPanel.color; only choosePreviewColor: does. Sidebar field editor initially has usesFontPanelYES/richTextYES, while prepareFieldEditor turns panel usage off only after beginning editing. Detached/hidden native tests failed to produce the panel setter even with simulated panel visibility, so those tests were not treated as root-cause proof. A visible independent diagnostic app, built from actual product sources with unique bundleID com.zonz.GlyphAtlas.VisibleColorOriginProbe.20261102, finally produced an actual normal-runtime call stack: openWindowForFontURL → showWindow → NSSearchField/NSTextView becomeFirstResponder → NSTextView updateFontPanel → native NSColorPanel action → GAAppDelegate changePreviewColor. Color sent was System controlTextColor. Original window's custom magenta became black; newly opened font retained magenta from saved defaults. This establishes the missing origin of the previously identified callback route. Clean trace uses ordinary color-change notifications and an override of our delegate action to record stacks, with no AppKit method replacement. A switch in our own sidebar-editor factory was used only for A/B diagnostics. Baseline+diagnostic-early comparison at visible-origin-baseline-and-early.log confirms suppressing editor panel usage BEFORE handoff prevents this native synchronization while the panel remains visibly open.

Initial visible diagnostic attempts created sharedColorPanel before the first window and dynamically subclassed its setter; AppKit raised a nil-object telemetry exception during native panel fallback action, preventing first window load. Sampling showed idle event loop, not a hang. Copying product Info.plist fields did not fix that harness. Successful diagnostic removed early panel creation/dynamic AppKit subclassing and used native notifications only. These initial failures were not product failures or accepted fix evidence; logs/sample retained for chronology.

User approved moving the setting earlier, initially retaining close cleanup; then explicitly requested removing the previous callback patch and applying the root fix cleanly. They suggested restoring the prior branch, but both prior branch tips were217ebf6 with all newer features uncommitted, so branch switching cannot restore that working-tree snapshot. Precisely reverted only the preceding GAAppDelegate panel-close observer/teardown, initialization actionNULL, and sender.isVisible filter, preserving all other uncommitted menu/color/size/gesture features. New branch codex/color-editor-initialization. Final product correction is localized to GASidebarViewController: remove usesFontPanelNO from prepareFieldEditor and set it immediately before every return of the custom searchFieldEditor from fieldEditorForControl:. One initial implementation set it only inside editor creation; clean-source GUI validation found that insufficient (a later setTypingAttributes/updateFontPanel during resignKeyWindow when showing the picker still reset magenta). Final every-handoff setting handles reuse as well and is the sole flag assignment. It remains the same underlying root opt-out, without callback filtering or panel auto-close behavior.

Final actual-source GUI diagnostic, with its extra early-configuration switch left OFF, verified: set original glyph to magenta and save defaults, open the real color panel (AX color well rgb1,0,1,1), open another Futura100CHI window with panel still visible. No PRODUCT COLOR ACTION or unintended colorDidChange occurred during opening. Original window, visible picker and new window all stayed magenta; saved defaults remained intact. Existing system background retained follow-system status. Final trace visible-origin-final.log; initial creation-only failed attempt visible-origin-init-only.log. The original baseline failure and final pass therefore exercise real window ordering/focus and the native shared picker, not constructed events. Diagnostic app was quit via CUA; user’s actual Glyph Atlas app was not quit or modified. Targeted validation is on14.8.7, not26/27. Final arm64 product build/resource lint and strict signing checked; no commit/push. Source/resource changes from earlier authorized feature rounds remain pending. This root fix supersedes the close-session workaround and pending conservative window-switch proposal above.


## Re-entering the sidebar editor and dedicated color UI discussion — 2026-11-02

User reports that after prior handoff fix, opening new windows is okay, but clicking/re-entering the new window's input still turns the original default-setting window black. They request a simpler approach. No product code modified this round. Previous final validation covered opening/focus only, not ending and restarting editing; acknowledged this coverage gap.

Using the already-authorized separate visible diagnostic app, instrumented only our GASearchFieldEditor.updateFontPanel via a diagnostic method and logged its flag plus actual product color actions. Reproduced current source: set magenta/save default/open picker/open new window, Tab out of input (AX focus table), click input again. usesFontPanel transitions from0 to1 on this new edit cycle; native updateFontPanel sends System controlTextColor through existing color callback and original palette becomes black. Evidence visible-input-panel-update-probe.log around lines72–106. Therefore factory handoff assignment is insufficient for subsequent editing.

Candidate tested ONLY in diagnostic app: override that dedicated editor's public updateFontPanel method without calling native implementation, irrespective of the flag. Enabled at runtime only for diagnostic class. Repeated new window, Tab out, click input, type Abc. Actual typing and glyph candidates appeared; log shows updateFontPanel invoked with flag1 but skipped, no new product color action. Recorded final palette/picker snapshot remains magenta for origin/new windows. This is a narrower stable opt-out for a plain sidebar input than repeatedly enforcing a flag. Product proposal would replace prior handoff flag fix with a small method override in GASidebarInput.m and remove obsolete flag assignment in GASidebarViewController.m, but user has NOT yet authorized that implementation. Do not claim applied. Real color-slider manual editing was not tested in this round. Diagnostic app quit via CUA, user main app/windows untouched.

User then discusses using dedicated panels because glyph/shadow/background currently share the picker and require switching. Evaluation only: Apple documents one shared NSColorPanel per app as standard. Suggested one optional app-owned palette panel with3 native NSColorWells to show all current colors and switch in one click; complete system color editing remains shared. Multiple full independent native pickers are not the documented standard configuration; simultaneous3 sets RGB/HSB controls would require custom editing UI. This UI proposal does not itself solve native text-editor panel synchronization, which still needs root opt-out. No dedicated palette UI or updateFontPanel override approved/applied yet; wait for product discussion/confirmation. Current product still uses the prior every-handoff flag approach and no callback filter/auto-close.

Primary references: https://developer.apple.com/documentation/appkit/nstextview/updatefontpanel%28%29 (public override point); https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/DrawColor/Tasks/ChoosingColors.html (single shared panel and color wells). No commit/push.


## Dedicated editor panel-update opt-out — 2026-11-02

User decided to keep native shared system picker and skip optional palette UI; explicitly approved overriding only sidebar editor updateFontPanel and removing the prior handoff flag experiment. They then asked whether restoring prior input-setting order is cleaner. Restored GASidebarViewController exactly to its original217ebf6 content: prepareFieldEditor uses richTextNO then usesFontPanelNO then typingAttributes; no factory flag assignment remains. New local branch codex/sidebar-panel-update-opt-out preserves all prior feature work. The ONLY net source change for this color-synchronization bug relative to pre-investigation state is4 lines in GASidebarInput.m: GASearchFieldEditor.updateFontPanel is a no-op with a plain-input comment. This uses the documented public override point. It prevents outgoing font/color-panel updates regardless of AppKit re-enabling the usesFontPanel flag during new edit cycles. No callback suppression, panel-close cleanup, automatic panel closure, custom panels or changed color-value order. Existing original usesFontPanel setting remains to preserve prior input/font-menu behavior.

Final real-window diagnostic built from these product sources has NO runtime method injection, switch or alternate editor implementation. It only records ordinary color panel notifications and logs the existing app delegate color action. In isolated com.zonz.GlyphAtlas.VisibleColorOriginProbe.20261102, set magenta/save defaults/open native picker/open another Futura100CHI window; Tab to table, click input, type Abc, Tab/re-enter and move cursor. AX confirmed text and glyph rows; final model snapshot shows original/current windows and visible picker all remain magenta, with no unintended PRODUCT COLOR ACTION during edit cycles. Then selected the current window as color owner and used the REAL native color-panel slider through CUA (value0.032513→0.5): color well changed to DisplayP3 rgb0.468666,0.101879,0.5,1, legitimate product callback updated only the bound current window, other window remained magenta. Thus manual picker editing remains functional. Native shared picker is retained; no custom drawing/UI. Full evidence visible-input-final-product-probe.log and final visible-origin-probe.m under diagnostics/color-panel-investigation-2026-11-02/. Earlier A/B log visible-input-panel-update-probe.log records re-entry flag1 failure and no-op success. Diagnostic app quit via CUA; user actual app/windows/settings untouched.

Arm64 build/resource lint passed, strict signature passed after removing provider-added FinderInfo, git diff --check passed. Validation14.8.7 only, no26/27 runtime. Current Sources/GASidebarViewController.m has no diff to217ebf6; added updateFontPanel method only in existing GASearchFieldEditor, not other editors or TextKit rendering. No commit/push; other authorized uncommitted menu/default/spacing/palette/gesture features remain. This supersedes the factory handoff fix and prior callback lifecycle trials, which must not be reintroduced without a new request.

Reference: https://developer.apple.com/documentation/appkit/nstextview/updatefontpanel%28%29 .


## Fixed appearance palette, nonnegative spacing, native gesture event diagnosis — 2026-11-02

User approved Current Colors saving all three currently resolved colors including shadowalpha for future windows, adding separator back, and separately decided to disallow negative spacing. New branch codex/fixed-preview-colors-spacing preserved previous pending work. GAPreviewColors.resolvedRepresentationForAppearance resolves under active window effectiveAppearance in extendedSRGB (chosen over sRGB to preserve saturated Display P3); source palette and existing windows remain unchanged. Option color menu is Follow System / separator / Current Colors. Existing spacing setter lower bound changes from−0.9 to0; upper bound2 and keyboard0.1 stay. Existing size restore already uses the setter; no preference migration or stored-negative rewrite added. Isolated palette-spacing probe25 checks passed before native gesture refactor, including light/dark freezing, wide-gamut roundtrip, shadowalpha, future-window scope, separator/context-menu count, keyboard/gesture bounds and old negative snapshot application. Probe's old handleMagnification helper is historical after the following replacement and must not be rerun unchanged.

User authorized read-only actual app File>OpenRecent / Dock comparison and supplied Dock screenshot. Common4 entries match; Dock shows them in reverse order and retains Wing-OPPO.ttf while persistent app list contains two missing Wing paths filtered out of app menu. Eight remaining valid paths appear in app menu. Own persistent recent list and native NSDocumentController registration remain separate sources. Native registration already occurs on opening; no Dock rewrite/rehydration implemented. Protected native sharedfilelist remained unreadable even after escalation; no broader disk access sought. Do not infer universal Dock limit or exact bookmark resolution from this snapshot.

User physically reproduced freeze twice in independent /tmp/Glyph Atlas Gesture Freeze Probe.app, unique bundle com.zonz.GlyphAtlas.GestureFreezeProbe.20261102. First recording:10.892-second span with76 touch samples and no recognizer callbacks. Second native-event diagnostic proves278 native Magnify packets continue after last recognizer callback, first packet Changed (phase4), following Scroll MayBegin/Cancelled and with no Magnify Began. Therefore angle gaps are not the cause: mapping remains ≤30° box / ≥75° spacing / remainder font. Current recognizer cannot establish a lifecycle for this captured stream. Evidence immutable gesture-trace-first-reproduction.log and gesture-trace-second-reproduction.log under diagnostics/gesture-freeze-2026-11-02/. Later interaction continued writing the live native-events log; immutable second capture is the regression fixture.

User explicitly approved replacing only Multi NSMagnificationGestureRecognizer with NSResponder.magnifyWithEvent:, handling first Changed without Began, retaining orientation lock, numeric curves and limits. They then requested branch before edits for easy rollback. Branch codex/native-multi-magnification exists; all older changes remain uncommitted, so branch pointers alone do not capture working trees. Saved independent restore-recognizer.patch (git apply --check passes) and full pending diff under diagnostics/native-magnification-2026-11-02/. Restore patch reconstructs only the preceding recognizer implementation, preserving all other features. New handler records start values on first packet, accumulates native per-event deltas, applies Ended delta, clears state on Ended/Cancelled; no custom distance-based zoom or AppKit recognizer modification. Single/all recognizers unchanged.

Recorded-event replay against real product view passed854 assertions:278 captured freeze packets for all3 controls, first Changed, cumulative curve, Ended delta, fresh next stream, cancellation, orientation lock, phase-less events and bounds. This is callback replay evidence, not hardware/UI acceptance. Initial sandbox execution exited134 before AppKit startup; identical independent probe succeeded outside sandbox. Updated existing native diagnostic to version3 (direct native handler) and opened via CUA, then requested user hardware repetition. Old diagnostic closed via CUA before binary update; user's actual Glyph Atlas windows/input untouched. Hardware result pending at this entry. No commit/push.

Discussion only, no implementation authorization: underline/strikeout as optional native preview attributes can illustrate post underline and OS/2 strikeout metrics; double-line spacing is system-synthesized rather than a second font metric. Current input/model normalization does not preserve per-selection decorations. Transparent background currently unavailable except shadowalpha; alpha0 would expose underlying view/window backgrounds, not automatically desktop; full window transparency would involve separate compositing behavior. References: Apple Event Handling Guide HandlingTouchEvents, Apple NSUnderlineStyle.double, OpenType post/OS2 specifications.


### Native direct-handler trial fails real hardware acceptance — 2026-11-02

User repeated on diagnostic3 and reports still freezes. Immutable gesture-trace-third-reproduction.log records1415 native Magnify events but only798 handler calls (617 unhandled), including Changed-only streams. Thus earlier replay proves handler arithmetic only; replacement alone is NOT an actual fix. Previous hypothesis attributing failure solely to recognizer lifecycle was incomplete: native delivery to NSResponder method is also absent for these streams. No further product patch authorized or applied. Diagnostic4 adds NSWindow.sendEvent, window/scroll responder logging, event window, keywindow, hit-test target and firstresponder; same product handler untouched. Need hardware repetition to locate delivery boundary before proposing a broader correction. Branch and rollback patch retained. Product arm64 build and strict signature passed (provider FinderInfo removed); no commit/push. Do not call this issue resolved.


### Gesture delivery boundary confirmed before NSWindow — 2026-11-02

User reproduced on diagnostic4. Immutable gesture-trace-fourth-reproduction.log:1918 native Magnify events at NSApplication.sendEvent override,1647 NSWindow.sendEvent and1647 actual view handler calls;271 not delivered to window, comprising269 Changed and2 Ended. Normal handler stack includes AppKit routeGestureEvent → NSWindow.sendEvent → view.magnifyWithEvent. Thus actual failure boundary is native NSApplication routing before NSWindow, not scroll view, view arithmetic or angular partition. Changed-only freeze815322913.453…918.718 follows cancelled/pending scroll and has no Magnify Began. No product code changed this round.

Testing diagnostic5 only: public NSEvent.addLocalMonitorForEventsMatchingMask(Magnify), forwards unchanged native event directly to the same view and returns nil to prevent duplicate handling, scoped to key window and visible preview hit or active magnification session. Still uses native event magnification and existing handler; no synthesized beginnings or touch-distance zoom. Monitor installed/removed on diagnostic view window attachment; weak capture. Await real trackpad validation before proposing production scope. Native monitor documented in Apple's Event Handling Guide MonitoringEvents; diagnostic experiment only, not accepted product fix.


### Local native monitor passes user hardware test — 2026-11-02

User confirms diagnostic5 now normal. Immutable gesture-trace-fifth-validation.log records5480 native Magnify packets,5480 local-monitor calls and5480 view-handler calls, zero missing or duplicate delivery. Includes13 Changed-only stream starts, covering the earlier concrete failure mode, plus120 Began streams. Thus this is live hardware evidence beyond synthetic replay. Prototype remains solely in diagnostic subclass; product still direct-handler-only trial until user approves broader monitoring scope. Prepared unapplied local-monitor-proposal.patch under diagnostics/native-magnification-2026-11-02/: one private monitor token; remove/reinstall on window attachment and release on view teardown; weak capture; only current key window's visible Multi view hit or active gesture is forwarded to existing magnifyWithEvent, returning nil to avoid duplicate. No event synthesis, angle or numeric changes, no single/all gesture changes. Existing local branch and recognizer rollback patch retained. Await explicit project code-change confirmation.


### User defers production local-monitor integration — 2026-11-02

On scoped confirmation user chose “先保留診斷版本”. Do NOT apply local-monitor-proposal.patch or re-ask this skipped integration without new user direction. Diagnostic5 and its native monitor remain available; leave its app/window as-is. No production code changed for this decision. Product remains the earlier authorized direct magnifyWithEvent-only trial, which hardware diagnostic3/4 showed insufficient; do not describe production freeze as fixed. Local branch codex/native-multi-magnification, independent restore-recognizer.patch and full pending-work snapshot remain. User did not request reverting that earlier product trial, committing or pushing. All prior unrelated approved work stays intact.


### Pointer-moving versus pointer-stationary no-zoom reports — 2026-11-02

User clarifies two phenomenologies: stationary pointer/no zoom (now resolved in diagnostic5), moving pointer/no zoom (asks whether this counts as a bug). Read-only live log now6829 native Magnify /6829 local /6829 handled. This cannot identify the pointer-moving episode because mouse movement is not logged; do not assert that exact episode contains no Magnify. Explain distinction: finger motion alone is not a recognized pinch; absent native magnification can legitimately leave zoom unchanged. If native nonzero Magnify is delivered for preview and chosen control is not clamped yet no response, that would warrant investigation. Pointer movement alone is insufficient evidence. No product or diagnostic code changes or expanded raw-touch zoom authorized. Official Apple HandlingTouchEvents distinguishes raw touches, mouse events and driver-recognized gestures. Previously deferred production monitor integration remains deferred.


### User reports freezes in other views; source-only conflict review — 2026-11-02

User now reports similar freezes in other views and asks whether handlers conflict. Read current source only, no product changes: Single GABoundingBoxView retains its own NSMagnificationGestureRecognizer; All attaches its recognizer to GAAllGlyphsGrid; Multi has direct magnifyWithEvent trial and no recognizer. GADetailViewController keeps them as sibling branches, hiding inactive branches. No magnify local monitor exists in production; sole production local monitor in GAInputFocus matches LeftMouseDown only and always returns original event. Diagnostic5's monitor is in a separate app process and cannot intercept main app events. No app-owned cross-view magnification interception is evident from this review. Does not prove native/internal gesture competition absent or that other-view freeze has same cause. Common native routing failure is a hypothesis requiring native/window/callback logging on actual Single/All reproduction; do not generalize Multi hardware evidence as proof. Asked user whether other-view freeze is stationary-pointer or moving-pointer type; answer pending. Prior decision deferring production monitor remains in force.


### Other-view stationary-pointer freeze diagnostic prepared — 2026-11-02

User confirms Single/All freezes have stationary pointer and no zoom. This matches the symptom class of Multi delivery failure, but not yet measured in other views. Prepared separate /tmp/Glyph Atlas Other Views Gesture Probe.app, unique com.zonz.GlyphAtlas.OtherViewsGestureProbe.20261102, sources/build.py under diagnostics/other-view-gestures-2026-11-02/. It uses actual product GABoundingBoxView and GAAllGlyphsView subclasses only to log original handleMagnification before/after; retains original recognizers and switches between sibling hidden branches like product. Does not create any Multi view or magnify monitor, to exclude new Multi code as a necessary cause. Logs NSApplication native events, NSWindow delivery, recognizer callbacks/state/value, numerical bounds; Thonburi.ttc real glyph and inventory displayed. No product code or user app windows/settings modified. Preserve diagnostic5 and deferred production integration decision. Await native trackpad reproduction separately in each mode.


### Single and All reproduce the same pre-window routing failure — 2026-11-02

User corrected accidental response “兩種暫時都不能重現” with “選錯了／兩個都能”; treat both reproduced as authoritative. Immutable diagnostics/other-view-gestures-2026-11-02/both-views-reproduction.log: Single1609 native Magnify →1514 window deliveries →1514 recognizer callbacks,95 pre-window losses (94Changed,1Ended). All332 native →147 window →147 callbacks,185 pre-window losses (184Changed,1Ended). Both missing streams have native Changed with no prior Magnify Began after pending/cancelled Scroll. Every delivered native Magnify resulted in original recognizer callback in this capture. Separate diagnostic has no Multi instance or local Magnify monitor, so new Multi orientation/monitor code cannot be a necessary cause of these reproductions. This establishes same measured failure boundary across all3 view types; not merely inference from stationary pointer symptom. Still does not establish private AppKit internal reason for dropping sequence.

No product code changed, no further diagnostic behavior change or production monitor integration authorized by this correction. Existing user deferral remains. If a formal fix is later approved, consider one common scoped native Magnify ingress for all3 modes with each original numeric rule retained, rather than assuming only Multi affected; Single/All native-monitor behavior still needs validation before claiming fixed. Do not apply pending Multi-only proposal or generalize diagnostic5 acceptance to other views.


### Angle correlation versus fixed angular exclusion — 2026-11-02

User observes freezes recur near similar finger angles and asks whether Apple handles those angles specially. Official Handling Trackpad Events documents gesture classification and possible magnify/rotate interpretation changes within a touch sequence, but reviewed public docs do not give an absolute-angle forbidden range. Distinguish orientation of two-finger line (our control selection) from angular change (rotation motion). Hypothesis: some poses/motions more easily cross native recognition/arbitration boundaries; no proof of an Apple hard-coded angular ban or exact private recognition rule. Confirmed frozen stream in fourth capture lasts815322913.453…918.718,270 undelivered packets inclEnd; last reported physical touch angles span17.55…55.09 during that same frozen segment. Thus failure persists across a broad angle range after starting, not demonstrated as an instantaneous static cutoff. Native Magnify is already being emitted, so this is not simply absence of native pinch recognition. Single/All new diagnostic also proves same pre-window losses without any Multi orientation code. No code changes authorized/applied; local-monitor production integration remains deferred.


### Pause investigation, desktop handoff, restore original native recognizers — 2026-11-02

User reports similar issue in macOS TextEdit and asks recommendation; recommended testing unified3-mode native ingress before any production integration, but user now explicitly chooses recording facts/cause/results/workaround on Desktop for boyfriend consultation tomorrow, restoring main App to pre-fix native scheme, then resuming remaining topics. This is authorization to undo the direct-event trial only, not whole-file/feature reset.

New branch codex/restore-native-gesture-recognizers. Copied direct-event GAMultiGlyphView.m to diagnostics/native-magnification-2026-11-02/GAMultiGlyphView-direct-events.m, then applied existing independent restore-recognizer.patch. Reverse apply check passes. All3 product views now create NSMagnificationGestureRecognizer; Multi direct magnifyWithEvent handler/state removed, original three-way direction/curve retained. No production Magnify monitor. Other pending palette/spacing/default/menu/editor features retained. Built arm64 dist/Glyph Atlas.app; did not quit/reopen user's existing running App/windows. No commit/push.

Wrote detailed UTF8 technical handoff to /Users/zonz/Desktop/Glyph Atlas 觸控板縮放調查 2026-11-02.txt (matches workspace diagnostics copy). Includes exact confirmed boundary, uncertain private cause, user-reported TextEdit corroboration, raw/window/callback counts, phase/state distinction, logs/snippets, angle caveat, failed direct handler trial, successful diagnostic5 monitor algorithm/5480-packet+13Changed-only validation, other2 not yet monitor-validated, API references and source paths. Saved compiled diagnostic5 and Single/All .apps from /tmp into their respective diagnostics folders so materials survive temporary cleanup. Existing live apps left alone. Updated build-probes.py to compile preserved direct-event snapshot for diagnostic5, so product rollback does not break future diagnostic builds. Proposal patch remains unapplied and based on old trial; do not apply blindly to restored source.

Gesture topic paused by explicit user direction, not an active fix request. Resume only when user brings external findings or requests further work. Remaining discussion: underline/strikeout necessity and per-selection preservation; Dock recents native ordering/filtering versus persistent menu; transparent background curiosity. Negative spacing removal and concrete appearance color defaults+separator already applied; do not reopen or expand them without a new issue. No decorations, Dock rewrite or transparent canvas changes authorized. Strict app signatures verified after removing provider-added root FinderInfo; initial Python xattr attempt unavailable on host Python, no source impact.


### Per-selection underline/strikeout implementation discussion — 2026-11-02

User originally favors whole-preview toggles but asks how per-selection styling could show real ordinary-text behavior. Source review only: sidebar already stores NSAttributedString with explicit GID selection and line-break metadata; GANormalizedSidebarInput and normalizeEditorStorage deliberately keep only current font/color, seed and marker attributes; prepareFieldEditor uses richTextNO and replaces typingAttributes. Main worker identity is plain text+GID selections, Multi reconstructs display NSString attributes and explicit seeds with output→source mapping. Thus no need for a separate ad-hoc range document, but styling must be preserved through all existing normalization/edit/display paths, including field/model line breaks and seed replacement.

Proposed design (not approved/implemented): limited native attributed editing retaining underlineStyle/strikethroughStyle only beyond current metadata; native selected-range actions, typing attrs and undo; input and Multi both display decorations via TextKit, font/color continue app-controlled, saved texts remain pure text by prior contract. Forward style runs to Multi independent of GSUB query identity; decoration-only changes refresh presentation rather than invalidate font analysis. Account for existing explicit-GID source mapping. Do not promise native shaping/GIDs unchanged across decoration boundaries (e.g. partially decorated ffi); use native TextKit behavior and validate instead of inventing glyph-level decoration rules. Apple's NSText.underline documentation explicitly distinguishes rich-text selected-range operation from whole-content plain-text operation; typingAttributes must update after attribute actions. Existing no-op updateFontPanel opt-out must remain effective with any edit-mode changes. Discussion only, no code or prototype created.


## Partial underline and strikethrough — 2026-11-03

User explicitly approved implementing per-selection decorations, preserving only underlineStyle/strikethroughStyle beyond existing input allowlist. Optional UI clarification answered “只加編輯選單”: add native Edit commands Underline⌘U / Strikethrough⌘L, single-line toggles, preserve original pasted decoration styles, no sidebar context additions. This is implementation authorization; did not re-ask permission for the already-approved core change. New branch codex/partial-text-decorations; before copies of changed source/catalogs and all-prior-work.patch saved under diagnostics/partial-text-decorations-2026-11-03/. Older pending work retained, no commit/push.

Implementation: GATextDecorations.{h,m} central two-key allowlist/copy; input normalization keeps native decoration values, app font/color, explicit GID metadata and line-break markers only. Rich field editing enabled for selected-range native attributes. Original no-op updateFontPanel retained. Underline routes to native underline:, strikeout supplies single-key conversion via documented changeAttributes:, avoiding custom drawing/undo implementation. Native menu validation follows first selected char or typing attributes. RTF paste filters attributes and preserves allowed styles; backwards newline/CRLF conversion keeps their ranges. Plain-text copy/cut and saved-text persistence unchanged. Other clipboard-only formats not specially implemented; plain-string fallback stays available.

Multi pipeline now accepts NSAttributedString. Scan snapshot projects original spans rather than rebuilding a second text string, preserving positions after missing-glyph omission. Publication reads latest main-thread attributed input; styles are not part of worker/query identity. Decoration-only notification with identical text/GID identity refreshes preview without sidebar scan/reload. TextKit2 receives decoration attributes on actual preview font/color. Explicit seed/vertical replacement copies decoration ranges at equal length; length-changing explicit display components inherit first source char's decoration, matching the chosen replacement policy rather than inventing character offsets. Existing glyph hit mapping unchanged; natural ligatures/marks remain native shaped and may respond to style boundaries.

Source review plus arm64 build/resource lint only per collaboration default; no test app launch, GUI automation or interaction tests. Native Undo/Redo, IME, paste/edit-cycle persistence, shared-picker interaction and partial ligature/combined-mark display require user's real acceptance; do not claim tested. Initial build found missing C helper prototype argument and empty-string initializer type mismatch; corrected both. Localized all14 catalogs using actual installed AppKit Underline/Strikethrough terms, no guessed regional labels. Root README/Help untouched. Gesture restoration/paused investigation and diagnostic artifacts unchanged.

Primary API evidence read: Apple NSText.underline (selected range rich-text vs whole plain-text), NSTextView.changeAttributes (sender.convertAttributes, native edit path), typingAttributes and shouldChangeText; SDK declarations checked. GUI success is not inferred from these docs or build.


## Repeated decoration commands blocked by usesFontPanelNO — 2026-11-03

User reports first shortcut after re-entering input works, later shortcuts stop; menu remains enabled. They approved isolated diagnostic launch. Built actual source copy with logging only (no AppKit method injection), unique /tmp/Glyph Atlas Decoration Repeat Probe.app, bundle com.zonz.GlyphAtlas.DecorationRepeatProbe.20261103, preferences isolated. Real CUA input reproduced: Tab out/click back/CmdA/CmdU updates preview to underline and emits control notification; second CmdU and subsequent CmdL still reach editor actions but textStorage remains unchanged and no edit notification occurs. Thus failure precedes preview propagation and is not menu routing. Evidence baseline-failure.log plus baseline-src under diagnostics/decoration-repeat-2026-11-03/.

Apple NSTextView.usesFontPanel explicitly says false disallows character attribute changes, not merely Font-panel display. Existing prepareFieldEditor sets it NO after native text change; AppKit may enable it on entering a new edit cycle, explaining one successful operation followed by blocked actions. Earlier feature implementation retained the old flag and missed this broader effect. Proposed candidate removes only that assignment, retaining existing no-op updateFontPanel (the actual shared-picker corruption fix), attribute allowlist and native edit/undo commands. Diagnostic candidate build started but not launched. User explicitly stopped tests: “不用測了，直接改吧，我來測”. Do not continue diagnostic/UI tests or claim candidate runtime success.

Applied authorized one-line product fix on new branch codex/allow-text-attribute-actions; source-before-fix saved. Original rich editing, palette opt-out, menu filtering and all other code retained. Default product build only; user owns runtime acceptance. No commit/push. Diagnostic baseline window was already quit before stop request; candidate not opened. Prior gesture investigation remains paused/restored. Reference https://developer.apple.com/documentation/appkit/nstextview/usesfontpanel .


### User acceptance and remaining-item status recap — 2026-11-03

User confirms repeated decorations now look normal after removal of usesFontPanelNO; this is user hardware/UI acceptance, not agent candidate test (user previously stopped tests). They ask difference between flag and updateFontPanel, and list four earlier items. Rechecked current source without GUI/testing: concrete-appearance Current Colors default via resolvedRepresentationForAppearance(active window effectiveAppearance) already implemented, future-window-only; default color menu separator already present; spacing setter already clamps0…2. No need duplicate these changes. Recent menus still own persistent filtered paths, every open registers noteNewRecentDocumentURL and Clear clears both; Dock native list not rewritten/force-aligned. Earlier observed sort/count/nonexistent-path differences remain prior evidence, not newly inspected live Dock. Explain usesFontPanelNO disallows native character attribute changes; no-op updateFontPanel blocks outgoing shared-panel sync while leaving native attribute actions available. No code change or resumed tests/gesture work this turn. Pending product decision is whether/how to align native Dock list and persistent menu, with no new alignment authorization inferred from recap.


## Native recent-document restoration and default-color checkmarks — 2026-11-03

**Superseded in part by the correction below:** native-history writes in rebuildRecentMenu caused a hover regression; simultaneous color checkmarks and unconditional palette freezing were subsequently rejected by the user.

User requests resolving Dock recents mismatch together with default color check states, then explicitly reiterates Dock should be fixed this round. Color clarification accepted: Current Colors ✓ compares entire active window actual palette against stored default actual palette, including shadowalpha; Follow System retains full✓ /partial− /all custom off. Explained comparison can make both✓ when current and default follow system and resolve identically. No requirement to make mutually exclusive radio choices inferred.

New branch codex/recent-files-color-checkmarks; before copies of3 touched files plus isolated restore-feature.patch under diagnostics/recent-files-color-checkmarks-2026-11-03/. Persistent GAPersistentRecentFontPaths remains canonical to retain prior cross-ad-hoc-copy persistence. Extracted existing filtering into recentFontURLs; rebuildRecentMenu now clears native NSDocumentController history and re-registers the same valid URLs from oldest to newest before rendering app menu newest-first. Called during startup main-menu construction, successful font load and explicit Clear; Clear removes persistent entries and reuses same publication path. Removed former single-URL registration and separate Clear native call as now covered centrally. No private sharedfilelist access, no custom Dock menu, no NSDocumentController.recentDocumentURLs override; native Dock still controls visible count/order/cache. This changes native history only when updated product runs; user's currently running app/menus/preferences not manipulated by tools. No claim actual Dock UI tested or exact row-for-row visual identity.

GAPreviewColors.matchesColors:appearance: resolves both palettes into extendedSRGB under one effectiveAppearance, compares each NSColor includingalpha via isEqual (no archive-data identity or guessed numeric tolerance). Validator now sets Current Colors check on exact equality and disables/unchecks without a font window. Existing default Follow System systemState logic remains (stored default override count); ordinary menu state unchanged. Frozen-default saving semantics and separator unchanged.

Arm64 build/resource lint and static diff/isolated rollback checks only, following user's prior “不用測了…我來測”. No UI launch, tests or user-window operations. No commit/push. All other pending features and paused/restored gesture work retained. User should relaunch output App for runtime acceptance. Primary Apple docs checked: NSDocumentController clearRecentDocuments, noteNewRecentDocumentURL, recentDocumentURLs, maximumRecentDocumentCount, native Dock menu APIs. Does not override native ordering/count policy.


## Read-only recent-menu refresh and conditional default palette saving — 2026-11-03

User reports merely hovering Open Recent clears Dock history while App records stay. Source review found the actual regression: menuNeedsUpdate calls rebuildRecentMenu, and the prior round put clearRecentDocuments plus full re-registration inside that shared display refresh. Acknowledged the overlooked entry point; this is an App write-path bug, not a verified native Dock sorting explanation.

New branch codex/recents-read-only-color-defaults; prior GAAppDelegate.m and both proposed startup patches under diagnostics/recents-read-only-color-defaults-2026-11-03/. User explicitly chose the second startup strategy after discussion: once in applicationDidFinishLaunching, clear the native recent list and register valid App-persisted URLs oldest-to-newest. App persisted paths remain canonical. Successful font loading updates persisted MRU and registers only that URL. Explicit Clear clears both histories. rebuildRecentMenu only reads valid persisted URLs and constructs menu items; hovering/opening the menu never writes either history. No changes to native Dock presentation, private APIs, or other running App copies.

User precisely corrected Default Colors semantics: saved defaults determine Follow System state; when fully On, Current Colors must not also check. Only when saved defaults are fully On does Current Colors resolve the active window's entire actual palette under effectiveAppearance into fixed extendedSRGB values, including shadow alpha. With Mixed or Off saved defaults, save the active window's raw representation, preserving system-following roles. Actual palette comparison remains for Current Colors when saved defaults are not fully On. Current window is unchanged by either default command.

No product UI or diagnostic interaction tests: user will verify behavior, per prior instruction. No commit/push; all earlier uncommitted features preserved. See build result below.

Arm64 build completed successfully via ARCHS=arm64 bash build.sh; git diff --check clean. Output dist/Glyph Atlas.app was not launched by tools. Isolated restore-feature.patch saved for this round only.


## Freeze only a fully system-following current window — 2026-11-03

User reports conditional palette freezing still wrong. Previous implementation checked the stored default palette, so a partly customized current window could still be frozen when saved defaults were fully system-following. Corrected useCurrentPreviewColorsAsDefault to check controller.previewColors.systemState instead: only a fully system-following current window resolves all actual colors into fixed values; Mixed/Off current windows save raw representation and preserve any still-system-following roles. Default-menu checkmark logic continues to describe saved defaults and is unchanged. This supersedes the saved-default-based freezing condition documented in the preceding entry.

New branch codex/current-palette-freeze-condition; source before copy under diagnostics/current-palette-freeze-condition-2026-11-03/. Recent-history changes and all earlier work retained. No commit/push; build only, no UI interaction testing per user preference.

Arm64 build completed; git diff --check clean. Output App not launched by tools.


## 原生字體排印目錄與資料視圖 — 2026-11-03

本輪使用者要求以 TextEdit 字體排印的每字體特性目錄取代兩個合併開關；新增可切換字體／字形資料的第四視圖；先建本地分支、必要權限先試、完成後睡眠。使用者明確答覆「允許必要驗證」，涵蓋工作區 Glyph Atlas、TextEdit、`/tmp` 獨立程式；後續又明確授權本輪遇到有益建議／優化可直接實施，明天看具體說明驗收。因此本輪不沿用平常僅建置、不測試的限制，也不逐處重新索取許可。這是本輪授權，不改變後續輪次的通常協作規則。

分支 `codex/font-features-and-information`；改前完整 Sources／Resources／README 快照與先前所有未提交差異在 `diagnostics/font-features-information-2026-11-03/before/` 和 `all-prior-work.patch`。保留此前未提交的顏色、預設、最近字體、局部裝飾、原生縮放識別器等工作；沒有 commit／push。觸控板調查仍暫停，沒有整合 Magnify monitor，沒有修改已保留的診斷 App。

使用者最初允許進入 Codex 鎖定使用；Computer Use 對 Codex 自身的存取受到工具限制，已如實說明。使用者最後選擇「不鎖定了，沒差」，所以未鎖定。TextEdit 先前首次操作實際由使用者點選允許，不把工具成功當成自動核准；本輪複用已獲准介面。睡眠方法此前已由使用者確認成功，本輪收尾再執行同一 `/usr/bin/pmset sleepnow`。

### 明天的使用與驗收

1. 開啟工作區 `dist/Glyph Atlas.app`。主 View 菜單和主視圖右鍵在「全部字」下提供「資料 ⌘I」；再按 ⌘I 回到進入之前的單字／多字／全部字。
2. 側欄沒選字形時是字體資料；選中字形後是逐 GID 的字形資料。**⌘ 點已選側欄行可以取消選取，看字體資料，不必刪除輸入。**多 GID 候選逐一列出，來源／座標另收進 Selection。
3. 資料可搜尋、展開、選取文字；頂部複製按鈕或資料列表的 ⌘C 複製所選行及子項，無選取則複製目前搜尋結果。複製文字包含字體、單位、數值來源，方便交給外援比對。搜尋會保留，若切換字形後沒有匹配，清空搜尋即可看全部。
4. 按 Option，View 菜單的資料替換成「預設開啟資料 ⌥⌘I」。僅影響未來窗口。以資料啟動的窗口按 ⌘I 返回全部字。驗證過此設定後，已將預設還原為原先的全部字。
5. 多字視圖的「字體排印」在豎排、文字對齊之後，隨字體出現不同目錄。互斥選擇用小實心圓；可並用特性用原生勾號；「其他」收獨立單項。底部可還原該窗口的字體預設。豎排現為 **⌘5**；原來的兩個合併開關及 ⌘6／⌘7 入口已移除。
6. 資料視圖固定跟隨系統顏色；預覽的自訂顏色仍保存在原預覽。資料模式下關閉當前顏色／放大／框／字級預設操作，避免把資料表當成字形畫布操作。

### 系統接口與實施選擇

檢查本機公開 SDK 與 Apple 文件後，使用 `CTFontCopyFeatures` 取得系統提供的本地化名稱、selector、獨占性、預設、AAT／OT 對應；用原生 `NSMenu` 做二／三級選單。目前未找到可公開嵌入階層選單的 AppKit Typography 面板接口；因此沒有調私有面板或照截圖手工寫一份特性清單。頂層「字體排印」字樣取自本機 AppKit 的原生名稱。原生面板本身仍是 AppKit 提供，這裡使用同類原生資料與原生選單控件。

每個字體窗口保存自己的顯式特性選擇；未改項維持該字體原生預設，還原即清空覆蓋。On／Off 成對 AAT selector 合成一個開關；純 OT 0／1 也合成一個開關，包含預設開啟與關閉兩種情況；總開關 type 0 不作操作項，資料頁仍保存完整原生目錄。單選以 SF Symbol `circle.fill` 作原生 menu on-state image，不在標題字串硬加 •。

多字顯示字體透過公開 feature-settings descriptor 複製，TextKit 決定最終整形。反查另外附帶 CoreText 自己給的 OT 映射；沒有再維護一份私有 type→tag 清單，候選發現仍完整、不隨顯示開關縮減。切變數軸保留同資源選擇；重開另一字體重建。特性反查工作捕獲不可變設定並拒收過期結果。既有豎排引號輔助遇到明確關閉直書替代時不再硬塞替代字形。

原生特性選單及右鍵視圖命令綁定實際右鍵來源窗口，避免背景字體窗口拿到另一個 key window 的目錄／操作。資料的搜尋與選字欄位共用既有空 `updateFontPanel` 策略，避免污染共享選色器；沒有重新引入會禁用字符屬性命令的 `usesFontPanel = NO`。

### 資料清單、優先級與取捨

常用概覽與度量預設展開；大量低階資料保留，但收合展示。沒有以「設計師不關心」為由刪除已展示的原生特性或表目錄。

| 對象／優先級 | 第一版展示內容 | 數值來源與忠實性 |
| --- | --- | --- |
| 字體／常用 | 開啟路徑、CoreText 格式、UPEM、字形數、已編碼 GID／Unicode 數量、語言及其本地化名稱、字重／字寬／傾斜 normalized traits、樣式位元 | 編碼統計來自已有 nominal inventory；排除 GID 0／不把 UVS 序列當標量。CoreText normalized weight 不冒充 OS/2 usWeightClass。語言為原生報告能力，保留重複項，不推斷完整語言整形品質 |
| 字體／常用 | 18類 CoreText 名稱、版本、設計／廠商／版權／授權／網址等及可取得的本地化值 | 保留 CoreText 原值與取得語言；不是原始 name 表每個 platform／encoding／language 記錄的完整讀取器 |
| 字體／常用 | ascent、descent、leading、capHeight、xHeight、底線位置／粗細、傾斜角、整體 bounds；既有 OS/2 typo ascender／descender／lineGap；適用的 MVAR 結果 | CoreText 量測按 UPEM 字號換回字體單位；原始 typo 值保留符號，與 CoreText 正向 descent 分開；只在確有相關 MVAR 項時另列變化結果。點值／單位／座標方向在副標與來源中明示 |
| 字體／常用至進階 | 變數軸 min／default／max、CoreText 報告座標、原請求座標、自有 fvar／avar1 正規化座標；既有命名實例 | 按軸 ID 對應，不假設字典順序一致；不把 CoreText 有可能取整的座標當原始請求 |
| 字體／進階 | 壓縮 Unicode 範圍、完整原生特性 catalogue、CoreText 可取表 tag／長度、已有 reader 的解析結果／錯誤 | 名義 cmap 覆蓋不等於 script shaping 支援；CoreText 表可能由 provider 合成，不宣稱一定是檔案原始 SFNT 目錄 |
| 字體／進階 | 已解析 GSUB／GPOS 的分支、active branch、feature 及 lookup 索引、最大 alternate、script／LangSys、required feature、lookup flags／子表類型／嵌套引用／mark filtering set；AAT chain selector | 自有解析器提供摘要，明示來源，不說成 CoreText 的替換執行追蹤；active branch 0 是 base。不是所有 lookup 原始 coverage／action 的完整反編譯 |
| 字形／常用 | GID、CoreText 字形名、真實 nominal Unicode 及 ICU 字符名、CGFont 原始水平 advance、CoreText 橫／豎 advance、ink／optical bounds、計算左右邊距、竖向原點平移 | 字形名可能由 CoreText 合成；無編碼字形不拿來源文字偽裝自己的 Unicode。raw advance 與帶尺寸相關 trak 的原生 advance 分開；左右邊距明示是由 bounds／advance 算得 |
| 字形／進階 | GDEF glyph／mark attachment class、mark filtering sets、連字 caret、原生 CGPath 子路徑與直線／二次／三次曲線段數 | 沒有／解析失敗時明示或不列；CGPath 是系統返回路徑，不能冒充 glyf／CFF 原始點拓撲或 hint 指令；位圖／彩色字可能沒有返回 path |
| 選擇／追溯 | 完整 GID 序列、原文 UTF-16 範圍、已有 feature 來源標籤、已有繪製 origin | 標籤是發現／反查來源，origin 是該側欄候選已有定位結果；都不冒充 TextKit 內部執行路徑／位置 |

第一版不展示記憶體指標、快取地址、執行緒／GPU 內部狀態、框架物件 dump，因它們不是字體本身資訊。尚未建立的 raw name 全記錄、完整 GSUB／GPOS action 反編譯、hinting／原始節點與彩色 paint tree，不造出看似完整的值；它們對專業設計師可能有用，適合未來獨立表檢視器，不能分類成「無用」。資料缺失與原生無法取得不補猜測。

資料模型為不可變樹，來源 tooltip 與複製結果保留來源說明；兩欄原生 Outline 可調寬、換行及選文字。只有資料可見才在串行背景 queue 讀取；同快照快取，generation＋取消記號防止切軸過期資料覆蓋。補上已有 inventory 惰性初始化的同步鎖，使資料與全字網格不會競爭建立快取。沒有修改替換核心演算法；OpenType 僅加 const lookup accessor，讀取既有程序。

### 實際驗證與證據

- 多次 arm64 建置完成，最後產物為 `dist/Glyph Atlas.app`。最末原始碼包含 inventory 同步與 OT boolean 修正。某次簽署被 file-provider 動態加回的根 `com.apple.FinderInfo` 擋住；清除附加屬性並重新 ad-hoc 簽署後，`codesign --verify --strict --verbose=2` 當次通過，但工作區 provider 之後會再附加該屬性。另以 `ditto --norsrc --noextattr` 保存乾淨副本並產生 `dist/Glyph Atlas.zip`，實際解壓至 `/private/tmp/glyph-atlas-information-archive-check/` 後嚴格驗簽通過；包內執行檔 SHA256 與工作區最後產物一致，證據在 `delivery-verification.json`。沒有把工作區附加屬性的暫時清除說成永久解決。未更改 build.sh，也沒有升級權限。
- `diagnostics/font-features-information-2026-11-03/build-verification.py` 在 `/tmp` 編譯現有 Sources＋核心與獨立驗證 main；結果保存 `verification-results.json`。Hoefler、Helvetica、蘋方港、Futura 100 CHI VF 四種字體，共128個實際原生 selector 選擇，檢查切換、互斥、原生設定字體建立、恢復預設；另用最小目錄檢查純 OT boolean 的預設 On／Off 兩種語義（這兩項是隔離模型驗證，不聲稱來自這四款字體的原生目錄）。
- 四字體資料樹分別367／422／5981／5338行（含收合進階細節），GID數1178／2252／49519／10235，與 inventory 一致；各驗 GID 0／1／最後一個能建立資料。多語系文字資源逐份 plist lint、重複 key 檢查；最終 diff whitespace 檢查。
- Hoefler 原生 CTLine 的 `fi` 預設為 GID191，一次關閉通用連字後為 GID73、76，恢復後顯式 settings 為空。
- **主 App 真實整條路徑**：輸入 fi→多字→點實際連字→資料顯示 GID191／U+FB01、來源0+2、raw advance1168、caret609；從主視圖右鍵關閉「通用連字」→點 i→資料顯示 GID76／U+0069、來源1+1、raw advance560。這是選單→TextKit→實際命中→側欄→資料的 GUI 驗證。
- 主 App 無選擇時顯示 Hoefler 字體資料；⌘點選中側欄行取消選擇後，資料自動由字形改字體。資料搜尋 sTypo、搜尋 wght、三種預覽與 ⌘I 往返、搜尋焦點退出均操作過。
- 主 App Futura VF：將軸400改700，資料立即更新至座標700／正規化1，命名實例 Bold700 正確列出；新窗口預設資料生效，還原預設全部字後重新啟動、新開 Futura 確實回到全字。
- 最終介面候選重新啟動檢查原生兩欄／長路徑換行／語言收合計數；資料複製到 TextEdit，看到標題、字體、單位、搜尋結果、各層來源；測試文字清空。Futura `H2O 123` 的 ⌘5 實際切成豎排，再按恢復；右鍵「上角文字／上標」讓數字實際縮小上移，還原字體預設恢復；單字→資料→單字後實際畫面仍是 H。

第一次資料 GUI 測試確實崩潰：誤把 `CTFontCopyAvailableTables` 的 unboxed integer tag 指標當 NSNumber 發消息。查 SDK 原文後改成 `CFArrayGetValueAtIndex`／uintptr_t 取值再裝箱，已修正。另一次同 UUID／舊 launch 時間的崩潰來自仍在執行的舊程序；此後以原生 Quit 選單、確認程序不在跑，再啟動產物，避免把重寫磁碟產物誤認為已換執行程序。原始 crash 在本輪 diagnostics 保存。後續資料頁實際正常工作。

沒有聲稱所有字體／macOS 版本或每個特性都已驗證。原生必要特性與竪排由 TextKit 決定，某些設定可能不改變顯示；本輪沒有全世界字體的整形等價保證。圓點使用原生 onStateImage，popup 未被 CUA 的窗口 screenshot 捕捉，不把 screenshot 缺少 popup 當作已視覺驗證其大小。背景窗口的右鍵歸屬與自訂 palette 排除已按源碼接線，但沒有額外做雙窗口背景點擊／改自訂色 GUI 實驗。原生 Undo／IME／觸控板 hardware 驗收不因本輪經過其他 GUI 操作而自動算通過。

### 對外說明建議（根 README 未改）

僅本輪新功能相關的 Usage 兩處：第28行視圖段落補 `⌘I opens Information; press it again to return to the previous view. Select a sidebar glyph for glyph information, or Command-click the selected row to return to font information.`；第29行多字段落改為 `In Multi-Character, use Typography in the View or context menu to choose the features provided by the current font. Vertical writing uses ⌘5.`。Help.09／Help.10 已在14個語系同步相應功能說明。根 README 第三方／其他段落未核對或重寫。

主要公開 API 依據：https://developer.apple.com/documentation/coretext/ctfontcopyfeatures(_:) 、https://developer.apple.com/documentation/coretext/kctfontfeatureselectorsettingkey 、https://developer.apple.com/documentation/coretext/kctfontfeaturesettingsattribute ，並直接核對本機 CTFont.h 的 available tables、metrics、name、caret／path 接口註解。

收尾時再次確定舊程序退出，再從工作區開啟最末產物；Futura 新窗口仍以已還原的全部字啟動，⌘I 正常顯示字體資料。留在該頁供明天驗收，搜尋空白、無側欄選擇、字體軸為原始400、該新窗口沒有測試用特性覆蓋。TextEdit 測試內容已清空。完成後執行此前使用者驗證過的睡眠命令；命令是否送出以本輪最後工具回覆為準，不以事前紀錄冒充已睡眠。


## 早晨驗收：移除特性還原入口與資料頁方案討論 — 2026-11-03

使用者已看到昨晚結果，整體認可；明確要求移除字體排印的「還原字體預設設定」，詢問圓點替代、資料頁其他方案與展示／不展示清單。新分支 `codex/typography-menu-cleanup`，改前 Sources／Resources／文件快照在 `diagnostics/typography-menu-cleanup-2026-11-03/before/`；保留此前所有未提交工作，未 commit／push。

直接執行已授權的移除：主選單與右鍵共用的還原項目及其上方分隔線、action、validation、僅供該命令的 `GAFontFeatures.restoreFontDefaults` 介面和實作、14語系鍵與 Help.10 還原句一起刪除。每個字體的原生初始預設及逐項切換語義不變。沒有為這個可逆、低影響刪除另寫測試；源碼引用掃描、14語系 plist lint／重複鍵、diff whitespace 檢查完成，arm64 建置完成。沒有重啟使用者正在使用的窗口。App 與 ZIP 均更新，`/private/tmp/glyph-atlas-menu-cleanup-delivery/` 乾淨副本嚴格驗簽通過。

圓點尚未修改。初步建議使用系統預設勾號，並引用 Apple Using Menu Item States（公開 NSMenu 單選也可用勾號），但使用者隨即明確指出必須讓使用者辨識互斥，不接受單選／多選統一勾號。以此最新產品要求為準。候選改為較小／較輕的實心圓，或完整「已選圓心＋外圈／未選空心圓」單選標記；後者較接近原截圖、語義清楚，前者較簡潔。尚未決定形狀／尺寸，不提前實施。

資料頁本輪僅討論，不改版。已實施的是一份原生可展開兩欄資料樹＋搜尋／複製；可比較的未實作方案為：分頁（概覽、度量、變數、佈局、字體表），或概覽表單＋低階資料樹。選前者可減少長頁滾動但增加跨類別切換；選後者可更快讀常用資料但有兩種版面。保留現結構時可優先考慮來源顯式顯示、CoreText normalized traits 標註更清楚、字體／字形分開保存搜尋避免空匹配；都屬建議，未實施。完整目前資訊清單依本輪核對過的 `GAFontInformation.m` 和前條記錄向使用者列出；未實作原始表解析不等於設計師不關心。

公開選單狀態依據：https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/MenuList/Articles/MenuItemStates.html 。單選標記的最終外觀仍由使用者選擇，不能把此接口能力當成產品偏好。


## 移除資料視圖、恢復舊輸入與預設程式、改為整套開檔快照及全文裝飾 — 2026-11-03

使用者改變產品方向，明確要求三項：建立分支並徹底移除資料視圖與配套程式；刪除逐項「預設…⌥…」入口，改成 View 底部、全屏命令上方的一次保存命令；從舊分支提取局部裝飾加入前的輸入框程式，僅保留 ⌘U／⌘L，將它們移至 Typography 最下方、作用於整段多字預覽。使用者補充三項都應從加入前的舊分支恢復；後續另要求 Option 將新保存命令替換為還原。這些是直接實施授權，不重新詢問已明確要求的修改。

分支 `codex/remove-information-unify-opening-settings`。本輪改前完整 Sources／Resources／README 及所有原有 tracked diff 保存於 `diagnostics/opening-settings-full-text-decorations-2026-11-03/before/`。保留此前顏色／行距、最近字體、原生字體特性、原生手勢識別器等未提交功能，未 commit／push。沒有恢復或擴大暫停的觸控板調查，沒有重啟使用者正在使用的 App。

### 已確認的保存語義

- 使用者選擇「按下時記住當前整套設定；之後的調整不影響，直到再按一次」，不是持續記住最新窗口。
- 保存模式、邊界框顯示、顏色、大小、行距、對齊、豎排、全文底線／刪除線。使用者選擇原生字體特性仍採新字體自己的預設；不保存跨字體 feature／變數軸／GID選擇，也不保存輸入內容或全屏。
- 使用者另明確選擇：顏色若跟隨系統，就保存跟隨狀態。這取代舊 Default Colors 中全跟隨時固定實際顏色的規則；沒有保留該舊 helper／比較路徑。
- Option 還原清除整套已存開檔設定，影響未來新窗口；現有窗口不變。還原不需要先有字體窗口。

### 舊分支與精確恢復的依據

`codex/saved-text-help` 指向 `0ff2507`，是整組 preview colors／line spacing／view defaults 提交前的版本；`codex/partial-text-decorations` 指向 `217ebf6`，是局部裝飾未提交修改加入前的版本。許多後續本地分支也指向 `217ebf6`，分支名稱本身不含後續未提交改動的快照，不能假稱每個分支都有不同資料視圖版本。資料視圖的加入前狀態另有上輪保存的 `diagnostics/font-features-information-2026-11-03/before/Sources/`。

直接以 git show 提取並恢復 `GASidebarInput.h/.m`、`GASidebarViewController.m`、`GAInputFocus.h/.m`；本輪已逐位元組比較，五檔與 `codex/partial-text-decorations` 完全一致。恢復 plain/richTextNO、usesFontPanelNO、原始 newline／paste／normalization 與自身空 updateFontPanel，明確 GID、換行標記及共享選色器修正保留。沒有只隱藏局部樣式入口而留下支援程式。

多字／Main 的純文字資料管線使用舊恢復 patch 提取，原先的 NSString、scan snapshot 的直接 multiText、輸入通知直接 scheduleAnalysis 都恢復；沒有 NSAttributedString 裝飾傳遞、multiSourceRanges、樣式投影、裝飾專用編輯 action／validation、RTF 裝飾讀取或 decoration-only 查詢分支。

逐項預設的 View 建構與縮放重設依 `codex/saved-text-help` 恢復，重新取回三模式原有 reset 函數；再疊回應保留的顏色、行距、原生字體特性、背景右鍵歸屬，以及本輪的新整套保存命令。沒有整檔覆蓋 AppDelegate／Main 而退掉這些其他功能。

### 最終程式結構

1. **資料視圖**：刪除 `GAFontInformation.h/.m`、`GAInformationViewController.h/.m`，並清除枚舉、⌘I、控制器 child／resource／selection／field editor 接線、背景 queue／cache、解析摘要 API、tableReadStatus、const lookups accessor 與只為背景資料建立的 inventory 鎖。CoreText 原生 Typography 模組保留。
2. **舊預設**：刪除 `GAViewDefaults.h/.m`、逐項 alternate、顏色／大小／對齊預設選單、舊各視圖 lazy default loading、匹配／清除／固定預設顏色 helper。舊偏好鍵不再讀寫；不為清空既有偏好引入額外相容／遷移程式。
3. **新快照**：`GAMainWindowController.saveOpeningSettings` 將目前模式與布林狀態合併 Detail 的 currentPreviewSettings，寫入單一 `GAOpeningSettings` 字典。Detail 保存共享 boxInset、多字 textScale／lineSpacing、全字 cellScale、原始 colors representation。窗口初始化時讀一次並統一套用，沒有每個視圖首次顯示再讀其他預設的程式。
4. **全文裝飾**：刪除 `GATextDecorations.h/.m`。主 Edit 裝飾項移除；Typography 底部分隔線後新增 Underline⌘U／Strikethrough⌘L，直接操作所屬窗口的 underlined／struckThrough。多字 TextKit 的整段基礎屬性與所有 fixed-GID 替代使用同一單線設定；不修改輸入框、選區、字形候選資料或查詢。無原生特性的字體也可使用這兩項；建構主選單時即放入快捷鍵項，不要求先展開 Typography。
5. **還原**：保存命令的 native Option alternate 呼叫 `GAMainWindowController.restoreOpeningSettings`，僅 removeObjectForKey:GAOpeningSettingsKey。⌘0 恢復原有 Actual Size 及出廠縮放；多字同時重設共享框／字級／行距0，不改寫開檔快照。

### 開檔／還原文案的系統依據

按使用者要求核對本機 Finder `Localizable.strings` 的 N151／LA44、VO14，確認各地 Open／Always open 的原文。香港保留使用者指定的「每次都以當前選擇來開啟檔案」；台灣「總是以目前選擇打開檔案」；簡體「始终以当前选择打开文件」。其餘11語系按 Finder 的開檔詞彙與語序翻譯新命令。

使用者後續詢問 macOS 中類似「保存／Option還原」叫什麼。本機 Finder `ViewOptionsWindow.strings` 的 `6.title`／`463.title` 同時提供：香港「作為預設值／還原至預設值」、台灣「作為預設值／回復至預設值」、簡體「用作默认／恢复默认」、英國英文「Use as Defaults／Restore to Defaults」。另核對 KeyboardSettings.appex 的 Localizable.loctable，Restore Defaults 為香港「還原預設值」、台灣「回復預設值」、簡體「恢复默认」。原始四語證據在本輪 `native-restore-wording.json`。Finder 的 restore 回到該資料夾所用的已保存預設，不等同清除 App 開檔快照；本功能回原始值更接近系統鍵盤的 Restore Defaults。

使用者要求「設置為默認的表述不變，港台簡分別」：建議新保存句不動、還原使用系統短名稱，不湊同樣長度。現以公開資源中的 KeyboardSettings「Restore Defaults」原文套用14語系，香港／台灣／簡體如上；沒有自行加「開檔」進該系統短名稱。參考官方說明：https://support.apple.com/zh-cn/guide/mac-help/mchlp1011/mac 與 https://support.apple.com/zh-hk/guide/mac-help/mchlp1011/27/mac/27 。本輪命名研究未做 Computer Use 操作系統設定。

### 檢查與交付邊界

正式 Sources 與目前 GLOSSARY 掃描已無資料視圖、舊預設、局部裝飾相關類／action／摘要介面；舊程式僅保留在歷史 git／diagnostics 快照供回退。14語系移除131個本輪無效的專用／逐項預設鍵，再加回原有 Actual Size、整套保存、原生 Restore Defaults；最終各104鍵，plist lint、重複鍵與 diff whitespace 檢查通過，沒有新增 source key 缺失。原先就缺失的 collection 提示翻譯不屬本輪，未藉機修改。

arm64 最末建置完成。恢復舊方法時先發現 resetZoom 宣告／實作曾隨舊預設重構移除、以及多字 text property 重複，已依舊分支取回／校正，最末無該編譯錯誤。依平常合作規則，本輪只做源碼核對、資源檢查與建置，沒有啟動測試程式、GUI驗證、修改使用者偏好或重啟 App；不能把上輪資料視圖 GUI 驗證當作本輪新快照／全文裝飾已驗收。工作區 App 需重新啟動才會載入新程式。

根 README 未修改；本輪直接相關的 Usage 建議：移除任何局部輸入樣式說明；Typography 增加全文底線／刪除線與 ⌘U／⌘L；整套保存／Option還原為未來窗口設定。Help.09 已恢復三視圖原文，Help.10 的14語系補上全文裝飾說明。


## Finder 短版預設名稱與「・」互斥標記 — 2026-11-03

使用者認為長版「每次都以當前選擇來開啟檔案」撐寬選單，明確選擇 Finder 顯示方式選項那組短名稱，香港指定「作為預設值／還原預設值」；另明確要求將 Typography 互斥選項圓點換成「・」試試。新分支 `codex/finder-default-labels-middle-dot`；改前 AppDelegate、14語系與文件快照在 `diagnostics/finder-default-labels-middle-dot-2026-11-03/before/`。其他未提交改動保留，未 commit／push。

保存／還原的行為與 Option alternate 不變。正式 source keys 改為 Use as Defaults／Restore to Defaults，14語系從本機 Finder ViewOptionsWindow.strings 的 6.title／463.title 取原文，具體值與來源路徑保存在本輪 native-labels.json。香港依使用者明確指定用「還原預設值」，省略 Finder 原文的「至」；台灣「作為預設值／回復至預設值」、簡體「用作默认／恢复默认」。舊長版 key 與前輪 Restore Defaults key 刪除，不留下兩套在用名稱。

互斥標記實際改為 U+30FB 字符，用所屬選單字體在原生 MenuOnStateTemplate 的尺寸內居中繪成 template image，交給 AppKit 著色；仍放在 onStateImage，不在選項標題拼字符，也不改單選邏輯。移除原 circle.fill／6pt SF Symbol 路徑。可並用特性與全文底線／刪除線仍使用原生勾號。

此為使用者要求的外觀候選，實際尺寸／視覺效果留給使用者重開工作區 App 驗收；本輪僅建置、資源與差異檢查，沒有啟動 GUI 或宣稱新標記已視覺驗證。前輪資料視圖移除、純文字輸入恢復、全文裝飾與整套開檔快照均保留。根 README 未修改。


## 「·」標記與補回輸入框面板同步修正 — 2026-11-03

使用者覺得「・」太細，先指定「•」，隨即更正為「·」；最終使用 U+00B7，不使用 U+2022。本輪使用者明確不要求新分支，保留在 `codex/finder-default-labels-middle-dot`；兩個來源檔與文件改前快照在 `diagnostics/bullet-panel-sync-2026-11-03/before/`。僅替換狀態圖內的文字，選單字體／原生圖標尺寸／template 著色／單選邏輯不變，多選保留原生勾號。

使用者另要求同步先前「開新字體窗口／重新進入輸入框導致舊窗口顏色被改黑」的 updateFontPanel 修正。核對正式 Sources 後發現確實缺少該空覆寫：前輪直接從 `codex/partial-text-decorations` 的217ebf6提取輸入檔，而空 updateFontPanel 是當時尚未提交的後續修正，未包含在該分支提交裡。此前記錄聲稱恢復後仍保留此修正不準確，本條予以更正；逐位元組等於舊分支本身並不能證明包含後來未提交的修正。

對比 `diagnostics/partial-text-decorations-2026-11-03/before/Sources/GASidebarInput.m`，與正式程式僅差已驗證過的四行 `GASearchFieldEditor.updateFontPanel` 空覆寫。直接取回該快照，沒有加入回呼過濾／新窗口關選色器／修改 colorOwner 或顏色設定順序。輸入仍為純文字，usesFontPanelNO 仍維持恢復後的既有配置；空覆寫本身阻止向共享字體／顏色面板同步，獨立於 AppKit 是否重設旗標。全文底線／刪除線仍由預覽自己的開關操作，不依賴輸入框原生屬性編輯。

本輪只做來源對比與建置，沒有再做 GUI 診斷或把舊日驗證冒充本輪測試。先前真實窗口／輸入重新進入／手動選色器驗證的證據仍在 color-panel-investigation-2026-11-02 的 visible-input-final-product-probe.log。新產物需使用者重開 App 驗收。沒有 commit／push。


## 縮小原生互斥圓點為4pt — 2026-11-03

使用者詢問原先 circle.fill 的其他變體，或直接改4pt試試。沿用目前 UI 調整分支 `codex/finder-default-labels-middle-dot`，改前 AppDelegate 與文件快照在 `diagnostics/circle-fill-four-point-2026-11-03/before/`。按明確試用要求恢復最初系統 SF Symbol 路徑，point size由原6改4、weight維持Regular；移除以文字「·」繪製 template image 的程式。原生多選勾號、命名、開檔快照與已補回的 updateFontPanel 均不改。

查閱 Apple SF Symbols 的 weights/scales 說明；符號支援九種 weight／三種相對 scale，但相關符號外觀與尺寸仍需在實際菜單驗收。公開依據：https://developer.apple.com/design/human-interface-guidelines/sf-symbols 。另讀本機 CoreGlyphs 公開資源目錄核對 circle 家族名稱。未啟動 GUI 或執行額外視覺測試；僅建置／差異檢查，使用者重開工作區 App 看4pt效果。沒有 commit／push。


## circle.fill 10pt 對照候選 — 2026-11-03

使用者觀察4pt改變的是寬度，大小未變，明確要求改10pt以進一步驗證。沿用當前 UI 調整分支，改前快照在 diagnostics/circle-fill-ten-point-2026-11-03/before/。僅將 NSImageSymbolConfiguration point size 從4改10，circle.fill、Regular、onStateImage、選單與其他程式均不改。使用者觀察不擴張成已確認的 AppKit 縮放機制；本輪未做 GUI 測量，10pt是配置值，不宣稱最終尺寸。僅建置與差異檢查，交使用者比較。未 commit／push。


## circle.inset.filled 候選 — 2026-11-03

使用者再次觀察10pt變化在左側寬度，要求暫維持此寬度並試 circle.inset.filled。沿用目前 UI 調整分支；改前快照在 diagnostics/circle-inset-filled-2026-11-03/before/。唯一產品程式變動是系統符號名稱由 circle.fill 改 circle.inset.filled，配置維持10pt／Regular，未另設 image size 或選單欄寬。最終實際佔位仍由 AppKit 按新符號處理，不以保留相同配置冒充已量測相同寬度。只建置與差異檢查，沒有 GUI 測量、commit／push。


## 「•」標記與右鍵裝飾項隱藏快捷鍵 — 2026-11-03

使用者否決 circle.inset.filled 外觀，明確要求試「•」，並要求右鍵的底線／刪除線不顯示快捷鍵。沿用目前 UI 調整分支；改前快照在 diagnostics/bullet-context-shortcuts-2026-11-03/before/。

互斥標記改為實際 U+2022 字符，以所屬選單字體在原生 on-state 圖示尺寸中居中繪為 template；移除 circle.inset.filled 的10pt配置。多選仍是原生勾號。Typography 根選單重建時依直接父選單是否 GAContextViewMenu 決定兩項 keyEquivalent：主選單保留 u／l，右鍵為空。兩處仍共用原 action／勾選狀態／窗口歸屬／全文作用範圍；主選單持續提供 ⌘U／⌘L。

僅建置與來源差異檢查，未啟動 App 或做 GUI 驗證；使用者重開工作區 App 看標記與右鍵外觀。其餘程式保留，沒有 commit／push。


## 放棄自訂圓點，統一原生勾號 — 2026-11-03

使用者認為「•」仍太細，明確放棄圓點方案、要求一律用勾。沿用目前 UI 調整分支；改前 AppDelegate、14語系與文件快照在 diagnostics/native-menu-checkmarks-2026-11-03/before/。

完整移除 addFeatureSelector 中自訂 onStateImage 的文字／繪圖／template 程式，交由 NSMenuItem 的原生 state 勾號呈現全部特性。單選／多選模型沒有修改：exclusive 組仍只選一個，非 exclusive 組仍獨立開關。右鍵底線／刪除線仍不帶快捷鍵，主選單 ⌘U／⌘L 保留。14語系 Help.10 同步改為勾號表示選中、互斥組每組只能選一項，不再提圓點。

此前要求單選與多選必須用不同標記的決定，由本次明確指令取代。僅建置／資源與差異檢查，沒有 GUI 驗證、commit／push。先前補回的 updateFontPanel 修正與其他功能保持不變，使用者重開工作區 App 驗收。


## 底線／刪除線選單歸屬討論 — 2026-11-03

使用者詢問兩項放在哪裡更合適，屬方案討論，沒有授權新一輪搬動。核對目前 Typography 同時包含原生字體特性與兩個全文裝飾。建議在 View 與主視圖右鍵的文字對齊／字體排印同層新增「文字裝飾」子選單，內放底線／刪除線；主選單保留⌘U／⌘L、右鍵不顯示快捷鍵。理由為兩項是與字體特性目錄獨立的全文預覽屬性，單獨分組更容易理解；僅兩項也無需新增頂層格式菜單。尚未實施，現有功能位置未變。

公開參考：https://support.apple.com/zh-tw/guide/mac-help/mchlp2544/mac 將底線／刪除線視為文字格式控制；https://developer.apple.com/design/human-interface-guidelines/menus 建議依邏輯關係分組並控制菜單長度。獨立「文字裝飾」屬本 App 的設計建議，不宣稱是 macOS 強制規範。


## 主選單文字裝飾、右鍵移除，以及原生文字控制調查 — 2026-11-03

使用者明確同意獨立「文字裝飾」，並修正提案：右鍵直接移除底線／刪除線，不新增右鍵裝飾子選單；另要求確認 macOS 有哪些相似控制、哪些值得本 App 做。沿用目前 UI 調整分支；改前 AppDelegate、14語系與文件快照在 diagnostics/text-decoration-menu-2026-11-03/before/。本輪授權只實施上述選單搬動，新增控制屬調查／建議，不提前實作。

主 View 在 Typography 同層後新增 Text Decorations，靜態原生 NSMenu 內放底線⌘U／刪除線⌘L；右鍵不建立此組。從動態 rebuildFontFeaturesMenu 刪除裝飾項與分隔線、showShortcuts 判斷。原生特性目錄不再混入裝飾。Action／驗證／勾選／全文範圍／開檔快照仍沿用既有程式；兩項仍只在多字模式可操作。14語系增加子選單標題，既有兩項名稱沿用原生用字。

### 原生控制的調查結果（尚未新增功能）

查公開 AppKit／CoreText 文件與本機 SDK NSAttributedString.h、NSTextView.h、NSParagraphStyle 屬性。下列是系統提供的排版能力，不代表都存在可直接嵌入本 App 的完整面板；也不把舊 TextKit1 接口列表當成 TextKit2 全部已驗證可用。

| 類別 | 系統能力 | 本 App 的建議 |
| --- | --- | --- |
| 底線／刪除線 | 無／單線／粗線／雙線；點線／虛線／點劃線；byWord 跳過空白；各自顏色 | 裝飾子選單中最自然的小幅擴充。先考慮單／雙／粗及是否跨空白；複雜線型與獨立顏色優先度較低。系統生成效果不冒充字體表原始數值 |
| Kerning | 原生使用標準字偶距／關閉／收緊／放鬆；attributed kern 值 | 優先建議做字體預設與停用對照，便於 AV／To 等 proof；不聲稱停用所有 GPOS。實施時需對照 TextKit2 的實際結果與字形反查 |
| Tracking | 正負數值調整均勻字距 | 值得，但 Apple 明示非零值可能停用非必要連字，除非指定 ligature 屬性；不能當成完全不影響整形的位移。需要原生預設重設與實際連字／命中驗證 |
| 語言 | kCTLanguageAttributeName 的有效 UTS35 語言識別可選字體本地化字形，影響地區換行 | 專業字體工具價值高，適合測 locl；應屬文字佈局控制，須連同自有反查語言路徑接線，不塞入裝飾 |
| 段落方向 | natural／LTR／RTL，與對齊獨立 | 阿拉伯／希伯來與混合數字 proof 有用，屬佈局控制，不是裝飾 |
| 基線／系統上標下標 | baselineOffset、raise/lowerBaseline、superscript/subscript | 基線混排測試可用，現有單字體全文模式優先度低；不能用系統縮放／移位冒充字體原生 sups／subs／sinf，後者沿用 Typography |
| 外框／描邊 | strokeWidth／strokeColor；正值描邊、負值填色加描邊 | 效果測試可選，優先度低；不是原始輪廓節點檢視，也不可默認改變真實筆畫呈現 |
| 字形陰影／文字背景 | NSShadow、backgroundColor；其他新版 highlight 屬性 | 陰影偏美術效果、非優先；字形／畫布色已具備。原生新版 highlight 有版本門檻，不宜把新 API 當12+都可用 |
| 段落 | 段前後距、縮排、tab stops、行高限制、斷字等 | 適合長段排印 proof，但目前已有行距／對齊／豎排，先不擴張成文書工具 |
| 人工傾斜／拉伸 | 舊 obliqueness／expansion 屬性 | Apple 明示不支援 TextKit2，SDK列為 deprecated；不建議。應優先用真實字體面或變數軸 |

若選下一項，推薦 Kerning 預設／停用對照；裝飾本身則以單／雙／粗線最實用。語言／方向是後續高價值佈局項。其餘先保留建議，不新增原始碼。

主要依據：

- https://developer.apple.com/documentation/appkit/nsunderlinestyle ：同一組 constants 適用底線與刪除線，含線型／byWord。
- https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/TextUILayer/Tasks/SetTextAttributes.html ：原生字偶距、連字、基線的 action 介面；舊文件行為需在本 App 的 TextKit2 再驗。
- https://developer.apple.com/documentation/foundation/nsattributedstring/key/tracking ：非零 tracking 與非必要連字的明確交互。
- https://developer.apple.com/documentation/coretext/kctlanguageattributename ：本地化字形與換行。
- https://developer.apple.com/documentation/appkit/nsparagraphstyle ：方向、行距、縮排、tabs、hyphenation 等。
- https://developer.apple.com/library/archive/qa/qa1531/_index.html ：描邊／填色的 signed stroke width。
- https://developer.apple.com/documentation/foundation/nsattributedstring/key/obliqueness ：明示不支援 TextKit2；本機 SDK對 expansion 亦作同樣註記。

本輪只建置與資源／差異檢查，沒有啟動 App 或對各候選屬性做 GUI 測試；不能把原生有 API 說成本 App 已驗證。使用者需重開工作區 App 驗收新選單。沒有 commit／push，updateFontPanel 修正與其他功能保留。


## TextEdit 實際控制核對 — 2026-11-03

使用者追問 TextEdit 做了哪些上述控制。本輪只調查，沒有改 Glyph Atlas 程式、建置或新增功能。核對本機 macOS 14.8.7（23J520）、TextEdit 1.19（404），以 Computer Use 在本輪新建的空白文件切成 RTF 檢查，未輸入文字或修改既有文件。

實際選單看到：格式／字體有粗體、斜體（本次所選 Lucida Grande 的斜體停用）、底線、中空字、樣式；字元間距有使用預設值／不使用／緊密／加寬；連字有使用預設值／不使用／使用全部；基線有使用預設值／上標／下標／提高／調低。格式／文字有四種對齊，書寫方向分段落及所選範圍、各有預設／LTR／RTL，並有間距與間尺。另有自動連字號、直向頁面、列表、表格。

實際工具列有字體／字面／大小、文字色／文字背景色、粗斜底線、四種對齊、行距及列表。行距詳細面板實際看到行高倍數、剛好／最少／最多行高、段落內行距、段前／段後距；以取消離開。樣式面板實際看到文件樣式／喜好樣式、瀏覽、套用、加入喜好與選取功能；以完成離開，沒有套用。

字體面板命令已切至「隱藏字體」，但本次 CUA 的主視窗 AX／截圖沒有提供獨立浮動面板內容，因此不冒充逐項目視驗證。Apple TextEdit 官方說明確認該面板提供底線／刪除線（例：雙刪除線及線色）、陰影的不透明度／模糊／偏移／角度，以及隨字體變化的 Typography 特性；本機 AppKit NSFontPanel／NSFontOptionsPanel 本地化資源亦有相應控制，但資源存在不等於本 App 全部有介面。官方現行指南的面板按鈕位置可能不同於本機舊版。

在本次檢查的介面沒有看到獨立數值 Tracking 或明確指定排版語言（shaping language）的選擇器；不把系統 API、拼字檢查語言或字體自帶特性當作此介面存在的證據，也不將本次未見說成所有版本均不存在。不能僅憑舊資源推論提供任意拉伸／傾斜。後續仍建議優先考慮原生字偶距對照與 RTL 控制，其餘保留討論。

官方資料：https://support.apple.com/en-lamr/guide/textedit/txte2be20f33/mac 。空白檢查文件未儲存；關閉時出現無法復原的刪除提示，已取消，保留空白視窗。


## 原生文字間距中的 No Kerning 實測更正 — 2026-11-03

使用者提供 Glyph Atlas 字體排印／文字間距截圖，指出最下方「預設」「不調整字元間距」，要求先驗證。本輪只核對與量測，沒有修改產品原始碼。此前把文字間距組概括為比例／全寬／半寬、不等同字偶距，漏掉同組末尾的實際 Kerning 控制，這個描述不完整。截圖中的原生項目確實涵蓋字偶距停用，不應對已有項目的字體再提議重複開關。

獨立 /tmp 探針直接編譯當前 Sources/GAFontFeatures.m，讀取本機真實字體 CTFontCopyFeatures，再經 chooseSelector 與 GACopyFontWithFeatureSettings 套用，分別以 CTLine 與原生 NSTextView 的 TextKit2 排版量測。HiraginoSans-W3 的 type22 有全部0–8項，7=Default（預設）、8=No Kerning；現有模型選8會輸出 type22／selector8，選回7則清空覆蓋。100pt、水平文字測得：AV 139.7→146.7pt；To 118.4→127.4pt；VA 138.7→146.7pt；漢字200→200pt。CoreText 與 TextKit2 數值一致，selector8結果亦與文字屬性 kern=0 對照一致。確認是實際停用字偶距，並非僅切字寬字形。

目錄依字體而異：本機 Times-Roman／Helvetica 無此type22組；PingFangTC-Regular有type22但沒有selector8。不能由此截圖推論每個字體都顯示同樣項目。本輪未操作 Glyph Atlas 真實窗口、也未對其全部自有引擎路徑作驗收；量測範圍是目前特性模型／顯示字體建立與原生CoreText、TextKit2排版。SDK公開 TextSpacing 枚舉與較舊線上Registry只列到6，不能據此排除實際查詢返回的7／8。

證據：diagnostics/native-no-kerning-2026-11-03/ 下的獨立探針與JSON原始結果。首次編譯因預設Clang快取在只讀目錄失敗，已把模組快取指向 /tmp 後成功，未申請額外權限。


## 排版語言重新實測、文字裝飾候選收斂 — 2026-11-03

使用者決定書寫方向維持預設，記得之前語言接口無效，要求實測；另問文字裝飾能否新增與字體內部資料有關的項目，排除純視覺效果。本輪僅研究，未改 Sources、選單、語系或開檔設定。

讀回2026-10-27 locl-control研究：當時無法可靠關閉的是locl=0，不是無法指定文字語言。以當前SDK重編舊Probe，在原fixture目錄執行；36個case與舊results.json完全相同。TRK專用合成字體的 a 在tr下GID4，在en／und／不指定下GID1；預設語言系統也有locl的fixture則全是GID4；設定locl=0未阻止相應替換。語言分支可選，但不是全局locl Off。

新獨立探針以macOS14.8.7的5個真實系統字面，分別測公開kCTLanguageAttributeName及Foundation NSLanguageIdentifierAttributeName（本機實際字串均NSLanguage），每種各跑CoreText CTLine和NSTextView TextKit2。後者讀原生CTLine，保持同一TextKit2 manager，未進相容模式。共44個屬性／字體／語言組合，各跑兩個排版引擎；兩個符號指向相同key，不能誤稱兩個獨立接口。每個run記錄實際字體PS名、GID、字形名。

PingFangTC-Regular固定相同字體、文字「骨直令」：zh-TW=[35463,4951,29348]；zh-HK=[8448,42349,29348]；zh-CN=[7755,4951,1381]；ja與不指定在本例均同zh-TW。兩個引擎與兩個key名稱的結果全相同，實際run字體均為PingFangTC-Regular，沒有透過替換成其他字體實現。ArialMT的iI（en/tr/az）、TimesNewRomanPS-ItalicMT和Georgia-Italic的бгдпт（ru/sr/bg）、HiraginoSans-W3的骨直令（zh-HK/TW/CN/ja）在本次樣本中沒有GID差異；不將無差異直接解釋成API無效或字體一定沒有相關規則。

公開接口在本機確實生效，可保留排版語言候選；不能把控制語言宣稱能關閉locl，也未完成Glyph Atlas整合與自有反查／重放語言資料流。這輪不新增語言選單。證據在 diagnostics/language-attributes-recheck-2026-11-03/。

文字裝飾調查：字體post表有underlinePosition/underlineThickness，OS/2表有yStrikeoutPosition/yStrikeoutSize；這些是現有底線／刪除線的資料類別，沒有找到符合使用者限制、值得加進此子選單的第三項。建議保留兩項。若日後擴充真正的字體檢查，可另考慮基線／x高度／大寫高度／升降部度量參考線，歸入邊界框同類的檢視輔助。沒有聲稱現有TextKit2原生裝飾逐項忠實採用原始post/OS2數值；那需要另外針對實際畫線做驗證。

參考：https://developer.apple.com/documentation/coretext/kctlanguageattributename 、https://learn.microsoft.com/en-us/typography/opentype/spec/post 、https://learn.microsoft.com/en-us/typography/opentype/spec/os2 。


## 書寫方向、排版語言與原生中空字 — 2026-11-03（選單狀態已過時，更新請看「移除排版語言、按RTL支援語言顯示書寫方向」）

使用者要求實測中空字能否看到未remove overlaps的輪廓；隨後明確授權新增書寫方向與排版語言，若中空字能看見交叉內線則一併新增。補充約束：右鍵選單完全不動。語言範圍經彈窗選擇「所有語言放在同一層，按本地化名稱排序」。中空字快捷鍵先討論⌘⇧O、⌘B，最後使用者明確改定⌘Y，取代此前的B決定；不保留其他別名。是否應在字體只有一個語言分支時隱藏仍屬討論，沒有實施自動隱藏。

改前建立本地分支 codex/text-layout-language-outline，保留現有未提交改動。改前完整Sources／Resources快照及本輪驗證證據在 diagnostics/text-layout-language-outline-2026-11-03/。沒有commit／push。

### 中空字實測

用獨立小字體構造A=兩個同向重疊矩形輪廓、B=相同幾何填色區域的單一聯集輪廓；分別建TrueType glyf與CFF Type2。TTF另有OVERLAP_SIMPLE標記與複合輪廓對照。原生NSTextView（TextKit2）選取文字呼叫outline:，確認系統設定NSStrokeWidth=3，再直接原生繪製至位圖。200pt時兩種格式A均出現被填色隱藏的內線，B僅有聯集外邊；測點A內線墨色1.00、B同位置0.00。普通填色幾何相同，位圖各僅1個像素差異，不聲稱逐像素完全一致。

最初CFF試件未完整閉合／統一慣用方向的版本有不完整描邊，已修正試件再重建重測；保留證據為最終有效版本，不將最初無效試件的結果歸因為系統限制。對照圖 ga-outline-comparison-20261103.png 展示TTF／CFF、普通填色／原生中空字。此功能僅顯示字體檔案還保留的輪廓，不恢復導出前已移除的輪廓，不顯示原始編輯器控制柄／節點。

### 實施範圍

- 主View在文字對齊後、字體排印前新增書寫方向（預設／由左至右／由右至左）與排版語言。兩組為原生互斥勾選，預設為自然方向／未指定語言。只在多字視圖啟用，不插入控制字符、不修改側欄文字。
- 語言取系統ISO語言代碼，規範化去重，加中文地區及必要文字體系變體；本機617個具體選擇加預設，共618項。單層按App本地化的NSLocale名稱排序，tooltip保留語言代碼；不根據字元覆蓋語言清單假裝判斷字體實際locl分支或自動隱藏。
- 書寫方向寫入NSParagraphStyle.baseWritingDirection；語言寫入公開kCTLanguageAttributeName；只重建原生多字排版，候選發現仍與顯示設定獨立。
- 文字裝飾末項新增中空字⌘Y，按全文布林值添加NSStrokeWidthAttributeName=3，沿用原生outline:的3%預設值。底線／刪除線保持原狀。三項與新增方向／語言都可隨「作為預設值」快照保存，之後改動不回寫快照；還原開檔設定後恢復自然方向、不指定語言、普通填色。
- 方向／語言切換取消過時的異步GID反查，結果回主線程時核對兩項狀態。自有回放的ICU文字準備接受明確基礎方向；有明確文字語言時不使用假設Default LangSys的快速回放，沿用既有字體語言分支搜尋，以實際原生GID／來源核對。沒有增加第二套CoreText shaping，也不把自有來源追查當作原生內部軌跡。
- 14語系新增五個選單名稱並更新Help.10；繁體為書寫方向／排版語言／由左至右／由右至左／中空字。語言實際名稱由系統提供。保留側欄updateFontPanel空覆寫等已有修正。

### 驗證與交付

獨立Probe連結當前產品Sources及佈局object，使用唯一bundle／偏好域com.zonz.GlyphAtlas.TextLayoutProbe，沒有修改正式App的偏好或既有字體窗口。1276個檢查中大部分是618個選項的唯一性／同層／排序核對，不能解讀成1276種不同字體情境。

具體行為通過：主預覽蘋方TC的zh-TW／HK／CN及還原預設GID；(123)的實際原生視覺索引LTR=[0,1,2,3,4]、RTL=[4,1,2,3,0]；⌘Y經原生NSMenu快捷鍵派送開／關中空字，還原填色；語言／方向互斥勾號；右鍵沒有新增語言／方向／裝飾；窗口獨立；整套開檔快照保存／凍結／還原；視圖往返保持語言、字形視圖禁用文字控制；TRK專用fixture與蘋方香港「骨」的自有GID來源反查。

探針最初在命令沙箱內建立NSApplication時遭LaunchServices註冊中止，並非產品功能斷言失敗。CUA第一次啟動完成原生驗證但因程式沒有窗口即退出而回timeout；新增反查測例後，最終以已獲自動核准的沙箱外獨立驗證程式完成上述1276檢查，證據為最終log。沒有操作正式App的真實窗口，勿宣稱完整人工GUI驗收。對照圖另有目視及內線像素取樣核對。

arm64建置、14語系資源語法／無重複key、來源差異檢查通過。乾淨副本嚴格codesign驗證通過，dist/Glyph Atlas.app與既有ZIP已更新；沒有測其他macOS版本或x86_64。正式App若仍是舊進程，使用者需重開驗收。


## 移除排版語言、按RTL支援語言顯示書寫方向 — 2026-11-03（語言部分過時，更新請看「以有序locl程序篩選恢復排版語言」）

使用者發現原先語言選單列出許多字體不支援的語言，要求有公開的字體支援語言查詢則使用，否則移除；另詢問方向是否需字體支援，要求先給例文，之後明確將其餘處理交給AI。先提供蘋方－繁的「123 - 456 (789)」，使用者已親見方向變化。補充：純中／英文的強方向字元通常不因段落基礎方向而逆排，數字組／中性標點和雙向混排才容易觀察。

AI查得CTFontCopySupportedLanguages，曾準備用它代替全部系統語言；實測蘋方TC103種、HiraginoW3117種、ArialMT62種、Times-Roman153種、Menlo183種、ArialHebrew2種（he/yi）。使用者隨後明確指出「支援語言」不是「支援locl的語言」；AI承認篩選依據混淆。此接口無法直接列出所需locl語言系統／分支；取得GSUB原始表後自行解析不等於有直接的語義查詢接口。按先前條件移除整個排版語言功能，不保留以字元／語言覆蓋清單充當locl分支選單的版本。

使用者最新另明確授權：先確認有無直接查詢字體是否「需要」書寫方向的公開接口；未找到則按支援的語言需要與否顯示，平時隱藏。公開的CTFont接口未提供此類需要旗標；以CTFontCopySupportedLanguages搭配NSLocale.characterDirectionForLanguage:判斷至少一項為RightToLeft，作為App顯示規則，不宣稱其餘字體無法排版RTL或純數字。兩個接口均公開且最低系統可用，不手寫語言名單。

### 原始碼與選單

本輪先建立codex/font-supported-typesetting-languages；語言範圍被澄清後，分支rename因.git reflog移動的權限限制失敗，改正常建立codex/remove-language-conditional-writing-direction成功。沿用同輪工作區全部未提交內容，沒有reset／checkout、commit或push。改前Sources／Resources及本輪證據在diagnostics/font-supported-languages-2026-11-03/。

- 完整移除排版語言選單／專用NSMenu類、action／validation、Controller／Detail／Multi的語言屬性與setter、kCTLanguageAttributeName覆蓋、開檔語言讀寫、異步反查的語言參數／過時核對，以及自有快速回放的特殊語言跳過條件。原始碼與14語系不再包含該功能字串或符號；歷史研究資料保留。舊偏好快照中的語言鍵不再讀取，下次保存整套設定時自然不再寫入。
- GAFontDocument於背景構造時用本機支援語言／語言方向API得出hasRightToLeftLanguages，只保留一個布林值；不存字體語言清單，也不把它傳入排版引擎。主窗口提供同名只讀值供UI。
- 主View保存明確delegate引用，每次打開只更新WritingDirection項目的hidden狀態；其餘主選單項保持原有顯示／停用規則，原右鍵delegate流程完全維持。沒有字體或沒有RTL語言時隱藏方向項；有RTL時顯示，三項仍僅在多字視圖可操作。
- 字體載入時若沒有RTL語言，重設自然方向；包含從舊開檔快照繼承的RTL選擇，避免控制隱藏仍有不易還原的效果。既有文字裝飾狀態保持原樣；中空字繼續⌘Y。
- 14語系刪除Typesetting Language名稱，Help.10改為說明RTL條件顯示與中空字。沒有更改根README。

### 驗證

以隔離bundle com.zonz.GlyphAtlas.DirectionVisibilityProbe連結目前產品Sources與佈局object，走實際非同步字體載入與原生選單更新，66項檢查通過。實測蘋方TC／HiraginoW3／Times-Roman／Menlo隱藏，ArialMT／ArialHebrew顯示；字體實際PS名均正確。例文在原生TextKit2的兩種方向確有不同視覺來源次序。換到LTR語言字體、繼承RTL開檔設定後再開LTR字體均恢復自然方向；裝飾保持；排版語言setter不存在、文字無語言覆蓋、新保存快照無語言鍵；右鍵沒有方向／中空字新項目，⌘Y保持。

Probe在獨立測試偏好域執行，未操作正式App窗口或改其現有偏好。運行經自動核准的沙箱外AppKit驗證，沒有人工批准等待／拒絕。raw支援語言JSON另保存，僅用作證據，不代表locl清單。未進行其他macOS版本驗收。

參考：https://developer.apple.com/documentation/coretext/ctfontcopysupportedlanguages(_:) 、https://developer.apple.com/documentation/foundation/nslocale/characterdirection(forlanguage:) 、https://www.unicode.org/reports/tr9/ 。

最終arm64建置、14語系資源／無重複key、git差異檢查通過。乾淨交付副本嚴格codesign通過，工作區dist App及既有ZIP已更新。使用者需重開正式App載入本輪版本；沒有關閉或改動其正在使用的正式窗口。


## 自有解析器列舉與篩選locl語言的最小方案調查 — 2026-11-03

使用者追問自有解析器是否也不能讀取locl語言，要求先找最簡單方案，特別篩掉宣告locl卻沒有替換預設字形的分支。本輪僅調查／隔離探針，未改產品Sources或選單，未恢復排版語言功能，沒有新分支／commit／push。

實際程式已具備資料與執行能力：GAOpenType.readScripts/readLanguage讀取各Script的DefaultLangSys及具名LangSys，含featureIndices與requiredFeatureIndex；OpenType.scripts/languages/features/plan公開於內部C++層，plan可選當前FeatureVariations分支。GASubstitutionEngine.discoverText既有流程已遍歷各語言。缺的是供產品選單使用的整理／匯出接口，不需要重寫GSUB解析。沒有公開CoreText語義查詢，不代表自有解析器無法讀表。

獨立Objective-C++探針直接連結當前GAOpenType/GASubstitution/GAGlyphBuffer/GAPositioning/GAVariation的object，未改其實作。每個Script／語言取locl的實際有序LookupStep，與同Script預設LangSys比較。相同程序直接視為同效果；程序不同且兩邊均為Type1（含extension包裝）時，逐一GID跑現有執行器，比較最終GID序列，找到第一個差異即可確認，否則篩掉。比較包含最終狀態，不能僅憑有trace／中途改變判定，也不能僅看Lookup索引不同。

空分支不能直接刪：預設LangSys本身可能有locl替換，明確語言的空locl或不引用locl會保留原本字形，與預設不同。建兩個小GSUB試件：default1為a→a，default4為a→alt；各含同程序、空feature、無locl引用、獨立identity、不同lookup但同效果、兩次交換而最終抵銷、真正替換、上下文a b→alt b。探針分類符合預期：default1下identity／空／無locl／抵銷等同預設；default4下這些反而有差異；default4下兩組不同lookup的a→alt同預設，會篩掉。上下文個案保留為待確認，不當作無效，並實際驗證單GID1不變、[1,2]變[4,2]。

再把兩個GSUB表放回有效小TTF，直接CoreText CTLine核對a：default4未指定語言為GID4，明確es／fr（分別無locl引用／空locl）為GID1；default1三者均GID1。原生結果確認空語言分支可有實際切換價值。此處DefaultLangSys比較不是locl Off，也不直接等同App的系統自動語言。

真實字體測量：蘋方TC（49,519GID）可讀出5個Script各自的ZHH／ZHS，10列均有與預設不同的Type1結果；合併語言標籤即香港／簡中兩類。HiraginoSans-W3無具名LangSys選項，不等於沒有預設locl或沒有其他原生特性。ArialMT／TimesNewRomanPSMT有arab/URD及latn/LTH，Georgia-Italic有latn/LTH及latn/ROM，均找到差異。探針連重新解析時間約0.18–28ms（本機單次，不是所有字體性能保證），當前變數座標用現有normalizeCoordinates/variationBranch選分支。

最小建議：相同有序locl程序先去重；常見純Type1分支用全GID最終輸出比較；有差異就保留；複雜／上下文分支先保留待確認，不以目前例文或單字未觸發就刪。跨Script合併時，只要某一Script有差異或仍待確認，就不能把整個語言刪掉。若恢復macOS語言預覽，還需OpenType語言標籤到系統語言碼的映射；本輪只驗證解析與篩選，不把這一段說成已接好。GID變化與肉眼外觀相同亦不同，不做輪廓相似度篩選。

證據：diagnostics/locl-language-filter-research-2026-11-03/。規範：https://learn.microsoft.com/en-us/typography/opentype/spec/chapter2 、https://learn.microsoft.com/en-us/typography/opentype/spec/features_ko#tag-locl 。


## 以有序locl程序篩選恢復排版語言 — 2026-11-03

使用者授權恢復自有解析器提供的locl語言選單；後續明確縮減為只比較相同的有序lookup程序，擔心逐GID第二層影響開檔。正式實作只做第一層，不逐字形執行、不另行shaping。先前研究的第二層方案未採用。

初始分支codex/parsed-locl-language-menu，變更前Sources／Resources保存在diagnostics/parsed-locl-language-menu-2026-11-03/before/。保留其他既有未提交變更，沒有commit／push。解析器比較同Script預設程序，含required feature、當前FeatureVariations；不同空程序保留，相同結果但不同程序亦保留。跨Script合併標籤。主選單按本地化名稱排序，無替代隱藏；右鍵不動，中空字⌘Y與方向條件顯示保持。

官方Microsoft OpenType語言登記表離線整理679項至Resources/OpenTypeLanguages.plist；系統原生名稱搭配標準語言標識，地區／音標標籤有明確對應；廣義多語群使用官方名稱避免冒充窄義語言。未知系統對應的標籤顯示停用。原始OT標籤用於來源反查與開檔快照，BCP47用於原生預覽；換字體／變數座標不再適用的選擇還原預設。參考：https://learn.microsoft.com/en-us/typography/opentype/spec/languagetags 。

隔離原生整合探針43項通過，走目前產品非同步載入、選單及原生多字佈局；沒有操作正式App窗口。蘋方骨直令的Default=[35463,4951,29348]、ZHH=[8448,42349,29348]、ZHS=[7755,4951,1381]；還原預設回到原GID。涵蓋快照、字體切換、右鍵未改、⌘Y、單字視圖停用及自有來源反查。獨立原始表fixture確認FeatureVariations與required feature、空程序、同結果不同程序的保留規則。

2000次微測量只衡量已解析資料上的新增比較：蘋方TC約0.002109ms、HiraginoW3約0.000404ms、Arial約0.000381ms、Times New Roman約0.000367ms、Georgia Italic約0.000322ms；不是完整開檔耗時或全部字體的保證。arm64建置完成；14語系lint／無重複key與差異空白檢查通過，其他macOS版本未測。

使用者接著要求預設項也有提示，並追問合併後顯示何種標籤。新增分支codex/locl-default-tooltip（當時工作分支為codex/clean-trial-files，保留原有工作樹），只補14語系tooltip：預設表示不指定排版語言、交由系統決定，不能標成某一固定語言或dflt。具名tooltip仍為原始標籤與系統標識；同標籤跨Script只顯示一次；與預設相同者直接省略，不另列入預設tooltip；不同具名語言不互相合併。


## 預設語言提示列出被篩掉的標籤 — 2026-11-03

使用者明確要求將被篩掉的語言標籤列在「預設」tooltip，並補充沒有標籤時完全不需要說明。新分支codex/locl-default-filtered-tags；變更前相關源碼保存在diagnostics/locl-default-filtered-tags-2026-11-03/before/。

同一次GSUB metadata比較同時收集相同程序標籤，扣除仍在其他Script具有差異而保留的標籤；以defaultLoclLanguageTags由Document背景構造緩存、Controller轉發。預設tooltip只顯示排序去重原始OT標籤，逗號分隔，空清單不設tooltip。移除前輪14語系Automatic Typesetting Language說明字串；具名提示、篩選規則、實際預設排版、右鍵保持。未新增額外解析、GID執行或shaping。

fixture斷言確認ENG列入被篩標籤，required feature亦正確，FeatureVariations分支改變時TRK轉入預設集合。實際蘋方TC／HiraginoW3／ArialMT／TimesNewRomanPSMT／Georgia-Italic的被篩集合均空，因此預設無提示；不能推測補上ZHT等未篩標籤。隔離探針源碼與JSON歸檔於同診斷目錄，未操作正式App窗口。arm64建置完成，沒有commit／push。


## 移除預設程序篩選，直接列出GSUB語言標籤 — 2026-11-03

使用者明確授權移除與預設lookup相同的篩選，只去掉跨Script重複的同一標籤，預設不再有tooltip；此前另要求直接顯示原始標籤並移除對照。分支codex/locl-declared-language-tags，改前源碼快照在diagnostics/locl-declared-language-tags-2026-11-03/before/。

解析器簡化為languageTags()，所有具名LangSys集合去重；移除lookup／required feature／FeatureVariations的比較、defaultLanguages輸出、橋接out參數、Document／Controller的預設標籤緩存與UI tooltip。其餘接口改名typesettingLanguageTags避免誤稱為locl差異清單。主選單改用原始標籤排序顯示，去掉具名提示、系統名稱整理與失去用途的名稱函式／14語系提示字串；Help同步描述所有GSUB具名語言與跨Script去重。

未重新測量字體樣本或盛行率。另已詢問移除底層對照的具體影響：原生預覽無法直接用所有OpenType標籤切換，需要確認保留切換所需對照、或移除切換僅供查看。等待答案時不擅自刪除實際切換能力，內部對照與原生預覽仍保留。


使用者回覆「那還是完整保留之前的對照吧」，撤回移除對照的要求。完整保留GAOpenTypeLanguages／679項資源、原有本地化名稱／排序、具名tooltip與原生切換；撤回本輪原始標籤UI整理及名稱函式刪除。最終僅移除預設程序篩選、預設標籤緩存與預設提示；14語系Help同步新列舉規則。沒有新增測量或實機測試。


## Futura CHS 100空白語言名稱診斷 — 2026-11-03

使用者要求測試Futura CHS 100的多個空白標籤。本輪僅診斷，未修改產品原始碼或重新建置。使用已安裝/Users/zonz/Library/Fonts/Futura100CHI-Var.ttf，獨立CoreText檔案descriptor取到預設實例PostScript名Futura100CHI-Light，未註冊／安裝新字體，也未操作正式App。

原始SFNT GSUB有5個Script、21個具名LangSys記錄／21個唯一標籤，沒有空白或全空格標籤；GPOS有5個Script、無具名LangSys。隔離探針連結目前GAOpenType解析器及GAOpenTypeLanguages.m，附目前OpenTypeLanguages.plist資源，確認21個名稱中KSM（sjd，Kildin Sami）、SJE（sje，Pite Sami）、SJU（sju，Ume Sami）在zh-HK／zh-Hant／zh-Hans／en均回傳長度0的系統名稱。

原因：GATitleForOpenTypeLanguage的title ?: entry[name]只處理nil；空字串並非nil，所以不使用登記表內有效英文名稱，最後成為空白選單項目。字體標籤與自有解析沒有丟失。最小修正建議改為檢查title.length後再選擇原有登記表名稱／原始標籤，等待使用者決定，沒有混入相鄰改動。

證據：diagnostics/futura-language-empty-titles-2026-11-03/，包含原始GSUB／GPOS語言記錄、隔離名稱探針及4語系結果。此次結果只針對這個字體及本機系統。


## 名稱空字串擴查、公開語言API與主選單停用診斷 — 2026-11-03

使用者擔心其他空字串，要求查CoreText是否提供轉換API，並指出非多字視圖中頂層文字子選單仍像可用。本輪只檢查、隔離探針與提案，未改產品Sources或正式App狀態。

目前679項OpenType語言對照逐一跑14語系的現有名稱函式，222項至少一語系得到空標題（繁中等13語系各222，英文221），不是222個字體。登記表679個官方名稱均非空，14語系Localizable.strings無空白值。Futura以檔案descriptor建立並核對Futura100CHI-Light，連同蘋方TC、HiraginoW3、Arial、TimesNewRoman、GeorgiaItalic共6字體的原生feature群／selector及display／style名稱未發現空值，不把樣本未出現當成普遍保證。

程式檢查另發現潛在名稱入口：GAFontFeatures群名稱的?:只判nil，selectorName直接傳選單；GAFontResource的DisplayName及可變實例StyleName也只判nil；GAVariationViewController直接使用原生axis名稱。GAFontDocument.fullName及字形名稱已有length檢查。空語言選擇等合法空狀態不能一律替換。

查本機CoreText公開headers及Apple官方文件，未找到OpenType四字節語言標籤與BCP47／locale identifier直接轉換的公開CoreText API。kCTLanguageAttributeName接受locale identifier並影響localized glyph／斷行；NSLocale.localizedStringForLocaleIdentifier提供顯示名稱（目前已用），不能代替OT映射，也不能保證非空。保留未找到公開接口的表述，不宣稱CoreText內部沒有對照。

主選單上層TextAlignment／WritingDirection／TypesettingLanguage／FontFeatures／TextDecorations是action:nil的submenu父項，現有可用性驗證只針對子命令；主View delegate僅更新方向與語言hidden，所以出現父層亮、子層灰。隔離AppKit探針（獨立bundle，activation prohibited，不建窗口）確認nil-action submenu父項可設停用，亦驗證帶target/action的父項會走validateMenuItem，連續禁用／啟用／禁用均正確。Apple文件警告autoenablesItems可能覆寫手動enabled，正式修正需把父項納入穩定更新／驗證，不能只設初始值；不必關閉整個View自動驗證。右鍵顯示規則維持。

參考：https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/MenuList/Articles/EnablingMenuItems.html 、https://developer.apple.com/documentation/foundation/nslocale/localizedstring(forlocaleidentifier:) 、https://developer.apple.com/documentation/coretext/kctlanguageattributename 。證據在diagnostics/menu-availability-and-empty-names-2026-11-03/。尚待使用者決定修改範圍。


## 修正文字排版父選單可用性，另查簡潔名稱API — 2026-11-03

使用者明確只先修上一輪第3項；其他名稱空值／語言轉換繼續找更優雅簡潔方案，不授權順手修名稱。本輪新分支codex/text-layout-submenu-availability，改前GAAppDelegate.m保存在diagnostics/text-layout-submenu-availability-2026-11-03/before/。

唯一產品源碼修改為GAAppDelegate.m：主View既有menuNeedsUpdate中，以同一textLayoutAvailable布林值同步TextAlignment／WritingDirection／TypesettingLanguage／FontFeatures／TextDecorations父項enabled，後者補穩定identifier。非多字及無窗口禁用，多字恢復；既有方向／語言hidden獨立保留。沒有關閉autoenablesItems、沒有新增menu子類／虛設action或修改右鍵。

隔離AppKit探針連結目前產品Sources與layout objects，獨立bundle及偏好域、activation prohibited，不顯示窗口或操作正式App。模擬menuNeedsUpdate後再連續執行兩次NSMenu.update，7次模式／窗口狀態各3輪，253項斷言通過，包含5個父項與豎排一致、恢復啟用及保留自動驗證。初版探針只呼叫NSMenu.update，未模擬打開時的delegate回呼，第一項因此失敗；修正探針前提後產品源碼不再改動。arm64建置與git diff --check通過，未commit／push。

名稱調查找到Foundation更合適的舊公開API：NSLocale.displayNameForKey:NSLocaleIdentifier value:，回傳nullable。實測sjd／sje／sju在localizedStringForLocaleIdentifier得到空字串，在displayNameForKey得到nil；保留zh-Hant-HK／zh-Hans／ro-MD等完整差異。localizedStringForLanguageCode雖也nullable，但把地區／書寫系統資訊省略，不適合取代本用途。CFLocaleCopyDisplayNameForPropertyValue有同樣效果，直接Foundation較簡潔。

獨立候選方案全表679×14＝9506項比對，現有非空名稱變更0、替代後剩餘空標題0，修復3107個語系×標籤空值。候選只是把現有名稱API替換，沿用官方登記表／原始tag fallback；未修改GAOpenTypeLanguages等產品碼。其他字體自帶名稱建議各模型讀入時統一處理一次、使用各自既有名稱／tag／ID，而非在各個UI補判斷或建立全App空字串攔截。未找到可取代OT語言對照的公開CoreText轉換API。

官方參考：https://developer.apple.com/documentation/foundation/nslocale 、https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPInternational/InternationalizingLocaleData/InternationalizingLocaleData.html 。本輪探針與JSON歸檔於同診斷目錄，名稱候選仍待授權。


## macOS 26 主窗口、側欄與工具列第一輪適配 — 2026-11-03（標題列／VF按鈕及頂距已過時，更新請看「macOS 26 恢復緊湊標題並延伸畫布底色」）

使用者提供macOS 26深色主窗口截圖，要求符合26設計，同時不得改變macOS 12–15及27的UI；每輪改碼前建立分支。明確授權先處理側欄結構／材質、標題列層次及邊距／圓角三項；其他介面目前無問題，由使用者自行驗證，不納入此輪。26無法在本機執行，使用者將在26機器自行構建及提供驗收截圖；本輪另明確要求確認本機改前改後UI相同。

先建立codex/macos26-sidebar-toolbar-layout，保留全部既有未提交變更，沒有commit／push。改前完整Sources／Resources及build.sh快照在diagnostics/macos26-sidebar-toolbar-2026-11-03/before/。未修改字體、語言或其他排版邏輯，也未改可變面板內部、選單、對話框與預覽畫布。

新增共用GAMacOS26.h，GAUsesMacOS26Layout僅在NSProcessInfo系統主版本恰好26返回YES，27亦走原路徑。26不再強制透明標題列，使用系統標題列背景及Unified工具列；字體名保留無玻璃資訊文字，原與字體名合包的可變按鈕改獨立原生NSToolbarItem，帶原生邊框、沿用圖示／動作／本地化名稱，靜態字體隱藏，Popover使用公開showRelativeToToolbarItem錨定。舊系統與27的UnifiedCompact、自訂stack與原按鈕／Popover路徑完整保留。

26側欄取消ScrollView不透明背景並設SourceList背景透明，讓系統材質呈現；搜尋框改錨本視圖safeArea，左右12pt／頂部8pt，列表底部距safeArea8pt；文字內縮12pt。這些是手調初版值，不宣稱Apple指定了相同數字。其他系統沿用原9pt與窗口contentLayoutGuide佈局。所有新增UI API均可由本機15.2 SDK編譯；沒有更換SDK、deployment target或全局外觀選項。實際26玻璃範圍、圓角、按鈕及小窗口效果尚待使用者驗收，沒有冒充26或27實機測試。

本機14.8.7使用隔離AppKit驗證程式與獨立bundle／偏好域com.zonz.GlyphAtlas.UIComparison.20261103；直接連結改前快照及改後產品Sources，使用相同現有核心objects，不操作正式App窗口或其偏好。讀真實Helvetica靜態字體與系統可變字體，等待非同步文檔及完整test文字快照發佈，再對三種視圖×深淺外觀×600×400／900×600窗口×兩種字體各取原生窗口影像，共24組。改前改後24組RGBA逐像素相同，變更像素0；視圖樹、frame／bounds、控件字體／尺寸、工具列項與窗口佈局數據一致（JSON只忽略NSFont描述中的進程記憶體地址）。這是本機受控狀態驗證，不能等同所有交互、12／13／15或27實機驗收。證據含before-ui／after-ui、geometry.json、pixel-comparison.json與comparison-summary.json，均在同診斷目錄。

arm64編譯完成。初次常規build的簽名因工作區dist App根目錄的FileProvider／FinderInfo附加屬性失敗；在/tmp以無資源叉／擴展屬性副本完成簽名及strict驗證後回填dist，未因此改build.sh。未重新打包既有ZIP。Apple方向參考：https://developer.apple.com/videos/play/wwdc2025/310/ 、https://developer.apple.com/documentation/appkit/nswindow/titlebarappearstransparent 。


## 採用nullable語言名稱API並在模型入口補空名稱 — 2026-11-03

使用者回覆「好的，改吧」，授權上一輪建議的語言名稱API替換，以及各模型讀入時處理其他空名稱。本輪從當時工作分支codex/macos26-sidebar-toolbar-layout建立codex/nonempty-font-display-names；保留其他未提交介面變更及根目錄GlyphAtlas.zip，未修改它們。改前3個源碼檔快照在diagnostics/nonempty-font-display-names-2026-11-03/before/。

GAOpenTypeLanguages.m只替換名稱API為displayNameForKey:NSLocaleIdentifier value:，沿用完整映射、既有英文登記名稱與原始標籤fallback，無新增依賴／對照。GAFontFeatures.m在模型構造時補群名稱與可見selector名稱，使用既有tag／type／selector標識／OT value；保留所有控制欄位、預設與選擇語義。GAFontResource.m於構造時補空軸名稱為原始四字節axis tag，空DisplayName使用既有Untitled Font、空StyleName使用既有Default；不更動家族歸並／坐標／命名實例順序。介面端不加判斷，合法的空語言覆蓋等狀態不改，也不修剪字體內的非空字串。

隔離Foundation／CoreText探針直接連結目前三個產品實作，用Futura檔案descriptor建立資源；得到Futura 100 CHI、1軸、6命名實例、17特性群，所有顯示名稱非空。KSM／SJE／SJU的繁中名稱實際為Kildin Sami／Pite Sami／Ume Sami。未操作正式App窗口或安裝字體。此處確認實際樣本，不聲稱每種損壞字體／其他OS均已測；全表9506候選比對證據沿用上一輪診斷，未重複測量。

初次編譯指出ARC fast enumeration變數不能改寫，改為獨立namedSelector局部變數後arm64建置完成，差異空白檢查通過。工作區App與既有dist ZIP更新，乾淨副本strict codesign通過；未commit／push。探針及JSON歸檔於本輪diagnostics目錄。


## macOS 26 恢復緊湊標題並延伸畫布底色 — 2026-11-03（背景已獲實機確認；26工具列樣式過時，更新請看「macOS 26 保留完整側欄，只恢復整體工具列佈局」）

使用者提供26實機預設灰底／自訂紅底的兩張截圖，回報三點：VF獨立工具列按鈕有懸浮背景且與字體名似不齊、佔空間；輸入框與紅綠燈／字體名之間太空，希望恢復標題上下近似留白；右側仍被不透明標題列遮住，底色也沒有延伸到側欄下方。本輪延續同一適配範圍修正，不納入其他面板／選單或排版功能。第一輪將26標題列背景打開與採用Unified，是右側新增不透明橫帶的直接程式原因；未延伸detailItem則未提供玻璃側欄下方的預覽底色。

從當時codex/nonempty-font-display-names建立codex/macos26-compact-title-background，保留最新名稱修正與全部既有未提交內容、根GlyphAtlas.zip。首次一般沙箱建立branch因.git lock寫入權限失敗；改經工具自動核准的權限提升建立成功，沒有人工批准等待或拒絕。修改前完整Sources／Resources與build.sh在diagnostics/macos26-compact-title-background-2026-11-03/before/；無commit／push。

移除第一輪專用GAVariations項、variationToolbarItem及新Popover錨路徑，全部系統恢復既有無邊框VF按鈕＋字體名stack，間距5pt，工具列項borderedNO，靜態字體隱藏原按鈕；Popover回到原按鈕錨，相關失去用途的代碼同步移除。所有系統統一恢復titlebarAppearsTransparentYES／UnifiedCompact，26搜尋框頂部亦恢復窗口contentLayoutGuide頂邊-1pt，不再疊加safeArea頂部8pt。26左右12pt、列表底部8pt、透明捲動背景等前輪設定保留；其他系統的對應行為原本就未改。

背景使用公開NSSplitViewItem.automaticallyAdjustsSafeAreaInsets，在系統主版本恰好26時啟用detailItem延伸；GADetailContainerView沿用同一GAPreviewColors，在完整容器填預覽底色，三種預覽子視圖左緣約束至本視圖safeArea，頂部仍貼容器，不把字形排進側欄，也沒有鏡像字形。選色、還原系統色、整套開檔顏色與有效外觀變更均更新該底色。12–15及27不啟用新分欄屬性／底色與safeArea左緣。GAMacOS26.h僅在舊SDK補聲明該公開屬性，呼叫同時受26精確版本與availability約束；不以私有API或更換SDK解決，不改deployment target或build.sh。背景延伸是本輪實施方案，實際26浮動材質與頂部效果仍待使用者截圖驗收。

本機14.8.7以本輪修改前快照及修改後Sources各編譯隔離AppKit程式，使用獨立偏好域com.zonz.GlyphAtlas.UIComparison26Round2.20261103，沒有操作正式App與其偏好。沿用前輪的真實靜態Helvetica／系統VF、三種視圖、深淺外觀及600×400／900×600窗口，新增每個狀態的預設色與紅色背景，共48組。全部48組RGBA逐像素相同，變更像素0；原生窗口／控件視圖樹、frame／bounds、字體／控件尺寸與工具列佈局數據亦一致（只略去NSFont描述的進程地址）。對照證據與源碼在同診斷目錄。未在26或27及其他舊系統實機執行，不將本機未改變等同26修正已通過驗收。

arm64構建完成；dist根目錄之後被FileProvider重新附加FinderInfo，strict簽名驗證指出該屬性，僅清除該產物屬性後strict通過，未改構建流程。Sources本輪只變更GAMainWindowController.m、GASidebarViewController.m、GADetailViewController.m、GAMacOS26.h；Resources及build.sh與本輪快照相同，未更新任何ZIP。git diff --check通過。

公開接口依據：https://developer.apple.com/videos/play/wwdc2025/310/?time=324 、https://developer.apple.com/documentation/appkit/nssplitviewitem/automaticallyadjustssafeareainsets 、https://developer.apple.com/documentation/appkit/nswindow/titlebarappearstransparent 。


## macOS 26 保留完整側欄，只恢復整體工具列佈局 — 2026-11-03

使用者以紫色背景／綠色字形的26實機截圖確認「這次背景對了」，並糾正上一輪：第一輪將側欄上下延伸、把窗口按鈕及字體名稱包入同一塊的結構才是對的；要求修正細節，不是退回原本標題區在側欄外的結構。AI承認上一輪將整體佈局也回退，超過了所需修正。後續必須同時保留已確認的背景延伸、完整浮動側欄、無背景VF按鈕及較近輸入框頂距，不能為修一項把另一項撤回。

改前從codex/macos26-compact-title-background建立codex/macos26-full-height-sidebar，保留所有既有未提交變更及ZIP。完整Sources／Resources與build.sh快照位於diagnostics/macos26-full-height-sidebar-2026-11-03/before/。本輪唯一產品源碼修改是GAMainWindowController.m的toolbarStyle：系統主版本恰好26時恢復第一輪使用的Unified，12–15及27保持UnifiedCompact。

保留透明標題列YES、detailItem延伸、背景底色繪製與safeArea左緣，GADetailViewController／GAMacOS26.h／GASidebarViewController／GASidebarInput均與本輪改前逐字相同；無背景VF按鈕與字體名stack、Popover錨、輸入框頂距亦未改。沒有重新打開造成橫帶的標題列背景，沒有重新拆出獨立玻璃按鈕，沒有改Resources、build.sh或任何ZIP。

第一輪與第二輪之間同時改了標題列透明與工具列樣式；現有截圖不足以把整塊側欄的差異單獨歸因於其中一項。這輪只恢復Unified，隔離這個變數並保留已獲確認的背景方案；不能在缺少26執行環境時聲稱恢復整塊側欄已實機通過，仍待使用者下一張截圖。Apple文件只保證Unified與UnifiedCompact的標題／工具列排列及緊湊程度，不以文件推論代替26實機。

本機14.8.7隔離AppKit前後對照於使用者新指令抵達前已完成：48組預設／紅底、兩字體、兩種窗口大小、深淺外觀及三視圖的RGBA逐像素相同，變更像素0；原生佈局JSON亦一致，僅忽略NSFont進程地址。獨立偏好域為com.zonz.GlyphAtlas.UIComparison26Round3.20261103，未操作正式App。arm64構建完成，dist附加FinderInfo清除後strict簽名驗證通過，差異空白檢查通過；證據在同輪診斷目錄，未commit／push。

使用者隨後明確表示「不需要測試了，我先確認26下UI正確」。從此指令起停止新增本機測試／前後截圖對照，先等待使用者26實機驗收；不得沿用前輪要求每輪48組對照繼續測試。上述48組是新指令前已完成的工作，不是忽略停止測試要求後執行。


## macOS 26 主窗口實機確認，查詢輸入框頂距 — 2026-11-03

使用者提供橙色背景、完整深色浮動側欄的26實機截圖，明確表示「這次看起來完全正常了」，僅問文字輸入框與標題欄之間目前設定多少。當前版本是Unified加透明標題列，完整側欄包含窗口按鈕與字體名，保留無背景VF按鈕及已確認的背景延伸；此輪主窗口驗收已獲使用者確認，不擴大為其他系統或全部互動驗收。

讀取當前GASidebarViewController.viewDidAppear確認：searchField.topAnchor相對window.contentLayoutGuide.topAnchor的constraint constant仍為-1pt。這是系統內容區上緣的約束偏移，不是標題字樣／窗口按鈕底部到輸入框之間直接設定的空白；實際可見距離也受Unified工具列的系統高度及內部留白影響。本輪未改產品原始碼、沒有新分支或執行測試。


## macOS 26 輸入框頂距再縮小7pt — 2026-11-03

使用者先要求再減8pt，隨即更正為「減7pt」，以最新7pt為準。先從codex/macos26-full-height-sidebar建立codex/macos26-input-top-spacing；原8pt要求尚未改入代碼，因此沒有實施或保留8pt版本。改前GASidebarViewController.m在diagnostics/macos26-input-top-spacing-2026-11-03/before/。

唯一產品修改為viewDidAppear的searchTopConstraint constant：主版本恰好26為-8pt，即原-1pt再減7pt；12–15及27仍為-1pt。輸入框上移，下面列表沿原相對約束同步上移；完整浮動側欄、透明標題、無背景VF按鈕與已驗收背景延伸保持。依使用者最新要求不執行本機UI測試或前後對照，26效果交由使用者確認；沒有commit／push或修改ZIP。


## macOS 27及以上輸入框頂部偏移改為0pt — 2026-11-03

使用者在確認其他系統仍是-1pt後，明確要求「27+改成0pt」，授權這一處27及以上的UI差異，取代最初不得改27 UI的相應窄範圍限制。從codex/macos26-input-top-spacing建立codex/macos27-input-top-spacing，改前GASidebarViewController.m位於diagnostics/macos27-input-top-spacing-2026-11-03/before/。

唯一產品修改仍在viewDidAppear的searchTopConstraint：以NSProcessInfo主版本>=27時選擇0pt，26保持-8pt，12–15保持-1pt。其他佈局、背景、工具列及按鈕均未改。沿用不執行測試／前後畫面對照的最新要求；沒有commit／push或修改ZIP。


## 開窗800px、拖動下限820px的只讀診斷 — 2026-11-03

使用者先確認前輪完全正常，另報開窗為1200×800、拖動後最小只能1200×820，懷疑系統額外補償，並問其他系統是否已有處理。明確要求「先看不修」，本輪只讀當前Sources、git歷史、本機SDK公開headers及Apple文件，未改產品、建分支、構建、啟動App或執行測試。

當前GAMainWindowController.init先寫入window.minSize=600×390pt，接著configureInterface建立分欄／工具列，26使用Unified、其他系統UnifiedCompact；最後以setFrame:display:將外框重設600×400pt。未找到其他minSize／contentMinSize設定、系統標題列高度差計算、工具列建立後重設最小值或窗口拖動尺寸delegate補償。390這個固定值在2026-10-19既有提交已存在，沒有本輪新增的26最小尺寸補償；僅憑其比400少10pt，不能確證原作者設定意圖。

按2×截圖換算，開窗600×400pt=1200×800px，宣告最小600×390pt=1200×780px，使用者觀察的拖動下限600×410pt=1200×820px。實際下限比早期設定多20pt／40px，比開窗多10pt／20px，不能把這兩個差值混為同一個補償。Apple minSize公開說明指出setFrame:display:及帶animate的對應方法不受該最小值強制限制，因此開窗可以低於後續有效拖動下限。本機SDK亦註明自動佈局時minSize／contentMinSize可能不作最終限制。

工具列建立／樣式改變及AutoLayout是優先診斷方向，但尚未讀取26運行時的minSize、contentMinSize、內容fittingSize或各階段值，不能斷言額外20pt全來自哪個AppKit機制，也不能宣稱其他OS的有效拖動下限已補償正確。公開依據：https://developer.apple.com/documentation/appkit/nswindow/minsize 、本機NSWindow.h的minSize／contentMinSize註解。

使用者隨後補充：其他系統原本就是把最小值設390pt，才讓實際最小值等於400pt。據此更正先前對意圖的不確定：390是既有固定10pt補償，不是尚未處理過此問題。這是使用者提供的既往驗收依據，不冒充本輪新測量。使用者接著表示「看來26要給到380」；按目前26設定390→實際410的觀察，若其20pt差值固定，380就是讓實際下限回到400pt的候選值，其他版本仍保留390。仍屬先看不修的討論，沒有修改產品、建分支、構建或測試，也尚未將380當作26已驗證結果。


## macOS 26 最小窗口高度補償改為380pt — 2026-11-03

使用者明確授權「改吧，不改我怎麼驗證。改完無須測試」。先從codex/macos27-input-top-spacing建立codex/macos26-minimum-window-height，保留其他未提交內容；改前GAMainWindowController.m在diagnostics/macos26-minimum-window-height-2026-11-03/before/。

唯一產品修改為原window.minSize賦值：GAUsesMacOS26Layout為真時600×380pt，其他系統仍600×390pt；初始外框600×400pt與賦值時序保持。預期26在原有20pt差值下拖動下限回到400pt，但尚待使用者實機確認，不聲稱已修復驗收。沒有新增尺寸攔截、重新計算工具列高度或調整其他佈局。不執行測試、UI操作或前後對照；無commit／push及ZIP修改。


## 窗口大小納入預設值、本機架構構建與ZIP清屬性腳本 — 2026-11-03

使用者確認最小尺寸修復，明確結束macOS26 UI適配。新授權兩項：「作為預設值」一併保存窗口大小；build.sh無參數只生成本機架構，參數選通用／指定架構，ZIP包含可一鍵xattr -rc的腳本。參數先討論長形式，使用者要求簡短並指定-a／-x，最終為-a=arm64、-x=x86_64、-u=通用、-z=ZIP。使用者另明確授權同步根README.md，完成後以Terminal git命令commit到GitHub，再睡眠電腦。

改前建立codex/window-size-defaults-native-build，保留此前全部未提交產品修改；GAMainWindowController.m、build.sh及README.md快照在diagnostics/window-size-defaults-native-build-2026-11-03/before/。本輪新增窗口設定鍵windowSize，保存當前外框pt尺寸的NSStringFromSize；構建窗口末尾以NSSizeFromString載入。舊快照或無快照回到600×400pt；同一保存動作凍結窗口尺寸，後續拖動不自動回寫；還原整套預設自然清除尺寸。位置／全屏狀態不保存，其他開檔設定流程保持。

build.sh預設使用uname -m，不再讀ARCHS環境變數；-a／-x／-u互斥、-z可併用，保留舊--zip／--help別名。build.sh本身補可執行權限。ZIP打包改在.build/package組裝，根目錄只有Glyph Atlas.app與Clear Attributes.command兩個入口，後者可執行並按自身目錄定位相鄰App，只執行/usr/bin/xattr -rc於該App；不用sudo、不改其他路徑、不啟動App。腳本保留在Resources作為打包來源，不拷進App的已簽名資源。

根README的中英文使用／構建同步窗口大小預設、短參數、本機架構及ZIP腳本；三個本地交接文件保持當前說法。依既定要求未跑GUI或功能測試；僅完成shell語法檢查與./build.sh -z的本機arm64構建／簽名／打包，並只讀檢查ZIP入口、腳本文本及可執行位元。未執行清屬性腳本或改正式App偏好。窗口保存／載入的實際GUI留給使用者驗收。

Git提交範圍為目前Sources／Resources（含此前已完成的原生排印、語言、26適配等待提交成果）、README.md、build.sh；不提交根目錄GlyphAtlas.zip、dist、.build或本地README／diagnostics。按專案既定流程在目前分支commit後直接git push origin HEAD:main，不建立PR、不合併本地main；若push遭拒不強推或自動合併。以下結果以後續實際工具回覆為準，睡眠僅在推送成功及全部收尾完成後執行。

終端git commit成功，commit為291f19d（Add native typography, macOS 26 layout and portable builds），共50個產品檔案。git push origin HEAD:main在程序啟動前遭自動核准審查拒絕，理由是廣泛修改直接推送共用main／default分支，要求本輪使用者明確授權這個確切主分支更新。不是GitHub遠端non-fast-forward或驗證失敗；沒有真正執行push，也沒有改用間接路徑繞過審查。已向使用者提出明確選擇：允許291f19d推送main後睡眠，或只推送目前分支後睡眠。等待回覆期間不睡眠、不重試主分支寫入。


## 版本更新至1.5，明確授權main推送並取消睡眠 — 2026-11-03

使用者透過確認回覆明確選擇「允許推送main，之後睡眠」，隨即最新更正「版本號改到1.5，不睡了」。保留main推送授權，先納入版本更新；睡眠要求已撤銷，禁止再執行或排程睡眠。

從已含291f19d的分支建立codex/version-1-5，僅將Resources/Info.plist的CFBundleShortVersionString從1.4改1.5，CFBundleVersion仍為5；改前plist在diagnostics/version-1-5-2026-11-03/before/。依既定不測試要求，只重新構建本機架構App與含Clear Attributes.command的ZIP，不操作GUI或正式偏好。版本變更另作commit，保留先前已完成的291f19d；再使用終端git push origin HEAD:main。實際提交／推送結果以後續工具回覆為準。

實際結果：本機arm64編譯完成，常規構建在簽名處再遇dist根目錄FinderInfo；只清除該產物屬性後完成簽名並按build.sh既定方式打包。只讀ZIP內容確認App版本1.5及兩個根入口（App與清屬性腳本），未跑功能／GUI測試。終端另提交113b321（Bump version to 1.5）。在使用者明確main授權後，git push origin HEAD:main獲自動核准並成功，遠端main由217ebf6更新至113b321，包含291f19d與113b321兩個提交。沒有PR、rebase、強推或合併本地main。工作樹僅餘原有未追蹤GlyphAtlas.zip，未將它提交；dist App／ZIP均為1.5。已遵循最新指令取消睡眠，沒有送出或排程睡眠命令。


## 依1.4後改動更新中文README，留待使用者續改 — 2026-11-03

使用者明確要求先更新README.md中文部分，模仿其語氣、習慣與用詞，待其繼續修改後再同步所有語言；補充1.4基準是本地最早分支，也可能是main。實際核對：本地main、v1.4標記及最早幾個工作分支皆指向03bb76a（Fix bitmap font position），與最新113b321的差異包含0ff2507、217ebf6、291f19d及版本提交，不以最近一次提交單獨代替1.4基準。

建立本地codex/readme-1-5-chinese，改前README保存在diagnostics/readme-1-5-chinese-2026-11-03/before/README.md。唯一對外／產品檔案修改是README.md分隔線後的中文部分；保留「默認」「支持」「菜單」「點右鍵」「記住」「閃一閃」等原有說法及暗黑模式玩笑，沿用原有結構與未變功能的敘述。

新增／更正macOS26適配、常用文字的Option刪除入口、點選排版結果的灰名臨時字形、原生字體排印取代舊calt／liga獨立開關、豎排快捷鍵⌘5、排版語言與書寫方向、底線／刪除線／中空字、行距快捷鍵與⌘0、三種顏色及陰影透明度、整套預設值的窗口大小與一次性保存，以及構建／ZIP腳本的口語說明。補充GSUB語言分支清單不等於字體全部支持語言，選擇後不一定換字形；沒有塞入內部解析、測量或適配常量。

內容依當前菜單action、快捷鍵、GSUB語言目錄及配色／預設值路徑核對。分隔線前英文區塊逐字節保持相同，其他語系資源、程式碼與構建腳本均未改。只作文件檢查，不構建、測試或操作UI；未commit／push，等待使用者續改中文後再獲授權同步其他語言。


## 使用者中文定稿同步、生成清屬性腳本、空語言選單與角度測試程式 — 2026-11-03

使用者已修改中文README，授權同步英文及App Help各語言；要求清屬性腳本移出Resources，優先由build.sh即時生成，並詢問空排版語言選單及多字手勢角度。改前從codex/readme-1-5-chinese建立codex/help-sync-generated-command，保留其未提交中文定稿及原有GlyphAtlas.zip；README、build.sh、Resources及GAAppDelegate.m快照在diagnostics/help-sync-generated-command-2026-11-03/before/。

按中文定稿同步英文README（含dfont、常用文字Option刪除、目前字體排印／⌘5、手勢／行距、邊界框、顏色與窗口大小預設、TextView限制、ZIP及終端手動清屬性說明）。使用者中文將豎向／橫向手勢寫反，AI指出當前程式實際對應，經彈窗明確回覆「按現有程式修正文案」後，只交換中文那兩處方向；其餘中文內容保持，僅補檔案末尾換行。Help以15條使用說明為準，同步14語系Help.01–15並在showHelp補15入口，保留各地區既有菜單名稱。不是把構建／限制全文塞進Help。

Resources/Clear Attributes.command刪除；-z時由build.sh以引用heredoc生成dist同名可執行腳本，先刪同名舊檔避免沿用舊inode屬性，再從dist放入ZIP。腳本操作與先前相同，只對相鄰Glyph Atlas.app執行/usr/bin/xattr -rc；打包仍排除資源叉及擴展屬性。來源檔不再放Resources，沒有承諾下載／解壓後系統不會加隔離屬性。

空語言選單先建議保留主入口、子項灰色「沒有可選語言」，因沒有具名GSUB分支不能稱為沒有locl或語言能力。使用者先答應，接著要求檢查CoreText實際回傳；AI暫緩第三項並調查。查出原生AAT Language Tag(type39)與App自有GSUB選單是兩條不同路徑，先前解釋只講GSUB而漏說這條AAT原生特性，需要補正。

獨立Foundation／CoreText只讀程式掃描本機14.8.7靜態註冊表可列出的511個PS字面，CTFontCopyFeatures有51個返回NULL、0個非NULL空陣列；16個字面提供type39。Baskerville-Italic／BoldItalic等為No Change(default=true,id0)與Serbian(id1)；BigCaslon-Medium為No Change與Polish；AlNile等為No Change與Persian；HelveticaNeue-Medium為No Change與Romanian；HelveticaNeue-Thin的id0名稱實際是<no default name>，仍標default=true。其餘沒有type39的目錄不補這一組。此處只觀察CoreText資料，不冒充原生Font Panel UI或26實機驗收，也不把NULL目錄解讀成字體沒有任何必要GSUB規則。原始JSON與程式在同診斷目錄。

Apple規範確認type39非零selector為ltag索引+1，0為No Change；CTFontCopyFeatureSettings也可在沿用默認時返回NULL，不能把「有默認狀態」等同每個字體必須回傳一個名為預設的選項。結果回報後再次詢問，使用者明確選「保留灰色沒有可選語言」。實施為TypesettingLanguage主入口不再hidden；沒有具名tag或全部沒有系統語言對應時，子菜單僅停用提示，不造一個只有預設的選擇器。有可用語言時保留既有預設與具名選項、個別無法映射項仍停用。14語系新增No Selectable Languages。Typography自身的原生type39與無特性提示不改。

手勢檢查確認正式GAMultiGlyphView仍以兩指normalizedPosition差乘各自deviceSize寬／高，再atan2得到相對水平的銳角；≤30°邊距、>30°且<75°字號、≥75°行距，即橫向容許30°、縱向容許15°。NSMagnificationGestureRecognizer Began才鎖定，手勢中轉角不改模式；量的是兩觸點連線，不是移動速度方向。使用者覺得橫豎手感相近，AI只指出座標修正與開始鎖定可能影響感知，沒有把其感覺判為錯覺；沒有改正式手勢程式。

使用者另外明確要求獨立測試程式。diagnostics/trackpad-angle-2026-11-03/內建立TrackpadAngleProbe.m與build-probe.sh，生成通用arm64／x86_64、最低12.0的Trackpad Angle Probe.app及ZIP。程式用與產品相同的兩指採樣／deviceSize角度／30及75門檻與NSMagnificationGestureRecognizer，顯示目前修正後角度、距垂直角度、未修正角度、實際裝置比例示意、當段／上段開始鎖定的模式與角度、手勢值；有複製讀數及重設按鈕，離指後保留最後讀數。獨立bundle com.zonz.GlyphAtlas.TrackpadAngleProbe，不讀寫正式偏好；未在本機啟動其GUI，留給使用者實際觸控板判斷。首次編譯因copyButton觸發ARC方法族命名規則，改readoutButton後通用編譯完成，沒有把修正混進產品碼。

14語系資源語法及重複key／Help.01–15完整性檢查、shell語法檢查與差異空白檢查通過；./build.sh -z完成本機arm64 App與ZIP。只讀檢查ZIP根入口、即時腳本與dist一致且有執行權限、Resources舊腳本不存在；獨立Probe ZIP含通用App。未跑正式App GUI／功能測試、未commit／push；使用者定稿中文除授權的方向修正外保留。

參考：https://developer.apple.com/fonts/TrueType-Reference-Manual/RM09/AppendixF.html 、https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6ltag.html 、https://developer.apple.com/documentation/coretext/ctfontcopyfeatures(_:) 、https://developer.apple.com/documentation/coretext/ctfontcopyfeaturesettings(_:) 。


## 多字撐捏門檻改為橫向40度、縱向10度 — 2026-11-03

使用者明確要求「橫向改為40度，縱向改為10度」。先建立codex/pinch-angle-40-10，保留上一輪未提交的README／Help、生成腳本與空語言選單等改動；正式GAMultiGlyphView.m與獨立TrackpadAngleProbe.m改前檔案在diagnostics/pinch-angle-40-10-2026-11-03/before/。

按既有定義，縱向10度是距垂直軸≤10度，不是相對水平≤10度。因此正式程式門檻改為相對水平≤40度調邊距、≥80度調行距，中間>40且<80度調字號。只改兩個常數，兩指連線、裝置長寬修正、手勢開始鎖定與縮放／行距的量值映射均不動。獨立角度測試程式同步同一門檻與畫面圖例，重新生成通用App／ZIP；正式App與既有ZIP重新構建，不操作GUI或新增功能測試，手感留使用者驗收。README及Help未寫具體角度數字，不另改其文案。未commit／push。


## 多字撐捏門檻調整為橫35、縱15 — 2026-11-03

使用者最新要求「橫35縱15」，取代前輪40／10。先建立codex/pinch-angle-35-15，改前產品及測試程式源碼在diagnostics/pinch-angle-35-15-2026-11-03/before/。正式程式與獨立角度程式同步為距水平≤35度調邊距，距垂直≤15度（相對水平≥75度）調行距，中間>35且<75度調字號；測試程式圖例一併更新。其餘手勢計算與開始鎖定保持。只構建產品與獨立程式，不跑GUI／功能測試，不commit／push。

使用者隨後明確要求同步GitHub。使用終端git將目前已完成的README、14語系Help、生成清屬性腳本、空語言提示及35／15度手勢共19檔提交為58dc0c8（Sync help and refine language menus and pinch controls），再git push origin HEAD:main成功，遠端main由113b321更新至58dc0c8。沿用本會話已明確允許main的授權，未開PR、不強推、不合併本地main；沒有新增測試或睡眠操作。產品工作樹乾淨，獨立探針與本地交接資料繼續保留在被忽略的diagnostics／README，不混入產品提交。


## README開啟說明同步及僅保留英文構建 — 2026-11-04

使用者再次修改中文README，要求同步英文並刪除中文「構建」，認為需要構建的人可直接讀英文。先建立codex/readme-opening-instructions，改前含使用者改動的README快照在diagnostics/readme-opening-instructions-2026-11-04/before/README.md。

英文新增獨立Opening the app段落，按中文同步Release／構建ZIP內容、腳本解壓位置及手動Terminal清屬性步驟；既有英文Build移到Opening前，命令與參數保留。中文僅刪除構建段，其餘與本輪改前逐字一致。只修改README.md，沒有變更App Help、資源或產品碼；差異空白檢查通過，不構建、不測試、未commit／push。

## 三輪逐檔清理與模組整理 — 2026-11-04

使用者明確授權本輪三階段逐檔修改：先刪無效程式與可省略預設，再整合邏輯，最後整理Sources結構；每輪／關鍵節點建分支。此範圍內直接改碼並逐處說明，不沿用舊的每改一處彈窗流程。新發現Bug或產品決定先寫桌面`/Users/zonz/Desktop/Confirmation List.md`，本輪不修、不彈窗，之後由使用者逐項諮詢／確認。全部完成後睡眠是本次明確新指令，取代前一天取消睡眠的舊狀態。

開始時分支為codex/readme-opening-instructions，只有原有README.md修改；全程保留該修改，未將其混為清理成果。依序建立codex/cleanup-round-1、codex/cleanup-round-2、codex/cleanup-round-3；均無commit／push，分支名不是各階段的獨立提交。原始Sources／build.sh、前兩輪輪末副本及三輪patch在diagnostics/cleanup-three-rounds-2026-11-04/，每處修改及62個原始程式檔逐檔核對表見CHANGE-REVIEW.md。

第一輪移除Resource從未讀取的glyphCount及其CoreText呼叫、discoverContent例外後不再使用的items回寫，以及多字視圖三個已在首次使用前定義的函式重複宣告。依本機SDK明文預設刪除sliderWithValue建立後的continuous=YES、水平標題stack的horizontal／CenterY、NSAlert的Warning樣式；其他原生設定不以本機偶然值猜測刪除。公開介面經呼叫、property／selector及系統delegate入口核對，沒有找到可以整組移除的測試專用API。

第二輪將三個預設動態顏色及深色判斷原樣移回GAPreviewColors，解除其對邊界框視圖的反向依賴；當前視圖的zoomIn／zoomOut／resetZoom集中Detail分派，Main只轉送，刪除七個逐模式公開轉送入口並以三個當前模式入口取代。側欄七個狀態更新點使用rememberSelectedRow:成對更新字形與來源範圍，保留各自回呼抑制、通知、pending及滾動順序。GSUB四處追蹤與目錄一處共用featureLabel(Tag,unsigned)，格式不變。Main移除與scanSnapshot鏡像的三份多字狀態，直接讀取目前快照；無快照時仍給空文字／空列表。

第三輪Sources分為App／Font／Input／Views／FontLayout。GAInputFocus與GAInputMenus合併為Input/GAInputSupport，原有cell父類差異／hooks不硬合併；OpenType語言名稱／系統映射函式併入Font/GAFontFeatures。GAScanDisplaySnapshot與不依賴窗口的預覽投影由Main移入Font/GATextQueryModel，建立入口為GABuildScanDisplaySnapshot(text,groups)，函式本體不改。跨目錄import有明確前綴，同目錄短名。build.sh以APP_SOURCES陣列收集四個App目錄下的.m，FontLayout仍由原腳本處理；62個程式／腳本檔減至58個，不計Finder元資料。Resources、bundle、偏好格式、版本與打包語義不變。

Bug清單C01：prepareText成功建立ICU bidi物件後，字素準備迴圈的cmap／來源對應例外可能越過ubidi_close；只寫桌面清單，未新增RAII或修改錯誤路徑，亦未用畸形字體重現量測。沒有其他需要產品決定的修改混入。交接速查另有一條既有過時描述：setTextScale:在改前已會對相同夾緊值跳過rebuild，按實碼更正文案，沒有把該guard算成本輪修復。

每輪僅在相關改動後做通用構建，arm64／x86_64均無warning。完成時簽名檢查遇到產物上重新附加的Finder元資料，清除該App擴展屬性後strict驗證通過，未修改產品建置語義。必要的無GUI前後資料對照使用修改前完整副本與最後Sources分別編譯；8個請求字面Times-Roman、Baskerville-Italic、Helvetica、Thonburi、GeezaPro、PingFangSC-Regular、Skia、AppleColorEmoji，合計62例（56個一般輸入，6個有效literal seed）。候選順序、GID、來源／範圍、Unicode／名稱、定位、水平及垂直頁面度量、側欄／預覽投影、來源map、語言及原生特性目錄JSON逐位相同，SHA256為cc85fb14537dd18cb2c58238aceb3a892bdfcb74eb5262000c161112fca60880。這是本機CoreText可解析資料，不宣稱所有請求字面都無fallback或所有特性都有覆蓋。

額外靜態核對：未改邏輯檔案除import外一致，三個預設顏色函式、多字手勢／布局／點擊方法及PingFang透明fill保留相同本體；新增行空白、shell語法及引用核對通過。沒有啟動正式App或操作GUI／正式偏好，沒有做12／26／27實機UI驗收；不可把資料一致或通用構建當作跨版本視覺驗收。最終報告在CHANGE-REVIEW.md，機器可讀證據在verification.json；當前分支為codex/cleanup-round-3，全部修改保留工作樹。睡眠命令執行結果以下方後續記錄／實際工具回覆為準。

## 已確認後續：自動釋放 bidi、合併26適配標頭且不改名 — 2026-11-04

使用者詢問清單C01的實際影響及GAMacOS26.h用途後，明確回覆「1. 同意；2. 同意，但無須改名」。因此直接執行兩項已說明的精確範圍，不重複詢問：修正異常釋放，並將26共用適配併入GAViewMode.h，保留GAViewMode.h名稱。從codex/cleanup-round-3建立codex/cleanup-confirmed-followups，保留全部既有未提交成果及使用者原有README修改。改前七個相關檔案及本輪patch在diagnostics/cleanup-confirmed-followups-2026-11-04/。

GATextPreparation.mm使用std::unique_ptr<void,decltype(&ubidi_close)>持有bidi物件，兩個讀取／設定呼叫使用get()，移除分析失敗分支的手動close，原成功路徑close位置改為reset()；因而字素準備中途的C++例外也會釋放，正常成功仍在原處釋放，不延後至整個prepareText結束。只新增直接依賴的memory標頭，不改Unicode準備、來源對應、shaping、例外文字或返回值。

GAMacOS26.h的舊SDK公開API補宣告與GAUsesMacOS26Layout本體原樣移到Views/GAViewMode.h；後者改import AppKit以承接NSSplitViewItem宣告。刪除GAMacOS26.h，SidebarInput及SidebarController更新import；Main及Detail已由自己的header取得GAViewMode，因此刪除多餘直接引用。仍只判定系統主版本恰好26，不修改窗口／側欄／輸入框的任何佈局數值或27行為。Sources程式／腳本總數由58減至57。

必要的隔離程序以合法cmap目錄／format6頭部但缺少宣告字形資料的樣本，確定舊版在open成功後拋出InvalidTable、close次數為0；新版本同路徑close為1。另核對配置失敗為0次、bidi分析失敗及正常完成各為1次；成功路徑保留相同單字GID與來源範圍。此程序攔截ICU bidi配置／釋放以精確計數，不操作正式App／偏好，不冒充真實字體記憶體量測。通用構建無警告；沒有執行GUI或跨版本UI測試。桌面Confirmation List.md的C01已標為已確認、已修正，目前無未處理確認項目。沒有commit／push；前輪睡眠已執行，本輪未另收到新的睡眠指令。

## 三輪清理已本地提交，main推送待明確授權 — 2026-11-04

使用者要求「好的，commit 到 GitHub」。提交範圍為本輪Sources與配套build.sh，不混入接手前原有README.md變更；後者保留本地。暫存後完整diff空白檢查發現搬移後GATextQueryModel.m多一個EOF空白行，僅刪該空白行，未改邏輯。以終端git提交為357735d（Simplify source structure and fix bidi resource cleanup），共49個檔案，包含三輪整理與後續已同意的bidi／標頭合併，未改版本號或納入診斷／交接資料。

git push origin HEAD:main在程序啟動前被自動核准審查拒絕：直接更新預設main屬高影響發布，本輪「commit到GitHub」未明確指定確切分支與直接推送流程，需要使用者明確授權。這不是GitHub非fast-forward、網路或驗證失敗；沒有實際推送，不以其他工具、分支或PR繞過拒絕，不強推／pull／rebase。已告知使用者並請其明確允許把357735d推至Zonz-Ly/GlyphAtlas的main。本地提交保留，工作樹只餘原有README.md修改，等待授權。

### main推送完成 — 2026-11-04

使用者明確回覆「再試一次，我來核准」，授權重新送出將357735d直接推送main的核准請求。git push origin HEAD:main獲准並成功，遠端main從58dc0c8更新至357735d；沒有PR、強推、pull、rebase或合併本地main。已發布三輪整理、bidi釋放修正與保留GAViewMode名稱的標頭合併。原有README.md修改仍留本地，未納入這筆提交；診斷及本地交接資料維持忽略。

## 既有README修改同步main — 2026-11-04

使用者明確要求「README也需要同步」，並詢問是否需要先提交分支。已解釋不必先推送遠端工作分支；在目前本地分支提交README，再直接推送main即可。沒有改寫使用者既有README內容；空白檢查通過後僅提交README.md為1a69556（Clarify README build and app opening instructions），包含既有構建段落搬移及中英文開啟／清屬性說明。git push origin HEAD:main獲准並成功，遠端main由357735d更新至1a69556。沒有PR、強推或合併本地main，產品工作樹乾淨；本地忽略的交接與診斷資料保留。

## 將⌘0文案改為預設大小 — 2026-11-04

使用者指出以香港為例，「實際大小 ⌘0」應為「預設大小 ⌘0」，其「預設」須與「作為預設值」一致。從目前工作分支建立codex/default-size-label，保留原有README.md未提交修改；改前相關Sources與14語系資源存於diagnostics/default-size-label-2026-11-04/before/。

將選單本地化鍵Actual Size改為Default Size，香港／台灣「預設大小」、簡體「默认大小」，其餘語言以既有Use as Defaults所用default術語翻譯；同步局部變數與相關註解，不改resetZoom邏輯、⌘0快捷鍵或整套預設值保存／還原行為。資源語法、差異空白檢查及本機arm64構建完成，沒有啟動GUI、功能測試或寫入正式偏好；未commit／push，本輪未修改根README.md。

## 側邊欄字形替換共用全字輸入字符優先規則 — 2026-11-04

使用者要求全字視圖向文本框插入字符時的控制字符過濾同樣適用於側邊欄替換。先建立codex/sidebar-input-scalar，保留前輪預設大小文案及原有README.md修改，Main改前快照在diagnostics/sidebar-input-scalar-2026-11-04/before/。

檢查確認現行全字規則是優先非C0（U+0000–001F）／DEL（U+007F）映射，不是無條件刪除控制字符：若只有這些映射仍保留首個。將原規則抽成Main內部靜態GAInputScalarForGlyph，供全字直接編碼追加和側欄activationPayload共同使用；普通雙擊／Return替換及Shift追加自動一致。無編碼字形的來源文字／固定GID run、全字借用替換集合首映射、複製全部編碼等既有行為保持，未擴大為C1、格式字符或可見性過濾。

差異空白檢查及本機arm64構建完成，未啟動App、GUI或功能測試，未改正式偏好，未commit／push。

## 1.5 正式發表基準與下一版起點 — 2026-11-04

使用者確認 1.5 正式版已在「預設大小 ⌘0」和「側邊欄字形列控制字符過濾」之前發表。從 GitHub 取得 `v1.5` 標記，核對它指向 `6a33688308665631587d76e42e0eebbbee553fd7`，並在該提交建立本地分支 `codex/release-1.5` 作為下一版的比較基準。該提交在目前本地工作分支基底 `1a69556` 之後，只多一筆 README 修改。

「預設大小 ⌘0」與「側邊欄字形列控制字符過濾」是下一版最初兩項改動，目前仍留在 `codex/sidebar-input-scalar` 的工作樹。整理下一版更新時以 `codex/release-1.5` 或 `v1.5` 為基準，並計入尚未提交的改動。

## 檔案選單的字體資料夾捷徑與清除常用文字措辭 — 2026-11-04

由 codex/sidebar-input-scalar 建立 codex/font-folder-menu，帶入既有工作樹改動。依使用者列出的第 1–3 項，檔案選單新增原生 Option 替代項：開啟字體子選單的目前用户／所有用户／系統內建依序對應使用者、共用和系統字體資料夾，使用原有 NSOpenPanel 並指定 directoryURL。拷貝到所有用户使用共用字體資料夾，沿用同名處理與系統錯誤顯示，以當前程序的檔案存取權限執行。

14 語系安裝位置名稱取自本機 macOS 14.8.7 字體簿 Preferences.loctable，中文系統項依要求用「系統內建」，西文去除字體簿資源中的語法變形標記。拷貝命令按相同目的地用詞翻譯。清除常用文字按 AppKit MenuCommands.loctable 的 Clear Menu 動詞核對，更新三個中文語系、西文與俄文。

第 6、7 項使用既有 Tooltip。視窗標題保留顯示名，第二行由 CoreText 提供相應的原始家族名／全名，僅在有不同值時顯示。側欄字形名稱 Tooltip 加一行十進位 GID，多 GID 按字形順序列出；原名已是相同 GID 清單時僅顯示一行。資源語法、差異空白檢查與本機構建完成，未執行 GUI 或實際複製字體。第 4、5、8 項先討論行為與排版。

## 開檔全螢幕與多字／全字 Tooltip — 2026-11-04

使用者確認第 4、5、8 項先做，Unicode 排版暫用 U+0041 · U+FF21，另討論 [0041] [FF21]。建立本機分支 codex/full-screen-and-glyph-tooltips，保留先前工作樹改動。

開檔快照新增 fullScreen，進入全螢幕前記錄一般視窗尺寸，全螢幕內保存預設時使用該尺寸。新視窗首次成功載入字體後依開檔快照呼叫原生全螢幕切換；手動進入時也消耗這次開檔切換。灰色選單提示使用 NSMenuItem.toolTip，套用於主 View 自豎排至文字裝飾的六項，14 語系沿用現有多字視圖名稱。灰色選單上是否顯示提示待實機驗收。

全字 Tooltip 以現有格子命中規則定位，只為指標下的格子登記原生 Tooltip，縮放重排與滾動時更新。停留時才向 CoreText 取得名稱，與側欄共用 GAUsableGlyphName；以字形名稱、十進位 GID、Unicode 碼位分行，缺項省略。使用既有 inventory 的 Unicode 映射，U+ 後為大寫十六進位（至少四位），多碼用間隔點分隔。資源語法、差異空白檢查與本機構建完成，未啟動 App。

### 全字 Tooltip 的 Unicode 分隔符定稿 — 2026-11-04

使用者確認保留 U+，以半形逗號加一個空格分隔碼位，例如 `U+0041, U+FF21`。沿用同一工作分支。

### 修正開啟字體的 Option 子選單及停用狀態 — 2026-11-04

使用者實機看到開啟字體的資料夾子選單平時也顯示，並要求父項省略號移到三個子命令。隔離 AppKit 讀值確認，加入 submenu 會令父項的 keyEquivalent 回報空字串，即使之後重設也相同。兩個可見項改為共用空 keyEquivalent，依原生 Option 替代項配對。⌘O／⌘N 改由隱藏項處理，普通開啟項不再列出 ⌘O。14 語系由同一開啟字體本地化名稱組合普通命令和替代父項，三個資料夾命令加省略號。

同輪使用者確認未開啟字體時「常用文字」和「顏色」父項要與內部命令一起停用。編輯選單保留原本刪除常用文字的獨立全域條件，有已儲存項才可刪除；顏色入口與子命令均按已開啟字體判斷。使用者亦確認保留 AppKit 原生自動填寫。

### 字體資料夾捷徑移到開啟面板 — 2026-11-04（已撤回，見下節）

使用者確認先建分支嘗試，移除檔案選單的 Option 開啟子選單，恢復可見 ⌘O。開啟面板使用 AppKit accessory view，在底部放「字體位置」原生下拉按鈕，沿用字體簿三個位置的本地化名稱，不加省略號。選取後只更改當前面板的 directoryURL。按鈕用原生適合尺寸，周邊內縮為本輪設定的水平 12pt、垂直 6pt。

分支為 codex/open-panel-font-locations。前一輪尚未提交，切分支本身不保存工作樹差異，另將改前 AppDelegate、14 語系及本輪差異放在 diagnostics/open-panel-font-locations-2026-11-04.ETxsT7/，可精確回退本次選單改動。

### 恢復 Option 字體資料夾子選單 — 2026-11-04

使用者實機看過面板底部的按鈕，要求恢復原先的 Option 方案。切回 codex/full-screen-and-glyph-tooltips 並反向套用上述補丁，移除面板 accessory view 和相應文案。復原的 Option 父項改用獨立 14 語系鍵 Open Font From，繁中「開啟字體於」。三個子命令沿用先前已驗收的名稱及省略號。

## 儲存與刪除配色 — 2026-11-04

使用者確認建立 codex/saved-color-palettes，直接在「跟隨系統」下方列出免命名配色，新配色依儲存順序加在尾端。「儲存目前配色」放在「背景色…」下方。原生 Option 替代項「刪除配色」只列同序配色、分隔線和「清除所有已儲存的配色」。沿用既有常用文字的單項／全部刪除方式。

三塊等高 12pt，依序寬 14／7／14pt，間距 3pt；陰影色按其 alpha 疊在配色背景色上。尺寸為本輪手調。Tooltip 提供現有色彩角色名稱、十六進位值、陰影透明度或跟隨系統。用既有 GAPreviewColors representation 持久保存，按覆蓋色和各角色是否跟隨系統判斷勾選與去重；全跟隨系統由既有選單項提供。開檔設定與套用配色共用 Detail 應用方法，配色資料跨視窗共用，套用只影響目前字體視窗。

14 語系資源、差異空白檢查和本機構建完成，未啟動 App。選單色塊尺寸、呈現與 Option 切換待實機驗收。

### 配色與常用文字的空清單、儲存狀態和提示 — 2026-11-04

使用者區分空清單和不可用：Option 的「刪除配色／刪除常用文字」即使清單為空亦可展開，子選單只顯示相應灰色空狀態。普通配色的儲存命令在原本停用的狀態改為隱藏。常用文字移除普通選單的「從常用文字移除」及切換式刪除邏輯，只有非空且未儲存的輸入才顯示儲存命令。

配色 Tooltip 以本地化冒號隔開角色和色值，陰影透明度改用括號。源碼沒有自訂 Tooltip 延遲；選單、普通視圖和全字格子分別使用 AppKit NSMenuItem.toolTip、NSView.toolTip 和 addToolTipRect。未找到公開 API 可指定單個選單項的延遲，未量測實際秒數，保留 AppKit 計時。

### 跟隨系統的色塊顯示深淺兩種外觀 — 2026-11-04

使用者同意對角線分色。沿用 14／7／14pt 寬、12pt 高、3pt 間隔及 0.5pt 描邊。跟隨系統的角色在左上用 Aqua、右下用 Dark Aqua，陰影每一半按相應外觀背景和 alpha 合成；固定角色仍畫一整塊。

### 陰影色塊配合背景的深淺外觀 — 2026-11-04

補上固定半透明陰影與系統背景的組合。只要陰影或背景任一跟隨系統，陰影色塊便依深淺背景分兩半合成。

### 固定背景與跟隨系統陰影的像素核對 — 2026-11-04

使用者回報仍有疑問。從現有 AppDelegate 取出原樣的色塊繪製函式，與 GAPreviewColors 編成離屏 AppKit 探針，先用正式 representation 儲存再還原，取原始 41×12pt 圖片中陰影色塊左右兩半內部像素。固定白底加系統陰影為 #D1D1D1／#6B6B6B，固定橘底 #FF9900 加系統陰影為 #D17D00／#6B4000，系統背景加固定 35% 黑影為 #A6A6A6／#272727，陰影和背景都跟隨系統為 #D1D1D1／#191919。順序為左上 Aqua、右下 Dark Aqua。四例均讀到不透明的合成像素。這次只確認色塊繪製，未確認使用者正在執行的 App 或選單最終顯示，未改程式。

### 等寬色塊與陰影僅調透明度的儲存修正 — 2026-11-04

使用者確認深淺合成無問題，要求三色等寬並回報只改陰影透明度存不下來。三色統一為 14×12pt，間距 3pt，總寬 48pt。離屏 AppKit 探針重現系統陰影套用 colorWithAlphaComponent: 後成為不可由安全封存寫入的 NSDynamicModifiedColor；同 RGB 的固定色不同 alpha 能正確區分。修正跟隨系統的陰影進入選色器時先按所屬窗口外觀取固定 sRGB，保留起始透明度。離屏使用相同流程驗證淺色 18%、深色 58% 的起始值，兩者只改成 35% 均能封存、還原並匹配。未操作實際選色器介面。

### 字形與背景色透明度實驗 — 2026-11-04（已撤回，見下節）

使用者驗收陰影透明度儲存後，要求另建 codex/preview-color-alpha-experiment，讓字形和背景色可調透明度。三個角色的原生選色器均顯示 alpha 滑桿；系統起始色先解析成可封存的固定色，配色模型不再將字形與背景 alpha 設回 1。已有配色與預設讀取仍使用原有 representation。非全不透明的字形／背景色在配色 Tooltip 顯示百分比，單字與多字視圖按背景 alpha 回報 isOpaque。實際畫布合成留給使用者實驗。

本輪改前程式及可反向套用的補丁位於 diagnostics/preview-color-alpha-experiment-2026-11-04.yCig0r/。

### 撤回字形與背景色透明度實驗、調整色塊寬度 — 2026-11-04

使用者決定放棄實驗，切回 codex/saved-color-palettes 並反向套用實驗補丁。色塊統一改成 16×12pt，間距 3pt，整組寬 54pt，圖片寬依色塊數量、尺寸與間距計算。

### 試用 15×12pt 色塊 — 2026-11-04

依使用者要求，三塊均改為 15×12pt，間距 4pt，整組寬 53pt。

### 試用 18×12pt 色塊 — 2026-11-04

依使用者要求，三塊均改為 18×12pt，間距 3pt，整組寬 60pt。

### 配色色塊尺寸定稿 — 2026-11-04

使用者確認三塊定為 16×12pt，間距 3pt，整組寬 54pt。

### 簡化調色命令和配色提示名稱 — 2026-11-04

三個調色命令在 14 語系改為角色本身的名稱並保留省略號。繁中為「字形…／邊界框…／背景…」。配色 Tooltip 沿用同樣名稱並去掉省略號。

### 配色色塊寬度改為 15pt — 2026-11-04

依使用者要求，三塊均為 15×12pt，間距 3pt，整組寬 51pt。

## 全項目只讀審查 — 2026-11-05

使用者要求審查 Bug、潛在問題及改進。以 codex/saved-color-palettes 的現有工作樹為準，檢視主要字體讀取、查詢、原生排版、全字繪製、選單與保存路徑；沒有修改產品程式或執行 GUI 驗收。工作樹含多輪未提交變動。

源碼顯示多字預覽合併字素簇後只檢查首個 GID 是否為 0；若後面的組件缺字，TextKit 可能使用 fallback 字體，而原生 GID 讀回沒有檢查 run 字體就交給目前字體反查。觸發與呈現仍需真實字體驗證。全字網格只繪製格子位於可見列的字形，越出格子的墨跡可能在來源列剛滾出視口時消失，需實機驗證。查詢取消只在整次 rawScan 前後檢查，舊查詢完成前新查詢須等同一序列佇列，影響取決於字體和輸入，未量測。全字 tooltip 依賴 mouseMoved，但程式沒有設定窗口 acceptsMouseMovedEvents；AppKit 預設為關，實際是否受其他 AppKit 行為影響仍需 GUI 驗證。關閉窗口不使正在載入的字體請求失效，載入完成後仍可能登記最近項目或處理關閉窗口，需重現確認。

### 逐項隔離驗證 — 2026-11-05

依使用者要求驗證並討論方案，未修改產品程式。使用目前 FontLayout 源碼重新編譯隔離程序，經產品查詢及快照管線測 Helvetica 的 A + U+1AB0：側欄組 GID 分別是 36、0，快照保留整段，獨立 CoreText CTLine 返回 Helvetica GID 36 與 LastResort GID 4。這證明實際替代字體及快照前提；TextKit 2 點擊結果未實機測。處理方案需同時決定缺字預覽策略並核對實際 run 字體，不能將其他字體 GID 當成本字體。

查詢取消以 TimesNewRomanPSMT、228 UTF-16 字元隔離測量，預定 1 ms 後取消；回呼在 0 ms 與 14 ms 各檢查一次，第二次才見到取消，總耗時 14 ms。具體時間只代表本機該次量測。若優化應將取消傳進完整查詢過程，取消結果不得寫入快取或發布。

全字幾何使用產品 pageForVariant，Helvetica GID 99 在預設 44 pt 格子中墨跡頂為 -2.69 pt，即上溢 2.69 pt。列頂距 18 pt、列間距 8 pt，第二列格子頂 70 pt，墨跡頂 67.31 pt；視口底 69 pt 時該墨跡應有 1.69 pt 可見，但現有列計算不包含第二列。這是實際字體度量加源碼計算，未作 GUI 滾動驗證。解法應依真實墨跡範圍處理上下可見性，勿假定固定 1 行足夠，並考量成本。

Tooltip 只有程式與 Apple 的窗口預設證據，尚未實測 AppKit 安裝 tracking area／tooltip 時對窗口狀態的影響；先請使用者在格間移動驗證，不應斷言已壞。窗口關閉競態由源碼確認已開始的工作持有控制器、關閉不遞增載入 generation，完成回呼可繼續，但尚未操作 GUI 重現。修正可於關閉時讓請求失效並阻止晚到結果與最近項目登記。兩項仍需 GUI 驗收。

### 缺字過濾整合方案討論 — 2026-11-05

使用者只選第 1 項，要求結合既有缺字過濾器先提出重構方案，尚未授權改程式。現有快照先合併字素簇的來源組，再由 GAGroupIsMissing 檢查首個 GID；後續組件的 GID 0 漏過。建議在保留來源範圍的前提下，以原有來源組進行缺字判斷，過濾可獨立處理的缺字組件，再重建可見文字／來源對應及需要的字素簇單位。不可分割的來源及明確 GID selection 必須沿用其原子邊界，預設忽略字符及 UVS／ZWJ 要避免只憑 GID 0 誤刪；需要以現有資料確認能否可靠區分。若遇到不可拆的缺字來源則整個來源不顯示。這種逐組件過濾可能改變文字整形及字素簇，需在實作前經使用者確認。

原生 CTLine 的 run 字體可不同，即便改善前置過濾仍需在讀回 GID 時確認字體身分，避免將外來 GID 當本字體；需保留 run 索引用於邊界計算及原子 selection 的處理，不可簡單跳過 run 而造成錯誤合併。真實 TextKit 2 顯示與點擊仍待驗證。隔離查詢另核對 Helvetica 的 A+ZWJ、A+VS16、AppleColorEmoji 的 👩‍💻 及 GeezaPro 的阿拉伯字母+ZWJ，不能把零 GID 無條件等同可刪字符。

### 缺字過濾目標與漏過根因 — 2026-11-05

使用者澄清核心要求是多字視圖源頭排除缺字，不允許顯示其他字體的字形，而不是僅避免反查錯誤。Helvetica 的 A + U+1AB0 在查詢時已各有來源組與正確根 GID 36／0；快照先把同一字素簇合併成 [36, 0]，現有 GAGroupIsMissing 只檢查首個 GID 36，於是整段漏過。組件化改動的歷史記載位於 2026-11-02 Browse nominal components separately from compositions。查詢辨識沒有漏掉 U+1AB0，漏洞在多字快照過濾順序。

如改為先按來源組過濾、再組合可顯示文字，必須同步處理來源游標與映射：現有快照會把組間原文字串補回，直接跳過缺字組會把它重新插入；不可只搬動判斷位置。應保留明確選擇、不可分割來源、換行與 Unicode 排版字符規則，另驗證零 GID 與實際缺字的關係，避免誤刪可影響排版的字符。這是方案分析，尚未改程式，也不能僅憑目前單一例子保證所有 fallback 路徑皆已阻止。

### 按原始組件過濾多字預覽缺字 — 2026-11-05

使用者同意修正並要求比較其他結果。在 codex/filter-preview-missing-components 改用單次遍歷建立多字快照。先按原始來源組的 nominal GID 判斷缺字，消耗其原文範圍，再合併保留的相鄰組件。附著於保留組件的預設忽略字符繼續供排版使用。原文位置對應仍使用既有來源映射。

macOS 14.8.7 離屏實際多字視圖前後比較涵蓋 7 款字體、59 組輸入，含橫排與豎排的 CTLine 字體及 GID。側欄 59 組一致，53 組完整結果一致，6 組移除漏過的缺字且修正後的 run 均屬目前字體。Helvetica 的 A + U+1AB0 + B 顯示 AB，B 的預覽索引 1 回指原文 UTF-16 索引 2。臨時比對程式及 JSON 位於 /tmp/ga-filter-preview，arm64 構建完成。

離屏比對另發現三組既有替代字體路徑。Helvetica 的 A + VS16 使用 Lucida Grande，Skia 的 A + VS16 與 A + ZWJ 使用 Helvetica，修正前後一致。它們涉及系統對控制字符和完整序列的排版判斷，與本輪修復的名義缺字漏過不同。多字視圖只顯示目前字體的總體條件尚未達成。

### 按來源組過濾多字缺字 — 2026-11-05（已撤回）

使用者明確要求修正並驗證其他結果。修改前由 codex/saved-color-palettes 建立 codex/filter-missing-preview-components，工作樹已有改動全部保留。GATextQueryModel 在字素簇合併前按原來源組判斷缺字，不合併缺字組，原有原文游標仍越過它，避免補回；原子來源含任何 GID 0 即排除整個來源。明確 GID selection、換行保留原有語義。GAUnicode 集中以系統 ICU Default_Ignorable_Code_Point 辨識控制字符；可見組件仍存在時保留隨附控制字符，組件全部缺字時不留下孤立控制字符，獨立未映射控制字符沿用原有排除。新行為只處理多字快照；輸入、側欄查詢和原生繪製未改。

隔離程序以現有完整產品字體／查詢來源與重新編譯的 FontLayout 測 17 項，包括 Helvetica A+U+1AB0 過濾、後續字符及位置映射、不可拆來源、明確 selection、ZWJ／缺字後孤立 ZWJ、換行，以及 CoreText 對過濾後文字的字體回讀。使用既有 62 個真實字體和種子對照案例比較修改前後資料，61 例完全相同；Skia 的 a+acute+n+dot-below 因末尾 dot-below 是 GID 0，預覽由完整輸入變為 a+acute+n，屬這次修正，側欄查詢結果相同。arm64 構建完成，沒有啟動 App 或驗收實際 TextKit 2 圖形／點擊，也未能保證所有字體及其他系統皆無 fallback。

### 合併缺字組件過濾與原生替代字體核對 — 2026-11-05

依使用者要求在 codex/keep-preview-font 合併兩版。保留逐來源組建立快照及游標，遇到預設忽略字符時，在原字素簇仍有可顯示組件的情況保留字符，包含跨已排除缺字範圍的 CGJ。每個有需要的原字素簇最多額外檢查一次。

重用 TextKit 2 的 CTLine 讀回，以 PostScript 名找出借用字體的 run。先嘗試從其顯示範圍移除 VS16／ZWJ 並重排，若仍借用其他字體，排除借用字體的範圍。顯示副本的 UTF-16 位置隨刪除更新，換行照常，固定 GID 序列維持原子處理。這個核對依賴原生行提供可讀的 CTLine。

macOS 14.8.7、7 款字體、76 組橫豎排離屏前後比對。76 組側欄一致，55 組預覽文字、字形、來源範圍與命中資料完全一致，其餘 21 組改前均有替代字體，改後讀到的字形均屬目前字體。包括 Helvetica／Skia 的 A+VS16、Skia A+ZWJ、PingFang SC 的漢+VS16，及缺字鄰近 CGJ 的案例。支援的 Apple Color Emoji ZWJ／VS16 序列、阿拉伯文連接控制、已選多 GID、空格和換行均有比對。arm64 構建完成。未測其他系統版本及實際視窗點擊。探針與 JSON 位於 /tmp/ga-compare-preview.KCEiR3。

### 多字缺字與替代字體修正的重排成本 — 2026-11-05

依使用者關心的性能做離屏對照。macOS 14.8.7 arm64，兩版均以 -O2 編譯，使用相同 720×640 pt 視口和輸入，交錯執行改前／目前版本。每版本每案例預熱後取 38 次中位數。量測拆成多字快照建構與 TextKit 2 重排，不含候選查詢、實際窗口繪製、事件或滾動。探針及原始數據在 /tmp/ga-preview-perf/extended-*.txt。

重排中位數（改前 → 目前，ms）：Helvetica 92 字元 0.207 → 0.217，920 字元 1.517 → 1.571，9,200 字元 16.331 → 16.936；PingFang SC 豎排 900 字元 2.607 → 2.722；Apple Color Emoji 630 個 UTF-16 code units 0.608 → 0.604；Helvetica 922 字元單處 VS16 fallback 1.653 → 2.871，825 字元多處 fallback 2.132 → 2.866；9,202 字元單處 fallback 17.385 → 29.308，9,185 字元多處 fallback 24.428 → 33.876。快照各案例中位數差異絕對值不超過 0.25 ms。普通路徑重用一次原生排版讀回；發現替代字體時目前會重新排整份預覽，因此單處替代也有長文成本。沒有改產品程式。

### 關閉無效字體窗口與重新定位開啟面板 — 2026-11-05

依使用者要求在 codex/close-invalid-font-and-reopen-panel 修正兩項。無法讀取字體時，按提示的「好」後關閉尚未載入任何字體的窗口。已存在的開啟面板收到資料夾命令時，記住目標並取消目前面板，在完成回呼建立新面板且於顯示前設定目錄。接收外部開檔事件會清除待開啟的目錄。實機介面待使用者驗收。

### 全項目及 UI／UX 只讀審查 — 2026-11-05

依使用者要求再次審查目前工作樹，參考既有三模式的畫面快照。使用正式啟用方法、替代側欄及不啟動查詢的控制器做離屏探針。當舊 A 行仍在、輸入已從 A 變成 BA，啟用編碼為 Á 的舊行得到 ÁA，Shift 插入得到 BÁA；兩者沿用已過期的來源範圍。建議以查詢版本封住修改入口，並在等待新結果時提供輕量狀態。另實讀系統 LastResort.otf，GID 4 對應 1,112,064 個 Unicode 標量。側欄目前每碼建立一個徽章，全字 Tooltip 將全部碼位逐一轉成字串，使用者可觸發大量主執行緒工作。建議限制畫面顯示數量並保留完整資料和複製能力。

此前量到的全字越界墨跡、無法中途停止舊查詢及關窗後載入回呼的風險仍在。Undo 對字形替換／追加的行為和全字 Tooltip 格間追蹤留待 GUI 核對。UI／UX 建議涵蓋缺字被排除時的提示、目前模式的可見性、全字鍵盤定位、重複字符的來源識別，以及清除全部常用文字／配色的復原能力。未操作正式 App 或更改程式。

### 阻止過期側欄結果改寫輸入 — 2026-11-05

依使用者確認在 codex/guard-stale-glyph-activation 實作。側欄替換及 Shift 插入共用目前請求與已發布快照的 generation 核對，並比對快照原文。新查詢尚未發布時，舊行的編輯指令靜默略過。快照接受與更新版本在主執行緒同處處理，純文字相同但固定 GID 改變時也須等待新結果。

離屏使用正式控制器方法及替代側欄核對六項。舊 A 行對 BA 的替換／插入皆無修改，相同字串更換固定 GID 後拒絕舊回呼和操作，新快照的替換及插入則得到 BÁ 和 BAÁ。arm64 構建完成。未操作實際視窗。

### 延後套用側欄字形操作 — 2026-11-05

依使用者要求在 codex/defer-stale-glyph-edits 將過期側欄操作從略過改為暫存最近一筆。側欄在每次快照發布後記錄原生 field editor 的字元編輯範圍與長度差，核對未編輯的前後文字。位置對應使用實際編輯記錄，避免用兩個相同字串猜測重複字的來源。來源與編輯重疊或來源無法追蹤時取消。接受最新快照後，僅有唯一候選符合原文、對應後的精確來源範圍、來源類型與完整 GID 序列才套用。其餘情況靜默取消。

離屏使用正式側欄、原生 field editor 和雙擊共用的列啟用入口，控制發布時點。插入同一個 A 使 A 變成 AA 後，過期雙擊等候新結果並得到 AÁ，Shift 雙擊得到 AAÁ。也核對 GID 不同取消、刪除原 A 後不誤用剩下的 A、等待期間第二次插入後正確移位，以及換行標記的原文位置。arm64 構建完成。未操作實際視窗。

### 舊查詢提早結束方案 — 2026-11-05

使用者要求提出方案。查明目前 generation 可拒絕舊結果發布，但取消只在 rawScan 前後核對，候選發現、度量和顯示組裝過程均可繼續佔住序列佇列。建議沿用現有 generation 與最新待處理輸入，將取消判斷傳入自有 GSUB／AAT 枚舉及後續投影迴圈，於 lookup／候選批次邊界核對。耗時單一規則需再下探其既有 budget／狀態迴圈。取消結果與合法空結果區分，完成的單字目錄可留在快取，未完成整段結果不可發布或寫入；保留主執行緒發布時的版本核對及延後側欄操作的來源／GID 核對。用可控取消點比較新版與舊版的最新結果延遲，並比對未取消查詢的 GID、來源範圍、排序和位置。尚未實作。

### 1,000 字元查詢分段量測 — 2026-11-05

依使用者要求，只在 /tmp/ga-query-timing 的 Sources 副本加計時，使用 macOS 14.8.7 arm64，沿用產品的編譯最佳化，先建立字體庫存。每款字體四組未命中整段快取的 1,000 個 UTF-16 碼元，中位背景耗時如下。Times New Roman 51.56 ms，Helvetica 1168.19 ms，PingFang SC 1005.54 ms，Thonburi 57828.06 ms。規則搜尋分別佔 36.54、1157.03、966.64、57805.83 ms。輸入均為重複短段，Thonburi 約 836–837 個字素簇。另測命中整段快取，背景耗時 7.32–23.82 ms。這是分段離屏量測，未量操作到主執行緒實際更新的延遲。

規則細分：Times 單次 GSUB lookup 最大 0.73 ms，PingFang SC 7.52 ms，Helvetica 單次 AAT 子表最大 118.58 ms，Thonburi 5314.62 ms。Thonburi 深入計時的單個搜尋起點最慢一次 64.16 ms 牆鐘。另一次 CPU 計時，每 32 次狀態轉移或該輪末尾形成一批，99% 以上牆鐘 ≤0.512 ms；單批最多 1.52 ms 執行緒 CPU。牆鐘最長一批 106.49 ms 但只用 0.36 ms 執行緒 CPU，主要時間未在該執行緒運算。已建議 AAT 子表入口及既有 Budget 狀態迴圈、GSUB lookup 入口，另在來源定位與候選投影的大批次之間檢查。Geeza Pro 額外樣本未完成，未列入結果。未改產品程式、未測實際取消延遲。

### 1,000 字元規則搜尋的算法探針 — 2026-11-05

使用者要求先找算法優化，再動手修。只在 /tmp/ga-query-opt 的獨立副本做實驗。Thonburi 的 300 UTF-16 碼元樣本裡，AAT type 2 動作的 26,736 次比較含緩衝區快照約 1.40 秒，規則搜尋共約 2.23 秒。現行 AAT 從每個有效起點重掃後綴，動作前後通常複製全緩衝區並各自排序、重建來源群組。只比對受影響區段須納入重疊的整個原文來源，來源順序無法證明時保留全量比較。Thonburi 的 10 次 AAT 執行中有 4 次子表序列重複，可在同一輸入重用結果並保留各 selector 的標籤。實驗也快取同一機器對同一 GID 的 class、對同一 state/class 的已解碼 entry，type 2 堆疊直接記固定 slot。GSUB 對一對一替換原地改 GID，並跳過同一輸入的完全相同 lookup 序列。蘋方 216 個序列僅 3 個重複，單一 GID 替換減少整段搬移是其主要改善。AAT 的狀態後綴重用另做過一版，收益有限，未用在最後一版。

同一 arm64/macOS 14.8.7 探針，1,000 UTF-16 碼元未命中整段快取，規則搜尋毫秒。Helvetica 1134.12 → 40.05、Times New Roman 35.77 → 6.60、蘋方簡中 933.06 → 493.77，各為四組中位數。Thonburi 的同一組 58606.54 → 1287.87；暫存版四組中位 1289.65，基線只跑一組。13 組配對長輸入與 10 組五款字體的短輸入逐項比對原始候選、來源區間、GID、功能標籤、座標及分組順序，輸出一致。短輸入覆蓋多 GID seed、混合方向、U+1AB0、VS16 和 ZWJ。另對通用 Trace 比較做 16,000 組隨機緩衝區差分。建議將 AAT、GSUB 各自分批，保留候選與取消驗證的界線。正式碼未改，未量實際取消或視窗操作。

### 預編譯字體規則與整字目錄成本 — 2026-11-05

依使用者要求，只在 /tmp/ga-query-opt 和 /tmp/ga-dict 試驗。現有 Resource 載入時已解析 GSUB 語言與 features、context patterns、第一 GID 索引和部分反查索引，但 Coverage/ClassDef 等仍以二進位 View 查詢，AAT 載入時只拆 chain、selector 和子表，狀態 entry 與 GID class 在執行時讀取。預編譯探針在上一輪優化版上，把 AAT class、狀態索引和 entry 轉成原生陣列。稀疏 class 以 64 個 GID 一頁，只儲存含非預設 class 的頁，密集時保留平面陣列。Thonburi 的 138 個狀態子表額外編譯 31.69 ms、常駐陣列容量 276426 bytes，1,000 碼元規則搜尋中位 1340.53 → 925.52 ms；平面表 25.00 ms、1000158 bytes、934.48 ms。Helvetica 的 5 個狀態子表 0.53 ms、3768 bytes、41.86 → 36.84 ms。兩款各四組的原始候選與分組輸出逐項一致。數字不含整個文件開啟時間，編譯探針沿用現有資料讀取來建表，未測跨字體的壞表行為。

全 GID 預算探針沿用 relatedOutputs，保留非空列。蘋方簡中 49519 GID，27778 有輸出，共 125286 條且皆為單一輸出 GID。三次中位預算 678.08 ms，進程 RSS 增量約 20 MiB，對照同一輪 1,000 碼元的 catalogue 只有約 10 ms。這測的是現行 Foundation 物件表示，緊湊 C++ 的空間可另估，尚未實作。Thonburi、Helvetica、GeezaPro 的現有單 GID 目錄沒有候選。上下文結果須執行規則，保留左右文、來源歸屬、方向、語言、功能及連續 lookup 的中間狀態。

GSUB 另計完全相同計畫先去重後的共同前綴。在蘋方測試 run 中，216 個計畫 3 個完全重複，剩下 782 次 lookup，前綴樹共 323 個非根節點。這只證明結構上可共享的次數，尚未量共用狀態快照後的耗時或尖峰記憶體。可依 AAT/GSUB 分開設計共享不可變規則、查詢期有限狀態和輸出來源。產品程式碼未改。

### 查詢優化與提早取消落地 — 2026-11-05

在 codex/compile-and-cancel-font-queries 整合已量測的 AAT 緊湊規則索引、連字局部來源差異、固定 slot 堆疊、相同 selector 子表序列共用，以及 GSUB 一對一原地更新與完整相同計畫去重。字體載入原本就在 fontQueue，已編譯資料由同一資源共用。AAT 編譯有工作量和記憶體上限，未能預編譯的子表沿用 checked View。規則共用保留原 selector 標籤及 GSUB feature、值與 lookup 順序。

用取消接線前的優化版重測四組 1,000 UTF-16 碼元。Thonburi 規則搜尋中位 924.91 ms，AAT 單一子表最長 80.68 ms，狀態轉移每 32 步一批最長 0.290 ms。蘋方簡中規則搜尋中位 481.55 ms，單一 GSUB lookup 最長 3.045 ms，候選定位與模型投影最長約 11 ms。於 AAT 子表入口和 Budget 每 32 步、GSUB lookup 和 Budget、候選與顯示投影接取消。主視窗以原子 generation 讓背景查詢輪詢，提交顯示前仍驗證版本。取消與合法空結果區分，未完成結果不進快取，模型僅提交完整投影。

離屏使用正式 controller 和序列佇列，8 次於 Thonburi 舊查詢運行中換輸入，最新查詢在 0.41–1.78 ms 開始，只發布最新文字。重新查詢剛取消的文字需約 936 ms，得到完整 1,176 筆候選，與快取重跑一致。再比較 16 組長輸入與 10 組含多 GID seed、混合方向和預設忽略字元的短輸入，候選、來源、功能標籤、位置及分組一致。離屏使用原生 field editor 重放過期雙擊及 Shift 雙擊，確認來源位置與 GID 符合才套用。arm64 產品構建完成。實際視窗操作未執行。

全字視圖的後續功能可由 GSUB feature → lookup 和 AAT selector → 子表索引起步，收集替換後 GID，避免拿整段文字的查詢快取當字體目錄。GSUB 需保留 nested lookup 的路徑與 variation branch，AAT 需保留 selector 和動作語義。下一輪仍需界定按已宣告的動作輸出收錄，或只收錄可達的上下文輸出。共用 GSUB 計畫前綴和 AAT 跨起點合併仍是獨立重構方向。

最終佇列檢查另把待處理輸入綁定字體文件，換字體時舊 worker 留下新文件的 pending，等模型交換後再讀取。離屏模擬此交界，舊文件沒有發布新輸入，交換後正常發布。最後一次 8 次 Thonburi 取消的下一筆開始區間為 0.37–1.43 ms，完整重跑約 957 ms，1,176 筆候選。再次通過原生 field editor 離屏重放和 arm64 構建。

### 查詢優化定案前覆核 — 2026-11-05

僅覆核與暫存探針，未改產品程式。AAT 機器預編譯已有限額，但 Resource 載入時把每個 selector 的 horizontalSchedule 向量存入 map，另一路沒有工作量或容量限額。用 188,424 bytes 合成 morx 直接跑相同分組，4,096 個 selector 各停用不同的子表，得到 4,097 個不同鍵，鍵向量共 134,283,264 bytes，RSS 增量約 129 MiB。用總掃描量預檢超限即略過去重，探針不再建立該 map。正式方案應以 chain、feature 和 subtable 訪問量計算上限，超限保留逐 selector 正常執行。

同一個離屏控制器關窗回呼探針，運行中的 Thonburi 1,000 碼元查詢關窗後仍運算約 852 ms 並進到發布入口。暫存版清除 pending 並遞增 generation，約 0.24 ms 停止，沒有走到發布入口。正式方案可共用換字體已有的背景查詢失效邏輯。此證據來自關窗回呼探針，未操作可見視窗。

來源群組由 prepared run 決定，字形目錄和各 domain 目前重建多次。暫存只建立一次，1,000 碼元該段中位 Thonburi 0.548 → 0.045 ms、蘋方 0.152 → 0.048 ms，14 組長短含 seed 配對輸出相同。建議作可選清理，依直接分段數字看收益，避免把總查詢波動歸給此項。

### 定案收尾與記憶體對照 — 2026-11-05

使用者確認三項收尾。AAT 去重索引先按 selector 數量和每次 chain、feature、subtable 掃描成本做預檢，總訪問預算 524,288，超限走原有逐計畫路徑。索引鍵按實際大小 reserve。合成表驗證 64 個 selector 仍建索引，512、2,048、4,096 個壓力樣本略過索引，且功能啟停依舊產生不同的替換 GID。視窗關閉清空並失效背景查詢，也失效已排隊的載入，與換字體共用查詢失效方法。離屏關窗回呼約 0.25–0.28 ms 內中止運行中的文字查詢，沒有發布，排隊的載入也被取消。按 prepared run 共用來源群組，16 組長輸入與 10 組含 seed 的短輸出比對一致。離屏雙擊、Shift 雙擊及字體佇列交換探針通過。arm64 產品構建通過。

記憶體以本輪搜尋優化前 /tmp/ga-release-query/before 和目前源碼各編成 arm64 離屏探針。每款字體三個全新進程，各量一組 1,000 UTF-16 碼元，均預先建立同樣的字形庫存。取 task_vm_info phys_footprint 中位數，查詢峰值約每 0.5 ms 取樣。單位 MiB，數字順序為載入後、查詢峰值、完成並排空本輪 autoreleasepool 後。Helvetica 舊 4.10 / 10.19 / 10.19，新 4.13 / 7.00 / 7.00。Times New Roman 舊 4.47 / 7.80 / 7.80，新 4.38 / 7.27 / 7.27。蘋方簡中舊 10.52 / 27.81 / 22.85，新 11.17 / 29.41 / 25.86。Thonburi 舊 4.55 / 14.86 / 12.22，新 4.81 / 14.80 / 11.53。蘋方簡中另各在同一進程連續跑八組不同的 1,000 碼元，峰值 30.08 → 32.22 MiB，完成後 26.67 → 29.31 MiB。這些是單字體模型到顯示快照的離屏進程數字，未涵蓋多視窗或實際 TextKit 渲染。

### 全字視圖篩選特性 — 2026-11-05

依確認在 codex/all-glyphs-feature-filter 實作。菜單欄「文字裝飾」之後與全字視圖右鍵選單「全字視圖」之後，各插分隔線及「篩選特性」子選單，列 GSUB tag 和 AAT type/selector 標籤，可回到完整字庫。每視窗獨立選擇，在專用背景佇列查詢，切換、換字體與關窗會使舊結果失效。選擇與多字排版特性分離。全字格用可見 GID 定位，未收錄 GID 不跳到其他格，雙擊繼續傳既有 inventory 條目。

GSUB 從目前變化分支所選 feature 的 lookup 收集宣告輸出，處理替代、多重、連字、反向和巢狀動作。巢狀動作帶已知來源位置條件及先前動作的可能輸出。AAT 按 chain 中所選 selector 明確啟用的 flags 找到所屬輸出子表，包含本來就啟用但同樣被所選 selector 明確啟用的子表；其他預設啟用的子表不歸入。連字採宣告列表，不求完整排版可達性。查詢快取以特性與分支為鍵，按需且有限額。

合成 GSUB、morx、mort 探針核對替換後 GID、其他預設輸出排除、已啟用的同 selector 輸出保留、巢狀位置與反向上下文、未編碼輸出、取消和兩種 AAT 讀取模式。離屏 AppKit 使用正式菜單與控制器、實際側欄選擇和格子雙擊事件，確認兩個菜單的順序、Times New Roman 的三個 liga 輸出、側欄跳到篩選後正確格、篩選外的 GID 不誤跳、編碼及 Thonburi 未編碼 GID 雙擊、快速切換、換字體和回到全部。arm64 構建和 14 組語系 strings 驗證通過。未操作可見視窗。

另以四款字體的 16 組長輸入與五款字體的 10 組短輸入比對此功能前後的既有文字候選，GID、來源、功能標籤、座標和分組輸出一致。

### 特性篩選覆核、效能與精簡 — 2026-11-05

在 codex/audit-glyph-feature-filter 分支。五款真實字體（Helvetica、Times New Roman、Thonburi、Geeza Pro、蘋方簡中）共 51 個選單標籤均返回非空 GID 清單。實測側欄來源與篩選語義有差異。裸 morx 是預設計畫。Helvetica／Thonburi 的 morx:27:1 等可出現在側欄，但所選 selector 未宣告自己的輸出，側欄既有代碼會把仍運行的預設子表掛在該計畫名下。Times New Roman GID 1019 在 rlig 的宣告清單中，側欄另外保留 fina／init 的上游來源。不能直接把這些標籤或 GID 當成篩選的缺漏。另有一項確定缺漏，GSUB 某 contextual lookup 合法地在另一個字形位置呼叫自身時，文字查詢以 lookup／identity／GID 為循環鍵能找到輸出，篩選只以 lookup ID 阻止重入。合成字體 calt 的 GID 85 在文字查詢 trace 出現、宣告篩選未收錄。依使用者要求只報告，未修改這些歸屬與缺漏。

效能以 /tmp/ga-query-opt/finalize 的上一輪源碼與本輪在 macOS 14.8.7 arm64 各七次新進程交錯測量，數字毫秒、中位。字體載入含全字庫存，長文為 1,000 個 UTF-16 碼元且文字快取未命中，計至顯示快照。Helvetica 載入 7.93→7.93、長文 77.07→77.51；Times 7.35→7.56、22.40→22.52；蘋方 46.43→46.60、522.71→523.19；Thonburi 32.83→33.25、966.33→978.97。全字格定位約 12–16 微秒，舊新接近。新功能冷查詢和建立篩選格分別為 Helvetica morx:27:0 0.016／0.231、Times liga 0.018／0.129、蘋方 aalt 9.58／0.90（27,099 GID）、Thonburi morx:1:0 0.103／0.247。結果不含可見視窗繪製與佇列等待。蘋方另五次用同一離屏流程量進程 phys_footprint，舊版完整格完成後約 32.97 MiB，新版套用 aalt 後約 31.69 MiB，只計完成時點。

精簡共用 AAT flags 套用公式，移除輸出收集只用一次的子表陣列，並把 AAT 標籤與 selector 改為一次建索引直接查；完整網格以 GID 直接定位，稀疏網格沿用二分查找。51 個選項的完整 GID 清單、16 組長文及 10 組含 seed 短文逐項一致。合成 GSUB／AAT、離屏 AppKit 雙選單／側欄跳轉／已編碼與未編碼雙擊、arm64 構建均通過。

### GSUB 合法重入修正與既有文字查詢效能 — 2026-11-05

在 codex/fix-gsub-filter-reentry 分支。全字 GSUB 收集器的循環鍵由 lookup ID 改為 lookup ID 與符號位置狀態。巢狀規則縮小條件時保留已知槽位狀態，跨位置或有新的替換輸出時允許重入。同槽位重複產生已知 GID 不反覆生成狀態，保留 64 層與執行預算上限。原案例 calt GID 85、兩次跨位置連鎖、同位置改 GID 再入、同槽自循環及會改字形的循環共五個探針均通過。五款真實字體 51 組特性輸出逐 GID 相同，arm64 構建通過。此修正僅在全字篩選的收集器。

效能按使用者指定比較加入篩選前（/tmp/ga-query-opt/finalize）、本版未篩選、本版篩選已套用。四款字體各七組相同的 1,000 UTF-16 碼元、整段快取未命中。三模式用新進程交錯，計文字分析到顯示快照，已載入字體及全字庫存，不含佇列等待及可見 TextKit 排版。中位 ms 依序：Helvetica 79.464／80.699／80.723，Times New Roman 22.497／22.681／22.716，蘋方簡中 523.932／531.409／528.216，Thonburi 950.630／964.453／970.877。相對未加入篩選版，本版未篩選每一對樣本的中位差約 +0.9% 至 +1.8%；開啟篩選對同版本中位差約 -0.1% 至 +0.6%。同版另七組蘋方簡中驗證冷查 aalt 與文字查詢實際時間重疊，單跑 526.810 ms、並行 529.147 ms。28 組文字輸入三種狀態的輸出分組數一致。這些是離屏效能比較，未測可見視窗互動延遲。

### 冷查詢和增量重構探針 — 2026-11-05

使用者問還能否優化或重寫。只在 /tmp/ga-query-opt 的副本試驗，未改產品程式或編譯設定。macOS 14.8.7 arm64，同一正式源碼只把 FontLayout 的 -Oz 改 -O2，四組未命中整段快取的單段 1,000 碼元，到顯示快照中位 ms：Helvetica 48.96→29.78、Times New Roman 21.42→15.02、蘋方簡中 526.06→352.54、Thonburi 971.82→551.45。四款輸出逐項一致。以同 flags 分別連結完整 arm64 App 的可執行檔，674,984→805,288 bytes，增加約 127 KiB；未量 x86_64 或完整程序記憶體。

同 -O2 下把 discoverContent 的候選合併從 NSString 格式化鍵換為「來源範圍＋GID 序列」的結構化鍵，四組蘋方中位 360.17→248.88 ms，Thonburi 543.60→537.53 ms，兩款輸出逐項一致。GSUB 有界前綴快照試驗沿用 -Oz，只重用前三步中的單候選狀態，蘋方 526.49→506.04 ms、Times 21.58→18.51 ms，輸出一致。AAT type 2 的無動作區段跳讀，同 -O2 下 Helvetica 29.49→23.76 ms、Thonburi 557.61→519.41 ms，輸出一致。後者原型仍需補齊快取容量、取消與非標準字體表驗證。

增量探針在 -O2 的十段 1,000 碼元，用相對來源範圍和已準備的 run 資料重用未變的規則輸出。第一版對候選再合併一次，蘋方首次 351→458 ms，改為保存既有合併步驟實際新增的記錄後，首次約 354→355 ms，最後一段改一字後 352.14→65.29 ms；Thonburi 首次約 122→125 ms，改一字後 121.11→31.84 ms。第一段插一字讓後續來源位移，也比對一致，蘋方 350.26→64.97 ms、Thonburi 122.27→30.99 ms。這些是各一組改字與插字樣本，未測跨 run 的 bidi／文字種子改變、快取峰值。第一階段建議 FontLayout -O2 與結構化候選合併，第二階段獨立試驗 run cache。如果仍要加速單一長 run，再重構 AAT 起點共用與 GSUB lookup 計畫；保留已解析字體資源、原文歸屬、輸出排序及取消邊界。

### FontLayout -O2 與結構化候選去重 — 2026-11-05

在 codex/optimize-font-layout-query 分支，依使用者確認只將 FontLayout 改為 -O2，並將文字與直接 GID 查詢共用的候選合併索引改為原文範圍＋有序 GID 序列。仍以既有結果陣列決定首次出現順序，以原方式合併來源標籤，並延後到新候選才建 NSNumber 陣列。增量查詢未改。

macOS 14.8.7 arm64，改前當前源碼 -Oz 與改後正式 -O2，四款各七組相同 1,000 UTF-16 碼元，整段快取未命中、獨立進程交錯，計文字分析到離屏顯示快照。中位毫秒：Helvetica 48.847→27.546（-43.61%）、Times New Roman 22.299→14.268（-36.02%）、蘋方簡中 526.390→242.792（-53.88%）、Thonburi 967.117→532.432（-44.95%）。28 組長輸入與五款 10 組含混合方向、預設忽略字元及多 GID seed 的短輸入，原始候選和分組的 GID、來源區間、標籤、位置及順序一致。另 20 組直接 GID 查詢輸出一致。Universal arm64/x86_64 構建通過，效能只量 arm64，未測可見視窗。與同源碼基線比較，arm64 可執行檔約增加 145 KiB。

### 按換行重用候選 — 2026-11-05

依使用者確認，在 `codex/cache-text-by-line` 分支以實際換行為唯一的增量重用邊界。保留全文的 Unicode／bidi 準備與行內既有搜尋單元。快取以準備後的行內相對資料比對，重用各 domain 實際新增的候選或來源標籤並換算回當前位置。單一有搜尋單元的行、跨換行的搜尋單元和超過 4,096 個可搜尋行的輸入沿用完整查詢。快取依字體引擎實例隔離，每代預算估算為 4 MiB；取消中的候選發現不發布快取。

與本輪開始前的源碼比較，17 組邊界查詢、90 組連續編輯及 24 組長文輸出的候選、來源範圍、順序及顯示資料一致。Universal arm64／x86_64 構建通過。arm64 離屏量測十行、1,000 UTF-16 碼元，各四組中位毫秒。蘋方簡中首次 245.43→246.19，末行改字 246.24→48.14，首行插字 248.71→48.69。Thonburi 首次 116.39→117.67，末行改字 116.13→27.11，首行插字 116.37→26.53。另測兩款完成編輯後的進程記憶體，樣本未見上升，未測峰值或可見視窗。

### GSUB 由規則找文字起點的效能探針 — 2026-11-05

依使用者要求，在 /tmp/ga-rule-starts 的隔離副本與 codex/cache-text-by-line 當前源碼比較。GSUB type 4–6 候選發現用現成的規則起始 GID 集合，反查目前候選序列中的位置。每份序列按需建立索引，位置按原順序交回同一套比對與執行器。字形或位置改變後重新建索引。確定性 lookup、AAT 與全字篩選沿用現行實作。產品源碼未改。

macOS 14.8.7 arm64 離屏計文字分析至顯示快照，各七組新進程交錯、中位毫秒。Times New Roman 稀疏拉丁 1,000／5,000 UTF-16 單行首次 14.18→12.98／67.58→62.23，5,000 十行改末行 55.85→55.54。SignPainter 實際拉丁連字 1,000 單行 35.90→33.22，5,000 十行首次 122.35→116.72、改末行 58.01→57.42。Times New Roman 阿拉伯文 5,000 十行首次 3703.74→3536.88、改末行 510.01→490.59。蘋方簡中 1,000 十行首次 245.93→257.94、改末行 47.91→48.34。樣本程序峰值記憶體有升有降，例蘋方 5,000 十行編輯後 36.02→37.83 MiB，SignPainter 同情境 13.69→14.22 MiB。

另三次探針分段。SignPainter 5,000 十行首次送入候選規則比對的位置 740,790→16,226，找位置和比對合計 14.61→6.60 ms，候選重放約 11.5／11.8 ms，確定性 lookup 約 26 ms。蘋方 1,000 十行，找位置和比對合計 54.84→61.66 ms，索引成本超過省下的比對時間。Thonburi 1,000 單行對照 534.62→535.53 ms；AAT 分段量測約 9 ms 查起點、388 ms 複製候選序列及重跑狀態機。

25 組離屏比較含換行、選字 seed、取消後重查，原始候選和顯示輸出一致。五個既有巢狀 lookup 表驗證通過。合成表驗證前一 lookup 產生下一條上下文規則的起點、完整前後文、上下文改字後再連字。八組合成文字輸入的候選、來源、標籤、順序與連字數也一致。診斷另查到 Times New Roman 阿拉伯文 1,000／5,000 單行與 SignPainter 5,000 單行觸發既有 GSUB 候選狀態預算，該計畫會捨棄結果。5,000 兩版觸發次數分別一致為 17／4，未拿這些單行數字當完整查詢的加速證據。未測可見視窗。這版索引有局部收益，但尚不適合全域啟用。

### 候選狀態上限與實際漏項 — 2026-11-05

依使用者要求只查證與提案。正式 Sources 未改。/tmp/ga-state-budget 在隔離副本記錄每個 GSUB 查詢計畫的超限 lookup、狀態數、計入的字形數和已產生 trace。原上限且照現行丟棄規則的輸出，逐項比對等於上一輪三份未加診斷基線。另以相同文字和查詢設定分別測保留已驗證 trace、只提高等候狀態的字形上限；未調整字形成長和執行步數上限。

GSUB 候選每層持有完整字形序列，掃描前、重放局部規則、產生 trace、及確定性續跑均有整段副本。每個 lookup 都把後續狀態的整段字形數計入上限，去重鍵也逐字形展開。5,000 字形樣本上限 320,000，連字後的 64 份狀態已計 319,936，第 65 份超限，當時 trace 已有 65 筆。引擎以 InvalidTable 捕捉後清空該計畫的整份 trace。其他計畫與字形目錄仍可提供候選。快取拒存該行的候選增量資料，但全文結果仍可能以完整查詢鍵快取。

- SignPainter 5,000 UTF-16 單行，4 個計畫在 lookup 3（liga）超限。正式結果無連字。保留已驗證 trace 恢復 65 項；4 倍排隊上限完成全部計畫，新增 175 項，逐位置核對為 88 處 er（GID 1150）與 87 處 tt（GID 1180）。單次離屏進程峰值約 73→402 MiB，耗時約 120→853 ms。
- Times New Roman 阿拉伯文 1,000 UTF-16 單行，13 個計畫在 lookup 13（liga）超限。2 倍、4 倍上限均完成，且原始候選與來源逐項一致，確認多出 52 個多組件候選，包含 لَا 與 اللَّه 的連字／附標組合。保留原上限的已驗證 trace 在這一樣本也恢復同 52 項。
- 同一阿拉伯文樣本 5,000 UTF-16 單行，17 個計畫先在 lookup 6（ccmp）超限。正式結果沒有多組件候選。保留現有 trace 恢復 65 個附標組合；2 倍上限且保留已驗證結果確認至少少 318 項，包括 127 個 ccmp 附標組合與 191 個 rlig 組合。15 個計畫仍在 lookup 12（rlig）超限；4 倍探針 45 秒未完成，已知至少 10 個計畫在 lookup 13（liga）再達上限。318 是同一份輸入上已驗證的下限。

提案先把 GSUB 整段副本改為共用字形序列與差異，使用局部變更記錄產生 trace；先做已證明等價的共用，後續再以實際讀寫區間、lookup 方向及來源區間證明可重用確定性結果。用可取消的分批續跑管理實際記憶體與工作量，區分預算、壞表、取消和完成，避免把預算前已驗證的候選全部丟掉，也避免將未查完結果當完整快取。AAT 起點後的長尾重跑另案，用實際狀態和副作用證明何時可共用。保留現有文字切分語義。

使用者明確決定放棄「由規則反查文字位置」方案。上輪探針只保留作為量測記錄。候選共用字形序列與避免超限丟棄是獨立提案，尚未獲授權實作。

### 修正 GSUB 長文候選超限漏項 — 2026-11-05

使用者確認側欄候選與字體實際可用結果不符是完整性問題，批准落地。在 `codex/complete-substitution-discovery` 實作 GSUB 候選的共用字形區塊及局部變更比對，保留原查詢方向、lookup 次序和原文歸屬。候選後續狀態以共用區塊與實際候選配置估算，不再以每份候選的整段字形數計入。只跳過可證明不適用的起點。特性來源按原順序合併，來源索引亦共用未修改區塊。GSUB 發現安全上限與壞表或取消區分，保留已驗證結果並標記未完成，全文、受影響的逐行快取及文字模型都不把該次視為完整。AAT 執行器維持原本的流程。

SignPainter 5,000 碼元單行從 0 恢復至 175 個連字，Times New Roman 阿拉伯文 1,000 碼元從 52 恢復至 104 個多字形候選，兩份輸出均與已跑完的高上限參考逐項一致。Times New Roman 阿拉伯文 5,000 碼元從 0 恢復至 507 個多字形候選，完成標記為 true，包含先前已驗證的 318 項。臨時壓低上限的測試保留 8 項並回報未完成，重查相同文字確實再次執行。114 次原本可完成的離屏查詢逐項相同，另 10,000 個字形區塊與變更比較、既有巢狀和連字接續樣本通過。arm64／x86_64 Universal 構建通過，未測可見視窗。

arm64 離屏單次診斷至顯示快照，SignPainter 5,000 碼元約 109 ms，Times New Roman 阿拉伯文 1,000 碼元約 855 ms，5,000 碼元約 21.2 秒、198 MiB 程序峰值。舊版同一份 5,000 碼元阿拉伯文很快結束，該數值包含丟棄候選，不作完整查詢的速度基線。

### 全 App 審查與相同代碼合併 — 2026-11-05

使用者要求從代碼結構縮小 App，排除圖示、語言資料及編譯選項的體積試驗，並確認合併相同代碼。在 `codex/consolidate-glyph-execution` 將 GSUB 發現及確定性／來源回放執行合成一份，並將側欄雙擊替換與 Shift 插入的版本判斷、來源定位、替換內容建立和提交合成一份。三個源文件合計少 70 行，原有資源及編譯設定不變。

同一套構建，Universal 執行檔 1,905,424→1,872,528 bytes，少 32.12 KiB。相同打包方式的 ZIP 1,151,834→1,142,947 bytes，少 8.68 KiB。四款 1,000 碼元各六次交錯離屏比較，字形、來源、標籤及順序相同，耗時接近。SignPainter 5,000 碼元及 Times New Roman 阿拉伯文 1,000 碼元的補回結果逐項相同，合成來源回放的前後字形和來源相同，側欄 27 項離屏檢查通過。Universal 構建及嚴格簽名檢查通過，未測可見視窗。

已驗證、待確認的行為問題：

- 多字預覽移除缺字後把原文不相鄰的字形接在一起重排。Helvetica／Avenir Next 的 f龘i 得到 fi 連字，SignPainter 的 e龘r 得到 er 連字，原文側欄查詢均沒有這個連字。Menlo 的 U+200B／U+2060 和 Helvetica 的 U+0085 也會被移除。建議保留原文整形邊界，區分控制字元與真的缺字，並保留準確點擊來源。
- Thonburi 5,000 碼元單行的 AAT morx type 2 三個計畫超出步數上限。現有結果有 870 項，對照探針完成後同樣 870 項，但每項補回 7 個來源標籤。保留已完成子表的探針先補回 232 項的標籤。後續 AAT 應分開處理預算與壞表，保留可驗證結果，並優化 type 2 重跑。Zapfino 5,000 碼元另重現多次超限，未量到完整差集。
- 多字預覽回呼缺少來源版本檢查。離屏控制器用 AB 舊快照並插入 X，點擊回呼仍能選舊 B 列，當前相同位置已是 A。重測舊側欄雙擊及 Shift 插入均等待新結果，沒有立即改錯位置。
- 全字篩選選項先打勾，再非同步更新格子。控制查詢延遲可穩定重現新勾選配舊結果；可讓已套用的標籤和格子一起提交。
- 多字預覽恢復預設大小會重排 3 次。可將同一次操作的縮放、行距、邊距合併提交，驗收應保持原有字形、位置及捲動。此結構建議尚未改動。

### 缺字排版邊界、AAT 長文與視窗回歸 — 2026-11-05

在 `codex/fix-preview-and-aat` 修正上輪四項問題。多字預覽保留不繪製也不接受點擊的缺字邊界，避免前後文字被誤排成連字。換行、斷詞與雙向文字控制仍交給原生排版。多字點擊及異步反查結果在套用前核對文字版本和連續原文範圍。全字篩選的已選項目與格子一起更新，過期請求無法覆蓋較新的選擇。

AAT type 2 候選共用緩衝區並只復原實際改寫的範圍，跳過無副作用且段尾無動作的轉移，只在狀態、堆疊與來源邊界都允許時重用已探索的後綴。提高候選探索的步數額度並維持上限。達限時保留已驗證結果，標記未完成並禁止當成完整結果快取。Thonburi 單行 5,000 UTF-16 碼元完成，870 項各補回 7 個來源標籤，輸出逐項等於高上限參考。最終單次冷查約 7.92 秒、程序峰值約 92 MiB，同一高上限參考約 11.87 秒、95 MiB。舊正式版約 6.29 秒，但未完成。Zapfino 長文的完整差集仍未量得。

在 macOS 14.8.7 可見視窗用 Helvetica 輸入 f龘i，兩個字母分開顯示，點 i 對應正確側欄列。另實際重現雙擊替換後 ⌘Z 無效，將側欄替換、Shift 插入和全字追加接入視窗 Undo，保留輸入中的顯式 GID 屬性。上屏確認 fi→ﬁ 與 fi→fiﬁ 均可復原及重做。離屏另驗證舊側欄請求重綁、舊預覽拒絕、篩選提交和 72 個橫直排點擊位置。這輪沒有宣稱遍歷所有上屏組合。

多字恢復預設大小合併為一次重排，原為三次。側欄連字組按來源終點集中插入，單 GID key 省去陣列及字串拼接，seed 先排除來源不相交的群組。115 次原能完成的離屏查詢，候選、來源範圍、側欄字形、標籤、順序與位置均與上一版相同。四組 1,000 碼元各六次交錯冷查中位數，Times New Roman 拉丁 10.86→10.94 ms、PingFang 163.44→164.75 ms、Times New Roman 阿拉伯文 125.80→127.35 ms、Thonburi 112.04→101.79 ms。

Universal 構建和嚴格簽名檢查通過。相比上一輪合併版，執行檔增加 33,216 bytes（32.4 KiB）。本輪的修正和額外功能沒有進一步縮小執行檔，資源與編譯設定沒有本輪變動。

### 全字特性篩選選單與停用提示 — 2026-11-05

篩選特性按 GSUB FeatureList 的實際次序列出，每個標籤只出現一次，AAT 標籤接在後面。「無特性」放在「全部字」和分隔線之間，顯示未被任何可選 GSUB／AAT 特性列為輸出的字形。無可選特性的字體仍可選「無特性」，此時顯示完整字庫。可變字體換軸時按目前分支重查篩選。菜單欄的「篩選特性」及「顯示邊界框」停用時沿用現有工具提示機制，指出可切換的視圖。14 套本地化補齊文字。

離屏以重排及重複標籤的 GSUB／AAT 字體、無替換字體和 GSUB FeatureVariations 探針驗證順序、差集和分支快取。Helvetica、PingFang SC、Times New Roman、Thonburi、Menlo 的篩選聯集及「無特性」逐項互斥，合併等於完整字庫。三種視圖均驗證選單可用性、提示及勾選。Universal 構建和嚴格簽名通過，本輪未上屏操作。

### 開啟字體閃退排查 — 2026-11-05

14:36 的兩份崩潰報告均來自 `/Applications/Glyph Atlas.app` 的 06:35 arm64 中間構建。主執行緒提交首份查詢快照時向 `GAMultiGlyphView` 呼叫 `setText:groups:omissions:`，執行檔內的視圖仍使用兩參數版本，觸發未識別方法例外。工作區 `dist/Glyph Atlas.app` 的 14:34 Universal 構建具有不同執行檔 UUID，且連結表確認兩個架構均包含三參數實作。嚴格簽名檢查通過。用目前源碼的實際主視窗控制器離屏開啟 Arial，三種初始視圖均通過首份快照提交、輸入 f龘i 和切換多字預覽。此次未替換系統安裝副本。

### 發表前代碼收尾 — 2026-11-05

在 `codex/release-code-cleanup` 移除切換到多字元視圖時的重複快照和排版設定提交。窗口建立時套用排版預設，後續由既有的文字、字體與排版設定流程更新。GSUB 探索摘要只保留標籤與最大候選數，去掉摘要用不到的 lookup 清單。配色選單的色塊、提示與選項共用角色順序及數量，並移除選字範圍計算的無效初始化。

離屏重現全字篩選在活動窗口改變後會套到另一窗口。子選單現在在重建時綁定原窗口，重新打開時取得新窗口。雙窗口探針在改前重現、改後通過。115 組文字查詢的原始候選和預覽快照逐項一致，三種初始視圖均通過開字體、缺字預覽和排版設定切換。配色選項、提示與色塊尺寸的離屏輸出相同。最終版所有實作檔靜態分析完成，Universal ZIP 解包後通過嚴格簽名檢查。本輪未操作可見視窗或發佈。

### 1.6 文件同步與提交 — 2026-11-05

依使用者的中文 README 定稿同步英文，逐字保留中文。15 條「使用」與 14 個語系 Help 同步，沿用各地區菜單名稱。把顯示版本改為 1.6，沿用上版做法保留內部構建號 5。重建 Universal ZIP，解包後版本與嚴格簽名檢查通過。

以 GitHub 當時 main 的 6a33688 為基準建立 codex/release-1.6。將本輪版本、文件及先前完成的功能與修正合為 69458ea，按使用者要求推送至 GitHub main，遠端回覆 6a33688→69458ea。

### 全字篩選空清單與介面覆核 — 2026-11-05

在 `codex/filter-empty-state` 改為無可選標籤時仍可打開「篩選特性」，子選單只有停用的「沒有可篩選的特性」。14 語系同步。以移除 GSUB 的 Arial 上屏確認主選單和全字右鍵均顯示灰色提示，字體排印仍能列出字距功能。以 SFNS 確認有可選特性時仍列「全部字」「無特性」和標籤。

本機 macOS 14.8.7 的獨立副本另檢視了檔案與開啟面板、編輯與常用文字、三視圖右鍵、顯示方式與配色空清單、全螢幕、可變字體面板及輔助說明。發現全部字網格未向輔助使用樹提供逐格項目，鍵盤 Tab 也無法進入格子。Help 是模態提示，不能開著一邊照做，繁中 Help 的「多字符」及「篩選字形選項」與菜單「多字元」「篩選特性」不一致。字形編輯後選單只顯示「還原」，與原生貼上後的「還原貼上」相比缺少操作名。上述事項留待使用者決定。

### 開啟面板的選單焦點、還原名稱及 Help 用詞 — 2026-11-05

在 `codex/open-panel-menu-routing` 延續上一輪未提交的空篩選提示。原生「開啟」面板或它的 sheet 取得焦點時，字體命令不再退回主窗口或最早可見的字體窗口。若使用者切回某個字體窗口，仍以該窗口執行命令。保留按 Option 切換「開啟字體於」及隱藏的 ⌘O／⌘N 快捷鍵。同一個 Help 對話框及全部字的鍵盤操作不變；繁中 README 與台灣、香港 Help 改用選單名稱「多字元」「篩選特性」。

替換與加入字形共用原本的窗口 Undo 註冊，以 `setActionName:` 交給 AppKit 產生還原與重做的標題，14 語系補齊。macOS 可見視窗對照：舊版開啟面板在前景時仍可使用字體視圖命令。新版同時開著 Geneva、Helvetica 與「開啟」面板時，視圖、放大、篩選、預設值和拷貝到字體簿停用，開啟與開啟最近仍可用。從視窗選單切回 Helvetica，字體命令立即恢復，⌘O 仍能帶回開啟面板。用 Helvetica 確認雙擊 fi→ﬁ、Shift 雙擊 fi→fiﬁ 可還原和重做，選單名稱正確。另用 Geneva 確認原生打字與貼上各自可還原和重做，保留原生標題。

另確認一個既有的混合還原問題，待處理：從空白欄位貼上 `fi`，雙擊 Helvetica 的 `ﬁ`，第一次 ⌘Z 恢復 `fi`；第二次 ⌘Z 執行「還原貼上」後，輸入欄仍顯示 `fi`。同樣步驟在改前及改後結果一致，本輪未變更混合歷史的還原邏輯。

14 套字串通過 `plutil -lint`，`git diff --check` 通過。Universal 編譯完成；同步資料夾會重新加上 Finder 屬性，將 App 複製到 `/tmp` 再簽名，通過嚴格驗證並確認 arm64／x86_64 兩個架構。

### 混合還原與 ⌘O 顯示的隔離查證 — 2026-11-05

使用者要求先提方案。混合還原的兩條路徑共用視窗 Undo Manager，但原生輸入操作綁定目前的欄位編輯器，字形操作及其還原直接寫回欄位值。隔離 AppKit 測試確認，同一個已接回欄位的編輯器用原生文字變更流程登記字形編輯，可逐步還原與重做打字和字形，包含字串相同、只改自訂字形屬性的操作。焦點移離而編輯器分離後，直接重放同一份原生紀錄在探針中出現範圍錯誤，不能只替換字形編輯的登記方式。

⌘O 顯示消失的直接原因見 2026-11-04「修正開啟字體的 Option 子選單及停用狀態」。隔離測試細化當時的結論：子選單父項使用預設子選單動作時讀到空快捷鍵，有明確動作時可以保留 o。試過以正常命令鍵和 Option-Command 配對，獨立 UI 探針確認兩組快捷鍵分別執行兩個動作，因此不能假設替代父項的快捷鍵只供配對。使用者提出按住 Option 直接互換兩列的顯示狀態，需另驗證選單追蹤期間可否用原生控件即時互換。正式 Sources 未變更。

### 統一輸入還原歷史與恢復 ⌘O 提示 — 2026-11-05

使用者同意兩項方案，在 `codex/unify-input-undo-open-menu` 實作。保留原生搜尋欄與既有編輯器，失焦時保留編輯器文字存儲，重新接回欄位時避免 AppKit 的欄位交接清掉還原紀錄。雙擊替換、Shift 插入和全字追加以原生文字變更方法登記到同一個視窗 Undo Manager，移除原本的手動還原副本。還原與重做後同步失焦欄位，清除待套用的側欄操作，再重新查詢。

「開啟字體…」使用真正的 ⌘O，「開啟字體於」保留原生子選單，按 Option 切換兩項的可見性。僅在檔案選單追蹤期間輪詢 Option 狀態，關閉時停止。⌘N 仍由隱藏選單項目處理。

以正式類別的離屏探針驗證預設 Undo 分組，側欄持有焦點時能完成空白／fi／ﬁ 的兩次還原和重做，重新取得及離開輸入焦點後歷史保留。換行標記、字串相同的指定 GID、全字追加、舊側欄來源重綁與 Shift 插入通過。選單探針確認 ⌘O 和 ⌘N 觸發同一動作，Option 旗標能切換兩列且沒有新增 ⌥⌘O。自動審核未允許用電腦操作開啟隔離版，所以未驗證實際選單追蹤畫面，也未完成真實貼上按鍵的上屏測試。Universal 編譯與嚴格簽名通過。

### 檔案選單保留同一列切換 Option — 2026-11-05

使用者上屏看到「開啟最近項目」展開後，滑鼠不動按 ⌥ 時舊子選單與白字會殘留，移動滑鼠後復原。在 `codex/keep-open-font-menu-row` 依確認的方案保留原第一列，在同一個 NSMenuItem 切換「開啟字體…」及其原生 ⌘O，或「開啟字體於」及其資料夾子選單。選單關閉後還原普通項目，鍵盤快捷鍵查找不再觸發可見內容切換。

離屏用正式類別重複 20 次按下／放開的狀態切換，確認列順序、最近項目子選單、三個資料夾命令與快捷鍵。隔離版上屏確認 ⌘O／⌘N 都可開啟面板。電腦操作工具不支援只送出 ⌥，且選單畫面不在 App 視窗截圖內，使用者回報的靜止滑鼠反白畫面尚未上屏驗證。Universal 編譯及嚴格簽名通過。

### 推送 1.6 後續修正 — 2026-11-05

使用者實機確認同一列切換方案無問題，要求提交至 GitHub。將空篩選提示、開啟面板選單焦點、原生輸入還原、⌘O 選單切換及繁中用詞一併提交為 f789e88，GitHub main 由 69458ea 快轉至 f789e88。

### 1.6 後續審查：換行旁貼上與字形指定還原 — 2026-11-05

使用者要求覆核 f789e88。本輪只做源碼檢查、隔離離屏測試及可見視窗對照，沒有改正式程式。

- Geneva 多字元視圖貼上 A、換行、B，移到第二行開頭後按 x。藍色組字標記期間側欄不查 x，按 Return 送出後立即出現 x（U+0078），符合組字邏輯。另從相同位置直接貼上純文字 x，輸入欄為 A⏎xB，沒有組字底線，但側欄不列 x，多字元預覽把它當成額外換行。f789e88 和上一版 69458ea 的同一輸入程式均上屏重現。轉換只按換行屬性還原 LF，即使字元不是 U+23CE；離屏探針也可讓插入的 X 繼承該屬性。建議從輸入端限制換行屬性的來源，轉換端亦核對字元，並測實際貼上、中文組字與字面 U+23CE。
- 以產品控制器與原生欄位編輯器離屏測試，對兩字元 fi 指定一個 GID，刪 i，再還原。f789e88 恢復 fi，但指定 GID 消失；舊版同一探針未恢復文字。刪除時重查會把殘餘範圍的 GID 屬性從整段清掉，該清理未進同一筆 Undo。建議同一還原操作保存與恢復受影響的字形指定，正常編輯時仍可解除已失效的指定。

### 修正換行旁貼上與指定字形的還原 — 2026-11-05

依使用者確認在 `codex/fix-input-marker-and-glyph-undo` 修正。輸入欄與查詢模型現在只把具有換行屬性的 U+23CE 當成換行，清除普通字元繼承的標記。字面 U+23CE 的輸入與貼上明確使用無換行標記的文字。清理格式只更新文字屬性，避免用整段文字重寫影響選區和還原。

一般文字編輯解除或縮短指定 GID 時，只改受影響的屬性範圍，並將變更加入同一筆原生文字還原。涉及指定字形的文字修改先結束前一段打字合併，讓還原與重做以正確次序重放文字和屬性。一般重新打回相同字串不會自行復活先前解除的指定。

macOS 可見視窗用 Geneva 確認在換行後貼上 x 時，側欄及預覽都有 x，還原／重做正確。用 SignPainter-HouseScript 的無編碼 e_r 驗證實際雙擊指定、刪除 r、單次還原恢復原字形、重做解除、Shift 雙擊插入及連續還原至初始貼上。離屏以正式類別驗證連續打字、跨兩段 GID、側欄焦點、字面換行符、模擬中文組字送出前後，以及先前的舊側欄來源重綁。Universal 構建與嚴格簽名通過。

### 全代碼覆核：cmap 選擇及局部錯誤隔離 — 2026-11-05

在 `codex/fix-input-marker-and-glyph-undo` 覆核。31 個實作檔的 Clang 靜態分析沒有診斷。離屏用正式控制器與原生欄位編輯器跑過 25 項輸入檢查，包括在已指定的 `fi` 中間插入 `fi`，確認指定不會轉移至新字，還原會恢復原指定。

- `Cmap::nominal` 逐表找第一個非零 GID，將互斥的字元映射表混用。系統 AppleGothic 的 `®` 在 Unicode 表沒有映射，側欄卻採用 Mac Roman 的 GID 144，正式多字元視圖的 TextKit 2 版面最後省略 `®`。Chalkduster 的 `Ā` 也重現側欄列 GID 683、預覽省略。建議選定一份基本映射，側欄及全字 Unicode 資料採相同規則，另套用合法的 format 14；保留只有傳統映射的字體並測對應結果。
- 子表錯誤可擴大為整份 cmap 或整次查詢失效。隔離 Arial 副本加上一份 App 不使用且長度越界的子表，CoreText 仍從該檔案讀得 `A` 為 GID 36，App 判成 GID 0 並從預覽移除。系統 Diwan Thuluth 的 format 4 終止段偏移越界，`اب` 可正常查詢，加入 `U+FFFF` 後兩個正常字仍在 TextKit 2 預覽，但側欄失去整筆查詢的 GID。建議在讀取記錄前篩選支援的編碼，將子表與個別映射的異常限制在出錯範圍，避免覆蓋其餘正常結果。

在 macOS 14.8.7 使用正式字體查詢及離屏 TextKit 2 視圖重現，探針放在 `/tmp/ga-source-audit.VQXDzs`。本輪沒有改產品程式或操作可見視窗。

### 隔離損壞的 cmap 映射 — 2026-11-05

使用者確認保留現有 Unicode、symbol 與 Mac Roman 查找方式，只修正錯誤擴散。在 `GACmap.cpp` 隔離單份子表的讀取例外，字元查找越界時讓原有候補順序繼續。載入 format 14 時先驗證選擇符目錄；單個選擇符的非預設映射損壞時，仍可讀取同一選擇符的預設映射。

離屏對照正式查詢及 TextKit 2 預覽。隔離 Arial 副本的 `A` 恢復為 GID 36。Diwan Thuluth 插入 `U+FFFF` 時，側欄恢復兩個阿拉伯字的 GID 132、1203，預覽保留兩字並省略 `U+FFFF`。六組正常樣本的改前／改後輸出逐位元組相同，包含 AppleGothic `®`、Chalkduster `Ā` 和 Apple Color Emoji 的變體序列。另以 ASan／UBSan 驗證 13 項 cmap 查找斷言，涵蓋損壞記錄、同表正常字元、候補表及 UVS。隔離 Universal 構建及嚴格簽名通過。

### 全代碼續查：組合字的側欄定位及字體拷貝 — 2026-11-05

31 個實作檔重新執行 Clang 靜態分析，沒有診斷。原生輸入探針另確認回填相同的常用文字會移除原先的指定 GID。

- Times New Roman 輸入 `بُب`，第一個字在 TextKit 2 排成母音符號 GID 757 與連寫字母 GID 913。離屏取出實際排版的來源範圍與 GID，交給產品的預覽選字回呼。側欄原有 GID 913，卻選到未連寫的 GID 911。預覽回傳完整組合字範圍，側欄分別列字母和符號。精確範圍反查沒有候選時，現行程式退回第一個相交群組的基本字。建議保留排版中各字形的來源，先核對同一來源的實際 GID，保留連字及指定字形的完整範圍。
- 字體視窗可從相對符號連結 `Linked.ttf → Real.ttf` 載入 Arial 並保留該路徑。用正式拷貝方法複製到獨立暫存資料夾後，產物仍是同一個相對連結，CoreText 可讀字體數由 1 變 0。建議拷貝或取代時讀取連結目標的字體資料，沿用目前的目的檔名和同名處理。探針只操作暫存資料夾。

兩項皆在 macOS 14.8.7 離屏重現，沒有修改正式程式。

### 修正組合字定位及符號連結拷貝 — 2026-11-05

依使用者確認修正兩項。多字元視圖保留整組字形和文字順序中第一個原生組件的來源。整組無法定位時，主視窗用原文範圍和 GID 找該組件，指定字形仍按完整範圍處理。字體拷貝和取代改讀符號連結指向的檔案，沿用原目的檔名。連結失效時走原生檔案錯誤流程。

離屏以原生字形位置觸發 Times New Roman `بُب` 的點選，側欄選中 GID 913。省略兩個缺字造成索引位移後仍選中同一字形。Helvetica `fi` 連字與指定的雙 GID 序列均保留完整定位。暫存 Arial 探針驗證直接拷貝、取代、普通檔案拷貝，並確認失效連結報錯時不建立檔案或覆蓋既有檔案。隔離 Universal 構建及嚴格簽名通過。

### 全代碼續查：變體表的錯誤範圍與目的檔名衝突 — 2026-11-05

- 以可由 CoreText 開啟的 SFNS 暫存副本重現。只把 `avar` 宣告軸數由 4 改為 5，GSUB 1.0 表仍相同，`fi` 查詢仍得 13 個候選，但 36 個可篩選的特性標籤全部消失，`liga` 從 220 個輸出變成查詢失敗，13 個候選的明確繪製位置也全部變空。從該副本移除壞的 `avar` 後，篩選標籤和 `liga` 輸出恢復。建議隔離 `avar` 的讀取錯誤，保留不依賴變體條件的有效特性與可用的字形度量。
- 目的資料夾已有同名失效符號連結時，`fileExistsAtPath:` 回傳否，拷貝走新增路徑後報 NSCocoaErrorDomain 516。離屏直接呼叫正式取代方法也報錯 4，連結未移除，CoreText 仍讀不到字體。新增與保留兩者的檔名判斷需檢查目錄項目。取代連結時可將已備妥的字體原子替換到該路徑。暫存探針驗證原子取代能換掉失效連結，且不建立原連結所指的檔案。

測試在 macOS 14.8.7 的暫存資料夾與離屏產品方法進行，沒有修改正式程式。

### 隔離變體座標錯誤與處理同名連結 — 2026-11-05

依使用者確認修正兩項。字體實例建立時保存已正規化的變體座標。座標表損壞時保留基礎 GSUB／GPOS、原生 advance 和靜態度量，略過無法判定的條件分支與座標差值。SFNS 的壞 `avar` 樣本恢復 36 個篩選標籤、`liga` 的 220 個輸出及 `fi` 13 個候選的位置。原始 SFNS 與無 `avar` 的對照樣本改前改後輸出一致。

字體拷貝以目錄項判斷同名及可用的數字後綴。取代符號連結時，先在目的磁碟準備副本，再用原子 `rename` 換掉該項。以暫存目錄及注入按鈕回覆的離屏探針驗證「保留兩者」跳過兩個失效連結、「停止」保留原項、取代失效連結後 CoreText 能讀取字體。另驗證取代有效連結保留它的目標，普通檔案取代與直接拷貝照常。隔離 Universal 構建及嚴格簽名通過。

### 全代碼續查：直排變體與側欄鍵盤跳轉 — 2026-11-05

- SFNS 暫存副本的 `vert` 為彎引號 `‘` 宣告兩個分支。字重 400 的篩選結果是 GID 19，字重 1000 的篩選結果是 GID 50。正式 TextKit 2 直排預覽在兩個字重都讀回 GID 19。引號補償遍歷所有分支並採用第一個替換，應改查目前的 GSUB 分支。側欄列出所有可能替換的用途仍可沿用既有發現流程。
- Arial 側欄的正式鍵盤事件處理離屏重現。`A` 和 `B` 中間只有換行時，`⌘↓` 和 `⌘↑` 可往返。兩個換行之間加入孤立的 `U+FE0F` 時，中間產生一個沒有可見列的來源群組，兩個快捷鍵都停在原列。可從可見列找相鄰的基本字，跳過沒有基本字列的群組。

兩項均為 macOS 14.8.7 離屏探針結果，正式程式未改動。

### 保留孤立選擇符及修正直排與鍵盤跳轉 — 2026-11-05

文字準備記下孤立的 VS1–VS256，完成替換搜尋後才將原文範圍和 GID 0 加到結果。側欄沿用缺字列顯示原碼位，多字快照沿用原有缺字和控制字元規則。Arial 離屏驗證全部 256 個孤立選擇符、換行旁的 VS16 及無映射時的基底字形。Apple Color Emoji 的 `❤️` 和 Hiragino Sans 的表意文字變體仍各使用一組來源。

側欄的 `⌘↑`／`⌘↓` 直接在可見列找基本字形。以正式鍵盤事件驗證可選取 VS16 缺字列並繼續移動。另將含無列群組的查詢結果載入側欄，確認兩個方向都能跨過。直排彎引號查目前的 GSUB 分支，SFNS 暫存副本的 TextKit 2 結果在字重 400 為 GID 19，字重 1000 為 GID 50，與篩選結果一致。隔離 Universal 構建及嚴格簽名通過。

### 全代碼續查：分隔符、換行後附標與過期側欄選取 — 2026-11-05

- Arial 輸入 `A`、LF、`U+0301`、`B`，模型仍保留原文，TextKit 2 可讀回附標 GID 1171，側欄卻沒有附標列。Foundation 將 LF 和附標放在同一個組合範圍，文字準備遇到其中的換行就略過整組。另外 `U+200B U+FE0F` 只顯示 Arial 的零寬空格映射，側欄的碼位標籤不含 VS16。建議只略過實際的換行，保留之後的附標來源，並防止沒有可用基底的控制字元吃掉選擇符。多字元預覽繼續沿用原本的缺字與控制字元規則。
- 單行輸入欄只替 CR、LF、CRLF 建立換行標記。`U+2028`、`U+2029`、`U+0085`、`U+000B`、`U+000C` 經正式輸入方法後均成了 `U+0020`，模型及側欄也收到空格。以替身剪貼簿走正式貼上方法再確認 LS／PS，原生預覽讀回 Arial 空格 GID 3。建議標記保存原分隔符，複製及查詢時還原其碼位，沿用 CR／CRLF 轉 LF 和字面 U+23CE 的規則。
- 全字雙擊所排定的側欄選取會跨輸入更新殘留。離屏在 Arial 的 `AB` 執行正常加入 `C` 會選中第 3 列。若在該結果發布前把文字改成 `D`，新列正常出現但未選取。改為 `DE` 仍未選取，改到 `DEF` 則跳到與原請求無關的 `F`。建議把選取請求綁定原來源與待發布的查詢，來源已被換掉時取消並走一般選取流程。

macOS 14.8.7 離屏使用正式控制器、欄位編輯器與 TextKit 2 驗證，並重跑全部 31 個實作檔的 Clang 靜態分析，沒有診斷。探針置於 `/tmp/ga-source-audit.VQXDzs`。本輪只記錄發現，未改正式程式或進行可見視窗驗收。

### 保留換行後的附標與控制字元後的選擇符 — 2026-11-05

使用者確認只修續查第 1 項。文字準備以實際換行碼位切開 Foundation 的組合範圍，讓換行後的附標進入下一個排版段。控制碼、格式控制字元和換行不消耗其後的變體選擇符，側欄沿用既有的 GID 0 列顯示孤立選擇符。

離屏用正式查詢驗證八種換行形式之後的正常附標、缺字附標及 VS16。也確認定位字元、零寬空格、連接與非連接控制字元、單字連接符後的 VS16 各有獨立側欄列。一般附標組合、無變體映射時的基底字、emoji 及表意文字變體仍保留原有結果。隔離 Universal 構建及嚴格簽名通過，未啟動正式 App。

第 2 項另外比對智慧型複製／貼上、文法及拼字檢查與自動更正的開關。全部關閉時，正式貼上與直接回填仍把 LS、PS、NEL、VT、FF 改成空格。無產品類別的原生 NSSearchField 探針顯示，LS 與 PS 寫入文字儲存時仍是原字元，欄位收到文字變更通知時轉成空格。這是原生單行搜尋欄的行為，與上述開關無關。第 2、3 項程式未改動。

### 保留 Unicode 分隔符並取消過期的側欄選取 — 2026-11-05

依使用者確認修正續查第 2、3 項。輸入欄以單個可見符號保護會被原生單行搜尋欄改成空格的分隔符。一般換行使用 ⏎，行分隔 ↵，段落分隔 ¶，換頁 ␌，換至下一行 ␤，垂直定位 ␋。每個符號的屬性記下原碼位，查詢、多字元預覽、複製、剪下及常用文字使用原字元。原生貼入的 CR／CRLF 仍正規化為 LF，字面輸入的符號仍為原字。常用文字選單的縮略標籤共用同一組符號。

已提交的輸入編輯取消前一次待選取，查詢發布時只嘗試選取一次，沒有對應列就走一般側欄選取。全字追加的快速反白只隨成功的自動選取觸發。離屏驗證正常加入 C 仍選到 C，結果發布前改為 D 則選 D，接著到 DEF 時不會跳到 F。

離屏用正式控制器驗證混合分隔符與字面符號的貼上、複製、還原／重做、切換焦點、模型回填、多字元快照及常用文字預覽。隔離 Universal 構建及嚴格簽名通過，未啟動可見 App。

### 全代碼續查：原生純文字匯入與 VS15 預覽 — 2026-11-05

- 正式側欄欄位的一般 paste: 經既有轉換，能保留 LF、LS、PS、FF。用同一個替身剪貼簿餵給 AppKit 的 pasteAsPlainText: 與 readSelectionFromPasteboard:type:，兩者都把四種分隔符變成 U+0020。字面的 ¶ 在各路徑都保留。建議讓原生純文字讀取也共用現有標記轉換，避免再建立一條文字修改路徑。未進行實際滑鼠拖放驗收。
- 用 Apple Color Emoji 查詢 `U+2764 U+FE0E` 或 `U+2615 U+FE0E`，側欄列出基底 GID 314／173。TextKit 2 請求其他字體呈現文字樣式後，多字元預覽按現有規則省略外來字體，但 VS15 不在重排的候選控制字元內，結果整個基底也消失。暫存探針只在確認用了外來字體的範圍加入 VS15 重試，兩個基底字形都恢復。Arial 原本能畫的 VS15、既有 VS16 回退、彩色心形、ZWJ emoji、表意文字變體與分段後附標輸出相同。此方案在指定字體沒有文字樣式時會顯示其本來的樣式，待使用者決定。
- 以暫存檔確認 CoreText 能開啟普通字體、有效符號連結和無副檔名的副本。不過本次隔離環境無法從 Launch Services 取得任何樣本的檔案類型，連系統 Arial.ttf 也一樣，因此不能用此結果判定近期項目或檔案拖放在正式環境會漏掉特定類型。

31 個實作檔的 Clang 靜態分析無診斷。探針用正式控制器與 TextKit 2 離屏執行，放在 `/tmp/ga-source-audit.VQXDzs`。本輪未改正式程式。

### VS15 退回目前字體並釐清貼上入口 — 2026-11-05

使用者確認只修前輪第 2 項。多字元預覽發現外來字體時，VS15 與既有 VS16、ZWJ 一樣可從排版副本移除後重試。原文、側欄和目前字體已能正常排出的序列不受此路徑影響。正式改動與前輪的暫存探針逐位元組相同。離屏比較 Apple Color Emoji 的心形、咖啡及其他七組對照，僅借用外來字體的 VS15 案例恢復基底字形。隔離 Universal 構建與嚴格簽名通過。

更正前輪第 1 項的範圍。離屏檢查正式主選單、輸入欄有選取及無選取時的原生右鍵選單，皆只有一般貼上，主選單快捷鍵為 ⌘V。前輪是探針直接呼叫未公開為產品命令的 AppKit 方法，未重現產品選單問題。輸入程式未改動。

### 全代碼續查：拷貝字體可能取代同名資料夾 — 2026-11-05

「拷貝到字體簿」遇到同名目錄項目時，一律提供「取代」。現行普通取代分支呼叫 NSFileManager replaceItemAtURL，在 macOS 14.8.7 會把整個同名資料夾換成字體檔，移除其內容。以正式拷貝方法在暫存目錄重現，另用只改目的路徑的選單流程探針注入按鈕回覆。同名 `Arial.ttf` 資料夾內有巢狀檔案。「停止」及「保留兩者」保留資料夾，後者另產生 `Arial 2.ttf`。「取代」將整個資料夾換成 Arial。提示出現時目的地是普通檔案、確認前改成同名資料夾，也重現內容被移除。

建議資料夾衝突只提供「保留兩者」及「停止」，並使實際取代操作在原子提交時拒絕覆蓋資料夾。暫存探針確認同卷 rename 能取代普通檔案，遇到同名資料夾則以 EISDIR 失敗並保留內容。未操作使用者或系統字體資料夾。本輪 31 個實作檔的 Clang 靜態分析無診斷，正式程式未改動。

### 保護拷貝字體時的同名資料夾 — 2026-11-05

依使用者確認修正。同名資料夾只顯示「保留兩者」和「停止」。字體取代先在目的磁碟準備一般檔案副本，再原子寫入目的路徑。寫入當下若該路徑是資料夾，會回報原生檔案錯誤並保留內容。

暫存目錄用正式拷貝流程及離屏注入按鈕回覆，確認「停止」保留原資料夾、「保留兩者」另存字體、普通檔案可取代、取代符號連結會保留連結目標。提示顯示後將目的檔案改成資料夾，再按取代會得到 EISDIR 並保留巢狀檔案。離屏確認 Enter 選中預設的「停止」，Esc 在可見提示的行為尚未驗收。隔離 Universal 構建與嚴格簽名通過。

### 全代碼續查：New Peninim MT 的附標開關互相打架 — 2026-11-05

用系統 New Peninim MT、正式「字體排印」選單和離屏 TextKit 2 重現。輸入 `שָׁלוֹם`，預設勾選 Show Hebrew Diacritics。點 Hide Hebrew Diacritics 後兩項都勾選，排版結果不變。再點 Show，兩項都不勾選，且預覽才省略附標 GID 122。

原始 `feat` 表對兩個名稱存的是 AAT 9/0 與 9/1，字體將此組標成非互斥。CoreText 的目錄回傳兩個 selector 0，App 因而把兩個選項綁到同一筆狀態，並重複送出設定。511 個已安裝字體樣式的目錄巡查中，重複 selector 編號的 4 個樣式均為這個字體家族。暫存探針讓同組相同編號只留一個非互斥開關，關閉會送出一次 9/1 並隱藏附標，開啟會恢復字體預設及原有字形。正式程式未改動。31 個實作檔 Clang 靜態分析無診斷。

### 統一 CoreText 回報的 AAT 開關 — 2026-11-05

使用者要求先追查原因再修。Apple 的 AAT 格式以偶數開、相鄰奇數關，非互斥組的名稱表只需列偶數項。New Peninim MT 的非互斥附標組同時列出 0 和 1。暫存副本只切換互斥旗標後，CoreText 由 0、0 改回回報 0、1。換成自訂 type 1000 仍回報 0、0，確認這是非互斥組的處理。切換 morx 預設關閉時，CoreText 的預設標記移到第二列，證實不能按哪列打勾來決定開關名稱。暫存逆序名稱表也確認 CoreText 保留名稱表順序，逆序違反 AAT 規格。

正式程式在共用的非互斥 AAT 選項整理依規格次序保留開項，同一編號只建一個開關。原字體、自訂編號、預設關閉及互斥對照均通過。離屏驗證正式選單開關能隱藏和恢復附標，關閉時只送出一筆設定。511 個本機字體樣式的選項、順序、名稱與勾選狀態前後比較，只有 New Peninim MT 的四個樣式去掉重複項。隔離 Universal 構建和嚴格簽名通過。

### 全代碼續查：組合字省略缺字後無法從預覽定位 — 2026-11-05

以 Arial、正式側欄和離屏 TextKit 2 重現。輸入 `A + U+1AB0 + U+0301 + B` 時，側欄依序有 A、缺字、附標及 B。預覽略過缺字並用目前字體將 A 與附標排成 Á（GID 200）。先選 B，再以原生字形位置呼叫產品命中處理，點 Á 後側欄仍選 B。換成 U+0300，預覽的 À（GID 172）有相同結果。沒有缺字的 A + U+0301 可選中 GID 200。

預覽字形的兩段來源在原文中隔著缺字，主視窗目前在偵測到不連續來源時直接結束。暫存版讓此分支選取第一個可確認的原文字形，兩組案例均選回 A；來源連續的對照仍選原來的列。完整字形反查的連續範圍檢查應保留。正式程式未改動，未操作可見視窗。31 個實作檔的 Clang 靜態分析無診斷。

### 定位含缺字組合字的可確認來源 — 2026-11-05

依使用者確認，只改多字元預覽點選。命中的可見字形在原文對應到不連續的範圍時，優先用可核對的首個原生組件 GID 和來源定位，否則選回第一段可確認來源的基本字形。預覽快照、缺字邊界與排版沿用現行規則。

離屏從原生字形位置驗證 Arial 的 Á／À 均選回原文 A，連續來源的 Á 精確選中 GID 200。驗證點選前後原文、查詢快照及實際字形一致。Times New Roman 阿拉伯文組合字、Helvetica fi 連字及指定多 GID 的定位對照通過。隔離 Universal 構建與嚴格簽名通過。

### 全代碼續查：多字元預覽點到伸出字距的筆畫時選錯列 — 2026-11-05

以 Times New Roman Italic、正式多字元視圖和離屏實際繪製驗證。輸入 `AjV`，`j` 向左伸出的下伸筆畫有可見黑色像素，該點落在 `A` 的排版位置內，產品命中方法回傳 A（GID 36）而非 j（GID 77）。點末尾 `V` 右上角伸出行寬的筆畫，畫面也有黑色像素，但方法無回傳。左對齊及置中的 `fjV` 有同類結果。Arial 的 ABC 在三種對齊下與 Times New Roman 的希伯來文，在字距範圍內的抽樣均選到預期字形。

根因是多字元視圖只在行的排版矩形內用原生字元索引命中，沒有用實際筆畫判斷越界部分。建議點中可明確歸屬的越界筆畫時採用實際繪製字形的來源，空白和重疊不明時沿用原生命中。探針用字形輪廓與離屏像素雙重確認，未操作可見視窗。正式程式未改動，31 個實作檔 Clang 靜態分析無診斷。

### 全代碼續查：全字篩選的損壞參照與換軸時序 — 2026-11-05

使用者決定斜體筆畫命中暫緩。此輪覆核全字篩選與開檔路徑，31 個實作檔 Clang 靜態分析無診斷。

- 可正常開啟的 Arial 暫存副本只將第二筆 `liga` 參照改成越界編號。第一筆仍指向正常查找表 13，足以提供相同輸出。正式篩選卻在讀到壞參照時讓 `liga` 和「無特性」都退回「全部字」，正常 `dlig` 仍可選。暫存驗證在讀取特性時去掉越界參照，`liga` 的 3 個輸出、「無特性」的 2,928 個結果、`dlig` 的 1 個結果均和原始 Arial 相同。
- 用可開啟的可變字體暫存樣本，`vert` 在字重 400 有輸出，1000 時分支無查找。先選 `vert`、調到 1000、再回到 400。如果初次篩選已完成，回到 400 仍是「全部字」。如果查詢尚未完成，第一次到 1000 時畫面也是「全部字」，但控制器仍留著 `vert` 的請求，回到 400 後它會自行套用。用暫停背景佇列控制先後以離屏重現，沒有宣稱一般字體必然會遇到。暫存驗證新座標不再提供標籤時清掉未完成請求，兩種先後均一致回到「全部字」。

正式程式未改動，未操作可見視窗。探針與輸出位於 `/tmp/ga-source-audit.VQXDzs`。

### 修正全字篩選的損壞參照與換軸時序 — 2026-11-05

依使用者確認，OpenType 解析器在查找表讀完後只略過各特性直接指向越界查找表的參照。原始及損壞的 Arial 暫存樣本經正式控制器篩選，9 個特性及「無特性」顯示的字形 ID 逐一相同。原始樣本的修正前後輸出也一致。

換軸後若原篩選不再有效，即使目前顯示「全部字」，也會清除待處理的舊請求。以可變字體樣本離屏測試字重 400 → 1000 → 400。分別在初次查詢完成、查詢尚在佇列且返回前釋放、以及返回後才釋放的時序測試，三者都維持「全部字」，重新選取 vert 則可正常套用。隔離 Universal 構建、嚴格簽名與 git diff 檢查均通過。

### 全代碼續查：cmap 接受超出字體範圍的 GID — 2026-11-05

Arial 有 3,381 個字形。暫存副本將 `U+20B1` 的兩份 Unicode cmap 記錄由 GID 2833 改為 4000，CoreText 仍可開啟，並回傳 4000。輸入 `A₱B` 時正式查詢把它列成正常字形，多字元 TextKit 2 讀回也將 4000 加入命中資料。暫存試修在讀取映射時核對 GID 是否落在字體範圍，這個案例只有 ₱ 變成側欄 GID 0，多字元只剩 A、B 的有效字形。

另一個副本只損壞第一份 € 映射時，試修保住另一份 Unicode 表的 GID 188。兩份 Unicode 映射都損壞但 Mac Roman 仍正常時，側欄可由現有候補取回 188，TextKit 則仍讀回 4000。單獨用既有固定 GID 排版重試 €，讀回 36、188、37。建議解析先篩掉越界的映射，按原順序保留有效候補；原生讀回也檢查 GID 範圍，能核對單一來源及有效候補時再重試。

八組未修改字體的側欄與預覽對照逐位元組一致，包含 Arial、Apple Color Emoji、Noto Sans Mongolian 及 Times New Roman。前輪 GSUB 篩選和三種字重查詢時序回歸通過。31 個實作檔 Clang 靜態分析無診斷。重現和試修在 `/tmp/ga-full-review.KpV5Vs` 離屏進行，正式程式未改動。

### 全代碼續查：Noto Nastaliq Urdu 的全字篩選超出查詢上限 — 2026-11-05

使用者決定暫緩只在刻意損壞的字體重現的 cmap 越界 GID 問題。本輪掃描未修改的本機字體 4,136 次特性查詢，兩筆失敗都是系統 Noto Nastaliq Urdu 的 `rlig`，分別為 Regular 和 Bold。

從未修改的 `/System/Library/Fonts/NotoNastaliq.ttc` 載入兩款字重，用正式全字右鍵選單及控制器離屏確認。選 `init` 正常保留 37 個字形，選 `rlig` 或「無特性」約一秒後回到「全部字」的 1,138 個字形。兩款的 `rlig` 都耗盡 1,100 萬次檢查的額度，其中逾 99% 在逐一核對字形類別。放寬原算法的上限至 4 億仍未完成。

暫存探針將反覆比對的字形集合改成可重用的位元集合，再放寬上限，正式選單流程可完成。Regular、Bold 的 `rlig` 分別為 663、673 個字形，「無特性」分別為 290、280 個字形。兩個冷查約 3.4、6.2 秒，原本額度下仍未完成。僅沿查找參照收集全部宣告輸出會在兩個字重都得到 697 個字形。後續宜減少重複的上下文檢查並保留候選範圍，查詢仍耗盡時可保留原有篩選與格子。另用正式全字追加入口抽樣七款未修改字體共 105 個無編碼字形，多字元預覽讀回均一致。探針位於 `/tmp/ga-real-review.OAFOvc`，正式程式未修改。

### 修正 Noto Nastaliq Urdu 的全字篩選 — 2026-11-05

依使用者確認，在 `codex/fix-rlig-filter` 修正。GSUB 全字篩選把每個位置可接受的字形存成位元集合，單次查詢內重用集合交集和起點相同的直接替換結果。保留既有的動作順序、位置狀態及重入規則。依兩款字重的測量將 GSUB 全字篩選額度加倍，保留快取容量與取消檢查。失敗時保留目前字體實例已套用的結果；若換軸後只剩上一個字重的結果，恢復「全部字」。「無特性」仍須拿到所有特性的完整結果。

以未修改的系統字體離屏走正式選單。Regular、Bold 的 `rlig` 分別顯示 663、673 個字形，首次耗時約 1.10、2.01 秒。「無特性」各顯示 290、280 個字形。四組結果逐 GID 等同高額度對照，另 4,572 項本機篩選的輸出逐項等同改前。以取消與受控失敗檢查重試、勾選與格子同步，並重跑換軸時序、五組 GSUB 重入和單一損壞參照。隔離 Universal 建置與嚴格簽章驗證通過。探針位於 `/tmp/ga-rlig-fix.42CzCH`。

### 今日修正收尾 — 2026-11-05

工作樹位於 `codex/fix-rlig-filter`，今天後半段的修正集中在 20 個尚未提交的源碼檔，基線為 `f789e88`。產品源碼與資源逐檔比對，與 `/tmp/ga-rlig-fix.42CzCH/build/dist/Glyph Atlas.app` 所用的建置輸入一致。該 App 通過 Universal 架構與嚴格簽章驗證。專案根目錄 `dist/` 的 App 和 ZIP 是早先的產物。

以同一份現行源碼重跑輸入分隔符、組字、GID 指定還原／重做、側欄待選、變體選擇符導航、多字元點選、字體連結拷貝及 AAT 開關的離屏探針。結果均符合前面各項修正。源碼未混入暫存探針、調試開關或測試資源。`GLOSSARY.md` 已同步 cmap、分隔符、側欄操作、VS15、多字元定位與直排引號的現行描述。斜體筆畫越界命中與刻意損壞樣本的 cmap 越界 GID 依決定暫緩。最新版可見視窗驗收仍待進行。

### Option 選單追蹤問題評估 — 2026-11-05

使用者回報「開啟字體」在指標不動時按 Option 已換名，但新增的資料夾子選單等到滑鼠移動才展開。「常用文字」與「顏色」則在已展開的子選單上按 Option 時卡住。源碼確認第一組已保留原列，仍在追蹤時掛上新的子選單。其餘兩組使用 NSMenuItem alternate 替代母項，各自持有獨立子選單，常用文字也有重建列的路徑。

查閱 Apple 的 NSMenuItem alternates、NSMenu submenuAction、NSMenuDelegate menuNeedsUpdate／menuWillOpen。AppKit 文件提供一般替代命令及展開前更新的機制，沒有找到要求既有反白項在靜止指標下重新展開新掛子選單的公開契約。另列原生「開啟字體於」可避免追蹤中更換結構。macOS 14.8.7 離屏確認固定子選單可與真正的 Command-O 共存，且沒有增加 Option-Command-O。用同一母項、子選單及已存文字列重複切換 20 次，確認改名可保住物件及資料身份。視窗內的靜止指標及追蹤尚待實機驗證。

常用文字與配色若保留即時切換，建議保留母項、子選單與共用資料列，更新標題和同筆資料的動作。僅屬單一模式的列在安全時機重建，避免在指標下換成另一筆可刪除資料。不帶子選單的普通命令保留原生 alternate。此輪為診斷與方案評估。

### 常用文字與顏色的 Option 子選單試用版 — 2026-11-05

依使用者確認建立 `codex/stable-option-menus`。隨後依指示撤回「開啟字體於」的獨立固定列試驗：「開啟字體」維持原列、原快捷鍵及按 Option 切換資料夾子選單的方式。只修改主選單的常用文字與顏色。子選單展開時保留母項、子選單和已儲存資料列，切換同筆資料的套用／刪除動作。只屬於一種模式的命令在切換後先停用，重開子選單時才按目前模式排列。側欄右鍵和一般原生替代命令照舊。

以實際 AppKit 選單物件離屏驗證兩組各 20 次 Option 切換，資料列物件、順序與資料不變；套用仍作用於原視窗，刪除只移除選中資料。另確認重開、空清單、沒有字體時的狀態，以及「檔案」選單只有原來的一列、⌘O／隱藏 ⌘N 及三個資料夾目標均照舊。Universal 試用版與嚴格簽章驗證通過，產物為 `/tmp/ga-saved-option.LVHYNZ/dist/Glyph Atlas.app`。滑鼠停在已展開子選單上切換 Option 的畫面仍待使用者實測。

使用者實測確認子選單切換 Option 已不再卡住，但即時顯示的內容和原版不同。源碼確認目前只切換共用資料列的動作，將原模式專屬的命令停用，等重開才顯示新模式的專屬命令及空狀態。下一輪可保留母項、子選單與資料列物件，試以顯示／隱藏專屬列還原兩種模式，並驗證位置變動不會讓停在原地的指標誤刪其他資料。

### 還原 Option 切換時的選單內容 — 2026-11-05

使用者同意繼續修改。保留兩個主選單的同一個母項、子選單與已儲存資料列。按下及放開 Option 時更新專屬命令、分隔線和空清單提示的顯示狀態，使兩種模式的可見內容與原有排列一致。指標停在原地時，切換前反白的同一筆仍可刪除，因重排換到指標下的其他資料或清除命令則不執行。

離屏 AppKit 探針驗證兩組各 20 次切換、資料列身分和可見列順序。另驗證空清單、已儲存文字不可重複保存、顏色勾選，以及固定指標位置時只允許刪除原項、移動後可選其他刪除命令。試用版在 `/tmp/ga-live-option.PtxwHD/dist/Glyph Atlas.app`。選單展開時的實際畫面與指標行為仍由使用者實測。

### 同步未展開的 Option 子選單與配色勾選欄 — 2026-11-05

使用者實測確認兩個子選單可即時切換，另回報游標留在配色子選單時仍有勾選欄留白、反白可能錯位，以及從其他選單按住 Option 移入時會先看到舊內容。先前母項在子選單未展開時會更新模式，但未同步已備好的資料列；若 AppKit 重用子選單而未再呼叫更新，後續輪詢也會因模式已相同而跳過。現改為同步已備好的子選單，開啟子選單的更新也直接讀取當下修飾鍵。配色刪除模式明確關閉 AppKit 勾選欄，列變動後通知 AppKit 更新仍可見的反白項目。

離屏探針以固定的修飾鍵及指標狀態模擬跨母選單、重用已備好的子選單、無母選單輪詢時更新，以及展開後來回切換。兩個子選單的內容、配色勾選欄和刪除保護通過。Universal 試用版與嚴格簽章驗證通過，產物在 `/tmp/ga-menu-refresh.PSG2VO/dist/Glyph Atlas.app`。畫面的反白寬度與實際跨選單移入仍待使用者確認。

### 調整刪除配色的列順序 — 2026-11-05

依使用者指示，「清除所有已儲存的配色」移到刪除模式首列，和一般模式的「跟隨系統」占同一個列位。兩種模式都從第二列開始以同一順序列出已儲存配色。分隔線只在一般模式顯示，無配色時刪除模式仍顯示停用提示。試用版在 `/tmp/ga-palette-order.c52baC/dist/Glyph Atlas.app`。

### 保留配色子選單的首列以改善反白 — 2026-11-05

使用者提供實際畫面並確認，按下 Option 時反白沒有對準，放開時反白會移位。首列原先雖占同一位置，仍以顯示／隱藏兩個不同項目切換。此次保留同一首列，直接切換跟隨系統與清除全部的標題和動作。一般模式專屬的尾端列從底部收起，並依原序展開。游標未移動時，首列即使是同一物件，也不會把對原命令的點選當成清除全部。

離屏驗證按下與放開 Option 後首列及配色列物件相同、內容順序正確、首列清除全部防誤觸。原生反白實際位置仍待實機確認。試用版在 `/tmp/ga-palette-highlight.kjbcn9/dist/Glyph Atlas.app`。

### 將固定選單列的做法同步到開啟字體與常用文字 — 2026-11-05

使用者實機確認配色反白正常，指定將做法同步到「開啟字體」與「常用文字」。常用文字有可儲存的輸入及既有項目時，儲存和清除共用首列，已存文字不移位。沒有儲存命令時，清除移到尾端，避免既有文字列移位。沿用清除全部的防誤觸。開啟字體仍使用同一列切換開啟命令或原生資料夾子選單，改用共用的即時 Option 輪詢，完成切換後刷新反白中的開啟項目。

離屏驗證跨母選單輪詢、⌘O／⌘N、三個資料夾目標、常用文字首列和清除尾列，以及配色和右鍵常用文字的既有流程。試用版在 `/tmp/ga-option-sync.aBtWnn/dist/Glyph Atlas.app`。開啟字體的原生子選單展開及兩個選單的反白仍待實機確認。

### 固定常用文字的切換寬度並調整配色命令位置 — 2026-11-05

使用者實測「開啟字體」的額外刷新沒有實質變化，回復同步前的同列切換與輪詢。截圖顯示「刪除常用文字」因長命令而變寬，但反白仍是原來的寬度。主選單的常用文字在展開前以 AppKit 量出兩種模式命令需要的最小寬度。離屏測量短文字及長文字、有或沒有可儲存的輸入四種情況，按放 Option 前後寬度都相同。依使用者指示，將「儲存目前配色」移到已儲存配色後、分隔線前。離屏確認配色命令順序與原有選單操作，Universal 試用版在 `/tmp/ga-saved-text-width.4lRGg1/dist/Glyph Atlas.app`。實際反白畫面仍待使用者確認。

### 撤回常用文字的預留寬度 — 2026-11-05

依使用者指示，撤回在展開前預留兩種模式寬度的修改。常用文字恢復依可見內容自動取寬，配色儲存命令仍在分隔線上方。此次未建置或測試。若繼續處理原生反白，可先評估把目前的項目刷新延到選單追蹤的下一輪，讓寬度更新和反白重畫分開。AppKit 的反白項目是唯讀，這個做法須以上屏結果判定。

使用者指出配色切換時寬度也不同，實測反白仍正常，因此寬度變化本身不足以解釋問題。截圖中的常用文字走的是一般模式沒有儲存命令的分支，進入刪除模式時才在末尾顯示分隔線和清除命令。若再試，優先縮小這個分支在追蹤中的列變動，例如只顯示清除命令而不另插分隔線。尚未變更該排列或驗證假設。

### 修正常用文字原生反白並合併 Option 選單實作 — 2026-11-05

依使用者要求在 `codex/simplify-option-menu-tracking` 整理。常用文字與配色由同一選單類別管理資料列、套用／刪除模式及防誤刪。重建時直接按當下模式建立新列，保留現有子選單時才原地更新。檔案、編輯與顯示方式共用一個輪詢，檔案選單關閉後恢復 `⌘O`。移除常用文字已停用的自動驗證分支。

在 macOS 14.8.7 以正式子選單、繁中和單筆 `1234` 擷取實際反白。舊版按 ⌥ 後選單寬 161 pt，藍色只畫 49 pt。只固定命令列、延後刷新或重新要求 AppKit 更新仍可重現。單獨隱藏分隔線會讓列文字和反白的高度錯開。最終有已存文字時，儲存與清除共用首列，分隔線和資料列留在原位。不能儲存時首列停用。展開前由 AppKit 量度兩個本地化命令的最小寬度，已存長文字照常撐寬。刪除模式切換原生勾選欄，避免選單已有足夠寬度時長命令仍被截斷。

同一個隔離原生子選單模擬按放 ⌥，停在 `1234` 時新版反白寬 151 pt，完整命令未截斷。另核對先開刪除模式、空輸入、可儲存時反白首列、長文字，以及配色按放 ⌥。14 語系離屏驗證幾何、項目身分、空清單、刪除保護、右鍵常用文字、字體資料夾與快捷鍵。主選單跨選單及實體按鍵路徑以離屏檢查，未在正式視窗完整走一次。Universal 試用版及對照截圖位於 `/tmp/ga-option-cleanup.ke4nhc/`。

### 子選單展開才接手 Option 切換 — 2026-11-06

依使用者指示，以 `codex/fix-rlig-filter`（`f789e88`）及該輪暫存源碼確認原生替代項的做法。在 `codex/native-option-until-submenu-opens`，常用文字與配色的子選單未展開時由 AppKit 原生替代項切換。子選單展開後固定打開它的父項，沿用原地更新和防誤刪；關閉即停止輪詢，再還原原生替代項。維持現行子選單順序及常用文字隨內容取寬，反白問題仍依使用者決定暫緩。

另按使用者指示移除「開啟字體」的輪詢，採用 `69458ea` 的原生替代項做法。資料夾依序為目前使用者、所有使用者、系統字體。隱藏命令繼續處理 ⌘O／⌘N，普通開啟列不再顯示 ⌘O 提示。

離屏確認兩種初始模式各切換 20 次時的父項、子選單和資料列身分、列序、計時器啟停、先關母選單及回到原生模式後才執行的既有刪除。確認三個資料夾目的地、⌘O／⌘N 和檔案選單無計時器。實體按鍵及切換畫面待上屏驗收。Universal 試用版位於 `/tmp/ga-native-option.VNoSmM/dist/Glyph Atlas.app`。

### 常駐字體位置與恢復原生 Option 替代項 — 2026-11-06

「開啟字體於」成為檔案選單常駐入口。子選單首項為「最近檔案夾」⌘O，隱藏同項處理 ⌘N，其後維持目前使用者、所有使用者、系統字體的順序。「開啟最近項目」保留於主檔案選單。新增 14 語系的最近檔案夾名稱。

使用者實機看到顯示方式選單出現重複的顏色列。現行混合方案在 AppKit 追蹤母選單時會改動原生替代關係及可見性，切換中能出現兩個普通列。依使用者指定的後備方案，常用文字及配色回到固定的原生替代項，移除展開後的手動切換及輪詢，維持子選單列序。使用者指示和後續改動一起驗收。

### 最近檔案夾的語系標點與選單整理 — 2026-11-06

核對本機 macOS 14.8.7 Finder「前往檔案夾」的原生選單資源。台灣、香港繁中用 U+22EF，德文用 U+0020 加 U+2026，其餘 11 種語系直接接 U+2026。「最近檔案夾」按這個方式更新 14 種語系。常用文字和配色共用刪除單項與清除全部的動作，由選單決定偏好鍵。檢視工作樹的選單、輸入、字形查詢及檔案操作差異，保留既有行為。

離屏確認 ⌘O／⌘N、三個字體資料夾、兩組原生替代項反覆開關時的列序與項目身分，以及刪除、清除、空狀態和兩份清單各自寫入。兩個本輪編輯的實作檔通過 Clang 靜態分析。14 種本地化與差異檢查通過。以專案內的 `./build.sh` 建置 arm64 至 `dist/Glyph Atlas.app`，一般簽章驗證通過；專案卷宗會重新附加 FinderInfo，清除該屬性時嚴格驗證亦通過。未啟動正式 App。

### 移除一般 Tooltip，使用 AppKit 截斷文字展開 — 2026-11-06

移除選單、工具列、變數面板、側欄及全字網格的一般 Tooltip。全字網格一併移除僅用於 Tooltip 的滑鼠及捲動追蹤。Unicode 徽章仍按碼位的文字量寬；舊 Tooltip 的 Unicode 字元名稱已移除。保留變數字體按鈕的輔助使用名稱和配色色票的輔助使用描述，清除 14 種語系中只供一般 Tooltip 使用的文字。

工具列字體名、側欄字形名稱和來源、變數字體軸標籤使用 AppKit 原生展開。離屏以正式控制項確認寬度不足時 AppKit 回傳展開範圍，足夠時回傳空範圍，並確認 App 建立的選單項沒有一般 Tooltip。正式畫面的滑鼠停留尚未驗收。14 種語系檢查和專案內 arm64 建置及一般簽章驗證通過。

### 修正工具列文字命中並清理舊說明 — 2026-11-06

使用者回報工具列的字體名似乎無法展開。原本的命中規則只讓變數字體按鈕通過，現也回傳字體名稱標籤，讓 AppKit 能找到文字控制項。標籤允許 AppKit 原生處理標題列拖曳，空白仍穿透。離屏確認實際工具列中的長字體名稱能被命中並產生展開範圍，變數字體按鈕仍可獨立命中。實際滑鼠停留及雙擊仍待驗收。

檢查所有源碼中的函式、屬性及引用，並執行 Clang 靜態分析。字形名稱查詢的共用包裝只剩側欄使用，併回原呼叫點。Unicode 徽章視圖不再儲存只用於當次重建的碼位陣列。README 的兩種語言和內建 Help 的 14 種語系皆移除 ⌥ 開啟字體資料夾、懸停 Unicode 徽章及懸停全字格子的舊描述。14 種語系的 Help 鍵與程式一致。

### Unicode 徽章的原生展開 — 2026-11-06

依使用者選定的冒號與空格格式，側欄徽章由 AppKit 展開為 `0041: LATIN CAPITAL LETTER A`。徽章沿用原本的碼位繪製與尺寸，以公開展開方法提供範圍和文字。第一次請求展開時才從系統 ICU 讀取名稱，查無名稱時回傳空範圍。

離屏確認實際側欄徽章能被命中，驗證基本多文種平面與補充平面的名稱及格式、未指派碼位不展開，以及繪製展開內容後徽章仍只顯示碼位。專案內 arm64 建置通過。滑鼠停留觸發的實際畫面仍待驗收。

### 徽章展開置中、擴大工具列停留範圍 — 2026-11-06

使用者確認徽章可展開，回報垂直偏移及工具列字體名稱難以展開。徽章按 AppKit 文字儲存格的高度在展開框內置中，框高增加時保留與徽章相同的中心。工具列字體名稱的命中高度由 16 pt 增至 22 pt，文字按原生儲存格高度居中繪製，依可見範圍向 AppKit 要求原生展開。macOS 14 離屏確認兩種工具列樣式下全高度可命中、長名稱可提供展開範圍，短名稱維持原樣。實際滑鼠停留的觸發率仍待使用者驗收。

README 及 14 種語系的 Help 恢復 Unicode 徽章滑鼠停留說明。Help 鍵核對、差異檢查及專案內 arm64 建置通過。

### 以實際原生彈窗核對徽章和工具列展開 — 2026-11-06

使用者回報兩項依然有問題，指定用 ThemeX 驗證。macOS 14.8.7 的獨立視窗實際觸發 AppKit 展開，確認徽章與原生彈窗同高同中心。常態文字原用 10 pt 數字等寬系統字體，展開改用小型系統字體及獨立儲存格，兩種排版使相同碼位基線不同。已改用同一字體與同一 AppKit 文字高度繪製，移除專用儲存格和上一輪的內距補正。

工具列在名稱改變但標籤大小固定時，AppKit 原生展開會沿用舊範圍。由長測試標題換到 ThemeX 柊野黑和金剛黑時，控件量出 118 pt 的展開寬度，實際彈窗仍寬 514 pt。名稱更新時使游標區域失效，正式程式碼重測兩款都實際展開為 118 pt，新黑在當次寬度能完整顯示，維持不展開。撤回無效的 22 pt 命中高度、自繪標題和展開範圍覆寫。專案內 arm64 建置通過。

### 徽章與展開改用相同的 AppKit 文字儲存格繪製 — 2026-11-06

使用者以 00B9 截圖指出共用字號正確，但兩邊都偏離中心，先前的彈窗是置中的。改回先前由 AppKit 儲存格繪製的方式，徽章和展開各自持有文字，使用同一個 10 pt 字體及同一套依儲存格高度計算的置中。刪除上一版的字串繪製與提前取整。原生彈窗實測以 00B9 觸發並分別擷取兩張畫面，兩者都是 13 pt 儲存格高度、16 pt 外框高度。專案內建置通過。

### 用 Auto Layout 置中 Unicode 徽章標籤 — 2026-11-06

依使用者同意，徽章把碼位交給原生 `NSTextField` 標籤繪製，由 Auto Layout 對齊垂直中心。原生展開仍顯示 `碼位: 名稱`，共用 10 pt 字號，彈窗範圍以徽章外框定位。實際觸發 00B9 確認 13 pt 標籤與 16 pt 徽章同中心，展開框也與徽章同高且對齊左緣。專案內 arm64 建置通過。

### Unicode 展開文字試用來源標籤色 — 2026-11-06

使用者希望試用字形來源標籤的顏色。Unicode 彈窗由主要標籤色改為未選取來源標籤使用的 `secondaryLabelColor`，由系統隨外觀調整。

### Unicode 徽章文字試用 80% 不透明度 — 2026-11-06

依試色要求，徽章的原生碼位標籤使用 0.8 的視圖不透明度。彈窗的獨立文字儲存格維持系統次要標籤色，沒有乘上這個係數。

### Unicode 徽章和彈窗依列選取切換 — 2026-11-06

未選取時碼位文字的視圖不透明度改為 75%，選取時恢復 100%。彈窗隨實際列選取改用主要或次要標籤色。由原生列選取更新徽章，失焦但仍選取的列也適用。離屏經正式側欄確認選取、失焦選取與取消選取的兩種樣式。專案內 arm64 建置通過。

### 三輪逐檔整理 — 2026-11-06

以 `codex/unicode-badge-selection-colors` 的現有工作樹為起點，包含未提交的改動。依序建立 `codex/nov06-cleanup-round-1`、`codex/nov06-cleanup-round-2`、`codex/nov06-cleanup-round-3`，工作樹累積三輪改動。基線、每輪源碼快照、差異與離屏探針存於 `/tmp/ga-nov06-cleanup.Vr5pvT`。

**第一輪｜無效代碼與省缺值**

- `GAGlyphBuffer.h` 刪除沒有呼叫者的 `visible`。原有的 GDEF 過濾與 lookup 接受規則繼續由現用入口處理。
- `GAFontEngine.h/.m` 把當時只有檔內呼叫的 `GAGroupsForText` 收回實作檔。第二輪把這個暫時群組入口併入範圍枚舉。
- `GASubstitutionEngine.mm` 讓 morx 使用 AAT 建構式的 extended 預設值。OS/2 和 head 在此只讀原始表資料，直接取得 bytes；會解析內容的讀取仍各自隔離 `InvalidTable`。
- `GATextPreparation.mm` 刪除 UTF-16 暫存陣列第二欄的顯式零值。第二輪由 Core Foundation 直接填入實際使用的碼元。
- `GADetailViewController.m` 用 `init` 建立沒有顏色覆蓋的預覽狀態，省去逐角色檢查空 representation。

**第二輪｜共用與整理邏輯**

- `GAFontEngine.m` 直接枚舉原文字素簇範圍補齊缺少的來源，並以排序後的來源範圍定位候選，省去兩批只用來取範圍的暫時群組。候選目標仍是最後一個相交來源，側欄實際群組由原有入口建立。
- `GAFontEngine.h/.m` 將字面 GID 查詢改為 `variantsForGlyphIDs:cancelled:`，直接回傳同一有序候選陣列，省去單元素外層陣列與空文字群組。`GATextQueryModel.m` 的明確選擇與 `GAMainWindowController.m` 的無編碼字形追加都使用這個介面。
- `GAFontEngine.m`、`GAUnicode.m`、`GATextPreparation.mm` 以 Core Foundation 的代理對轉換取代各自的位元運算。原有的碼位有效性和文字來源邊界照常檢查。
- `GACmap.cpp` 合併 format 6／10 取連續 GID 的範圍檢查，保留兩種表頭各自的欄位寬度與位移。
- `GAGlyphBuffer.h/.cpp`、`GASubstitutionBuffer.cpp`、`GAAAT.cpp` 共用「GID 和來源範圍相同」的比較。GSUB 候選等價仍比對其餘排版資料，AAT 先取得一次 inventory 狀態並沿用同一值。
- `GAAppDelegate.m` 讓建立刪除替代項和選單更新共用同一個常用文字／配色分派。視圖和對齊列按標題陣列數量建立，主 View 選單辨識只做一次，原本與通用回傳一致的四個選單驗證動作走共同回傳。
- `GAGlyphViews.m` 讓字形名稱與來源標籤共用單行、截斷、原生展開和 Auto Layout 設定。兩個標籤各自保留字體與顏色。

**第三輪｜檔案結構**

- 將 `GAInputSupport.{h,m}` 和 `GASidebarInput.{h,m}` 合併為 `GAInput.{h,m}`。原生輸入選單的兩個函式及其選項只在實作檔可見。將僅供側欄 cell 繼承的一層焦點通知併入該 cell，維持原生編輯呼叫、焦點通知和還原暫停狀態的先後。`GAAppDelegate.m`、`GAMainWindowController.m`、`GASidebarViewController.m`、`GAVariationViewController.m` 改用合併後的標頭。
- 將 `GARelatedSubstitutions.cpp` 和 `GAFeatureOutputs.cpp` 合併為 `GAGlyphCatalogue.cpp`。單 GID 的候選目錄與當前分支的特性輸出各自保留原有搜尋、限額及錯誤邊界。沿用現行構建腳本的來源收集。

三輪各自的 Universal App 均通過嚴格簽章。在 macOS 14.8.7 離屏比對，8 款字體的 62 組候選、度量、預覽文字與來源，以及 4,576 項篩選結果均逐位元組相同。25 項輸入與還原檢查、105 次無編碼字形追加、原生選單與 Unicode 徽章的離屏輸出一致。可見視窗與其他 macOS 版本仍待驗收。整理期間工作樹的 14 個語系另有 Help.01 更新，第三輪 App 採用工作樹上的新版資源。

**已重現，依使用者決定暫緩。** 以實際拷貝方法在暫存目錄確認，來源檔名若已變成同名資料夾，新增目的檔的路徑會把資料夾和內容一起複製。此輪維持原有行為。

### 拷貝字體時追蹤視窗開啟的原檔 — 2026-11-06

使用者指出移走檔案後，最近項目仍可找到它，並確認修正拷貝流程。用 Arial 在同一磁碟驗證，`NSURL` 檔案參照能追蹤搬移或改名，原檔刪除後解析失效。原檔刪除且舊路徑放入另一份 Arial 時，書籤探針可回到新檔，故視窗的拷貝來源使用本次開啟的原生檔案參照。

在 `codex/track-open-font-source`，開啟時取得符號連結目標的參照，載入成功後交給視窗，換軸沿用。新增、保留兩者和取代使用同一套暫存複製，寫入前重新核對來源與副本。以新的路徑 URL 查檔案身分，避免沿用拷貝前的快取。新增與保留兩者用排他改名，取代沿用 `rename`。目的檔名沿用開啟時的名稱。原檔失效直接顯示系統錯誤。

在暫存目錄以正式視窗開啟 Arial，離屏驗證搬移、舊路徑被資料夾或一般檔案佔用、符號連結改指、原檔刪除、暫存中途換掉來源、目的名稱競爭，以及原有取代與目的資料夾保護。主程式重建至 `dist/Glyph Atlas.app`。

### 整理與拷貝修正提交至 GitHub — 2026-11-06

依使用者要求，在 `codex/track-open-font-source` 建立本地提交 `b1e5d35`，包含累積的源碼整理、字體拷貝修正、選單與字形預覽改動、14 語系資源及根目錄 README。GitHub `main` 由 `f789e88` 快轉至 `b1e5d35`，本地工作樹乾淨。

### 同步開啟字體說明 — 2026-11-06

依使用者修改的繁中 README，同步英文 README 與 14 語系內建 Help 的開啟字體段落。補上從字體安裝資料夾開啟、拖到 App 圖示或已有字體的視窗，以及設為字體檔案的預設開啟 App。Help 引用各語系實際使用的選單名稱。核對 14 語系的說明鍵和資源格式。

### Unicode 彈窗只顯示字元名稱 — 2026-11-06

移除彈窗文字前的碼位與冒號。徽章顯示碼位，滑鼠停留展開時顯示 Unicode 字元名稱。

### 依 macOS 資源核對全部本地化 — 2026-11-06

核對 14 語系的選單、Help、輔助使用格式、Finder 文件類型及字體數量複數規則。macOS 14.8.7 AppKit 的 `MenuCommands.loctable` 和「預覽程式」的 `MainMenu.loctable` 都把簡中 App「文件」選單的 Open Recent 寫作「打开最近使用」。Apple 指南的說明頁題為「在 Mac 上打开最近使用的项目」，蘋果選單則為「最近使用的项目」。14 語系的 Open Recent 都和 AppKit 一致。

「最近檔案夾」取 Finder `MenuBar.strings` 的 262.title，並沿用 261.title 的語系標點。三個字體位置命令改由資源提供省略號。對照 AppKit、Finder 和字體簿，更新全螢幕、對齊、字體排印、還原預設值、字形與字體位置用詞。中文 Help 只調整詞語和選單名稱。補齊配色的兩個輔助使用格式。

14 語系各 126 個字串鍵、15 段 Help 及獨立的字體數量規則通過檢查。專案內 arm64 建置與一般簽章驗證通過，並用 Foundation 離屏讀取打包後每個語系的全部字串，檢查 0、1、2、5、21 的數量格式及俄文詞尾。

### 開啟字體子選單改用簡稱 — 2026-11-06

依使用者提出的簡稱，三個中文語系的「開啟字體於」子選單首項改為「最近使用」，沿用前次確認的各地省略號。主檔案選單的 Open Recent 仍是另一個命令，列出最近開啟的字體檔案。

其餘 11 個語系也採用 Finder 的 Recents 簡稱（`Localizable.strings` 的 NE91），沿用各自的省略號。

### 三輪程式整理及舊功能覆核 — 2026-11-06

以 `b1e5d35` 為基準。共用目錄切到本地化審查分支後，將整理差異移到獨立工作樹。三輪依序使用 `codex/streamline-unused`、`codex/streamline-logic`、`codex/streamline-sources`，舊功能的追加整理使用 `codex/streamline-former-feature-paths`。每個階段的差異以基準為起點存於 `diagnostics/streamline-2026-11-06/`。整理工作樹在 `/private/tmp/ga-streamline.ZyGIOt/work`，改動仍為未提交差異。

**第一輪｜無效介面與宣告**

- `GASidebarViewController.h/.m` 把舊的公開 `setGroups:` 收窄為 `clearGroups`。`GAMainWindowController.m` 的兩個呼叫點只傳空陣列，改為直接清空。側欄發佈新快照繼續使用原來的 `updateGroups:sourceText:fontDocument:`。
- `GAFontFeatures.h` 收回只有模型使用的群組識別碼公開宣告，保留私有屬性。
- `GAAAT.h/.cpp` 拿掉所有呼叫端都省略的值寬參數。固定 16 位元的格式直接讀 `u16`，format 10 繼續按表內宣告讀取。 `GABinary.h` 移除 `View::contains` 從未使用的預設長度。
- `GAAllGlyphsView.m` 移除兩個可由編譯器合成的屬性宣告。

**第二輪｜重複邏輯**

- `GASidebarViewController.h/.m` 與 `GAMainWindowController.m` 讓一般啟用與僅按 Shift 的啟用共用同一回呼，傳入插入旗標。兩種動作仍使用同一套原文範圍與待查詢規則。
- `GAInput.m` 讓一般複製與原生選取輸出共用選區到模型純文字的轉換，各自維持原生剪貼簿流程。
- `GATextQueryModel.m` 共用初次查詢與換軸時的來源分組和候選投影，維持原有發布及取消條件。
- `GAOpenType.cpp` 一次掃描 LangSys，優先精確匹配並記住首個預設語言；選取順序等同原本的兩輪查找。
- `GAAppDelegate.m` 共用四個多字縮放／行距命令的可用條件，綁定常用文字／配色時只辨識一次母選單。`GAFontFeatures.m` 與 `GAPreviewColors.m` 分別重用同一份選項字典與已查到的顏色。

**第三輪｜檔案結構**

- `GAFontResource.h/.m` 集中檔案種類檢查、原檔參照解析、暫存副本與原子改名。 `GAAppDelegate.m` 管理選單、同名提示、保留兩者命名和原生錯誤顯示。暫存目錄前後比對涵蓋搬移、連結改指、原檔刪除、來源在暫存中被取代及目的名稱競爭。
- `GASubstitutionBuffer.cpp` 的寫時複製實作移入 `GASubstitution.cpp`，保留供 OpenType 共用比對引用的 `GASubstitutionBuffer.h`。Sources 檔案數由 57 減至 56。驗證原有增量構建流程會移除已刪實作檔的舊物件。

**舊 Tooltip 與資料視圖**

比對資料視圖移除前的快照、Tooltip 移除的 Git 差異和現行 Sources／14 語系。舊資料視圖類別、⌘I、解析摘要、Tooltip 追蹤和登記在正式源碼中皆無呼叫或定義。`Outline` 現用於中空字選單。工具列、字形列和變數軸的 AppKit 文字展開仍有入口，Unicode 名稱仍供側欄徽章展開。

- `GAAllGlyphsView.m` 的滑鼠事件只在雙擊且有接收端時做格子命中，原有視窗拖曳和雙擊命令照常。
- `GAGlyphViews.m` 讓徽章由列在掛入前一次設定選中狀態及背景樣式，去掉兩筆隨即覆寫的初始化。
- `GAFontEngine.m` 的字形名稱及碼位整理直接讀取文件內同一份 Unicode 映射，三個呼叫端省去重複傳入，字形名稱統一在選定實名或 GID 名稱後加入結果。
- `GAFontFeatures.m` 用實際設定需要的 AAT type 及 OpenType tag 取代對整份 CoreText 定義字典的持有，原生名稱、選項及預設仍採同一來源。

各階段 Universal 構建與嚴格簽章通過。macOS 14.8.7 離屏比對 8 款字體的 62 組查詢和 4,576 項篩選，結果逐位元組一致。原生選單、全字點選、120 次排印選擇、輸入與還原、Unicode 徽章和 105 次無編碼字形追加也與基準一致。整理與 0 pt 修正使用獨立工作樹，兩份改動均待可見視窗驗收。

### 多字元預覽的缺字間隔為 0 pt — 2026-11-06

依使用者選擇，獨立於程式整理在 `codex/zero-width-preview-omissions` 修正 `GAMultiGlyphView.m`。AppKit 的附件 bounds 為零時取圖像大小，原來的 1×1 pt 空白圖像使附件步進為 1 pt。現在使用零尺寸圖像，保留原有 TextKit 附件作為排版邊界。獨立工作樹在 `/private/tmp/ga-streamline.ZyGIOt/zero-width`。

離屏驗證 Arial 51 pt 的橫排和直排每段由 1 pt 變成 0 pt，兩段缺字的累積位移也消失，點 B 仍選到原文位置。Helvetica 的普通 fi 保持連字，f龘i 維持兩個 GID。Apple Color Emoji 的外來字體省略路徑同樣讀到 0 pt。Universal 構建及嚴格簽章通過。

### 新增阿拉伯語、印地語和馬來語 — 2026-11-06

加入 `ar`、`hi`、`ms` 三份本地化及 Info.plist 登記。每份有 126 個介面字串（含 15 段 Help）、Finder 文件類型、關於面板版權與字體數量複數格式。標準選單、位置和字形相關術語對照本機 AppKit、Finder、預覽程式和字體簿。阿拉伯語 Help 的組合鍵及動態檔名使用 Unicode 方向隔離。

17 語系的鍵、Help、格式參數和原生選單名稱通過資源檢查。專案內 arm64 建置及一般簽章驗證通過。Foundation 離屏確認打包後每個語系的資源讀取、`ar-SA`／`hi-IN`／`ms-MY` 的語系匹配、阿拉伯語六種數量形式與快捷鍵隔離字元。

### 合併整理與缺字間隔修正並推送 GitHub — 2026-11-06

依使用者要求，將三輪整理、舊功能覆核及多字元 0 pt 缺字間隔修正合成一筆提交 `b723616`。本地分支為 `codex/integrate-cleanup-and-zero-width`。原工作目錄的本地化修改仍在其獨立分支。GitHub `main` 由 `b1e5d35` 快轉至 `b723616`。

合併版通過 Universal 構建、嚴格簽章與六組離屏基準對照。0 pt 的橫直排、連字及原文點選輸出逐項等於獨立修正版。合併版 App 位於 `/private/tmp/ga-streamline.ZyGIOt/work/dist/Glyph Atlas.app`。可見視窗待實機驗收。

### 本地化補併與 UI 幾何覆核 — 2026-11-06

上一筆 GitHub 提交 `b723616` 已包含三輪整理及 0 pt 修正。另一對話的本地化及 README 改動當時還在 `codex/arabic-hindi-malay-localizations` 工作樹。將該快照的資源、README 與字體位置選單字串接到 `b723616` 上，在 `codex/integrate-localizations` 提交為 `b8a1529`，GitHub `main` 已快轉。原本地化工作樹的改動保留。整合版 Universal 構建與嚴格簽章通過，17 語系的 126 個介面鍵、255 段 Help、打包後資源載入及複數格式通過對照。

macOS 14.8.7 離屏覆核兩個 UI 幾何問題。全字網格以格子列的位置決定要畫哪些列，未計入越出格子的墨跡。用 Helvetica GID 99 放在第 2 列，該列始於 y=70 pt。視口底部從 y=71 pt 移至 y=69 pt 時，同一段仍在可見範圍的 y=67–69 pt 帶狀區域，4 倍取樣的深色像素由 131 變成 0。另以 Times New Roman Italic 的 `AjV` 重跑前次暫緩的點選問題。點 j 伸進 A 字距的筆畫仍選到 A，點 V 越過行末的筆畫仍無選取。兩個問題均只覆核，修正未納入本地化提交。

### 新增上海言话（简体） — 2026-11-06

加入 `wuu-Hans` 語系，涵蓋 126 個介面字串（含 15 段 Help）、Finder 文件類型、關於面板版權及字體數量格式。採上海市區話句式，參照錢乃榮的《上海話正字》和〈上海話裡的「個」〉使用「个、勿、搿、辣、里向、侪」等用字。保留必要的排版術語及原有組合鍵。

專案內 arm64 建置及一般簽章驗證通過。離屏確認 `wuu-Hans` 及 `wuu` 的語言偏好都選中上海話資源，`zh-CN` 選中簡體中文資源。核對資源鍵、Help 菜單名稱、快捷鍵及格式參數。本機 macOS 14.8.7 的 Foundation 把 `wuu-Hans` 顯示為「上海话（简体）」。系統設定的實際清單由 macOS 提供。

### 新增廣州白話和香港廣東話 — 2026-11-06

加入「简体粤语 - 简体粤语」`yue-Hans` 和「繁體廣東話 - 繁体粤语」`yue-Hant`。兩份各有 126 個介面字串（含 15 段 Help）、Finder 文件類型、關於面板版權和字體數量格式。共同採用「喺、嘅、冇、畀」等粵語用字，按地區分別採用「按住／窗口／文件夹」和「撳住／視窗／資料夾」等用詞。標準命令參照本機簡體及香港中文介面。App 共有 20 語系。

本機 macOS 14.8.7 的 Foundation 回傳與使用者指定相同的語系名稱。資源鍵、Help 內選單名稱、快捷鍵及格式參數核對通過。專案內 arm64 建置及一般簽章驗證通過。離屏確認 `yue-Hans`／`yue-CN` 讀取廣州版，`yue-Hant`／`yue-HK`／`yue` 讀取香港版，並確認現有中文和上海話的資源仍可分別載入。

### 新增藏語、維吾爾語、拉丁語、世界語和高棉語 — 2026-11-06

加入 `bo`、`ug`、`la`、`eo`、`km`。每份有 126 個介面字串（含 15 段 Help）、Finder 文件類型、關於面板版權和字體數量格式。藏語用藏文，維吾爾語用阿拉伯字母，拉丁語採現代拉丁語的軟件術語。維吾爾語在 Help 的快捷鍵和含變數檔名的提示中加入方向隔離。五份為本輪校訂的譯文，尚未經獨立語言審校。

App 內 25 份資源的鍵和 Help 對齊。專案內 arm64 建置及一般簽章驗證通過。Foundation 離屏確認五份新語系的標準代碼與地區變體都讀到對應字串及字體數量格式，並核對維吾爾語快捷鍵的方向隔離。

`ii`（涼山彝語）和 `ain`（阿伊努語）已確認可由 Foundation 識別。雙語詞典、研究用翻譯模型及阿伊努語軟件用例能支持個別術語，整套介面及 Help 仍需譯文和語言審校。這兩份尚未登記為支援語系。

### v1.6 正式版標籤及下一版起點 — 2026-11-06

依使用者要求，將上海話、兩份粵語、藏語、維吾爾語、拉丁語、世界語和高棉語，以及語系登記和 README 同步，提交為 `4f6090a`。25 份語系各 126 個介面鍵和 15 段 Help，資源語法、字串鍵及格式參數檢查通過。GitHub `main` 由 `b8a1529` 快轉到 `4f6090a`，同次推送新增正式版標籤 `v1.6`，兩個引用指向同一筆提交。此提交的 App 顯示版本為 1.6。後續版本從 v1.7 開始計算。

### 簡體中文的字體開啟選單 — 2026-11-06

依使用者指定，把簡中 `Open Font From` 的「从以下位置打开字体」縮成「打开字体于」。舊版「打开字体」與資料夾子選單一度是兩個命令，後者成為常駐入口後留下較長的名稱。對照 25 語系的介面、Help 及可取得的舊版譯文，德、日、韓也擴寫了原本的開啟命令；印地語、廣州白話、上海話、藏語和維吾爾語的首版則使用較長描述。另記錄香港中文的「還原至預設值」及三份中文的「系統字體／系统字体」與之前選定的用詞不同。

25 語系的資源鍵、Help 選單名稱及格式參數通過檢查。專案內 arm64 建置通過。

### 統一字體開啟選單的來源名稱 — 2026-11-06

依使用者要求，對照 25 語系的既有用詞，縮短其中八份「開啟字體於」的譯名並同步 Help 引用。四個子項只寫來源，末項改為「系統內建／系统内置」及各語系對應簡稱。上海話的使用者來源縮成「自家」和「大家」。25 份資源的鍵、四個子項的省略號和八處 Help 引用通過檢查，專案內建置的資源與原檔一致。

### v1.6 正式版打包與文件定稿 — 2026-11-06

`build.sh -z` 直接打包 `Glyph Atlas.app`，移除隨附的清屬性腳本及其產生和組裝程式。兩份 README 更新 ZIP 開啟說明，英文版同步中文的觸控板撐捏限制。依使用者要求一併提交 25 份最新選單譯文。Universal ZIP 解壓後通過嚴格簽章，根目錄只有 App，包內 25 份翻譯逐一等同提交版本。

舊本地分支改名為 `codex/release-1.6-initial`（`69458ea`），正式版分支為 `codex/release-1.6`。GitHub `main` 快轉至 `2d29156`，並在同一次推送建立當時遠端缺少的 `v1.6` 標籤，指向同一提交。下一版仍從 v1.7 起算。

### 統一開檔、視圖與字體樣式提示用詞 — 2026-11-06

在 `codex/localized-menu-wording` 同步 25 套語系、內建 Help 及中英文 README。標準命令比對本機 Font Book、TextEdit、AppKit 與 Finder 的在地化資源。英文檔案選單採 Open At、Recent Location…、Close。視圖使用 Characters、Glyph Grid、Bounding Box 與 Vertical Layout。中文視圖採字形表、邊界框，既有開啟位置與直／豎排用詞照舊。篩選子選單仍用 All Glyphs（所有字形）表示清除篩選。TTC／OTC 的選擇提示數可選樣式，使用各語系原有的數字與複數規則。

隔離 arm64 建置與嚴格簽章通過。25 語系各 126 鍵及 15 段 Help，核對選單引用、快捷鍵與包內資源，Foundation 各以 7 個數字格式化樣式提示。系統的 `ADTNumeric.ttc` 檔頭有一個字體資源，CoreText 的描述符經 Glyph Atlas 歸併後只剩一個可選樣式，因此直接開啟。術語核對未包含母語者獨立審校。

### 補齊具名實例、行距與預覽大小的用詞 — 2026-11-07

依使用者補充，在 `codex/localized-preview-terms` 延續上一輪未提交的修改。Named Instance 的三份中文及三份漢語方言資源改為「具名實例／具名实例」。英文採 Increase／Decrease Leading、No Typographic Features、Expand／Shrink Bounding Box、Make Text Bigger／Smaller。可取得系統譯名的文字大小命令直接對照本機 Safari，簡體中文按指定採「放大／縮小文字」，粵語保留「縮細」。25 語系的 Help 第 12 段及中英文 README 同步文字大小及 leading 用詞。

使用者先要求移除不會顯示的單數提示，隨後決定完整保留各語系的數量詞形。所有 stringsdict 已還原為本輪開始前的內容，包含英文單數、俄語 21 使用的 one，以及阿拉伯文的數量分支。

25 語系各 126 鍵與 15 段 Help、快捷鍵、內建字串載入及包內文字核對通過。以本輪開始前的資源對照，175 組數量提示的格式化輸出完全相同。英文 Help 逐條對應 README。隔離 arm64 建置與嚴格簽章通過。術語譯文尚未經母語者獨立審校。

續按使用者澄清，逐項覆核全部 25 套語系的 8 個對應標籤。補正印地語與阿拉伯語的形容詞措辭、高棉語的排印特性語句、世界語及拉丁語的具名實例，以及各語系 Help 與介面之間的行距用詞。標準 Typography 名稱對照 AppKit 原生字體面板；日、韓、德等行距標籤沿用當地 macOS 的慣用表達。

### 保留篩選的全部字並簡化還原命令 — 2026-11-07

依使用者補充，在 `codex/localized-restore-command` 將六份中文／漢語方言的篩選子選單項目統一為「全部字」，視圖名稱仍為「字形表」。英文還原命令改為 Restore Default，25 份語系資源同步鍵名；中文及廣東話去掉「至」，Help 第 15 段和英文 README 同步命令引用。其他語系的還原譯名對照 Finder 的本機對應用詞。

25 語系各 126 鍵與 Help 引用核對通過，精確比較本輪只修改上述項目。英文 README 的 15 條使用說明與內建 Help 相同。

### 新語系可行性驗證與前輪用詞定稿 — 2026-11-07

使用者確認前輪用詞定稿，要求驗證上海話繁體、長沙話／湘語簡繁與潮州話簡繁的支援能力。以本機 macOS 14.8.7 Foundation 測試，原 App 維持 25 套資源。

暫存合成 bundle 同時登記現有 25 語系及 wuu-Hant、hsn-Hans、hsn-Hant、nan-Hans、nan-Hant，每份只放可識別的標記。14 種語言偏好／地區變體分別使用全新程序測試，NSBundle 均選中正確簡繁資源並讀回標記。NSLocale 的繁中顯示名分別是「上海話（繁體）」「湘語（簡體／繁體）」「閩南語（簡體／繁體）」。

IANA 2026-09-17 登記資料中 wuu 為 Wu Chinese、hsn 為 Xiang Chinese、nan 為 Min Nan Chinese；本輪未查到以 Changsha 或 Teochew 命名的獨立標籤。使用 hsn 能承載長沙話譯文，但系統名為湘語；使用 nan 能載入簡繁資源，系統名為閩南語。teochew 及自訂私用標籤未取得可用的系統顯示名稱。資料源為 https://www.iana.org/assignments/language-subtag-registry/language-subtag-registry 。

這輪僅做語系識別及資源匹配驗證。沒有實機檢視系統設定語言清單，也尚無這五份完整新譯文。探針及輸出在 /tmp/ga-dialect-check.6pdOPk/。

### 新增上海話繁體、長沙話及潮州話簡繁 — 2026-11-07

依使用者要求，在 `codex/add-five-dialect-localizations` 加入 wuu-Hant、hsn-Hans、hsn-Hant、nan-Hans、nan-Hant。每份提供 126 個介面字串（含 15 段 Help）、Finder 文件類型、版權及樣式數量提示。長沙話採市區話，參考《長沙方言中的動賓式離合詞研究》與長沙方言否定詞研究，採「咯、噠、冇得、莫」等用字。潮州話參照《潮典》用「汝、睇、佮、無、只陣、揣」等常用字詞。簡繁分別配合介面用詞，兩份 README 同步登記。macOS 名稱仍由系統提供，分別顯示上海話、湘語和閩南語。

繁體上海話沿用上海市區話的句式及「个、搿、辣、里向」用字。使用者追問「辣」的本字。錢乃榮提出「辣辣」的第一個音節由「在」演變，並採市區通行的「辣」記音。張惠英比較江浙各方言後提出「來」「落」的推源可能。兩者不足以確定上海話這個詞的本字，本次保留有文獻依據的通行記音字「辣」。參考錢乃榮〈「辣辣」的寫法和用法〉（https://www.people.com.cn/24hour/n/2013/0327/c25408-20937970.html ）及張惠英〈從吳語動詞介詞「勒、勒勒」說起〉（https://m.fx361.com/news/2025/0126/25479543.html ）。

使用者指出兩份粵語句式不夠道地，同輪重順廣州白話和香港廣東話的 15 段 Help 及三處提示。修正廣州版 Help.01 對舊開啟命令的引用。保留各地原來的介面用詞與已定稿的命令名。

30 套資源各 126 鍵、15 段 Help，五套新資源及兩套粵語的鍵名、Help 選單引用、快捷鍵與格式參數核對通過。本機 arm64 App 建置與嚴格簽章通過，包內資源與工作樹逐位元組相同。以 20 個語言偏好及地區變體分別執行 Foundation 探針，選中正確資源，讀回全部字串與 1、2、21 的樣式數量提示。探針在 /tmp/ga-add-dialects.AS0qeA/。尚未經母語者獨立審校或檢視系統設定的語言清單。

### 粵語介面改用較口語的措辭 — 2026-11-07

使用者澄清，兩份粵語的 Help 採上一輪改寫前的正文。各還原 15 段，只有第 1、14、15 段引述的選單名稱隨介面更新。以使用者定稿的潮汕話為主要參照，覆核檔案、編輯、視窗、文字對齊、預設、空狀態與對話框。兩份粵語採用如「閂埋」「揀晒」「退返一步」「兩個都留低」「用返預設值」等口語表達，字形表、具名實例、邊界框等專門術語沿用。簡體 55 條、繁體 54 條 Help 以外的字串有改動。

對照時發現繁體長沙話的 Custom 值缺少起始引號，經使用者同意只補引號，保留其譯文。兩份粵語和繁體長沙話字串檔通過語法檢查，兩份粵語各 126 鍵、Help 參照與格式參數核對通過。

### 上海話選單、提示及 Help 的口語用詞 — 2026-11-07

依使用者要求，按潮汕話與粵語的修改範圍覆核兩份上海市區話資源，並按補充允許順修 Help 正文。簡體 26 條、繁體 27 條介面字串採用如「上趟个地方」「儕揀上」「囥起來」「存好搿歇个配色」，並區分最近開過的字體與上次所在的資料夾。簡繁各改 12 段 Help，核對實際選單名稱、豎排入口及邊界框開關，保留快捷鍵及既定的技術術語。原有「辣」在處所句中照舊使用。「關脫」「囥」「搿歇」參照錢乃榮的上海話研究及《上海通志》方言資料。兩份語系各 126 鍵，字串語法、格式參數及 Help 選單引用核對通過。

### v1.6 正式版語系定稿 — 2026-11-07

依使用者確認，把最新本地化、選單用詞、中英文 README 及五份新語系提交為 `a768f4b`，本地分支改名為 `codex/release-1.6`。GitHub `main` 由 `2d29156` 快轉至 `a768f4b`。遠端舊標籤於推送前已移除，新建的 `v1.6` 指向此正式版。

30 份語系的字串鍵、格式參數、打包後字串載入及樣式數量格式已驗證。Universal ZIP 根目錄只有 App，解壓後嚴格簽章通過。

### 恢復 ZIP 隨附的首次開啟腳本 — 2026-11-08

依使用者要求，在 `codex/restore-first-open-command` 恢復 `2d29156` 移除的 `build.sh -z` 腳本生成和 ZIP 組裝流程。檔名改為 `Double-Click This First.command`，雙擊後對同一資料夾中的 `Glyph Atlas.app` 執行 `/usr/bin/xattr -rc`。隔離 arm64 建置確認 ZIP 根目錄包含 App 和具執行權限的腳本。未執行腳本或開啟 App。

使用者指出 Finder 也可能攔下雙擊執行的腳本。依指示改名為 `If the App Won't Open, Drag into Terminal and Press Return.command`，解壓後若 App 打不開，將腳本拖入 Terminal，再按 Return。

使用者要求縮短檔名，定稿為 `If Won't Open Drag this into Terminal.command`。

### v1.7 隱藏側邊欄的工具列設計探針 — 2026-11-08

使用者提出隱藏側邊欄後，在原生工具列放入橫向伸展的文字輸入框。可變字體在左側顯示普通 VF 工具列按鈕，右側放原生空格。本輪在 macOS 14.8.7、SDK 15.2 以離屏 AppKit 視窗試驗，正式程式未改。

- AppKit 提供側邊欄原生收合動畫。現有 `canCollapse = NO` 時，離屏直接呼叫 `toggleSidebar:` 不改變收合狀態，設定分欄項目的 `animator.collapsed` 則可變更目標狀態。隱藏視窗未產生可判讀的動畫過程；直接收合後搬動輸入框並插入工具列項目，離屏幾何立即換位。尚未驗證可見視窗的工具列過渡。
- 視窗寬 600、800、1200 pt，有／無 VF 按鈕時，兩種空格都讓輸入框吃滿其餘新增寬度。輸入框右緣至視窗右緣，UnifiedCompact 固定／彈性空格分別為 31／16 pt，Unified 為 35／20 pt。兩種樣式的標題區高 38／52 pt，輸入框高 25／31 pt。建議先用彈性空格及 Unified 做實機試版。macOS 26 已使用 Unified，玻璃外觀與實際留白需在對應系統核對。
- 用正式視窗控制器及原有輸入框，離屏結束編輯後將同一控件搬到工具列，再搬回側邊欄。確認可重用同一個欄位編輯器、還原選取範圍、保留換行及指定 GID，並能在工具列還原和重做搬動前的 GID 操作。切換時的實際輸入法組字及焦點仍待驗收。macOS 14 起有公開的工具列項目 Popover 錨定方法；12–13 可用原生有框 NSButton 的視圖錨點。

離屏探針及數據在 `/tmp/ga-sidebar17.glBCEV/`。

### 接入隱藏側邊欄與工具列輸入 — 2026-11-08

依使用者確認，在 `codex/hidden-sidebar` 新增主「顯示方式」的「顯示側邊欄／隱藏側邊欄」，補齊 31 套語系。每個字體視窗獨立切換，三種預覽皆可用。收起時使用 Unified，排列原生有框 VF 按鈕（僅可變字體）、撐滿剩餘寬度的原輸入框、原生彈性空格。側邊欄使用 AppKit 原生收合與展開，啟用減少動態效果時直接切換。工具列項目在同一操作換位。變軸面板沿用原內容，macOS 14 起錨定工具列項目，12–13 錨定有框的原生按鈕。已獨立拖出的變軸面板保留。

macOS 14.8.7 離屏以正式選單、視窗及輸入編輯器驗證三種視圖切換、視窗外框與原側欄寬度復原、SFNS 與 Arial 切換、600→1200 pt 視窗中的輸入框增量、選取範圍、換行與指定 GID、跨換位的還原與重做。離屏首次復焦發現工具列需先完成佈局，修正後探針通過。31 套資源字串鍵一致，arm64 建置完成。探針在 `/tmp/ga-sidebar17.glBCEV/integration.m`。可見視窗動畫、輸入法組字與 macOS 26 的實際玻璃外觀仍待驗收。

### 隔離各視窗工具列並延後收合換位 — 2026-11-08

依使用者回報，在 `codex/sidebar-window-isolation` 為每個視窗使用獨立工具列識別碼。原本 AppKit 會在共用識別碼的工具列之間同步項目，讓側邊欄仍展開的視窗失去字體名稱。收合後開啟標題區原生背景。VF 佔工具列第一項，左側的 App 佔位為 0 pt，AppKit 仍留自己的視窗按鈕間距。macOS 14.8.7 離屏量到原生按鈕外框與綠色視窗按鈕相隔 18 pt。

收合時保留側邊欄原有佈局和輸入框，等原生動畫完成才切換 Unified 與工具列項目。展開時先將輸入框移回側邊欄。探針重現修正前既有與新開視窗皆取得收合工具列，修正後兩者保留各自的工具列，且新開 SFNS 視窗保有字體名稱及原 VF 按鈕。離屏模擬動畫完成回呼，核對佈局切換的先後。原有三模式、焦點、選區、換行、GID 及還原測試一併通過。可見動畫與 macOS 26 背景待實機驗收。試用版在 `/tmp/ga-sidebar-fix.3UMYtb/Glyph Atlas.app`。

### 試用側邊欄控件移動動畫 — 2026-11-08

依使用者回報再查 VF 左側空間。上一輪沒有加入自訂間距或寬度。VF 一直位於收合後工具列的第一項，與視窗控制鈕之間的距離由 AppKit 決定。120 pt 約束屬於輸入框的最小寬度。

加入 `GASidebarMotion` 試驗。原生分欄動畫期間，以透明子窗口保留控件快照。分欄就位後，快照以 180 ms 移到輸入框與 VF 的實際位置，並裁切與淡換原尺寸的圖像。原生工具列的 VF 透過公開輔助使用介面取得可用的快照位置。系統的減少動態效果設定可略過整段過渡。中斷時清除覆層並恢復原生控件的透明度。

macOS 14.8.7 離屏控制分欄完成時序，驗證靜態與可變字體的雙向移動、輸入框經過中間位置、兩個端點的快照、完成清理，以及原有的跨視窗隔離、輸入與還原。試用版在 `/tmp/ga-sidebar-motion.ySD8wa/Glyph Atlas.app`。可見視窗的過渡與 macOS 26 材質待實機驗收。

### 撤回控件移動動畫試驗

依使用者要求撤回快照移動試驗，移除透明子窗口、動畫計時器及 VF 輔助使用查找。恢復原生分欄動畫，收合完成後再切換工具列。VF 由 AppKit 放在工具列第一項。

### 驗證先換工具列再原生收合 — 2026-11-08

用 macOS 14.8.7 離屏拆開工具列樣式、背景與搬移輸入框。Arial 的五個字形列在切換 Unified 和開啟原生背景後仍可見，清單高 324 pt。搬移輸入框後，空的側欄容器被 Auto Layout 撐高，清單高度變成 0 pt。暫時固定原輸入框容器的 30 pt 高度，五列及 324 pt 清單都恢復。

以原生工具列測 VF 與輸入框先放在側欄追蹤分隔項之前。300 pt 側欄可顯示兩項，收合後兩項進入溢出，移除分隔項才重新佈局到主工具列。使用自訂識別碼的原生追蹤分隔項並放寬欄位最小寬度，收合後輸入框只剩 3 pt，仍沒有跨區轉移。在同一 NSAnimationContext 開啟隱式動畫並移除分隔項，離屏只看到工具列立即重新佈局，未取得可見動畫證據。探針在 `/tmp/ga-native-sidebar.U2NkxK/`。未改正式程式。macOS 26 的原生工具列行為未實機驗證。

### 驗證 Apple 原生固定工具列位置的做法

macOS 14.8.7 離屏以 800 pt 寬視窗及 300 pt 側欄比較原生 AppKit 佈局。標準 `NSToolbarToggleSidebarItemIdentifier` 排在側欄分隔項之前的第一位，側欄收放前後的可及性外框同為 x=87、y=448、寬 42 pt。一般 VF 和輸入框設成 navigational 後仍隨側欄移動，x 各由 313／373 pt 變成 91／151 pt。

用 `allowsFullHeightLayout = NO` 讓側欄從共用工具列下方開始，固定 Unified 樣式與工具列項目，VF 和輸入框在收放前後都保持 x=91／151 pt，輸入框寬 629 pt。保留全高側欄時，另用 `NSTitlebarAccessoryViewController` 的 leading 位置，140 pt 寬的附屬容器在兩態保持相同外框。探針在 `/tmp/ga-toolbar-pin.paSVzP/`。未改正式程式，未驗證 macOS 26 實機。

### 全高側邊欄與固定標題列附屬視圖試驗 — 2026-11-08

依使用者要求，在獨立副本以 `NSTitlebarAccessoryViewController` 的 leading 位置放原生 VF 按鈕和原有輸入框。兩態都採 Unified 與原生背景。全高側邊欄可用原生分欄方式收放，兩個控件一直留在標題列。試用版以 AppKit 排出的前緣位置計算附屬視圖寬度，目標右距 20 pt，保留視窗標題資料供辨認。獨立 bundle ID 為 `com.zonz.GlyphAtlas.TitlebarAccessoryTrial`。

macOS 14.8.7 離屏驗證 600、800、1200 pt 視窗再縮回 600 pt。VF 字體的輸入框寬 468、668、1068 pt，靜態字體為 503、703、1103 pt。右距實量 19 pt，VF 與輸入框在收放前後的外框相同。正式輸入類別驗證原生編輯器與選區保留，側邊欄保留查詢列並可取得焦點。試用 App 在 `/tmp/ga-titlebar-accessory.mOKfRX/trial/dist/Glyph Atlas.app`。工作區產品碼未改，macOS 26 材質及可見視窗過渡待使用者驗收。

### 整合原生標題列展開 — 2026-11-08（寬度動畫更新見下一節）

獨立測試版由使用者驗收。依補充要求在 `codex/titlebar-sidebar-expansion` 整合正式程式。側邊欄展開時沿用原有工具列樣式、字體名稱、VF 按鈕與側欄輸入框位置。收起時先將普通 VF 與原輸入框裝入標題列附屬視圖，控件寬度先限制在側欄內。保留原輸入框容器高度讓字形清單隨分欄收合，再於同一 AppKit 動畫群組把控件寬度約束展開到標題列右距。展開側欄時先還原原佈局。啟用減少動態效果時直接切換。

依使用者要求使用正式分支版本，未另外製作獨立試驗。Universal App 已產生，可見動畫仍待實機驗收。

### 以 AppKit 視圖外框動畫展開輸入框 — 2026-11-08（由「輸入框直接跟隨原生收合」取代）

使用者實測收合時輸入框立即撐滿。正式分支改以 `NSViewAnimation` 動畫標題列內控件所在視圖的實際外框。起點按收合前的側欄寬度計算，與原生分欄收合同時啟動，沿用同一時長。側欄展開時使用原有佈局。

macOS 14.8.7 離屏用正式控制器取樣。在 800 pt 視窗及 280 pt 側欄中，輸入框起點為 148 pt，設定 AppKit 動畫進度後依序量到 224、408、591、668 pt，VF 水平位置固定在 78 pt。離屏執行環境無法觀察自動推進，因此可見視窗的同步播放仍待使用者驗收。Universal 完整版已編譯及驗證簽章，位於 `/tmp/ga-titlebar-expansion.T9JsAK/Glyph Atlas.app`。

### 實際視窗量測輸入框與分欄收合 — 2026-11-08

使用者再次看到輸入框立即撐滿，要求檢查可見視窗。以現行完整版程式加上臨時記錄，於 macOS 14.8.7 開啟 800 pt 的可見 SFNS 字體視窗，側欄設為 280 pt，系統減少動態效果關閉。從「顯示方式 → 隱藏側邊欄」操作，自動推進的 `NSViewAnimation` 與輸入框顯示圖層均出現中間值。以選單動作為時間零點，27 ms 輸入框 149 pt、側欄 280 pt，37 ms 輸入框 172 pt、側欄仍 280 pt，87 ms 輸入框 236 pt、側欄 260 pt，145 ms 輸入框 490 pt、側欄 162 pt，266 ms 輸入框 669 pt、側欄 3 pt，281 ms 側欄才到 0 pt。兩條動畫有重疊，但進度未鎖在一起。未重現輸入框瞬間撐滿。原始記錄在 `/tmp/ga-sidebar-visible.x1Wes9/menu-trace.txt`。

收合完成後，臨時測量視窗另出現無回應。以直接呼叫同一選單動作的第一次測量程序取樣，AppKit 主執行緒仍在自動填寫的鍵盤焦點巡覽中，取樣時程序實體記憶體用量為 49.1 GB。已關閉該程序，未改產品程式。取樣在 `/tmp/ga-sidebar-visible.x1Wes9/sample-27766.txt`。

### 輸入框直接跟隨原生收合 — 2026-11-08（已撤回）

依使用者要求，移除輸入框獨立的 `NSViewAnimation`。收合時以原側欄寬度確定輸入框起始範圍，並監聽 `NSSplitView.arrangedSubviews` 中側欄面板的外框通知。AppKit 每次縮窄面板，標題列輸入框以同一比例展寬。面板收至零寬或隱藏時停止跟隨，避免 AppKit 還原隱藏面板的內部尺寸後出現一幀回跳。側欄顯示時保留原有佈局。

以完整版執行檔附掛臨時量測，從 macOS 14.8.7 實際視窗的「隱藏側邊欄」操作。600 pt 視窗與 200 pt 側欄下，SFNS 的輸入框從 69 展至 469 pt，Arial 從 103 展至 503 pt。三次收合中，所取樣的輸入框與側欄顯示圖層均同時開始變寬／收窄，同時到達終點，無回跳。兩種字體均可在收合後繼續輸入，展開後保有文字和原工具列。正式成品不含量測元件。原始量測 `/tmp/ga-sidebar-sync.VaZIPI/final/visible.log`，Universal 成品 `/tmp/ga-sidebar-sync.VaZIPI/final/Glyph Atlas.app`。macOS 26 可見視窗尚未量測。

### 恢復輸入框動畫試驗前版本 — 2026-11-08

使用者實測仍未看到輸入框動畫，要求先回退並暫停研究。依首次控件動畫試驗前的修改記錄，恢復「隔離各視窗工具列並延後收合換位」的兩份原始碼。側欄原生收合結束後，輸入框、VF 原生工具列按鈕與彈性空格才出現在 Unified 工具列。31 份現有選單語系與當時的 App 資源逐檔相同，維持原檔。回退前的修改存於 `/tmp/ga-sidebar-rollback.ZGnDyY/before.patch`。

回退後 Universal 版簽章通過，arm64 的 `__TEXT,__text` 與試驗前的 App 完全相同。完整版在 `/tmp/ga-sidebar-rollback.ZGnDyY/Glyph Atlas.app`。

### 收合開始時換位並保留字形清單 — 2026-11-08

依使用者要求，在側欄開始原生收合時，將 VF 和原輸入框換入 Unified 工具列。搬移輸入框前固定其側欄容器當下的高度，避免空容器把字形清單擠到零高。展開時解除高度約束並恢復原佈局。

macOS 14.8.7 離屏攔截正式視窗控制器的原生收合入口。在分欄仍展開時，已確認 VF 與輸入框在工具列，原側欄輸入容器維持 30 pt，字形清單維持 324 pt，表格共 25 列且可見範圍仍為最前 8 列。模擬完成後切回展開，核對文字及原工具列回復。可見動畫待使用者驗收。

### 以標題列附屬視圖的右側空白展開輸入框 — 2026-11-08

依使用者要求採用 `NSTitlebarAccessoryViewController`。在 macOS 14.8.7 可見 AppKit 視窗中，右側長條初始等於主視圖寬度。長條若是獨立的右側附屬視圖，移除、換成短空白、換成原生工具列彈性空白或改變寬度，都不會帶動左側輸入框。共用同一附屬視圖時，移除與替換會直接切至終點寬度。保留同一空白並用 AppKit 的 `animator` 改其寬度約束，量到 15 個輸入框顯示寬度。直接改約束常量只出現起點和終點。

完整版採用共用附屬視圖及寬度約束動畫。以可見視窗驗證 Arial（600 pt 視窗、200 pt 側欄）及 SFNS（800 pt 視窗、280 pt 側欄）。輸入框顯示寬度分別由 124 展至 503 pt、由 170 展至 669 pt。兩種字體都有 15 個取樣寬度，輸入框與側欄在同一次取樣開始變動並到達終點。VF 的水平位置固定，展開時回復原有工具列。原始記錄在 `/tmp/ga-titlebar-spacer.9s4cSf/` 的 `visible.log`、`native-space.log` 和 `product.log`。Universal 完整版在同一目錄，macOS 26 可見動畫尚未驗證。

### 補上反向動畫並清理控件定義 — 2026-11-08

依使用者要求保留同一空白的寬度動畫。展開側欄時，空白由 20 pt 增至主視圖寬度，輸入框縮窄後再回側欄。移除搜尋框的側欄包裝視圖，回到原本直接定位的約束。搜尋框在標題列時，以原高度計算清單上緣。VF 沿用初始定義的同一按鈕，回到字體名稱旁時恢復原無框樣式。依使用者補充省略舊版佈局比對。

### 恢復收合後的原生工具列 — 2026-11-08

使用者截圖顯示附屬視圖左緣裁切搜尋框焦點環，VF 按鈕也比原生工具列版本矮且偏左。收合完成後恢復最初的原生 VF 工具列項目、原輸入框項目及原生彈性空白，交由 AppKit 排版。附屬視圖只在收放動畫期間存在，繼續以同一空白的寬度動畫過渡。展開後恢復原工具列及搜尋框的側欄約束。

### 原生工具列項目內的輸入框動畫試用 — 2026-11-08

依使用者澄清，測試將收放期間的輸入框和 VF 都留在原生工具列，移除附屬視圖。第三種寬度動畫改成直接改動輸入框在原生項目內的尾緣留白。macOS 14.8.7 的可見完整版視窗中，Arial 和 SFNS 在收合時各量到 13、14 個非零顯示寬度，展開時各量到 13 個。原生工具列項目本身也隨側欄移動，收合開頭的少數取樣沒有可見輸入框，展開尾段會縮得很窄。收合與展開的終點都回到原有原生佈局。原始記錄和 Universal 試用版在 `/tmp/ga-toolbar-input-motion.uAZivm/`。

### 收尾整理側欄收放 — 2026-11-08

收放流程直接設定搜尋框在原生工具列的尾緣約束，移除轉交動畫參數的方法。將展開時延後還原側欄的條件集中到同一處。離屏確認有動畫和即時切換的原生工具列端點、起始約束與輸入文字。另以 macOS 14.8.7 的分欄項目及約束代理量到隱式動畫開關維持關閉，因此保留動畫群組內的顯式開啟。

### 移除搜尋框伸縮動畫 — 2026-11-08（後續恢復，見下一節）

依使用者決定撤回搜尋框伸縮，移除動畫留白、側欄寬度記錄及延後搬移的程式。搜尋框在收放開始時直接在側欄與原生工具列間換位，側欄沿用 AppKit 原生動畫。使用者指出右上角的溢出箭頭是反向動畫時被撐出來的。

### 恢復輸入框伸縮並清除動畫留白 — 2026-11-08（已撤回，見下一節）

依使用者決定恢復原生工具列內的雙向輸入框動畫。側欄收合時，輸入框右側的暫時留白縮至零，平時的間距由 AppKit 排版。側欄展開時，輸入框縮完後，在同一次佈局更新內清除留白、將輸入框移回側欄，再排好原工具列。右上角溢出箭頭的實際表現待視窗驗收。

### 恢復輸入框即時換位 — 2026-11-08（現行容器見下一節）

使用者回報右上角的溢出箭頭似乎仍出現，決定恢復上一版的即時換位。移除輸入框伸縮的留白約束、側欄寬度記錄和展開時延後搬移的流程。輸入框在側欄收放開始時立即換位，側欄沿用 AppKit 原生收放動畫。

### 以標題列附屬視圖承載隱藏側欄的輸入框 — 2026-11-08 17:45（已撤回）

依使用者要求恢復 `NSTitlebarAccessoryViewController`。側欄隱藏時，附屬視圖承載原輸入框和使用 AppKit 工具列外框樣式的 VF 按鈕。附屬視圖跟隨視窗寬度，留出焦點環空間。展開時移回輸入框並移除附屬視圖，恢復原本的字名工具列。刪除原收合工具列的輸入框、VF 和彈性空白項目，以及僅用於工具列項目的 VF 彈出錨點。源碼已無實驗用的伸縮約束、快照及計時器。

macOS 14.8.7 離屏檢查 Arial 及 SFNS 的兩次收放和 600→1200→600 pt 視窗變寬。兩種字體的輸入框高度皆為 31 pt、右距 19 pt，寬度隨視窗增減 600 pt。展開後輸入文字、側欄輸入框及原字名項目復原。macOS 26 的焦點環及 VF 外觀待實際視窗驗收。

### 恢復原生工具欄項目並移除附屬視圖 — 2026-11-08（現行方案見下一節）

使用者確認將輸入框和 VF 按鈕恢復為原生工具欄項目，右側使用原生彈性空白，移除 `NSTitlebarAccessoryViewController`。一併撤回附屬視圖的寬度計算、視窗縮放回呼和額外 VF 按鈕。側欄收放時輸入框即時換位，側欄沿用 AppKit 原生動畫。

### 在同一個標題列附屬視圖固定 VF — 2026-11-08（已撤回）

使用者指出側欄收放時 VF 會隨主視圖向左移，決定由同一個前緣 `NSTitlebarAccessoryViewController` 承載 VF、收合後的輸入框和右側留白。兩態共用 Unified，因為 macOS 14 切換 Compact 與 Unified 會改變附屬視圖的原點及高度。VF 在兩態共用同一顆 AppKit 工具列外框樣式按鈕；輸入框在收放開始時直接換位。右側 20 pt 是附屬視圖內的約束。側欄展開後，附屬視圖只保留 VF 所需寬度；靜態字體的附屬視圖歸零並隱藏，原字名回到工具欄。移除收合用的舊工具欄項目及 VF 工具欄項目專用的彈出定位程式。

macOS 14.8.7 離屏驗證 Arial 和 SFNS 各兩次收放與 600→1200→600 pt 視窗調整。SFNS 的 VF 外框維持相同，兩種字體的輸入框右距實量 19 pt，展開後保有字名、輸入文字與側欄輸入框。實際視窗收放過程及 macOS 26 外觀待驗收。

### 還原收放時的工具欄樣式 — 2026-11-08（後續恢復 17:45 版）

依使用者要求撤回兩態共用 Unified 的改動。收合維持 Unified，展開恢復原本依系統版本選擇的工具欄樣式。

### 恢復 17:45 交付版本 — 2026-11-08（已由原生工具欄版取代）

使用者在彈窗確認恢復 17:45 交付版本。按當時的修改記錄重建 `GAMainWindowController.m`。收合時才建立附屬視圖放入輸入框與工具欄樣式的 VF，展開時移除附屬視圖並恢復原本的字名與 VF 工具欄。撤回後續的常駐附屬視圖及固定 VF 改動。

### 由 AppKit 排版收合後的工具欄 — 2026-11-08

使用者在彈窗確認回到 17:22 的原生工具欄方案，以恢復收合後 VF 的原生外觀。VF、原輸入框與原生彈性空白均交由 `NSToolbar` 排版。移除 `NSTitlebarAccessoryViewController`、附屬視圖寬度計算、縮放回呼及附屬視圖內的 VF 按鈕。輸入框在收放開始時即時換位，側欄使用 AppKit 原生動畫。

### 切換 Unified 時保留側欄原控件 — 2026-11-08（順序更新見下一節）

使用者在彈窗確認試做。收合開始時切換 Unified，輸入框與 VF／字名組留在原容器。以 `contentLayoutRect` 上緣的變化補償輸入框，以字名組切換前後在視窗中的外框差補償 VF 與字名。AppKit 完成收合後清除補償，換入收合後的原生工具欄項目。展開及減少動態效果沿用原流程。

macOS 14.8.7 離屏量到工具欄與標題列合計由 38 pt 增至 52 pt，輸入框下移 14 pt，VF 與字名右移 11 pt、下移 7 pt。正式控制器離屏攔截原生收合入口，確認補償後三個外框均與切換前相同，已採 Unified 時也保留原位置。模擬完成後確認原生工具欄接回輸入框與 VF，展開後輸入文字及位置復原。實際視窗的過渡待驗收。

### 先換原生工具欄並保留側欄過渡畫面 — 2026-11-08（現行方案見下一節）

依使用者在彈窗的選擇，恢復上午初版先換工具欄、再啟動 AppKit 收合的順序。原 VF／字名和輸入框的畫面在切樣式前取樣，以不可互動的靜態視圖留在側欄。工具欄即時接回原輸入框與原生 VF。字形清單按切換前後的 `contentLayoutRect` 上緣差值補償，動畫完成時清除補償和靜態畫面。撤回延後換位與改動字名組 `bounds` 的方式。

macOS 14.8.7 離屏在正式控制器攔截原生收合入口。第一次和第二次均確認原生工具欄項目已就位，VF／字名與輸入框的靜態畫面外框等於切換前，字形清單上緣及高度維持 344 pt。模擬完成後確認畫面移除，展開後輸入文字保留。使用者在舊方案看到的首次可見位移未在離屏重現，實際視窗仍待驗收。

### 以原生控件保留側欄收合過渡 — 2026-11-08（現行方案見下一節）

依使用者指定，展開時可變字體的 VF／字名組左移 9 pt，靜態字體的字名左移 2 pt。收合時以實際 VF／字名組及側欄輸入框取代靜態畫面。切換工具欄前先記下字名組的位置，並將側欄輸入框固定於側欄上緣，字形清單沿用相對輸入框的約束。切到 Unified 後，原生工具欄使用獨立輸入框，與側欄輸入框共用同一個編輯器、文字與還原紀錄。展開時恢復側欄輸入框和字名組。

macOS 14.8.7 離屏攔截正式控制器的原生收合入口，首次及第二次收合時，原 VF、字名、輸入框和字形清單座標均與切換前相同。核對展開、工具欄輸入、跨兩個輸入框的還原與重做，以及 9／2 pt 偏移。左移 9 pt 後，VF 最左約 5 pt 位於 AppKit 工具欄項目的點擊範圍外。可見視窗的動畫與較新 macOS 的外觀仍待驗收。

### 收合只固定字形清單，展開時單獨左移 VF — 2026-11-08（VF 間距更新見下一節）

依使用者彈窗確認，撤回 9／2 pt 整組位移，VF 與字名的排版間距歸零，展開時只以 Auto Layout 對齊矩形左移 VF 5 pt。收合期間原字名組與側欄輸入框留白，僅固定字形清單。兩個輸入框繼續共用編輯器與還原紀錄，工具欄輸入框使用 `GASearchFieldCell`。

macOS 14.8.7 離屏量到 VF 由 x=80 移至 x=75 pt，字名 x=95 pt。首兩次收合時字形清單的外框相同，確認控件留白、展開後恢復輸入框及跨輸入框的還原與重做。VF 最左約 1 pt 仍在 AppKit 工具欄項目的點擊範圍外。可見視窗的過渡待驗收。

### 側欄展開時在 VF 右側留 5 pt — 2026-11-08

使用者在彈窗確認一般視窗與全屏共用排版。移除 VF 的 5 pt 左移及對應的點擊補償，改用 `NSStackView` 在 VF 右側設定 5 pt。堆疊預設間距維持 0 pt，字名沒有額外間距。

### 側欄收起後由 AppKit 處理工具欄覆蓋 — 2026-11-08

參考 Finder 圖像視圖在捲到頂端和向下捲動時的表現，依使用者彈窗確認套用到三個視圖。保留延伸到工具欄後方的主畫布，收起側欄後採用原生自動分隔樣式。全字和多字視圖啟用 AppKit 的捲動內距，單字視圖以安全區安排字形。展開側欄時回到原先的排版。

macOS 14.8.7 以 SFNS 離屏核對兩次收合、全字首排間距、捲回頂端後縮放、單格篩選、橫排與直排的多字視圖，以及單字畫布與安全區。AppKit 量到工具欄佔用 52 pt，普通視窗的全字首排在其下方留 18 pt。工具欄在可見視窗的懸停外觀待核對。

### 工具欄分隔線隨垂直捲動顯示 — 2026-11-09

使用者發現原生自動樣式在頂端仍顯示分隔線。依彈窗確認，依目前視圖的 `NSClipView` 垂直捲動位置切換原生分隔樣式。全字及多字視圖捲離頂端時顯示。回到頂端、內容不足一屏、切到單字視圖或展開側欄時隱藏。

macOS 14.8.7 離屏核對全字與多字視圖捲離頂端後返回、全字篩成一格、直排多字的水平捲動、切換單字視圖，以及再次收起側欄。驗證範圍為視窗分隔樣式的切換。

### 驗證 AppKit 自行切換捲動陰影 — 2026-11-09

macOS 14.8.7 的暫存副本移除分隔線判斷。全字與多字的捲動視圖填滿主區域，AppKit 在現有視圖層級即可辨識捲進工具欄後方的內容。實際視窗的 `.automatic` 在頂端畫細線，捲動後加上陰影，捲回頂端恢復細線。單字視圖也有靜態細線。改為直接使用捲動視圖當視窗根視圖、改用內容列表區段、保留工具欄追蹤項及啟用全高佈局，均未得到頂端無分隔線且捲動時顯示陰影的組合。`.none` 同時移除兩者。實驗未整合進產品。

### Finder 主視窗的分隔樣式呼叫鏈 — 2026-11-09

唯讀分析本機 macOS 14.8.7 的 Finder arm64e 執行檔。`TBrowserWindowController.containerTitleSeparatorChanged:`（`0x100402fbc`）向 `TBrowserContainerController` 讀取 `titleBarSeparatorStyle`，再呼叫 AppKit 私有的 `NSWindow.setContentTitlebarSeparatorStyle:`。公開的 `setTitlebarSeparatorStyle:` 在此執行檔中另有呼叫點，位於簡介視窗的初始化。

一般圖像模式採覆蓋式捲軸時，`TIconCollectionViewController.titleBarSeparatorStyle`（`0x10013d320`）回傳 0。使用傳統捲軸、啟用分組或遇到指定背景類型時回傳 2。主容器也會依預覽欄、標籤欄或橫幅等狀態選擇 2。此路徑選擇分隔樣式時不讀捲動座標。尚未驗證只呼叫這個私有 setter 能否重現 Finder 的外觀。

### 側欄收起時依可捲動範圍切換工具欄背景 — 2026-11-09

依使用者彈窗確認，側欄收起時主畫布鋪滿視窗。有可捲動範圍時恢復原生工具欄背景，其餘狀態透明。單字視圖以安全區排列字形，全字與多字由 AppKit 保留工具欄高度。全字首排貼齊工具欄下緣。可捲動的內容仍可進入工具欄後方。

macOS 14.8.7 離屏核對全字從完整字形到單格篩選、空白與長文多字、直排水平捲動、切到單字及兩次收起側欄。全字首排在透明與原生背景時均留 52 pt 的工具欄空間。

### 側欄收起時單字與短篇多字以視窗置中 — 2026-11-09（安全線行為見下一節）

使用者釐清安全區是裁切界線，並在彈窗確認修改單字和多字。單字以完整畫布計算頁面，在工具欄下緣裁切頁面、陰影及墨跡。多字放得下時以完整畫布置中，沿用文件視圖頂端裁切，出現捲動範圍時回到原生捲動佈局。全字沿用已確認的首排位置。

macOS 14.8.7 離屏核對短篇橫排和直排置中，直排放大後頁面仍置中，文字的可見範圍截止在工具欄下緣。單字的兩次離屏繪製只有工具欄範圍內的像素因裁切而變化。長文多字捲動和全字首排亦通過核對。

### 單字與多字沿安全線向下延伸 — 2026-11-09

使用者釐清安全線限制頁面位置。單字按完整畫布置中，頁面或墨跡到達安全線後使用下方空間繼續放大。多字以同一套公式計算置中和碰線後的位置。即使文字仍放得下，邊界框超出也會增加可捲動範圍。第一次出現垂直捲動範圍時保持在頂端，已有的捲動位置按原有比例保留。

macOS 14.8.7 離屏核對單字碰線後繼續向下放大，多字往返跨過可捲動門檻時頁面連續定位，且邊界框超出而文字仍放得下時已可捲動。長文、直排水平捲動、全字首排及側欄收放亦通過核對。

### 多字視圖碰到安全線後可捲出頂部留白 — 2026-11-09（簡化方案見下一節）

依使用者在語音中確認，頁面尚未碰線時在完整畫布置中，工具欄蓋住的留白不能捲出。頁面超出安全線後，原本的頂部留白納入文件高度，初始捲動位置停在頁面貼齊安全線的位置。往上捲可露出全部留白。縮放時分開保留頁面內的捲動進度和留白已露出的比例。捲動只發生在留白區時不顯示分隔線。也排除較高視窗因底部留白提前產生的垂直捲動範圍。

macOS 14.8.7 離屏核對一般和較高視窗跨越捲動門檻的頁面位置。一般視窗的測例可捲出 49.5 pt 原有頂部留白，並在繼續縮放時保持已捲到頂端的位置。單字、全字、長文、直排及側欄收放通過既有離屏核對。已產出並驗證通用 App 簽章，實際視窗待驗收。

### 多字碰線後切換中心，僅補償首次位置 — 2026-11-09

使用者進一步釐清，安全線只決定何時由完整畫布居中切換成可捲動文件。出現垂直捲動後，頁面依正常文件中心與邊距排版。依本輪指示移除留白獨立捲動比例與持續貼齊安全線的邏輯，還原共用的捲動位置保存函式。多字僅在垂直捲動第一次出現時補償一次位置，其後沿用正常的捲動位置。文件頂部留白自然可捲出。

macOS 14.8.7 離屏核對一般及較高視窗的首次切換、之後的正常捲動位置、向上捲出完整留白，以及縮小回無捲動狀態。單字、全字、長文、直排與側欄收放也通過既有核對。實際視窗待使用者驗收。

### 標題欄懸停、全字安全區與側欄原生邊緣效果方案 — 2026-11-09

使用者驗收多字切換中心的修正，開始研究新一輪外觀與側欄操作。核對現行全字的 NSScrollView 仍填滿主區域，收起側欄時 AppKit 自動 contentInsets 預留工具欄高度。網格 topInset 補足 safeAreaInsets.top 與原生 contentInsets.top 的正差，通常為 0。這個結構允許後續內容捲進工具欄後方。

標題欄懸停的公開接口候選為 NSTrackingArea 配合既有 titlebarAppearsTransparent，只切換原生背景。建議在側欄收起時採「內容可捲動或游標位於標題欄則顯示背景」。Finder 當前只有桌面、沒有資料夾視窗，本輪沒有取得實際懸停前後畫面，也未確認 Finder 使用相同呼叫鏈。

側欄快捷鍵建議 Control-Command-S，目前未找到專案衝突，Apple 備忘錄、地圖與 Console 的官方說明採用此組合。尚待使用者選定。

依 WWDC25「Build an AppKit app with the new design」，macOS 26 的 NSScrollView 在工具欄、標題列附屬視圖及分欄附屬視圖後方自動呈現 ScrollEdgeEffect。側欄列表目前位於輸入框下方，需要讓列表延伸到輸入框後方，並將輸入框交給 NSSplitViewItemAccessoryViewController，系統才能在該處辨識重疊。preferredScrollEdgeEffectStyle 與 softStyle 自 macOS 26.1 起提供。使用者明確說本機不支援，因此不用測試這項新系統效果。本輪為源碼與官方文件研究。

### 簡化全字安全區、側欄快捷鍵及預設 ScrollEdgeEffect — 2026-11-09

使用者釐清標題欄需要的是背景緩慢出現，並要求僅在 AppKit 有原生接口時採用。本機 NSWindow 對 titlebarAppearsTransparent 與 titlebarSeparatorStyle 的 defaultAnimationForKey:、animationForKey: 都回傳 nil；透過一秒的 animator 區塊切換仍即時變更。按使用者條件維持既有背景切換。

依使用者確認，全字捲動區的頂邊改直接貼齊安全區，網格頂部留白為 0，移除原生內容內距與網格補差的組合。內容的可見捲動範圍止於工具欄下緣。普通視窗展開側欄時保留原 18 pt。工具欄背景與分隔線以目前視圖的捲動狀態處理。側欄命令加入 Control-Command-S，沿用每窗切換與現有驗證。

macOS 26 及以上將原側欄輸入框交給 NSSplitViewItemAccessoryViewController，左右 12 pt、下方 9 pt，高度取原生 fittingSize，停用附屬視圖額外套用的標準內距。列表填滿側欄，由 AppKit 辨識輸入框的重疊並產生 ScrollEdgeEffect。使用者後續指定系統預設樣式，已移除柔和樣式及其 26.1 接口宣告。較舊 SDK 以 NSClassFromString 查找新的公開類，避免舊 SDK 的連結庫缺少類別符號。

macOS 14.8.7 離屏確認全字捲動區與首排同在工具欄下緣、兩層頂部內距均為 0，並核對短內容、捲動、縮放、側欄兩次收放及快捷鍵設定和命令派送。單字與多字的既有核對通過。依使用者要求，未模擬或測試新系統的 ScrollEdgeEffect，實際佈局及效果留待新系統驗收。

### 淺色預設背景改為 RGB 253，核對拖動時的標題欄陰影 — 2026-11-09

依使用者要求，GABoundingBoxBackgroundColor 的淺色分支由純白改成 sRGB (253, 253, 253)，alpha 為 1。透過既有自動配色路徑套用到三個預覽及畫布。

使用者詢問有捲動範圍時，拖動標題欄出現的陰影是否由 App 實作。核對 Sources 內所有陰影、視窗移動與標題欄樣式設定：自繪 NSShadow 僅用於預覽的邊界框。標題欄只由 GADetailViewController 按捲動位置設定 none／automatic 分隔樣式，初始樣式在主控制器設定。未找到拖動時切換陰影的程式。依目前源碼判斷該拖動外觀由 AppKit 呈現，本輪未追蹤實際拖動中的系統呼叫。

### 恢復全字捲動區延伸到工具欄後方 — 2026-11-09

使用者指出全字視圖的捲動區止於工具欄下緣，要求恢復簡化前的覆蓋結構，並將網格的頂部留白直接設成 0。依此恢復填滿主區域的 NSScrollView 及 AppKit 自動內容內距，移除兩組頂邊約束與其狀態。收起側欄或全屏時 grid.topInset 固定 0，普通窗口展開側欄時維持 18 pt。詳情控制器恢復依捲動視圖的自動內距狀態處理工具欄外觀，清除簡化版新增的重複狀態。

核對全字與詳情控制器和簡化前快照，執行邏輯的差異只剩使用者指定的固定 0 pt 頂部留白。

### LucidaSubmono 空白根因、現行安全區修正與 v1.6 功能檢查 — 2026-11-09

使用者授權修正單字安全區、多字留白、統一工具欄透明條件及 LucidaSubmono 字形表空白，另要求 v1.6 功能差異先報告。後續明確要求空白問題先找根因，不能以刷新掩蓋。

本機實際打開 LucidaSubmono 並放大視窗後，重現底部空白及收合側欄後的頂部空白。離屏量到 738 個字形，最後一格底部到文件底部只有 18 pt，最後一字形的墨跡非空。根因是 GAAllGlyphsGrid.drawRect: 按 self.visibleRect 篩選字形，忽略 AppKit 要求的 dirtyRect。系統要求畫 1484 pt 高的文件，但當下只可見 1068 pt，剩餘區域被快取成空白。收合後系統要求整張 1258 pt 高的文件，當下 visibleRect 從 y=190 開始，因而漏畫頂部。改為按 dirtyRect 與 bounds 的交集選行，未新增刷新或計時器。首尾格的離屏墨跡檢查在最大化、底部、收合及回頂均通過。此繪製寫法在 v1.6 已存在。

單字刪除把 pageLimit 下緣擴到視窗底部的指令，僅限制上緣。離屏對照受限與未受限的 H 字形，逐步縮放時下緣保持相同。全字及多字工具欄外觀統一以邊界是否進入工具欄後方決定，回頂或邊界仍在其下方時透明。

多字移除首次捲動的特殊補償，改用正常捲動位置保存，文件上方的正常邊距扣除已由 AppKit 提供的工具欄內距。使用者後續仍回報「往下推」，要求檢查邊界計算。曾試將上下邊距一起補足工具欄高度，離屏量得中心偏下 7.65 pt 歸零，但使用者指出這不是其意思。已撤回該一行變動，等待釐清實際指涉的邊界和操作。

#### 第 5 項的檢查報告，待使用者決定

逐一比對本地 v1.6 標籤與當前 15 份有差異的 Sources 檔案。31 份 Localizable.strings 各只新增 Show Sidebar、Hide Sidebar，既有字串未修改。Font、FontLayout、Input、build.sh、Info.plist 均與 v1.6 相同。既有 Objective-C 方法入口名稱沒有刪除。以下列出行為層面的發現。

| 項目 | 發現 | 驗證邊界 |
| --- | --- | --- |
| 新系統返回列表焦點 | focusGlyphList 以 searchField.superview == self.view 判斷輸入框是否在側欄。26+ 的原輸入框已放到分欄附屬視圖內，因此會被誤判成工具欄輸入框，makeFirstResponder: 傳 nil。Enter、Escape、關閉變數面板或空白區移焦可能無法返回列表 | 已確認源碼路徑，未在 26+ 實機測試，依要求暫不修 |
| 全屏展開側欄時的全字頂部 | v1.6 全屏使用 safeAreaInsets.top 作網格頂部留白。現版全屏直接 0，而自動內容內距只在收起側欄時啟用。展開側欄的全屏存在首排缺少工具欄預留的風險 | 源碼風險，仍需全屏實機核對，暫不修 |
| 字體名稱雙擊放大 | GAFontTitleField、GAFontTitleView 及工具欄字名項目的尺寸／bordered 設定與 v1.6 相同。本機重建 v1.6 對 LucidaSubmono 的字名雙擊也未放大 | 已實際操作 v1.6 對照 App，尚不能將使用者觀察歸為這幾輪新增的回歸，暫不修 |
| 字形表兩端空白 | 原有 visibleRect 篩選漏畫系統請求區域 | v1.6 已有，此次已按第 4 項授權修正 |

### 依截圖修正多字收放側欄時的上下邊距 — 2026-11-09

使用者提供同一頁面捲到最底端的兩張截圖，釐清「往下推」是側欄收放後字框底部留白不同。根因是 updateMultiLayout 將 contentInsets.top 從 viewportSize.height 扣除，而 pageArea 又用 viewportSize 計算所有頁面邊距。側欄收起時正常底部邊距因此縮小。

依截圖修正，viewportSize 保留工具欄後方的完整主視圖高度。pageVerticalMargin 以完整畫布計算居中留白，documentSize 的最小可見高度才扣除 toolbarTopInset；頁面上方的有效文件邊距扣除 AppKit 已預留的工具欄高度。工具欄覆蓋判斷同步改用實際安全可見高度。上下正常邊距均以完整畫布計算，只有原頂部留白不足工具欄高度時才補足，底部維持原邊距。

本機以 LucidaSubmono、輸入 123、放大文字並固定 414 pt 畫布高度，兩次收放側欄後捲到最底端，四次量到的底部留白均為 41.981 pt。側欄收起時工具欄高度為 52 pt，捲到頂端時已核對頂部留白足夠且工具欄透明。


### 修正功能检查中的焦点、全屏预留与字名双击，补核绘制空白 — 2026-11-09

使用者授权修正上轮功能检查发现的问题，并追问 LucidaSubmono 空白与其他字体的差异。本轮修改限于 GASidebarViewController.m、GAAllGlyphsView.m 和 GAMainWindowController.m。

focusGlyphList 改以 searchField 与 sidebarSearchField 的身份比较，避免新系统附属视图改变父视图后误判。全字视图区分侧栏收起状态与当前全屏状态，两者任一成立即由 AppKit 自动提供工具栏内容内距，网格自身顶部留白为 0；退出全屏且侧栏展开时恢复原 18 pt。字名 NSTextField 双击明确调用 NSWindow.performZoom:，保留既有拖动窗口、截断提示与缩放 delegate 路径。此双击失效也在上轮重建的 v1.6 复现，不能归为本轮新增回归。

用独立临时 App 保留旧 visibleRect 选行算法，并记录真正可见窗口的原生 drawRect 请求。LucidaSubmono 最大化时文件高 1432 pt、当前可见高 1068 pt；AppKit 请求整个文件，旧算法只遍历 738 格中的前 588 格。捲到底后没有新增 drawRect 请求，后 150 格沿用空白缓存。相同操作下 SFNS 有 2935 格、文件高 5488 pt，原生请求仅覆盖当前可见区域，捲到底又收到 y=4420、高 1068 pt 的绘制请求，故正常显示。记录证明差异与实际文件尺寸及 AppKit 请求范围有关，不能宣称所有其他字体永远不受影响，也未推断固定的系统缓存阈值。

“完整字形”与“整张字形表完整绘制”不同：旧算法会跳过整行／整格，不一定截断已绘制的轮廓；空白在该复现中是未画出的格子，并非额外添加了文件高度。正确实现按 dirtyRect 与 bounds 的交集选行，不扩大文档、不新增强制刷新。本轮未再修改该已修复算法。

macOS 14.8.7 可见窗口核对静态字体与可变字体的字名双击缩放，以及修正 App 的全屏进入、侧栏收放和退出全屏。新系统 ScrollEdgeEffect 仍依使用者要求不测试，焦点层级改动不等于已在 macOS 26 实机验收。


### 追溯 v1.6 以前的字名双击路径 — 2026-11-09

使用者继续追问更早版本。跨旧 Sources/ 与新 Sources/App/ 路径追踪后，找到 ffcbc45（2026-10-30，Fix title bar double-click behavior）为 GAFontTitleView 加入 hitTest：仅 VF 按钮接受命中，字名及空白返回 nil，字名位置的点击因而穿透到原生工具栏／标题栏处理。v1.4、v1.5 保留该规则。

b1e5d35（2026-11-06）为恢复长字名的原生截断展开，将 hitTest 改为返回字名标签，并新增 GAFontTitleField.mouseDownCanMoveWindow = YES。此举保留拖动但改变字名处的事件接收者；当时产品日志也明确写明实际双击待验收。按源码历史，这是双击失效的关键嫌疑变更，尚未重建更早版本做可见窗口 A/B，因此不将确切运行时因果说成已实测。前一轮仅核对 v1.6，范围不足以解释用户记得的更早行为；并无删除显式 performZoom 实现，而是改变了原生事件穿透路径。本轮只读历史并补充交接记录，未改产品源码。


### 清理字名拖动覆写与穿透容器 — 2026-11-09

使用者授权检查并删除 mouseDownCanMoveWindow = YES、旧点击穿透代码，及附近可精简的部分。本轮产品源码仅修改 GAMainWindowController.m；修改前备份位于 /tmp/ga-title-cleanup.CsnmJF/GAMainWindowController.before.m。

本机 macOS 14.8.7 的离屏原生控件探针量到 NSTextField label 和 NSStackView 的 mouseDownCanMoveWindow 均已为 YES，因此移除 GAFontTitleField 的同值覆写。当前 GAFontTitleView.hitTest: 并非完全失效，但只让 stack 自身的空白处返回 nil，字名与按钮均已接收正常命中；移除该专用子类及其引用，直接使用 NSStackView。GAFontTitleField 仍保留明确的双击 performZoom:，字名原生截断展开不变。

探针同时量到字名加入 stack 后 translatesAutoresizingMaskIntoConstraints 为 NO，故删除旧 NSViewWidthSizable autoresizingMask 赋值。保留零组间距、VF 右侧 5 pt、字名压缩优先级、工具栏项目尺寸以及字名变化后的展开区域更新，未把仍有效的布局及兼容路径当作冗余删除。此轮没有操作实际窗口，拖动及空白处的鼠标体验仍由使用者验收。


### 收尾检查现行完整源码与 v1.7 工作区改动 — 2026-11-09

使用者授权检查本轮全部改动及既有代码，清理能确认的冗余。沿用 codex/titlebar-sidebar-expansion，未提交或推送。清理前完整 Sources 与 build.sh 备份、引用扫描和分析记录位于 /tmp/ga-final-source-cleanup.74FCcp。

对 Sources 的 56 个文件进行接口／字段／函数引用及实验残留扫描，并对全部 28 个 Objective-C、Objective-C++、C++ 翻译单元运行 Clang 静态分析及未用私有字段检查，未发现诊断。单次出现的 AppKit 委派、事件及属性 setter 逐项排除误删。C++ 表解析接口均仍有调用；没有找到 NSTitlebarAccessoryViewController、过渡快照、自订输入框动画或动画占位条残留。保留现有侧栏原生收合、清单顶部固定、全字定位高亮，以及列表更新时禁用隐式动画的路径。31 份已改语言资源均只增加显示／隐藏侧栏两个标签。

本轮仅做三处等价精简：GAMainWindowController 的字名 paletteLabel 复用 item.label，避免重复查询同一翻译；GASidebarViewController 移除只返回系统 controlTextColor 的 inputTextColor 包装，两处调用直接取得相同系统色；GADetailViewController 的分隔线样式直接从现有 overlapsToolbar 结果派生，删除独立的初值及分支赋值。源代码变更限定这三份文件，差异保存在上述临时目录 cleanup.patch。

未合并语义不同的字体查询／布局路径，保留取消及来源版本检查、输入 Undo、TextKit 字形读取、缺字占位、PingFang 每次绘制前填充、平台布局分支和正常捲动位置保存。静态检查不能证明所有运行时路径均无冗余；本轮无实际窗口操作，GUI 仍由使用者验收。


### 全字平均分配横向空白、主视图最小尺寸与工具栏字体名提示 — 2026-11-09（横向留白与最小尺寸更新见下一节）

使用者要求全字将横向剩余空间分给各栏间及左右两端；去除整窗原尺寸限制，主视图改最小200×200pt，收起侧栏时包含标题栏；空的工具栏输入框显示字体名称。弹窗进一步确认保留侧栏200–1000pt。第四项仅征求选单建议，未修改选单。

只读分析本机macOS 14.8.7 Finder arm64e的TIconCollectionViewKeepArrangedLayout。prepareLayout（0x1005883c4）读取sectionInset、itemSize及minimumInteritemSpacing；其均分分支用可用宽度扣除各栏宽度后除以栏数加一（0x100588544–0x100588550），再保存各栏偏移，layoutAttributesForItemAtIndexPath:按栏号取偏移。资料位于 /tmp/ga-finder-objc-layout.txt 与 /tmp/ga-finder-arranged-layout.asm。此为二进制静态分析，未操作Finder界面，也不将所有Finder排列模式概括为同一规则。

GAAllGlyphsGrid改用8pt为水平最小空隙，栏间和两端取相同horizontalGap；删除旧14pt侧边距及只把多余宽度放在两端的contentLeft。格子大小及垂直8pt间距沿用原值；最后一行沿用整张网格的栏位。点选同步拆分水平／垂直步长，绘制、揭示和闪烁仍共用rectForIndex:，保留按dirtyRect选行的修正。

删除GAMainWindowController原window.minSize及详情minimumThickness=300，改在GADetailViewController以Auto Layout约束主画布高度及实际可见宽度至少200pt。26的可见宽度从safeArea左缘算起；侧栏限制与初始／保存窗口尺寸流程不变。工具栏输入框通过新setToolbarInputPlaceholder:使用同一字体显示名作为原生占位文字；不写入输入、候选查询或撤销记录，侧栏保持原提示。现行实现是两个输入控件共享编辑器，术语表原称同一控件搬移的说法已对齐。

修改前五份源码备份位于 /var/folders/7g/9md6b191673fmyv9wssspz840000gn/T/ga-grid-window-placeholder.tz3f3au4；沿用codex/titlebar-sidebar-expansion。本轮仅改这五份源码，未提交或推送。完成本机架构构建及差异空白检查；未操作产品GUI，小尺寸拖动、侧栏收放及各系统实际布局待使用者验收。

菜单建议为「隐藏／显示侧栏 → 边界框 → 颜色」，边界框保留勾选项；右键侧栏开关可置于底部独立分组，颜色维持菜单栏入口。此为建议，尚非用户决定。

### 恢复全字原始留白与换栏临界值，主视图300pt及菜单栏边界框动作名称 — 2026-11-09

使用者提供新旧布局截图，纠正上一轮误删左右14pt留白的问题：原始留白必须保留，只分配额外空间，且换栏临界值须与旧布局一致。另要求主视图改最小300×300pt，菜单栏边界框改显示／隐藏动作名称，右键菜单不变。

GAAllGlyphsGrid恢复GAAllGlyphsSideMargin=14及原来的完整栏数表达式。额外空白为max(0, (width − 28 − columns × cellSide − (columns − 1) × 8) / (columns + 1))。两端各为14pt加一份extra，栏间为8pt加一份extra。horizontalGap改名为horizontalExtraSpacing，绘制与命中共用；垂直间距及dirtyRect选行规则不变。

diagnostics/grid-spacing-thresholds-2026-11-09/保存原始网格源码、直接编译现行产品实现的离屏探针、编译记录及结果。旧栏数表达式直接从上一轮前的原始源码截取，与现行网格方法比较。覆盖21个整数缩放步及4个任意缩放值，共2610个换栏临界值；每个临界值取前后0.5pt、0.001pt、相邻double及临界值本身，共18270个宽度，新旧栏数全部相同。另核对两端14pt、栏间8pt的基础留白、extra均分、垂直间距及2464608次格子／间隙命中。

探针最初沿用前一宽度时，受产品既有0.5pt文件frame赋值容差影响，不能将请求宽度当成实际bounds。最终每个独立宽度样本先设置准确frame，再调用布局方法；结果证明各宽度的几何和换栏行为，不冒充实际窗口连续拖动。没有借此改动既有frame赋值策略。

GADetailViewController两条主视图最小约束由200改300pt。26仍按safeArea左缘计算实际可见宽度，收起侧栏时画布高度包含标题栏；侧栏200–1000pt保持。GAAppDelegate只对self.viewMenu的边界框命令更新Hide／Show Bounding Box标题，不带勾号；右键原名称及勾选保留，⌘4、命令及可用视图不变。31份语言资源仅各新增两条标题，逐键对照保留所有既有值。离屏菜单核对三种视图与显示／隐藏状态的标题、右键勾选和可用条件。没有加入右键侧栏开关或改变选单顺序。

本轮只改GAAllGlyphsView.m、GADetailViewController.m、GAAppDelegate.m及31份Localizable.strings。修改前副本位于 /var/folders/7g/9md6b191673fmyv9wssspz840000gn/T/ga-grid-threshold-menu.n731hywk。完成本机架构构建、资源格式校验及差异空白检查；未操作实际产品窗口，300pt的实机拖动下限及收放侧栏仍由使用者验收。沿用当前分支，未提交或推送。

### 全字左右基础留白改为16pt — 2026-11-09

使用者说明最新截图并未调到换栏临界值，确认上一轮实现没有问题，另明确要求左右各14pt改为16pt。本轮产品源码只改GAAllGlyphsView.m的GAAllGlyphsSideMargin常量为16。栏数、额外空白分配、绘制及点选继续共用该常量；栏间8pt不变。对应每种栏数的临界宽度较14pt版本增加4pt，这是本次调整两侧基础留白的直接结果。前一节的2610个临界值验证属于14pt版本，未将其当作16pt版本的重新实测。按默认流程仅构建，无新增测试或实际窗口操作，未提交或推送。


### 全字基础栏间距改为4pt — 2026-11-09

使用者要求栏间4pt。本轮只修改GAAllGlyphsView.m，将原共用8pt间距拆为水平GAAllGlyphsHorizontalGap=4及垂直GAAllGlyphsVerticalGap=8。栏数、额外横向空白、横向绘制及命中统一使用4pt；文档高度、纵向绘制、命中及dirtyRect选行继续使用8pt。左右基础留白16pt及额外空间均分规则保持。按默认流程仅构建，无新增测试或GUI操作，未提交或推送。


### 全字左右18pt与基础栏间距6pt — 2026-11-09

依使用者要求，只修改GAAllGlyphsView.m的GAAllGlyphsSideMargin为18、GAAllGlyphsHorizontalGap为6。行间距仍为8pt，额外横向空间继续在栏间及两端均分。栏数、绘制及命中共用原有计算路径。按默认流程仅构建，无新增测试或GUI操作，未提交或推送。


### 全字左右16pt、栏间8pt，两端各分两份额外空间 — 2026-11-10

依使用者要求，GAAllGlyphsSideMargin改16、GAAllGlyphsHorizontalGap改8；多余横向空间分配改为每个栏间1份、左端2份、右端2份，因此总份数为columns+3。rectForIndex:与indexAtPoint:的左起点同步改为16pt加2倍extra，栏间仍为8pt加extra。行间距8pt、基础栏数计算、最后一行的栏位对齐及其余布局保持原流程。产品源码只修改GAAllGlyphsView.m。按默认流程仅构建，无新增测试或GUI操作，未提交或推送。


### 全字基础栏间距改为6pt，保留两端各两份 — 2026-11-10

依使用者要求，产品源码只将GAAllGlyphsView.m的GAAllGlyphsHorizontalGap从8改为6。左右基础留白16pt、额外空间栏间各1份及两端各2份、行间距8pt均保持。栏数、额外空白、绘制与命中继续共用该常量。按默认流程仅构建，无新增测试或GUI操作，未提交或推送。


### 全字左右基础留白改为14pt — 2026-11-10

依使用者要求，产品源码只将GAAllGlyphsView.m的GAAllGlyphsSideMargin从16改为14。基础栏间距6pt、行间距8pt、额外空间栏间各1份及两端各2份均保持。栏数、额外空白、绘制与命中继续共用该常量。按默认流程仅构建，无新增测试或GUI操作，未提交或推送。


### 全字左右基础留白恢复16pt — 2026-11-10

依使用者要求，产品源码只将GAAllGlyphsView.m的GAAllGlyphsSideMargin从14改为16。基础栏间距6pt、行间距8pt、额外空间栏间各1份及两端各2份保持。按默认流程仅构建，无新增测试或GUI操作，未提交或推送。


### 作為預設值記住側邊欄狀態 — 2026-11-10

使用者要求「作為預設值」一併保存顯示／隱藏側邊欄。GAMainWindowController.saveOpeningSettings 在既有 GAOpeningSettings 字典加入 sidebarHidden，建立新視窗時在套用視窗大小後、顯示前，按保存值復用既有 toggleSidebar 流程，連同工具欄輸入框與安全區一起恢復。舊快照沒有該鍵或清除預設值後，仍預設顯示側邊欄；現有視窗不受其他視窗儲存預設值影響。產品源碼僅修改 GAMainWindowController.m，修改前備份位於 /tmp/ga-sidebar-defaults.F2XpDZ/GAMainWindowController.before.m。


### 隱藏側邊欄開檔時先初始化展開寬度 — 2026-11-10

使用者回報保存隱藏側邊欄後，新視窗首次展開側邊欄過寬。源碼原在 windowDidBecomeKey: 首次執行且側邊欄可見時才設為200pt；恢復隱藏狀態會跳過，未建立正常初始寬度。使用者確認先設寬度再隱藏，且開檔不應增加動畫。

本輪將原200pt設定移到初始化套用視窗大小之後，先完成原生佈局，再設定分隔位置，最後套用保存的隱藏狀態。刪除首次成為主視窗時的舊設定，避免重複初始化。此時視窗尚未顯示，既有 toggleSidebar 不走動畫分支；之後手動調寬及收放流程維持。產品源碼僅修改 GAMainWindowController.m，修改前備份位於 /tmp/ga-sidebar-initial-width.QihzIA/GAMainWindowController.before.m。實際視窗的首次展開寬度留待使用者驗收。


### 作為預設值保存側邊欄展開寬度 — 2026-11-10

使用者要求將側邊欄寬度加入「作為預設值」。GAMainWindowController 在既有 GAOpeningSettings 中加入 sidebarWidth：側邊欄展開時保存實際寬度，隱藏時保存每窗 sidebarExpandedWidth 記錄的收起前寬度。記錄在既有 toggleSidebar 的收合前完成原生佈局後更新，不另建分欄委派或持續寫入偏好。

建立新視窗時，在顯示前先以保存寬度設定分隔位置，再套用 sidebarHidden；舊快照沒有寬度鍵及清除預設值後維持200pt。沿用原生200–1000pt及畫布最小尺寸限制，現有視窗不因其他視窗保存預設而改寬。產品源碼僅修改 GAMainWindowController.m，修改前備份位於 /tmp/ga-sidebar-width-defaults.ysoXeq/GAMainWindowController.before.m。實際收放及新視窗寬度仍由使用者驗收。


### 量測系統文字色的深淺色透明度 — 2026-11-10

使用者提出以透明度取代換行標記的 secondaryLabelColor，要求先量測兩種外觀相對 controlTextColor 的透明度。本輪只做獨立命令列 AppKit 探針，未修改產品源碼、未啟動產品 GUI。於本機 macOS14.8.7（23J520），以 NSAppearance 的 Aqua／DarkAqua performAsCurrentDrawingAppearance 分別解析系統色為 sRGB。

淺色 controlTextColor 為黑色、alpha216/255（84.7059%），secondaryLabelColor 為黑色、alpha127/255（49.8039%）；相對 alpha 為127/216（58.7963%）。深色兩者均為白色，controlTextColor 的 alpha216/255（84.7059%），secondaryLabelColor 的 alpha140/255（54.9020%）；相對 alpha 為140/216（64.8148%）。本機兩種顏色在各外觀下 RGB 相同，差異只有 alpha。相對比例指原 alpha 乘係數，與 colorWithAlphaComponent: 直接指定最終 alpha 不同。

證據位於 diagnostics/system-text-color-opacity-2026-11-10/probe.m 及 results.json。數值僅代表本機一般深淺色外觀，不代表使用者新系統、提高對比或工具欄的實際繪製結果；換用透明度是否可消除輸入換行後整框文字變色，本輪沒有驗證。


### 換行標記改用普通文字色乘透明度 — 2026-11-10（已撤回，更新見「工具欄輸入框未編輯時取消標記單獨顏色」）

依使用者明確要求，將「⏎」換行標記由 secondaryLabelColor 改為普通文字的 controlTextColor，原有alpha在淺色乘0.59、深色乘0.65。修改集中於 GAInput.m 的既有 GASetLineBreakMarker，共用該函式的分隔符標記同樣沿用此規則；普通文字、模型分隔符與標記識別、Undo及輸入流程不變。顏色使用原生動態 provider，按傳入外觀解析普通文字色後再乘alpha，避免固定在建立標記時的外觀。

產品源碼僅修改 Sources/Input/GAInput.m，修改前備份位於 /tmp/ga-line-break-opacity.crNkyb/GAInput.before.m。工具欄整框文字變色是否改善仍待使用者實際驗收，未將此項顏色調整宣稱為已驗證的根因修復。


### 透明度方案未改善工具欄文字變色，建議先試同色標記 — 2026-11-10

使用者回報改用 controlTextColor 的淺色0.59／深色0.65 alpha後似乎仍無效，詢問其他方法。本輪唯讀查看現行輸入路徑並查閱 Apple allowsEditingTextAttributes 文件；該文件說明啟用時 attributed string 以自身視覺屬性顯示。現行普通文字與標記仍有不同 NSForegroundColorAttributeName 值，因此前輪沒有排除多色文字這個變因；文件本身不證明該新系統工具欄的內部變色機制。

建議下一步先撤去標記獨立顏色，讓標記與普通文字完全同色，以最小範圍排除多色因素。GALineBreakAttributeName 的語義記錄仍保留，換行功能與顏色不同層。此方案尚未獲執行指令，本輪不改產品源碼、不操作GUI，不宣稱根因或修復已實測。官方參考：https://developer.apple.com/documentation/appkit/nstextfield/allowseditingtextattributes?language=objc 。


### 工具欄標記顏色的原生樣式判斷與局部繪製透明度探針 — 2026-11-10

使用者拒絕讓換行標記與普通文字同色，明確要求繼續查原生繪製路徑。本輪僅診斷，未修改產品源碼、未啟動產品或操作實際GUI。證據在 diagnostics/toolbar-marker-native-style-2026-11-10/；本機為 macOS14.8.7（23J520），所有原生探針視窗均未顯示。

以現行 GASetLineBreakMarker 的實際程式建立深淺色工具欄探針。只有 GALineBreakAttributeName 語義記錄時，保留 Toolbar Control 的原生 _NSWidgetContentStyle；現行動態文字色乘alpha時，_customForegroundColorInTitle: 回傳YES，_effectiveContentStyleForTextInView: 變為 NSNullContentStyle。反組譯確認系統按每段前景色的身分、背景樣式、semantic context及視窗呈現狀態判斷能否使用原生文字樣式，並非只比較RGB數字或文字是否有兩種顏色。這些私有介面只用於診斷，未接入產品。

本機未啟用的離屏工具欄樣式會將普通文字的216/255 alpha轉為0.25；field.textColor讀值仍為216/255，說明最終樣式色不是公開textColor的直接讀值。此狀態下 secondaryLabelColor 仍被原生樣式接受，但被套成同色；因此沒有重現使用者新系統原本使用secondaryLabelColor時的截圖，不能宣稱所有系統及狀態都走相同分支。離屏 makeKeyWindow 未使視窗成為key，本輪沒有取得啟用視窗或macOS26／27的驗證。

另做只用公開繪製介面的短文字探針：保留整段原生普通文字色及換行語義，使用原生 NSSearchFieldCell 繪製，在「⏎」的局部clip區域對繪製群組套用淺色0.59／深色0.65透明度。對照單次原生繪製，2×像素下淺色189個、深色219個像素改變，標記區域外變動像素均為0。這證明短文字樣本可在不改普通文字像素的前提下淡化標記。

此為方案原理驗證，尚不是完整修正。正式實作仍需處理多標記、原生字形位置、長文字水平捲動、雙向文字、文字選取、field editor及文字圖層的繪製入口；不能將樣本的前綴寬度量測直接搬入產品。後續建議將淡化放到顯示階段，保留原生文字樣式，不再在文字資料中指定標記的不同前景色；仍待使用者決定是否進行實作。官方文字屬性優先順序參考：https://developer.apple.com/documentation/appkit/nstextfield/textcolor?language=objc 。


### 工具欄輸入框未編輯時取消標記單獨顏色 — 2026-11-10

使用者回報透明度試驗仍無效，明確要求撤回，改為僅在側邊欄收起且文字框不在編輯時取消「⏎」單獨顏色，其他狀態照常。GASetLineBreakMarker 已恢復原 secondaryLabelColor，移除 GAInputLineBreak 動態色及 0.59／0.65 倍率。

GASearchField 增加 usesUniformIdleTextColor 與 setIdleAttributedStringValue:，僅工具欄輸入框開啟；未聚焦同步與 GASearchFieldCell.endEditing: 結束編輯時，共用此入口清除顯示副本的前景色屬性，讓普通文字及分隔標記同走原生單色顯示。編輯器保留文字、分隔符及明確 GID 屬性；重新開始編輯時 prepareFieldEditor 檢查標記顏色，經既有規範化恢復 secondaryLabelColor。側欄輸入框不啟用此顯示規則。

產品源碼修改限於 Sources/Input/GAInput.h、GAInput.m 及 Sources/Views/GASidebarViewController.m；修改前備份位於 /tmp/ga-toolbar-idle-marker.RaNkLQ。實際工具欄外觀、重新編輯及收放側欄留待使用者驗收，本輪未操作 GUI。


### 標記顏色要等首次輸入才恢復的原因 — 2026-11-10

使用者回報工具欄輸入框取得焦點時標記沒有恢復灰色，要再輸入一字才生效。源碼將恢復顏色的 prepareFieldEditor 放在 controlTextDidBeginEditing: 與 controlTextDidChange:，而既有 cell 的 editWithFrame:／selectWithFrame: 焦點入口只處理 Undo 過渡與空白點擊 monitor，沒有恢復顏色。

核對 Apple 的 controlTextDidEndEditing: 官方文件警告：controlTextDidBeginEditing: 只在使用者實際輸入時通知，不等於取得焦點。因此上一輪把此通知當作焦點進入時機，造成延後恢復。修正方向是在原生 field editor 已取得焦點的現有 cell 入口即恢復標記樣式；本輪僅查原因，未改產品源碼。官方來源：https://developer.apple.com/documentation/objectivec/nsobject-swift.class/controltextdidendediting:


### 取得輸入焦點時立即恢復標記灰色 — 2026-11-10

使用者確認修正恢復顏色的時機。GASearchFieldCell 在既有 editWithFrame:／selectWithFrame: 原生呼叫完成、確認 field editor 已為 first responder 後，改經 GASearchField.fieldEditorDidGainFocus 沿用原空白點擊 monitor，並觸發 onFieldEditorFocus。兩個輸入框在建立時弱引用側欄控制器，經此回呼立即執行既有 prepareFieldEditor，不等待第一次輸入。顏色恢復仍在 transitioningFieldEditor 的既有 Undo 抑制範圍內。

刪除只轉呼叫 prepareFieldEditor 的 controlTextDidBeginEditing:，保留文字改變時的規範化，以及程式主動聚焦／替換文字時的既有準備流程。未編輯的工具欄維持原生單色，編輯時與展開側欄時仍用 secondaryLabelColor。修改限於 Sources/Input/GAInput.h、GAInput.m 和 Sources/Views/GASidebarViewController.m；修改前備份在 /tmp/ga-marker-focus-timing.b4pEKU。實際點入、鍵盤進入與未輸入即離開的外觀留待使用者驗收。


### 修正全字局部重绘漏字与侧栏收放后的列表焦点 — 2026-11-10（焦点规则已由下一节取代）

使用者要求检查本轮侧栏与工具栏改动，先报告不改代码；报告两项后，使用者明确回复「好，修」。沿用 codex/titlebar-sidebar-expansion，仅修改 GAAllGlyphsView.m、GAMainWindowController.m 及 GASidebarViewController.h／.m。修改前四份源码及本轮独立差异在 /tmp/ga-sidebar-fixes.gxkHVA/before 与 changes.patch，未提交或推送。

全字 drawRect 原来只用 dirtyRect 所在的网格行决定绘制范围；Zapfino 的 degree（GID1269）墨迹完全位于所属网格行上方，闪烁要求的局部区域因而漏掉该字形。修正保留 dirtyRect 与 bounds 交集，依据当前 CTFontGetBoundingBox、网格共用页面基线与原有2pt墨迹外扩，计算能够触及该区域的网格行。原墨迹外扩抽为 GAAllGlyphsInkOutset，由闪烁失效范围与绘制共用；不回退 visibleRect、不新增强制刷新、不每帧遍历全字体。

侧栏收起前通过新增只读 isGlyphListFocused 记录列表是否持焦，展开结束后在窗口仍为 first responder 且没有输入选区待恢复时返回列表。输入框选区恢复保持优先，其他控件已取得焦点时不覆盖；展开完成后清除本次记录。

本机macOS14.8.7以当前产品源码编译独立离屏探针。Zapfino degree 的局部重绘前后深色像素均为40，修正前同一探针从40变0；列表收起后为NSWindow、展开后恢复GASidebarTableView，原输入选区、换行和Undo／Redo探针保持原结果。证据为 /tmp/ga-sidebar-fixes.gxkHVA/grid-probe-results.json 与 probe-results.json；前轮探针源码在 /tmp/ga-sidebar-review.swydcL/。本机编译、链接及App组装完成；签名阶段仍被产物的Finder扩展属性阻止，依既有协作边界未处理此项。本轮未操作实际窗口，动画及macOS26／27的实际焦点行为仍由使用者验收。


### 按展开时的焦点决定恢复目标，厘清 v1.6 与闪烁漏画的版本边界 — 2026-11-10

使用者授权按三条规则改焦点并删除旧判断：工具栏输入框编辑中则恢复侧栏输入框及选区；输入已失焦且焦点在主窗口则返回字形列表；其他控件持焦则保留。GAMainWindowController 展开完成分支删除 sidebarHadGlyphListFocus 条件，移除该字段及收合时的记录、展开时的清除，同时删除 GASidebarViewController 的 glyphListFocused／isGlyphListFocused 接口与实现。原有切换完成时检查 firstResponder 是否仍为主窗口的保护保留，避免覆盖期间新取得的控件焦点。修改仅这三份源码，备份及差异在 /tmp/ga-focus-current-state.XPyoc9/before 与 changes.patch；沿用当前分支，未提交或推送。

本机macOS14.8.7独立离屏探针确认：工具栏输入框持焦时展开仍恢复输入框与选区；使用者描述的输入框持焦收起→失焦到主窗口→展开，最终为 GASidebarTableView；另一个 NSTextView 持焦时展开后仍保留。证据位于 /tmp/ga-focus-current-state.XPyoc9/focus-probe.m 与 focus-results.json。本轮未操作实际窗口，动画及其他系统由使用者验收。

使用者指出 v1.6 未遇到闪烁擦掉字形。重新核对 v1.6 标签的 GAAllGlyphsView.m：旧版用 visibleRect 选行，未采用只按 dirtyRect 所在行选字形的后续写法。用标签中的原始网格实现，在目标字形所属格位于可见区时做同一 Zapfino degree（GID1269）局部重绘，深色像素前后均为40；本工作版修复前为40→0、修复后为40→40。此案例是改用 dirtyRect 后引入的回归，不应称为 v1.6 已有的闪烁 Bug；它与日志此前记录的 visibleRect 漏画系统请求的非可见区域是两件事。证据为该目录 GAAllGlyphsView-v1.6.m、v1.6-grid-probe.m 与 v1.6-grid-results.json。最初探针未滚动到目标、旧实现连初次绘制也为0，不用于证明闪烁结果；最终探针先将目标滚入可见区，前后均为40。

本轮本机架构构建及App签名完成，build.log 保存在本轮临时目录。


### 字形表重绘方案的隔离性能比较与UI前提修正 — 2026-11-10

使用者要求实测现有可行方案的性能并淘汰明显不合适的方案，仅做诊断；产品 Sources、Resources 与 build.sh 均未修改。隔离源码、生成／编译脚本、优化构建探针、原始结果、统计及审计在 diagnostics/grid-redraw-performance-2026-11-10/。GAAllGlyphsView.original.m 与当前产品源码的SHA256一致，source-hashes.json 中所有产品.m文件也保持原值。

比较四种候选：0 当前font-wide bounds外扩选行；1 同样选行后用已有单字墨迹与dirtyRect相交再提交绘制；2 先量全字形实际垂直伸出范围并快取，选行后同样按单字墨迹过滤；3 闪烁时用visibleRect与dirtyRect的网格行并集选候选，普通绘制维持当前路径。全视口失效、每次重绘扫全部字形不列为候选；全字实际墨迹过滤只作为不计性能排名的正确性对照。

使用者指出「格子已在视口外但仍需要闪烁」不符合产品UI，明确要求不能作为淘汰理由。已移除该测例，按目标格在视口内的实际闪烁场景重跑全部测试；不将原探针在该情景的差异用于判断。原模式3还改变普通绘制的版本也不参与最终排名，最终模式3只改变闪烁路径。环境审计记录两轮弃样原因；LucidaSubmono最初按未注册名称找字体时替成Helvetica，后已改读 /Users/zonz/Library/Fonts/LucidaSubmono.otf 的实际descriptor，确认738字形，重新测量。

本机Apple M3／macOS14.8.7；6套字体资源、7个实例（Helvetica、Lucida Submono、Zapfino、Apple Symbols、蘋方简体、系统字默认与轴最大请求），字形数738–49519。3组窗口／格子缩放×1×／2×像素密度，共42种配置。每配置测闪烁、小条带捲动补画、整视口、超过视口的系统缓存请求；每方案168次影像对照均与全字实际墨迹参考逐像素相同。独立离屏位图窗口未显示，不测GUI调度、合成或实际屏幕帧率。

以产品相同-O2／LTO构建，当前方案保留原绘制循环顺序。各工作负载按轮换顺序测7组批次，每批至少8次、按校准最多180次，统计每次绘制耗时中位数；常规比较使用已建立的字形度量快取，另以全新网格快取独立测首次绘制3次。系统字体原生快取已暖，字体解析与库存构造为共同前置成本，不计首次绘制。

42组配置中位数（µs／次，按0／1／2／3顺序）：闪烁25.434／9.037／8.923／91.335；小条带捲动38.698／18.666／18.474／38.381；整视口201.066／179.865／178.733／198.467；较大缓存请求295.244／266.566／267.327／292.787。模式3普通绘制与0同一路径，少量数值差异不作为优化收益。闪烁提交绘制数的配置中位数为22／1／1／99；没有让整个visibleRect失效。

预量所有实际墨迹的稳态收益很小，代价是蘋方49519字形的预处理约162.524ms；首次绘制中位数为模式1约0.427ms、模式2约164.455ms。其他字体预处理约1.263–10.023ms。推荐模式1：保留当前边界选行，按已有真实墨迹过滤实际绘制；模式2因首次代价与维护成本不推荐，模式3因有效闪烁场景的实测较慢不推荐，不以不可能的UI情景淘汰。建议尚未接入产品代码，等待使用者决定。详见results.json、summary.json及environment-and-audit.json。


### 接入目前选行加单字墨迹过滤并共用几何计算 — 2026-11-10

使用者明确要求采用性能比较的模式1「目前选列＋单字墨迹过滤」，同时清理不再需要的旧代码并解释机制。本轮产品源码只修改 Sources/Views/GAAllGlyphsView.m，沿用 codex/titlebar-sidebar-expansion，未提交或推送。修改前源码、独立差异与接入验证归档于 diagnostics/grid-redraw-performance-2026-11-10/integration/，工作副本在 /tmp/ga-ink-filter-integration.hugdhH。

保留当前按dirtyRect及字体整体边界外扩的候选行计算。每个候选先读取已有pageMetrics，跳过空墨迹，以绘制原点及缩放换算单字墨迹外接框，再检查其与绘制区域相交；未相交即跳过颜色设置及CTFontDrawGlyphs。字形颜色与GID读取移到过滤之后，删除原位置的重复页面／原点读取。既有redrawRectForIndex:中的坐标换算及2pt抗锯齿余量提取为静态GAAllGlyphsInkRect，两处共用，保持闪烁失效区域与绘制过滤一致。没有接入诊断模式开关或预量全字墨迹方案，没有更改格子布局、字体度量、闪烁时序及焦点规则。

以当前实际产品源码与重命名的隔离参考网格同时编译优化探针。复用最终性能比较中符合UI前提的42种配置及4种绘制请求，与全部字形按真实墨迹过滤的参考逐像素比较，168项差异均为0。verify.m、verification.json与构建记录保留在integration/；原性能比较文件保持不变，避免覆盖接入前基线。本机架构构建与App签名完成，未操作实际窗口。


### 普通版面 visibleRect 与 dirtyRect 的隔离性能比较 — 2026-11-10

使用者澄清关心一般版面渲染而非闪烁，并要求实测。本轮只做隔离测量，未修改产品 Sources、Resources 或 build.sh；开始与结束逐文件SHA256核对一致。证据位于 diagnostics/grid-layout-render-performance-2026-11-10/，包括当前源码快照、生成与构建脚本、benchmark.m、results.json、summary.json、environment-and-audit.json、独立边界复现及影像。旧性能目录保持原样。

从当前实际源码生成四种对照：0 dirtyRect选行＋现行单字墨迹过滤；1 visibleRect选行＋相同过滤；2 dirtyRect选行不加过滤；3 visibleRect选行不加过滤。四种均沿用相同字体整体边界外扩、安全余量、原点和实际dirtyRect绘图裁切；仅替换候选范围并控制过滤开关。模式4扫描全字实际墨迹作为像素参考，不参与排名。没有闪烁、颜色变动、全视口失效。visibleRect数值由探针提供，未测属性getter成本、真实窗口调度或合成；也未测字体解析、库存构造与视图创建。首次绘制指新网格度量快取，系统字体快取已暖。

Apple M3／macOS14.8.7，沿用7字体实例×3种视口／格子缩放×1×／2×密度，共42配置。每配置测顶部整视口、上缘24pt补画、下缘24pt补画、中段整视口和1.5视口缓存请求；每模式7组轮换批次，每批8–240次。冷度量首次绘制也以7次轮换测量。

每次耗时的42配置中位数（µs，按0／1／2／3）：顶部整视口175.633／175.674／175.603／175.815；上缘条带18.708／24.151／38.421／105.825；下缘条带20.346／27.052／40.241／106.245；中段整视口178.710／177.777／197.058／196.630；缓存请求271.946／211.624／293.335／226.613。冷度量首次绘制433.854／430.854／428.458／428.188µs；保留过滤时两种矩形的配对首次耗时几何平均比0.998，整页差异接近噪声。合并上下缘条带：保留过滤dirty19.442µs、visible24.812µs，逐配置配对耗时比中位数1.343；不加过滤dirty39.271µs、visible105.825µs。缓存请求中visible方案少画了内容，不能将其较短时间当性能优势。

840次影像对照发现：dirty模式0／2各有1项顶部视口差异；visible模式1／3各有同一项差异，另有38/42项缓存请求漏画，全部缓存请求的当前可见区仍相同。共有差异位于System-axis-max（系统字体各轴最大值请求，最终变体名.SFNS-Regular_wdth960000_opsz600000_GRAD3E80000_wght3E80000），600×400pt视口、cellScale2、2×像素密度的顶部首屏。实际dirtyRect与visibleRect相同，四模式同样漏掉GID24／26共42px；不是矩形选择造成。独立复现6/6次一致。所属下一行从y402pt开始，含余量墨迹分别从y397.213／398.601pt伸入画面；整体font bbox maxY为191.40625 shaping pt，而GID24／26实际maxY为200.68359／196.97266pt，页面高度及基线相同。确认之前整体font bbox保守包含所有变体实际墨迹的前提在此实例不成立；这是新增加顶部测例才发现的现行选行边界问题，尚未修复。未使用UI不可能的视口外目标闪烁情景作判断。

独立差异探针曾两次因将数字键variation字典直接JSON序列化而退出，最终改以description字符串记录，完整成功结果为difference-inspection.json；两次退出不影响正式benchmark或排名。产品代码、当前分支及未提交工作均保留，未操作真实窗口，未提交或推送。


### 变体选行边界问题的修正方向与原生批量量测初探 — 2026-11-10

使用者询问上轮新发现漏画问题的建议，未授权产品修改。核对本机SDK CTFont.h与Apple官方CTFontGetBoundingRectsForGlyphs文档：可一次传入字形数组，boundingRects=NULL时只返回合并外接框。隔离探针batch-bounds-probe.m对当前7字体实例的全部GID调用该API，再与逐字输出的矩形合并对比；7实例上下界均覆盖全部逐字结果。System-axis-max的真实合并框为{{-142.96875,-69.23828125},{906.25,281.34765625}} shaping pt，确实扩大到原font bbox以外；本轮未接入绘制，也未宣称已完成新方案的影像验证。

批量调用首次耗时为Helvetica0.170ms、LucidaSubmono2.698ms、Zapfino0.096ms、AppleSymbols0.257ms、PingFangSC-Regular114.585ms、系统字默认8.335ms、系统字极端轴值9.025ms。后续7次调用中位数分别0.096／0.800／0.059／0.180／117.488／6.416／7.322ms。只能说比构造全字page更直接，不能说大字集量测便宜；原生接口内部仍须处理字形。完整结果为batch-bounds-results.json。

建议保留dirtyRect与单字墨迹过滤，优先隔离验证「只对非预设变体实例量测真实上下界，并按字体实例快取，改轴即使用对应新范围」的限定修正方向；不能将普通字体原font bbox的可信度或此方向的大字集／拖轴成本当作已验证。固定多补一行只修当前样例，没有一般边界依据；回退visibleRect不能修复两种矩形相同首屏中的共同遗漏，也会恢复系统缓存区域漏画问题。尚无产品改动、构建或GUI操作，先给建议及成本依据，等待进一步范围决定。

官方来源：https://developer.apple.com/documentation/coretext/ctfontgetboundingrectsforglyphs(_:_:_:_:_:)


### 漏画墨迹的图像展示 — 2026-11-10

使用者要求截图查看上一轮边界Bug。复用独立探针实际导出的actual.png与reference.png，原图各1200×800px；原生位图逐像素确认42px差异集中在x113–137、y798–799。未修改或生成字形图像，仅在本地HTML并列显示两张原图，以CSS nearest-neighbor放大原图x100–159、y784–799区域8倍，并标示视口底缘与原图对应位置。浏览器截取最终对照页保存为diagnostics/grid-layout-render-performance-2026-11-10/bug-comparison.jpg，页面为bug-comparison.html。明确告知这是原生离屏渲染证据，不是App实际窗口截图；未启动Glyph Atlas或改产品源码。临时本机HTTP服务完成后关闭。


### 接受首屏边缘墨迹差异，决定不修 — 2026-11-10

使用者看过放大对照，询问是否仅在视口底缘、捲动后是否正常。已区分：目前实际复现的是底缘；按选行机制推断捲入候选范围后会正常绘制，但尚未实际捲动验证，其他重绘边缘的可能性也仅为推断。使用者明确决定「那就没必要修啦，不影响视觉」。据此接受本次少量边缘墨迹差异，不实施变体全字边界预量／快取或其他修正，保留现行dirtyRect选行加单字墨迹过滤。此前批量量测仅为诊断证据，不再视为待接入或待修任务。未修改产品代码。


### 觸控板存在判斷與系統設定顯示條件研究 — 2026-11-10

使用者討論無觸控板的精細行距操作，要求收集觸控板存在判斷資訊，並追查系統設定如何決定顯示觸控板項目。本輪僅研究、獨立命令列探針與離線反組譯，未改產品源碼、未操作 GUI。證據位於 diagnostics/trackpad-detection-2026-11-10/。

macOS 14.8.7 的 TrackpadExtension 設定檔將顯示表示式設為 device.trackpad == YES，另一條 != YES 的表示式 hidden=1，另宣告 providesAvailabilityCheck。側邊欄 predicate 值的完整上游尚未追通，不將其與頁面自己的 isAvailable: 混稱同一條件。後者使用 currentTrackpadType 與上蓋狀態；type 來自私有 PreferencePanesSupport 的 MTTGestureBackEnd。該後端透過公開 IOKit 的裝置服務比對，包含 ApplePreferenceIdentifier=com.apple.AppleMultitouchTrackpad、ApplePreferenceCapability=2、部分 ProductID、外接 BNBTrackpadDevice 及舊驅動分支；這些 Apple 屬性與分類是私有實作細節，不是公開的存在判斷保證。

獨立公開 IOHIDManager 探針列到 21 個 HID 介面，其中一個的完整用途含 Digitizers/Touch Pad（13,5）。只比對 PrimaryUsage 會回傳0，因本機內建觸控板主要用途為 Mouse（1,2）；改用 DeviceUsagePage/DeviceUsage 比對能得到1。裝置名稱在鍵盤與多個 vendor 介面也相同，不能只憑名稱。IORegistry 的 Apple 偏好屬性比對同樣找到一個 AppleMultitouchTrackpadHIDEventDriver，Built-In=true。探針未 open 裝置、未讀輸入報告，未出現權限提示；不擴大為跨系統權限保證。外接 Magic Trackpad、有線／藍牙、新系統和無觸控板電腦尚未實測。


### Lucida Submono 特性篩選失效診斷 — 2026-11-10

使用者要求查明 Lucida Submono 特性篩選選項失效。本輪只讀產品程式及字體，執行獨立命令列探針與隔離試修，未修改產品 Sources／Resources／build.sh、未操作 GUI。證據位於 diagnostics/lucida-feature-filter-2026-11-10/，隔離工作目錄為 /tmp/ga-lucida-filter.GpKsrQ。

讀取 /Users/zonz/Library/Fonts/LucidaSubmono.otf 的真實 descriptor，確認 PostScript 名稱 LucidaSubmono-Regular、738 個字形。GSUB 有四筆同名 calt feature，均指向 lookup 6；選單去重後只列 calt。全表共 7 個 lookup（有效編號 0–6），lookup 6 的 3680 個 extension subtables 中含 7944 筆 lookupListIndex=65535 的上下文動作引用。直接讀取原始字體位元組核對，並非 UI 或 CoreText 字體替代造成。

現行 GAGlyphCatalogue.cpp 的 FeatureOutputs.collect 遇越界 lookup 即拋出 InvalidTable（feature lookup outside list），GASubstitutionEngine 捕捉後回傳 nil；「無特性」依賴所有特性完整輸出，同樣回傳 nil。控制器保留原畫面與勾選，所以點選時看似無反應。現行這兩份 FontLayout 源碼與本地 v1.6 標籤相同，不是本輪側欄或局部繪製修改新增的邏輯。

在 /tmp 的 GAGlyphCatalogue.cpp 副本中只將越界 collect 改為返回，保留其他動作及原有順序；使用相同正式引擎重新查詢，calt 輸出 51 個字形，「無特性」687 個字形，合計 738。這只是篩選查詢的隔離試驗，未驗證 GUI 或宣稱與 CoreText 完整排版等價。建議讓特性篩選與既有文字執行器／單字目錄對越界嵌套引用的處理一致，僅忽略該引用，不因一筆越界中止整個特性；尚未獲准接入產品。OpenType Sequence Lookup Record 定義 lookupListIndex 為 LookupList 零起算索引：https://learn.microsoft.com/en-us/typography/opentype/otspec184/chapter2 。


### 核對 Lucida Submono 的 65535 動作：原始欄位與不替換語義 — 2026-11-10

使用者要求先查清 calt 的 7944 筆 65535 是否為有效資訊，避免將自己的解析錯誤當作字體錯誤。本輪只研究與獨立命令列量測，未改產品源碼、未操作 GUI。補充證據在 diagnostics/lucida-feature-filter-2026-11-10/independent-check/；venv、臨時字體副本與可執行檔在 /tmp/ga-lucida-filter.GpKsrQ。

FontTools 4.60.2 獨立解析同一原字體，確認 7 個 lookup 與 7944 筆 SubstLookupRecord.LookupListIndex=65535，與自寫原始位元組讀取和產品解析一致；不是 extension 相對偏移或動作欄位讀錯。lookup6 共 3680 條規則，每條恰好為每個 input 位置依序列一筆動作（SequenceIndex=0…GlyphCount-1）。65535 與正常替換動作混合分布，沒有整條規則全為65535的案例。Objective-C 規則中 O→O.w1、j→j.t1、t→t.t0、i→i.t0、C→C.w0；e、c、v、e、hyphen 的動作為65535。字體名稱記錄版本為 Version 1.000;Glyphs 3.1.1 (3135)。

以 FontTools 建立兩份僅供診斷的副本：一份只移除65535動作記錄、保留全部上下文輸入與其他動作；另一份增添明確的 identity single lookup（原字換原字），將65535改為該有效編號7。從每條規則選取可編碼字形構造代表文字，另加常用樣本，去重後3685組。HarfBuzz12.1.0（uharfbuzz0.51.7）逐組比較三版的完整GID／cluster／advance／offset無差異，其中3682組的原字體結果確實受calt影響，排除三版全部沒套用calt的假通過。CoreText在macOS14.8.7對同樣3685組逐組比較GID、UTF-16索引、position及advance亦無差異。CoreText以CGFont資料提供者載入，逐份核對實際CTFontCopyTable(GSUB)與各原檔GSUB位元組一致，並拒絕fallback run，避免同名快取或替代字體使對照失真。這是各規則的代表輸入，非所有Coverage組合的窮舉；無GUI驗收。

OpenType1.9.1 SequenceLookup record只定義lookupListIndex為LookupList零起算索引，沒有賦予此欄位0xFFFF特殊不替換語義；requiredFeatureIndex的0xFFFF是另一欄位的明確定義，不能混用。HarfBuzz12.1.0的GSUB遞迴取得lookup accelerator時，越界索引回nullptr，執行回false，不中止其餘動作。故可確認：此欄位值在規範上不是有效lookup編號，但此字體在CoreText／HarfBuzz實際等同不替換，不能僅因該值判整條規則或整個calt無效。上一輪直接稱字體壞資料的定性過早；應區分欄位事實、規範有效性、引擎執行語義和未知的生成原因。

生成原因仍是推測，尚無這份字體原始.glyphs／feature生成腳本。查到alphaArgon的submono文章描述五種寬度組與大量GSUB規則；其公開Caesium/scripts/apply.js對不改變位置寫lookup _，定義為sub .notdef by .notdef，可作相近方案的佔位設計佐證，但不能證明LucidaSubmono的來源或Glyphs3.1.1將identity lookup移除後留下-1／FFFF的確切過程。未將「Glyphs導出bug」寫成已確認原因。

官方／原始來源：
- https://learn.microsoft.com/en-us/typography/opentype/spec/chapter2#sequence-lookup-record
- https://raw.githubusercontent.com/harfbuzz/harfbuzz/12.1.0/src/hb-ot-layout-gsubgpos.hh （get_accel越界回nullptr）
- https://raw.githubusercontent.com/harfbuzz/harfbuzz/12.1.0/src/hb-ot-layout-gsub-table.hh （dispatch_recurse_func未取得accel時回false）
- https://argon.red/posts/typography-stuffs
- https://github.com/alphaArgon/Caesium/blob/main/scripts/apply.js

修正產品仍未授權，本輪不接入上一輪試改。日後若修改須保留完整上下文條件，只略過不執行的那筆動作；不能刪整條規則、刪輸入位置、改動後續SequenceIndex或編造不存在的替換輸出。


### 修正特性篩選的越界嵌套動作處理 — 2026-11-10

使用者明確要求「只略過這些越界動作，保留完整上下文和其他替換，修好特性篩選」。沿用 codex/titlebar-sidebar-expansion，產品程式只修改 Sources/FontLayout/GAGlyphCatalogue.cpp 一行：FeatureOutputs.collect 收到超出 lookup 列表的索引時直接返回，不再拋出使整項特性查詢失敗的 InvalidTable。保留原有 budget／取消檢查、所有上下文條件、輸入位置、其他動作和順序，不修改字體、一般排版或候選發現路徑。沒有特判65535，也沒有移除整條規則或輸入位置。

以修正前獨立物件與本次正式構建的 FontLayout 物件透過公開 GASubstitutionEngine 介面核對：LucidaSubmono 的 calt 與「無特性」由 nil 恢復為51／687個字形；兩集合不重疊，聯集恰為原738個GID。兩項完整GID清單均與上一輪僅移除65535動作、及改為明確identity動作的字體副本完全一致。Arial 的9個特性及「無特性」共10項完整GID清單修正前後相同。本機架構構建成功，git diff --check 無問題；未啟動App或做GUI操作，使用者負責選單實機驗收。

改前源碼、獨立單行差異、探針、前後完整結果及構建記錄在 diagnostics/lucida-feature-filter-2026-11-10/integration/。未提交或推送，既有工作區其他變更保留。


### 將額外行距改為原生行高倍率 — 2026-11-10

使用者已回覆「好，沒問題了」驗收LucidaSubmono特性篩選修正，接著明確要求將「行距」改為「行高」，每次倍率為現行1.12的平方根，上下限各為從原生值調整20次。使用者特別指出兩者是TextView的不同參數，英文必須為line height，並要求舊行距直接丟掉。沿用codex/titlebar-sidebar-expansion，未提交或推送。

多字預覽移除原本額外行距的CTFont ascent／descent／leading手動計算和paragraph.lineSpacing賦值，直接設定原生NSMutableParagraphStyle.lineHeightMultiple。GAMultiGlyphView同名屬性初始1倍，setter統一夾緊於1/1.12^10…1.12^10（0.3219732366…3.1058482083倍），相當於每次乘／除√1.12（1.0583005244）各20次。Detail的adjustLineHeight:使用pow(GAGlyphZoomStep,steps*0.5)，重用現有倍率常數，不改文字或邊界框的縮放步長。

主選單、Control-Command加減快捷鍵、GADropWindow事件派送及Controller／Detail接口都改用行高動作；仍限多字模式。縱向撐捏使用手勢開始時的行高乘以1+magnification連續調整，保留原角度判定、方向鎖定與捲動位置保存。Command-0一次將共享框、字級和行高重設，行高回到1倍。整套開檔快照改寫lineHeightMultiple鍵；舊lineSpacing鍵不讀、不轉換，新快照不寫。其他快照設定維持。

31份語系的選單鍵改為Increase Line Height／Decrease Line Height，譯名與Help.12同步改為行高；Help.13移除多餘的額外行距說明，既有Klingon泛稱維持。已逐份核對相對修改前資料，資源變動只含這兩個選單鍵和Help.12／Help.13，未重譯其他字串。根目錄對外README未改。

本輪產品改動限7份源碼（GAAppDelegate.m、GAMainWindowController.h／.m、GADetailViewController.h／.m、GAMultiGlyphView.h／.m）及31份Localizable.strings。修改前逐檔副本在/tmp/ga-line-height.g8CZia/before；本輪獨立差異及構建記錄保存在diagnostics/line-height-2026-11-10/。本機架構構建成功、資源plutil與git diff --check通過；僅做源碼／差異核對及構建，未執行行為測試或操作GUI，原生行高在實際橫排／豎排、重疊與視窗捲動的外觀由使用者驗收。


### 還原行距／Leading的介面用詞 — 2026-11-10

使用者按實際TextKit效果要求將翻譯還原為「行距／leading」。本輪只將GAAppDelegate.m的兩個NSLocalizedString鍵與翻譯註解恢復為Increase Leading／Decrease Leading，並從上一輪改名前副本精確還原31份語系的兩項選單及Help.12／Help.13。本輪開始時資源已另有分組／排序整理，僅按鍵替換目標四項，保留當前排序、註解與所有其他鍵值；逐份核對非目標鍵值與本輪修改前相同。

內部lineHeightMultiple屬性、原生段落參數、快捷鍵與action、縱向手勢、√1.12步長、上下各20步範圍、1倍預設值與快照鍵均保留。沒有恢復舊lineSpacing計算或舊快照讀取。介面稱Leading屬使用者的產品命名決定，不宣稱兩個原生參數相同。未修改對外README，未提交或推送。改前副本及單輪差異在/tmp/ga-leading-labels.d56xjcqi；僅構建及差異核對，不做行為測試或GUI操作。


### 行距倍率改變首行頂部留白的計算研究 — 2026-11-10

使用者觀察lineHeightMultiple會增加／減少頂部空白，希望頂部與1倍一致，詢問計算方法。本輪只讀現行GAMultiGlyphView與本機NSTextLineFragment公開header，執行獨立離屏TextKit2探針；未修改產品程式，未操作GUI。證據在diagnostics/leading-top-offset-2026-11-10/，工作目錄/tmp/ga-leading-top.R8dvow。

本機macOS14.8.7，Helvetica、LucidaSubmono（讀取實際檔案descriptor）、PingFangSC、Zapfino各51pt，橫／豎排、4種文字（兩行、軟換行、首段空行、尾段空行）、6個倍率（下限、0.5、1、√1.12、2、上限）共192組。首行在容器座標的基線位置由layoutFragmentFrame.minY＋typographicBounds.minY＋glyphOrigin.y取得。Lucida橫排1倍基線48pt、0.5倍16.5pt、2倍111pt，分別需向下31.5pt／向上63pt，首行正常高度63pt。Helvetica橫排1倍的TextKit行高61pt，而CTFont ascent＋descent＋leading為51pt，不能把CTFont度量直接當TextKit正常行高。

建議補償量Δ=B(m)−B(1)，按同一文字容器座標讀實際首行基線；整段文字在行進方向的垂直軸移動−Δ，內容長度也扣同一Δ，保留正常頂端及尾端留白，後續行距維持原生。1倍參照需對應當前字體／字號／變體／排版方向／首行顯示內容，不能只存全域常數。單一方向上本輪192組的基線差均等於首行typographic高度差（浮點誤差）；因此可用實測H(m)−H(1)表示，但直接基線差最貼合目標。

橫排測例可化簡Δ=(m−1)×H(1)，不是多出行高的一半；但PingFang的豎排20個非1倍測例不符合這個簡式。例：豎排Hx在1倍首行高度約103.0001pt、0.5倍約77.0001pt，差−26pt，而直接乘正常總高會預測−51.5001pt。不可把橫排公式當跨方向保證。這些是獨立TextView測量，不是App像素／捲動／點擊／固定GID和缺字附件驗證；實際接入時還須同步頁面尺寸與文字位置，不能只挪繪圖。建議尚未接入，等待使用者決定。

公開API依據：https://developer.apple.com/documentation/appkit/nstextlinefragment/glyphorigin 及 https://developer.apple.com/documentation/appkit/nstextlinefragment/typographicbounds ；語義亦核對本機SDK的NSTextLineFragment.h。


### 首行留白補償的其他方案比較 — 2026-11-10

使用者詢問有無其他方案。本輪繼續獨立TextKit2離屏量測，不改產品程式。第一批96組比較原生paragraphSpacingBefore、lineSpacing、固定minimum／maximumLineHeight、NSBaselineOffsetAttributeName與textContainerInset；第二批以與前輪相同的192組比較原lineHeightMultiple平移首行基線後的目標和改用lineSpacing的結果。探針與結果附於diagnostics/leading-top-offset-2026-11-10/。

改用lineHeightMultiple=1、lineSpacing=原首行基線差，可在本機接受負行距，Lucida兩行測例的首行保持48pt且下一行距離可匹配。不能因此宣稱整體等價：192組中46組基線序列不符，包含首段空行；46組usageBounds高度不符，包含負行距時仍按原片段高度回報的情形。要採用須另處理空段與文件尺寸，並且更換已選定的原生排版參數；不推薦作此次等價替換。

paragraphSpacingBefore沒有補償首段基線，反而改動後續段落；baselineOffset在本輪測例會改變原生行片段高度與行距，並非只挪繪圖位置；固定minimum／maximumLineHeight仍有相同首行基線變動，不能獨立解決。修改textContainerInset可搬移容器，但本機textContainerOrigin取整（原40.56為40），且對上下兩側都作用，不能單獨視作精確補償方案。獨立建立NSTextLineFragment並將樣式改1倍的嘗試未得到有效高度（typographicBounds.height=0），不能當成已驗證的一行量測捷徑。

較小的計算替代是採原生首行高度差H(m)−H(1)，前輪192組等同基線差；仍需正確的1倍參照，不能用CTFont ascent+descent+leading替代。另一個較大方向是自訂TextKit2 layout fragment以固定首行起點並重算後續布局，公開NSTextLayoutFragment提供自訂margin與繪製入口，但本輪未實作或驗證此方案，不宣稱加一個override即可完成。以上均為方案評估，未獲准產品接入。


### 直接對比首行基線差與首行高度差補償 — 2026-11-10

使用者要求對比兩方案。本輪從當前Sources建立隔離快照，將真正GAMultiGlyphView、GAFontDocument及完整FontLayout連同其他App依賴編入獨立命令列探針，走現行原生顯示字串、固定GID與缺字附件剔除管線。未修改產品源碼、未建立或操作實際視窗、未把任一補償接入產品。完成後逐檔SHA256核對產品Sources與開始快照一致。證據在diagnostics/leading-compensation-comparison-2026-11-10/（完整結果results.json.gz、compare.m、summary.json、Sources快照、構建／執行記錄），工作目錄/tmp/ga-leading-comparison.q45uHC。

Apple M3／macOS14.8.7，9個字體實例：Helvetica、PingFangSC-Regular、Zapfino、AppleSymbols、AppleColorEmoji、GeezaPro、實際LucidaSubmono檔案、系統字預設與各軸最大請求。3個文字縮放0.5／1／2 × 橫／直排 × 12種文字／顯示案例（單行、硬換行、自動折行、首段空行、尾段空行、行／段分隔、組合附標、中字、阿拉伯文、emoji、固定GID、起首零尺寸缺字附件）×6個行距倍率（下限、0.5、1、√1.12、2、上限），共3888組。各實例的非支援文字仍走產品既有缺字剔除，未把fallback字體的幾何當所選字體；不是3888份全部含可見墨跡的畫面。

各組以同一當前顯示內容的1倍原生布局為參照：基線法ΔB=B(m)−B(1)，B=layoutFragmentFrame.minY+typographicBounds.minY+glyphOrigin.y；高度法ΔH=H(m)−H(1)，H=首行typographicBounds.height。將兩Δ分別套入整段平移及usage內容長度扣除的數值計算，3888組均等效：最大Δ差1.4210854715202004e-14pt，高度法補償後首行基線誤差同值；補償後內容長度差最大2.2737367544323206e-13pt。首行top位置變動0，基線到底緣的距離保持一致至浮點誤差，解釋本輪兩公式相等的原因。原生行數與顯示字串在各倍率間均未改變。這是原生幾何與公式比較，未做兩版位圖、實際App捲動、裁切或點選驗收。

LucidaSubmono51pt、三行Hx：0.5倍兩方案Δ均−31.5pt，1倍均0，2倍均63pt；扣除首行多出／缺少的空白後內容高度依次126／189／315pt，首行相對字框頂端基線均回48pt。後續原生行距不改。

兩法皆需同一份有效的1倍首行參照與目前布局，高度法沒有減少一次參照布局或排除參照更新條件。前輪「計算較簡單」僅指讀取一個height，基線法多讀兩個origin並相加；本輪未做getter微效能測量，不能宣稱可感知速度差。基線法直接針對首行繪製位置，高度法依賴本輪成立的「首行top及基線到底緣距離不變」關係。兩法現行結果相同，若優先精確表達產品目標，較傾向基線差；不是發現高度法有現行失敗案例。尚待使用者選定，不實作或修改產品。


### 接入首行基線差補償與有條件的1倍基準快取 — 2026-11-10

使用者明確選定基線法，要求先檢測基線變化條件，只在需要時重讀；並糾正同一窗口始終是同一字體，不存在換字體。沿用codex/titlebar-sidebar-expansion，產品源碼只修改GAMultiGlyphView.m，未提交或推送。修改前源碼、單輪patch、最終源碼、探針和原始量測歸檔於diagnostics/baseline-anchor-2026-11-10/，工作目錄/tmp/ga-baseline-anchor.7qplEy。

先用原產品預覽流程補做1004組操作：字號72組全部改變1倍基線，橫／直排18組全部改變；寬度54、高度54、邊距72、對齊72、書寫方向36、語言72、裝飾54及468個原生特性選項均未改變。系統字體兩種起始實例的32組逐軸極值未改變所測基線，但不能擴大為所有字體的軸均無影響。因此快取在現有新變體文檔換入入口失效，並不建立跨字體快取或處理窗口換字體。另測9字體實例×2方向×9個孤立控制字元共162組，沒有1倍基線變化。前輪3888組中的12種文字／固定GID／缺字附件亦未改變同一字體、字號及方向的1倍基線。

GAMultiTextView新增firstBaselineOffset並在super.textContainerOrigin的容器y軸減去該值；同一容器座標在橫排向上、竪排轉成右至左補償。完整原生usage長度扣除同一差值再取整，保持第一行起點及尾端留白，既有TextView frame／旋轉與單字／全字幾何不改。點擊原本已減去實際textContainerOrigin，保留這條轉換；小於1倍時，第一行命中矩形補上被移出原生行框的首行墨跡區域，避免恢復可見後點不到。

只快取naturalFirstBaseline及有效旗標。改字級（含Command-0實際改回字級）、橫／竪排切換、新變體坐標的GAFontDocument換入時清除旗標。文字／首行內容、窗口、邊距、對齊、語言、方向、裝飾、顏色、排印及僅調行距倍率不清快取。當前為1倍時可從既有布局建立基準，已有效則不再讀基準；當前非1倍而基準失效時，只取實際第一個NSTextLineFragment的顯示內容，使用與主預覽共用的原生TextView建立函數和方向／容器設定，臨時量一次1倍首行，立即釋放。每次需要補償仍從現成布局讀當前倍率基線，這不是重排1倍全文；未額外建立第二套shaping或字體表估算。真實無行片段／無首行文字範圍時不捏造參照。

隔離接入的3888組頁面上緣／右緣基線錨點與1倍參照一致，並逐組強制快取失效核對一行參照與完整1倍布局一致。最終產品源碼編譯的KVO計數：文字和非度量操作增加0次基準讀取；字級和橫／直排各增加1次；新軸實例增加1次，同一實例重複設定不增加。LucidaSubmono單行的橫／直排×5倍率（下限、0.5、1、2、上限）共10張原生離屏影像與1倍控制逐像素一致，10次直接點選映射均回到原文首字，包含小倍率時原行框上方的區域。這是離屏量測與直接命中函式呼叫，不是可見窗口／GUI事件驗收。

影像探針曾把最初一次構建的1倍畫面直接當控制，所有倍率甚至再次1倍都出現固定2028／1737個色彩樣本差。重建未修改的原產品源碼做控制，冷畫面及僅refreshPreviewColors重排的1倍畫面也有完全相同差異，且兩組PNG雜湊分別與接入版相同；證明是原有初次布局與再次布局的差異，不能歸因本次補償。最終以同一既有重排流程建立1倍控制，10組差異均0。未為這個原有初次布局現象修改產品。探針早期亦修正過生成程式的換行轉義及控制日誌printf格式；最終歸檔均為成功重跑版本，不把錯誤格式的日誌當數據。

本機arm64構建與git diff --check通過。未啟動產品App、未做可見窗口、實際捲動／手勢或其他macOS版本驗收，保留既有工具欄安全區及正常捲動位置保存。


### 釐清變軸與新變體實例的關係及證據邊界 — 2026-11-10

使用者追問為何以「新變體實例換入」而非「可變參數改變」作為基準失效條件，以及軸不改變基線究竟是字體特性還是TextKit保證。本輪唯讀核對程式與既有結果，未修改產品程式。

現行onCoordinatesChanged在座標真正不同時建立同一fontResource的新descriptor，loadDescriptor在fontQueue建立同一字體的新GAFontDocument／CTFont；過期請求會被合併或丟棄，只有最新成功結果在主線程透過Detail傳入Multi。setDocument接到不同document後清除1倍基準。因此「變體實例換入」描述的是參數改變後的新排版資料實際生效的節點，不是更換字體，也不是只在選擇具名實例時才觸發。對產品操作可表述為「可變參數變更並套用完成時重建一次基準」，在滑桿剛發事件而新字體尚未建立時讀取會量到舊資料。

精確的軸實測範圍僅為本機系統字體System-default及System-axis-max兩種起始座標，各16組，共32組，並非9種字體都有軸測試，也不是掃遍本機全部可變字體。這32組未改變所讀TextKit1倍首行基線。OpenType MVAR允許ascender／descender／lineGap等隨軸改變，但這只是字體格式能力，不能直接證明TextKit讀到的首行基線必然會變，也不能反向據此宣稱TextKit一律保持基線不變。尚未取得會在TextKit改變該首行基線的變軸反例。

因此目前變軸失效屬保守的未覆蓋情況處理，並不是「已實測確認會改變基線」的條件。前輪應明確區分已證實的字號／橫直排變化與仍未證實必要性的變軸重建策略。產品行為維持原樣，使用者本輪只要求解釋，未要求改動此條件。

原始規範：https://learn.microsoft.com/en-us/typography/opentype/spec/mvar 。


### 用真实可变字体及受控度量旗标确认首行基线可变 — 2026-11-10

使用者要求找会随轴改变度量的字体实测。本轮未改产品源码、未安装字体或操作可见GUI。原生离屏探针直接编入当时产品Sources，使用真实GAFontDocument／GAMultiGlyphView；归档diagnostics/vf-baseline-metrics-2026-11-10/，临时工作目录/tmp/ga-vf-baseline.KvUE2A。归档时57个Sources文件逐个字节核对仍与开始快照一致。

从googlefonts/amstelvar-beta下载Amstelvar Roman（原始SHA256 5b0708fbbb069e127ae62d017bd03beb9dd9dd61bc07b748f6508a7fcd901662，UPEM2000，OFL、源地址及哈希保留）。独立FontTools计算确认其原有MVAR使YTAS500／767／983的OS/2 typo ascent分别为1200／1500／1966，确实有可变行度量。但原版USE_TYPO_METRICS=false，本机CoreText ascent仍固定48.9603424pt（51pt字级），TextKit首行基线横49／竖30pt不变。不能把字表变化直接当作原生基线变化。

为确认采纳哪组度量，在保留原有轮廓、fvar／avar／gvar／MVAR等变化资料的诊断副本启用USE_TYPO_METRICS并改名防同名缓存；另设「只改名、不开旗标」和「开旗标并将hhea默认值同步typo默认值」两份控制。flag-only副本仅head／OS/2／name表字节不同，其他表不动。只改名的300组原生结果与原版相同；同步hhea副本的300组行布局与flag-only相同。因此这次正例明确是修改过旗标的对照字体，不是未经修改的已发布字体正例；不能省略这个边界。

本机macOS14.8.7／Apple M3，1倍行距，51pt的flag-only副本在YTAS500／767／983分别读到CoreText ascent30.6003113／38.25／50.1330872pt，原生横排首行基线31／38／50pt，竖排21／25／31pt。每字体默认＋12轴各min/max ×3字级（25.5／51／102pt）×2方向×2文本，共300组，四份共1200组。逐组核对显示CTFont有效坐标等于请求坐标、显示串未被fallback剔除、当前首行补偿为0、缓存自然基线等于原生行片段读数。因此差异不是现有补偿掩盖／伪造，也不是只改参数但新实例未生效。

结论：TextKit2没有「可变参数不改变首行基线」的普遍保证；当CoreText实际采用的行度量随轴变化，首行基线可以变化。先前系统字32组未变只能解释为已测样本的结果。当前「参数变化的新文档实际套用后使基准失效」策略已有上述受控正例支持，无需修改现行实现。原版MVAR未被采用的情况与该控制正例须同时保留，不能把保守推测倒写为一开始就已测明。

辅助筛选：旧AmstelvarAlpha／RobotoFlex仅发现xHeight／capHeight等变化；Literata／SourceSerif4／RobotoSerif未找到所测轴极值的基线正例。扫30个本机可变字体文件的首descriptor，各轴min/max未找到CoreText A/D/L变动；这不是所有集合face及轴组合穷尽。上述负例仅辅助选择样本。未实测其他macOS版本。

规范说明可变行度量使用typo字段、USE_TYPO_METRICS和MVAR hasc／hdsc／hlgp：https://learn.microsoft.com/en-us/typography/opentype/spec/os2#os2-table-and-opentype-font-variations 。实际CoreText／TextKit行为结论来自本轮测量，不从规范直接推导。


### 评估以原生度量比较减少变轴后的基准重读 — 2026-11-10

使用者询问是否可预先判断基线不会变化以避免每次量测。本轮只读源码与规范、重新分析已归档结果，未改产品代码或新增原生布局测试。现行不同document即失效；非1倍时会额外建临时1倍首行参考，因此可优化的是这次参考布局，不是省掉主预览必要的布局。

候选方案：同一字级／方向下，新变体实际生效时比较CoreText当前采用的ascent／descent／leading，而不只看MVAR或USE_TYPO_METRICS。重新分组既有Amstelvar四版本及Literata／SourceSerif4／RobotoSerif共1428组，按同字体文件、字级、方向、文字和A/D/L归为204组，未发现A/D/L相同而首行基线不同的组。这支持以实际度量作为轻量失效条件，但只是所测样本，不是TextKit公开保证；尤其其他竖排或Apple特殊度量来源尚未覆盖，不能直接声称只比较三值对所有字体充分。

表级静态预判可作为另一筛选，但MVAR可能仅含xhgt／cpht，且Apple还有fmtx等来源；仅有／没有MVAR或USE_TYPO_METRICS开关均不足以简单判定所有字体的原生基线行为。建议继续评估「实际原生度量相同则复用基准，变化或未覆盖来源则重读」；本轮是方案答复，未实施新的缓存规则。


### 补验原生度量依赖并改为按度量失效基准快取 — 2026-11-10

使用者明确要求补验直排及特殊来源，测试ascent／descent／leading所需最小集合，确认后直接改。沿用当前codex/titlebar-sidebar-expansion，未提交／推送。产品代码只改Sources/Views/GAMultiGlyphView.m；本轮前文件、单轮patch、最终57文件Sources快照、探针、受控字体、原始结果与日志在diagnostics/native-baseline-metric-cache-2026-11-10/；临时目录/tmp/ga-native-metric-gate.C8ls31。归档时逐文件核对与产品相同。

macOS14.8.7／Apple M3／arm64。21个字体样本共11364组1倍布局：3个字级25.5／51／102pt ×横竖排，Latin、空首行、仅换行，以及支持时的CJK直立／混排；默认、单轴端点与选定轴组合／中间值。所有样本核对有效轴坐标等于请求、显示串未因fallback剔除而改变、1倍补偿为0、缓存值等于直接读取的原生首行基线。不是21个未经修改的真实字体：包括系统Skia、原版Amstelvar、前轮只开USE_TYPO_METRICS副本及本轮专门构造的独立来源控制。

特殊来源覆盖MVAR vhea vasc／vdsc／vlgp、gvar轮廓／phantom advance及origin、fmtx magic points、bsln点基线、BASE VariationIndex基线、BASE MinMax及轮廓点引用。原版Skia本机确有fmtx；在诊断副本另加独立magic-point轴，原生CTFont glyph path证明点随轴移动，但本机采用的A/D与首行基线未随点变，明确只记作本机未采纳的结果。自制小字体的部分横排typo MVAR亦未被本机采纳，因此独立横排A/D/L的正例使用原有已知会采用typo度量的Amstelvar副本，替换MVAR为可单独控制的资料；不把这些说成原版发布字体。Skia控制生成初次曾在扩充fvar后触发FontTools lazy gvar解码，产生无效变化及NaN；最终先完整解码原gvar／cvar再加轴，记录结果均为修正后成功重跑，失败输出不当证据。

关键反例：MVAR vhea ascent单独变化，在51pt横排A/D/L全不变时，使原生直排ascent25.5→40.80016pt、直排首行基线26→41pt。反向也存在：无显式直排度量的Amstelvar控制，直排CTFont副本的A/D/L不变，横排ascent38.25→53.55使直排基线25→33；只改横排descent约12.2403→27.5397也使直排基线25→33。只取某一排版方向的一组值都不充分。

穷举比较6个原生值（横排／直排A/D/L）的子集，在同一字体样本、字级、方向及文字内分组。横排仅横排ascent没有漏判；横排descent、leading的独立变化未移动首行基线。直排最小通过集合为横排ascent＋横排descent＋直排ascent：只比横排A/D有84个基线冲突组；横排A＋直排A、横排D＋直排A各有60个冲突组。所选3值及全部6值均0冲突。单独正负leading含112.71034及−91.28966pt只改变行高，没有改变1倍基线。直排descent的单独变化亦只改行高，不需纳入本轮基准身份。没有用「A+D+L总和」或字表指标公式来代替原生基线。

实现新增GAFirstBaselineMetrics及原生读取函数。横排读取实际显示字体的CTFontGetAscent；竖排再读取默认字体descent，并以相同字体／字级／坐标但kCTFontOrientationVertical的副本读取ascent，立即释放副本。setDocument不再按不同对象清空基准；updateFirstBaselineOffsetForFont在显示数据实际套用后按上述值精确比较，变化才使基准失效。成功测得1倍基准后同时保存其度量身份。保留字级／横竖排显式失效、当前倍率基线读取、现有1倍首行临时参考方式、页面／点选／捲动逻辑。首次尚无基准仍正常建立；无有效行片段不发布虚构基准。leading变化会走必要的主预览原生布局及当前基线读取，但不额外重排1倍参考。

接入后将11364组原生测例连续换入新GAFontDocument（包括重复坐标及文字变化），KVO逐次断言：所选原生度量变化或首次建立才恰好读一次；否则0次。计486次基准读取、10878次沿用；每次再检查6个行距倍率，共68184组，缓存／补偿基线对接入前独立1倍参考误差0。这里计数是新文档赋值，不全是用户实际改了轴值；每组另核对字号和方向切换均各重读一次。

原9字体现行多字管线回归3888组（3字级×2方向×12内容／固定GID／缺字等案例×6倍率），缓存与强制重读的基准及页面内容尺寸一致，补偿后页面边缘基线对1倍最大误差9.094947017729282e-13pt。产品arm64构建与git diff --check通过；没有启动产品或可见窗口，不作为真实GUI、其他macOS版本或所有可能字体的普遍保证。前轮「三值相同可能足够」的提案已被本轮直排反例取代，最终比较的是按方向选择的上述集合。


### 通览代码并列出计算／结构优化候选 — 2026-11-10

使用者认可基线快取工作后，要求浏览所有代码寻找类似的省计算或结构优化。本轮仅静态审阅：Sources的55个来源档与compile-font-layout.sh、根目录build.sh，共57个代码／脚本文件、17517行；不将Sources/.DS_Store计作源码。代码与前轮已验证Sources快照逐文件比较一致，未改产品代码、未构建、未运行性能／行为测试、未启动GUI、未提交或推送。记录在diagnostics/optimization-review-2026-11-10/review.json，含源码SHA256、位置、观察、提案、依赖、风险和后续验证要求。此轮不是优化已经实现，也没有任何实测加速比例。

优先候选R1–R5：颜色／外观更新目前直接rebuildLayout（背景及阴影可分离重绘，字色需检查原生属性更新）；多字模式曾打开留下有效viewport后，隐藏状态仍接收文档／文字并排版，可延后至再显示；变轴文档先用旧快照排一次、新扫描投影再setText一次，可按真正显示输入判等而不按group对象身份，保留新字体即时预览；横排只改viewport高度或竖排只改宽度时有效折行长度不变，可只更新页面／内距／位置；侧栏宽度变化重载全部列，但现行行高只依特性行及Unicode徽章数量、名称均单行截断，可按真正行高依赖重载。以上都须保留捲动、toolbar安全区、点击、固定GID及缺字边界，不能仅用相同文字作缓存身份。

第二批R6–R8：变体engine共享program及全文缓存，但不延续已完成的immutable段落快照，主要浪费在换轴后再改一段而非相同全文；GPOS pair／mark反复构造ClassDef／Coverage，其构造会验证全份range，可缓存静态结构和验证结果，但不能提前让未使用的坏subtable破坏其余输出；unicodeMap冷建立仍逐scalar扫0…0x10FFFF，可先跳空plane或枚举原生字符集合，仍保留CoreText映射和完整Unicode aliases，不能谎称它每次打字都会全扫，现已按字体资源缓存。

较后R9–R12：analysisQueue上过期变体的重绑定／投影目前没有取消，不能只加early return而破坏worker文档与pending输入配对；text getter为取纯字串也正規化整份属性文本，可评估marker-aware纯字串或同次编辑快照；GPOS mark attachment多次从一端求pen累加，长multi-GID含大量附标时可评估一次位置表，须验证RTL浮点次序；字体固定的名称／编码装饰与未变化的Unicode徽章可独立于坐标相关的字形／位置重绑定。后四项收益及实施成本更依具体输入，尚未profile。

已存在且不重复提为新工作的机制：共享不可变字表／完整查询缓存、单字及全字格内字形page缓存、AAT预编译与相同schedule复用、GSUB持久buffer和symbolic mask/effect memo、fontQueue合并与可取消发掘、侧栏同视觉列刷新及捲动锚点、前轮基线原生度量快取。没有为了优化提议删除字表边界检查、预算或用户确认的workaround，也没有把历史暂缓的行为问题自动混入范围。后续只有使用者选定并授权具体项目后才改码；本轮无需再弹确认窗。

### 完成十二项性能优化，逐项分支与等价对照 — 2026-11-10

使用者明确授权十二项全部实施，顺序为 R1→R5→R3→R2→R4→R6→R7→R8→R9→R10→R11→R12，每项开始前建立分支；性能优先、结构其次，UI／UX／输出不得改变（Bug 除外）。此授权覆盖该十二项，无需再逐项弹窗；未混入旧的暂缓行为修复，未推送、打 tag 或发布正式版。

初始为 codex/titlebar-sidebar-expansion@391219a，含前轮已接受但尚未提交的 Sources／Resources 改动。在第一项分支先以 a1ee179 保存这49个文件的原状；原始分支没有移动。随后十二个分支按前一项提交顺序串接，每项独立本地提交，最终 codex/perf-12-glyph-decoration@15d6ff0 含全部成果。证据与逐项 patch／探针／原始结果／哈希见 diagnostics/performance-2026-11-10；progress.json 是分支和 before／after commit 的索引。

| 项目／分支尾缀 | 提交 | 代码变化、目的与对照结果 |
| --- | --- | --- |
| R1 perf-01-preview-colors | 05d488e | GAMultiGlyphView 字色仅改现有 foreground 属性，保留无该属性的边界附件；背景／阴影／外观只重绘。216组像素、布局及命中完全一致；80次背景更新的显示副本构建80→0。 |
| R5 perf-05-sidebar-width | 1ac772e | GASidebarViewController 移除宽度变化专用全表重载和已无调用的包装函数；原生列宽更新保留。400行×16宽度状态，像素、全部行框、选择及卷动一致；reloadData 16→0。 |
| R3 perf-03-equivalent-preview | 45493c1 | 复制实际显示依赖值判等，仍替换最新 group 对象；范围、文字、omissions、seed／inserted 标志及完整首 variant GID 均参与，能识别原对象被修改。306组一致；100次等价投影的构建100→0。 |
| R2 perf-02-inactive-preview | 1b30431 | 多字模式隐藏时仅保存参数并标记 pending；显示前先接收最新 viewport 再一次完成布局。真实 Detail 的两种隐藏模式×方向×空／非空共8状态，最终画面、几何及滚动尺寸一致；隐藏期间构建336→0。 |
| R4 perf-04-viewport-geometry | e4614d1 | 有效折行方向长度不变时只更新 inset、通知及位置，其他情形保留原路径。126组原生与8组真实 Detail 尺寸／滚动条状态共134组一致；正交方向100次赋值（首次同值）构建99→0。 |
| R6 perf-06-paragraph-cache | 6958cbb | 新 engine 在 source 锁内取得已完成的 const 段落快照，定位仍属新实例。三字体×无 seed／单字符 seed／跨换行 seed 共9组完整候选、位置、来源及取消一致；Lucida 发掘调用26→2，Skia195→15，Amstelvar351→27；跨换行 seed 原有完整路径不变。 |
| R7 perf-07-positioning-tables | 0b60b9f | GPOS secondary ClassDef／Coverage 通过共享 call_once 首次按原条件读取，保存成功或 InvalidTable，未提前解析未使用坏表。87组 pair／mark／mkmk、坏表未命中与命中、多线程首次读的数值或错误一致；合成测例验证1000→4次。 |
| R8 perf-08-unicode-planes | f03c3ab | unicodeMap 跳过原生字符集为空的 plane，实际 scalar 仍调用原 CoreText nominal mapping。Helvetica、PingFang、Emoji、Symbol、Dingbats、LucidaGrande 六份完整 GID→Unicode aliases 相等，含补充平面。一次冷构建测量约5–26ms→0.5–22ms，非逐键收益。 |
| R9 perf-09-cancellable-rebind | 8023d06 | 过期 worker 安装先跳过；candidate 重定位和 projection 可取消，在 analysisQueue 完成后才一起替换 model document／result／groups，再安装 workerDocument。三字体完整结果一致，22个取消断言无半安装；真实控制器12次连续坐标与输入更新、关闭作废均通过，最终组等于独立完整查询，定位调用344→91。 |
| R10 perf-10-input-string | 4adb57c | string getter 直接遍历有效换行 marker，仅复制字符串，不正規化富文字，也不增加输入缓存。300组 literal／有效／未知数字 separator、GID属性及实时编辑对照一致；100次读取富文字正規化100→0，约11.36→8.82ms。 |
| R11 perf-11-attachment-pens | a20a085 | lookup advance 完成后预存 LTR prefix，仅到实际需要的最后 pen；resolve 只读位置。RTL 为保留 double 顺序仍用原正向 suffix。87组常规加16组长附标／方向／小数度量，共103组逐值一致；6400 GID×4次 LTR 累加122854400→25600，约255→24ms，RTL调用与结果保持。 |
| R12 perf-12-glyph-decoration | 15d6ff0 | 同资源 NSCache 保存不可变完整 GID 序列的名称／排序 aliases，限制项数与成本，大单项绕过；来源特定 base 补值和位置／墨迹在外。三字体90个坐标状态、两种来源补值、24组cell像素／辅助说明一致；名称查询每字体240→8；100次同值cell刷新徽章新建200→0（约8.24→1.94ms）。 |

各阶段 arm64 产品构建与 git diff --check 通过。最终累计重跑 R1 216、R3 306、R4 134、R5 16、R10 300、R2 8 状态，及9份完整段落候选与实际控制器最新输入／关闭流程，均与对应已验结果完全一致。前轮3888组基线结果逐字段相同，且本轮明确以私有 rebuildLayout 强制重读作参照（R1 后 refreshPreviewColors 已不重排，不能再用它冒充重读）。缓存／强制重读完全一致，页面边缘基线对1倍误差最大仍9.094947017729282e-13pt。

最终 ./build.sh -u 成功，二进制含 x86_64／arm64；清除生成 app 被文件提供器再次附加的 FinderInfo 后，strict deep codesign 验证成功。R10 一次组装曾因同类元数据签名失败，清理生成 bundle 后重试成功，未改源码构建脚本。与初始记录相比，预期16个源文件之外的141个受保护文件内容和模式无差异，Resources及构建脚本均保持，tracked工作区干净。

测量环境仍为本机macOS14.8.7／Apple M3。数字为受控原生离屏／队列探针的操作数与片段时间，不代表整应用通用加速倍率、实际持续交互帧率或其他macOS版本验收。R9 初版队列探针误用会激活窗口的 replaceInputText 入口，隐藏断言失败；正式前后对照改用 sidebar 输入入口，均断言窗口未显示。R10 非数字私有marker属性的诊断输入会令原代码抛异常，改为测试其约定的数字值与未知 separator；此轮没有顺手改变属性类型校验。未修改用户输入语义、undo、IME、焦点路由或既有缺字／overhang workaround。


### 十二项完成版本的再次全项目优化审阅 — 2026-11-10

使用者再次要求浏览所有代码，寻找类似基线门控的省计算／结构优化。本轮发现实际副本已是codex/perf-12-glyph-decoration@15d6ff0，tracked源代码干净，已有R1–R12全部实施；已在交流中说明按这个现行版本审阅，不把先前十二项重复当未做。本轮仅静态源码／脚本清单扫描与重点调用链审阅：55个源文件、2个构建脚本、按splitlines共17683行；逐文件SHA及git show HEAD字节核对一致。不是逐行形式验证，也未运行性能、行为或GUI测试，未构建、未改产品代码、未提交或推送。证据在diagnostics/optimization-review-after-perf12-2026-11-10/review.json。审阅期间hsn-Hans／hsn-Hant资源出现与本轮无关的外部修改，未触碰。

新增八项候选：F1 applyRawResult每笔复制整组并线性去重，可改为保序builder＋完整身份索引；F2 positionsForGlyphIDs每个候选重复完整prepareText，仅取第一run的script／level，适合复用原文定位上下文；F3 GPOS一次定位内plan先执行、再为kern状态重复构造，可合为一次并保留失败时legacy kerning；F4 同实例重复GID逐个调用CoreText advance，可先量原生热缓存，再考虑实例内缓存／批量读取；F5 隐藏全字视图仍在主线程冷建立全量GID inventory，可延后首次显示，Unicode反查在其它路径需要时仍会做；F6 多字每次必要重排仍新建相同显示CTFont并读相同方向度量，可按fontBox／显示字号／features复用；F7 固定normalized坐标下重复VariationIndex／region运算可评估延迟、有界缓存；F8 Objective-C十八个.m每次全部重编，可仿C++对象复用加header依赖与工具链身份，收益仅开发构建时间。

建议优先F1→F5→F2→F3→F6，F4先测原生getter是否已有足够快的内部缓存，F7视可变GPOS字体的重复引用密度决定。另有跨cell单GID原始ink／advance及vmtx/vhea存在性重用、Unicode徽章宽度／格式化的较小后续机会，均排后。不为了凑项目数重新处理R1–R12，也不把已按视图缓存的page说成每帧都在重新测量。

关键约束：候选身份必须保留ligature及其sourceRange而非仅GID；定位上下文不可用首字元猜测RTL／script；GPOS计划的kern状态只在原定位成功后采用，否则会改变回退；CoreText定位advance不能与无trak的CGFont raw page width混用；可变度量缓存不能跨坐标实例；VariationIndex不能提前验证未使用坏表或重排浮点加总；全字延后须验证首次进入、过滤、高亮及scroll/safe-area。所有预期收益仍待独立前后测量，未声称提速百分比。

### 第二轮性能候选逐项实施、保留六项并放弃原生 advance 缓存 — 2026-11-10–11

使用者明确授权除F8「增量构建」外，按建议F1→F5→F2→F3→F6→F4→F7逐项进行，每项开始前建分支；性能优先、结构次之，不改变当前UI／UX／输出（Bug除外），无合理收益则放弃。此授权直接覆盖实施与必要离屏验证，无需重复确认。起点codex/perf-12-glyph-decoration@15d6ff0；hsn-Hans／hsn-Hant已有外部资源修改，未触碰或纳入提交。七个分支依序串接，六项有独立本地提交，F4分支仅保留评估起点。没有推送、tag或发布。完整索引与证据在diagnostics/performance-followup-2026-11-10/progress.json及各F目录。

| 项目／分支 | 提交 | 变化、收益与边界 |
| --- | --- | --- |
| F1 codex/perf-13-candidate-builder | 2b0d89e | GAFontEngine对达到32项的组使用保序builder及散列桶，完整GID／ligature／连字范围仍决定身份；小组沿用原扫描／复制。完成或取消前发布已累计结果，来源合并顺序不变。35份真实／合成／取消结果完全一致。4096候选的隔离聚合测例复制元素38485872→24564，7轮中位时间2.941385→0.086261秒。最初无条件建索引令小组慢约40%，已舍弃；门槛版本小组基本持平，大组才获益。该片段用双方相同廉价装饰hook隔离聚合，不是整应用提速倍率。 |
| F5 codex/perf-14-lazy-glyph-inventory | f0ceadb | GAAllGlyphsView只对首次隐藏且尚无inventory的状态延迟建立，保存最新文档／筛选，首次显示前完成；warm流程不变。3字体36组首次／重复显示、筛选、reveal、清除的像素／几何／卷动／高亮状态相等。隐藏冷赋值Helvetica2252、PingFang49519、Skia591项均暂不建立，PingFang该次主线程片段约25.6ms→1µs。工作移至首次显示；默认AllGlyphs模式不适用，也不保证其它查询不需要Unicode反查。首版探针未在建view前切Single，误测默认AllGlyphs，纠正后完整重跑。 |
| F2 codex/perf-15-position-context | 91d22ff | GASubstitutionEngine在共享program中以完整原文保存prepareText首run的script／rtl；空串保留默认Settings，长于32768单位不保存，NSCache1024项／1MiB软限制。坐标与定位结果仍实例独立，异常不缓存。3字体×3坐标×14上下文×4GID序列共504结果完全一致，另32并发查询／字体；重复定位prepareText8400→1次，各字体隔离时间约32.75→4.23、39.87→10.81、37.18→7.96ms。涵盖规范化、双向控制、UVS、emoji、混合脚本。 |
| F3 codex/perf-16-gpos-plan | 7f5f283 | GAOpenType.position返回同一成功执行plan是否含kern，GAPositioning只建一次plan，engine直接接收结果。赋值在成功返回后才完成，GPOS异常仍使hasKerning=false并走原legacy回退。2016原生结果和32并发／字体相等；另87组纯C++ pair／mark／方向／坏表／并发值或错误相等。成功路径plan16800→8400次，失败路径保持8400；有legacy kern的受控损坏表输出保持。收益主要是消除重复计划与简化流程，未声称所有字体明显加速。 |
| F6 codex/perf-17-display-font | cca93d3 | GAMultiGlyphView按fontBox／实际显示字号／feature settings复用displayFont；有效基准与同一字体对象可沿用已读的方向度量，字号／方向及基准失效照旧原生读取。文字／行距／对齐等仍实际重排，当前首行仍读TextKit。180组实际字体属性、轴、像素／几何／点选状态一致；12组各400次行距更新中，字体副本4800→0、度量读取4800→0，native布局片段有稳定改善。含清空文档／空文字／恢复、reset、特性、变轴和固定多GID。 |
| F4 codex/perf-18-native-advances | 无提交，撤回 | 原型以实例内稀疏原子页缓存CoreText advance，2016结果及并发一致，重复native调用25200→3。但多数定位片段仅改善约2–5%，Lucida反而略慢；页、原子值、内存上限及生命周期复杂度不值收益。按用户底线完全恢复该段源码，未把减少API调用本身当成保留理由。rejected.patch和实测保留，不存在于最终产品。 |
| F7 codex/perf-19-variation-deltas | ef34a0c | Metrics增加可选device evaluator，GAPositioning按原顺序调用；engine只对有效正规化坐标与存在GDEF store时启用实例内outer／inner键delta缓存，互斥保护、最多2048项，计算在锁外，异常不缓存，无跨坐标共享或提前验证。432份实际定位、32并发首次使用／字体、104472次delta数值／错误比较相等；有效缓存上限2048，损坏store保持0。RobotoFlex／Amstelvar重复定位delta336000→7，片段126.19→33.26／142.84→33.43ms；静态字体近似持平、坏store21000次失败仍21000次。MVAR初始化未改。 |

最终直接从初始15d6ff0与累计ef34a0c独立编译未插桩产品源，比较完整3份字体投影／22项取消与事务断言、9份段落完整候选、306份原生像素／几何／命中状态、8份真实Detail隐藏状态、3888份九字体基线资料；剔除时间字段外均完全一致。缓存与明确清除基准后私有rebuildLayout强制重读结果完全一致，页面边缘基线相对1倍最大误差仍9.094947017729282e-13pt。最终源码哈希与实际测试快照一致，七个预期源文件外150个tracked文件内容及权限完全相等，包含外部两份本地化当前原状及构建脚本；无探针hook或F4原子缓存进入产品。verification.json和verify.py可重查存档。

每项arm64编译及git diff --check通过；F7组装曾遇文件提供器附加FinderInfo导致签名失败，仅清除生成app元数据后重签／strict deep验证，未改构建脚本。最后./build.sh -u成功，产物含x86_64／arm64；再次检查时元数据重现，清理生成bundle后签名与strict deep验证成功，日志保存。一次手动lipo查询误写可执行档为「Glyph Atlas」，纠正为实际GlyphAtlas后成功，不涉及产品变动。

测量仍为macOS14.8.7／Apple M3原生离屏探针；没有启动产品可见窗口，不代表真实GUI验收、其他系统版本或所有字体保证。速度是受控片段，不是整应用通用倍率。F8增量构建明确排除；未扩展到其他小候选、旧暂缓Bug或本地化。最终分支codex/perf-19-variation-deltas，六项提交按前项串接。

### 依数据审计收益，撤回名称装饰快取 — 2026-11-11

使用者要求无合理收益的修改放弃，明确不重新查看产品代码，只核对数据及必要补测。本轮未重审产品源码；读取既有诊断数据与探针，自动从原Git提交提取源码编译。当前起点已为codex/perf-19-variation-deltas@ef34a0c，因此同时核对后续F1–F7。两份hsn本地化未提交修改不动。证据在diagnostics/performance-benefit-2026-11-11/。

补测仅针对R7／R11原计时包含细粒度原子计数器、R12没有隔离装饰成本，以及F3计时不一致。使用未插桩原始提交，前后交替顺序；核心每组7轮，每批至少40ms；原生每组5轮，内含7或9批，取中位数。不把旧插桩计时当作纯算法加速比例。

R12名称／Unicode装饰快取撤回：四字体每10000次已热读取，原14.05–19.99ms，快取版41.84–43.61ms，慢约2.1–3.1倍。首次737／590／961／3000个不同GID分别约1.71／1.08／2.06／6.18ms→49.31／31.60／82.69／773.01ms，标签与aliases全部相等。旧测例只用少量相同序列且混合新字体实例构造，不足以判断字形种类增加后的成本。按用户授权，在修改前建立codex/perf-benefit-remove-decoration-cache，仅自动反向应用原R12在GAFontEngine.m的18行新增；保留GAGlyphViews.m徽章同值判等，没有另造快取。提交7652089。

无插桩R7有效测例省约9–19%时间：Roboto125-GID90.96→80.25μs，Amstelvar124.13→100.64μs。R11长6400-GID附标25.81→3.47ms（7.44倍），400-GID257.69→205.29μs；100-GID约51μs持平，4-GID2.35→2.39μs，收益限较长序列；RTL原顺序不动。F3／第16项每12000次定位，Amstelvar64.31→58.28ms、Roboto48.20→40.53ms、合成有效表29.73→25.13ms，其余约1%内差异；兼有计划建立2→1的结构收益。三项保留。

其余沿用既有证据，不重复测：R1–R4减少显示副本构建；R5整表重载16→0且删除包装逻辑（混合绘制计时差1.7ms不当作显著整体提速证据）；R6段落发掘26→2等；R8完整Unicode映射冷建表约5–26→0.5–22ms；R9过期定位344→91；R10每100次字符串读取11.36→8.82ms、富文字正規化100→0，无新输入缓存；R12徽章刷新新建200→0、8.24→1.94ms。后续F1大候选2.94s→86.26ms且保留小组直路；F5隐藏网格首次inventory延后（蘋方约25.6ms暂不发生）；F2上下文准备8400→1（Lucida每1200次32.75→4.23ms）；F6每400次布局字体副本／度量读取400→0，十二组中位时间合计116.48→99.76ms；F7有效可变定位约126.19→33.26ms等。F4／第18项早已因多数仅2–5%改善、一个字体退步与原子页面寿命复杂度而放弃，本轮未恢复。未实施的网格假说不视作已保留修改。

撤回后以当前完整实现重跑90组装饰／来源补值及24组cell像素／accessibility，与旧无快取输出无差异，100次徽章刷新仍0新建。arm64产品构建与git diff --check通过；没有不必要地重复3888组布局回归。只提交GAFontEngine.m，未推送。速度仍是本机macOS14.8.7／Apple M3受控片段，不是整应用通用倍率。

### 十九号分支后的全项目性能审阅：优先三个范围处理热点 — 2026-11-11

使用者要求再浏览代码，标准同上轮：性能优先、简化次之，保持当前UI／UX／结果，无合理收益放弃。本轮按审阅处理，没有修改产品源码、建实施分支、提交／推送或构建产品；允许的测量全部使用/tmp隔离副本，无可见窗口。起点codex/perf-19-variation-deltas@ef34a0c，55个源档及2个构建脚本、按splitlines共17831行，执行全文件哈希／结构／循环与昂贵调用扫描，并深查剩余热路径，不称逐行形式验证。证据在diagnostics/optimization-review-after-perf19-2026-11-11，review.json含建议、边界、排除项；保存探针、插桩patch、源哈希及原始结果。

审阅期间其它工作将分支切为codex/perf-benefit-remove-decoration-cache，并在GAFontEngine.m移除18行装饰缓存；两份hsn资源原有修改仍在。本轮未操作这些外部改动或切回分支。两套探针源副本逐文件均等于ef34a0c，三个推荐项的当前源文件与副本仍字节相同，故推荐仍适用；memo探索的时间明确属于有旧装饰缓存的该快照，不冒充移除后的全流程结果。GLOSSARY的外部装饰缓存调整留给其所属工作同步。

优先建议G1→G2→G3，均为当前成本证据，尚未实现优化，不能把下列时间当成已实得加速：

1. G1：GAMultiGlyphView.m的MapGlyphLayoutRuns逐个原生hit遍历atomicRanges，复杂度hits×固定选择数。原生离屏5000字、每6单位一个固定GID选择（约833项），20次交替行距重排共69505560次范围检查；mapping本身1.266893秒，总重排1.497447秒。1000字同样流程2785560次检查，mapping60.3ms／总103.5ms。无seed的5000字无atomic检查，mapping50.3ms／总135.4ms。建议每次mapping建一次范围索引，只查相交范围；保持range与leadingRange/component各自的扩展、原生GID顺序、合并及字素簇语义。需覆盖横／竖排、RTL、多GID、surrogate／composed text、缺字边界及点击结果，不可用原生单字符索引代替完整来源。
2. G2：GATextQueryModel.m的GABuildDisplayGroups为每个独立combination范围扫全份groups统计spanLengths；明确选择合并也每个selection扫全部源组。密集合成100／1000／5000来源组，每组除末项有跨两组组合，检查9900／999000／24995000次，该次投影约0.44／7.82／126.62ms。建议同次投影构建来源范围索引或端点统计，以范围检索计相交组并仅取重叠选择源。不能假设通用接口groups天然无重叠或排序；必须保持重复／同范围项、selection有效性、stable root、来源合并、组合顺序、无法锚定的组合位置及取消边界。这是隔离合成密度，不代表所有字体常用输入。
3. G3：GATextPreparation.mm每个明确GID selection重新从groups开头find_if，随后vector erase／insert搬后缀。当前单独prepareText七轮中位：100字50选择2500次搜索、0.167ms；1000字500选择250000次、2.032ms；5000字2500选择6250000次、19.962ms。同长度无选择约0.161／1.265／4.103ms，只说明不同工作负载差别，不是优化前后。建议以有序selections与prepared groups单次走访构建输出，避免反复搜前缀、搬后缀；保留预先按选择边界分开规范化、identity编号、prefix／suffix来源及script／level、UVS、组合字符、跨换行seed和原错误行为。

本轮筛掉／排后：完整定位结果的query-local精确原文＋GID序列memo临时原型，4字体18轮各完整group输出共72份一致；1000字重绑投影中位Lucida4.277→5.182ms（约慢21%）、Skia24.214→15.715、RobotoFlex4.528→3.766、Amstelvar3.948→2.671ms。虽其它字体有收益，不能直接推广，未推荐通用缓存。GSUB计划重复确实存在，RobotoFlex400字首次查询8600次但仅360种，实际plan内部约2.48ms／instrumented总51.35ms；收益与新键／寿命管理不匹配，暂不优先。显示副本构建在5000普通字20次重排约27ms／总135ms，密集seed约74ms／总1497ms；先去掉明确范围热点，再决定是否引入额外副本缓存与fallback依赖管理。

曾怀疑common script向右搜索及Arabic透明字符邻接扫描为平方复杂度，读码后否定：首组解析后previous已建立，透明项自己不做邻接扫描，不把它们列作新热点。现有页面／段落／上下文／delta缓存、预算、坏表边界及用户workaround保留；不重复推销已撤回native advance缓存或排除的增量构建。菜单／文件操作／资源归并等冷路径未找到足以优先的新收益。本机仍macOS14.8.7／M3；本轮探针是成本定位和局部memo探索，不是产品等价验收或三项优化已完成。

### 三项范围处理优化：逐项分支、实测后全部保留 — 2026-11-11

使用者明确授权按G1→G2→G3实施，每项开始前建分支；沿用性能优先、结构次之、UI／UX／结果不变（Bug除外），无合理收益放弃。无需重复确认。当前起点已为codex/perf-benefit-remove-decoration-cache@7652089，包含另一轮已提交的装饰缓存撤回；没有把旧ef34a0c当实际起点。两份hsn本地化原有未提交修改保持。三个分支按前项提交串接，分别本地提交，未推送、tag或发布。

| 项目／分支 | 提交 | 实现与收益 |
| --- | --- | --- |
| G1 codex/perf-20-hit-ranges | 68b094b | GAMultiGlyphView的MapGlyphLayoutRuns先验证至少8项atomicRanges是否有序、互不重叠且无范围溢出；符合时直接以既有数组二分找首个可能相交项，范围外停止。没有另造数组或长期缓存。小清单及顺序／重叠不符者仍按原顺序单次扩展，range与leading component各自NSUnionRange、MergeHits及原生GID顺序保持。Helvetica5000字、每6单位一个固定GID的20次行距重排，7轮中位1.49914→0.301128秒；1000字同样更新101.259→57.145ms；无选择的5000字139.958→139.332ms，基本持平。这是必要原生重排及命中映射片段，不包含实际窗口持续绘制帧率。 |
| G2 codex/perf-21-display-spans | 29ca090 | GATextQueryModel在收集byRange后，达到64来源组／16独立组合范围才建立本次投影的start／end数组，各自qsort；相交数=起点在查询末尾前的项数−终点不晚于查询起点的项数，两个二分求值。保留重复／重叠／未排序来源，忽略空及NSNotFound来源；遇溢出来源保留原扫描。小投影直接扫描，无跨查询缓存。明确选择合并的循环及取消检查保留，没有引入另一套复杂重叠树。5000来源／4999组合密集合成投影130.048→23.307ms，1000／999为8.722→4.495ms，64／16约107.672μs持平，1000／1约547.7→527.3μs。两份端点数据只在该次大投影存在，约16B／来源组。 |
| G3 codex/perf-22-selection-splice | 5e94e54 | GATextPreparation按已验证的有序selections，以游标走过原group向selected vector输出；仅保留最后字素簇未消费的suffix供后续选择使用，结束后一次替换groups。移除逐选择从头find_if及vector中间erase／insert，prefix／suffix来源与script／level、literal GID、identity产生次序及错误保留。无选择跳过此阶段的新vector。原始／新prepareText同进程无插桩、9轮交错顺序：5000字2500选择20.4166→3.9109ms，1000字500选择1.4024→0.7531ms，100字50选择83.16→75.14μs。无选择5000字3.5016→3.4980ms，单选择3.5227→3.5434ms（约0.6%差异），基本持平。1000单位超长字素簇500选择3.6891→2.9058ms；剩余簇内项仍可能再处理，不承诺所有输入均为线性时间。 |

三项经实测均有合理收益，全部保留；没有为了省调用数增加缓存。G1原生必要布局、G2密集合成投影、G3独立prepareText是不同层的片段，不能相乘成整应用倍率。原生探针用本机macOS14.8.7／Apple M3，未启动产品可见窗口，不作为真实GUI、其他系统或任意字体的普遍验收。

等价验证：G1有3000组直接映射（有序／逆序／重叠／空范围、随机显示到来源映射、组字与双向顺序等）及54组真实TextKit横／竖排、三字体、不同seed密度和行距的像素／几何／来源索引／leading命中逐字段相同。G2有300份合成投影，包含重叠、重复、未排序、空／NSNotFound及溢出来源；另三字体×有／无多GID seed共6份完整显示／多字投影及36份按poll次数取消均相同。G3六份不同cmap共10554组完整TextRun／Item字段和unpaired selector结果相同，包含3204份同类型同文本错误；覆盖NFC/NFD、UVS、surrogate边界、组合字、双向控制、空及多GID、跨换行、无效／重叠／逆序范围，另以G3实际引擎重跑上述6份真实投影和36取消状态一致。

累计版本从未插桩的7652089和5e94e54源分别编译，306组原生像素／几何／命中、3份完整查询投影及22项取消／事务断言一致。最终Source哈希与实际测试副本一致，三个预期源文件之外154个tracked文件内容及模式均无差异，含两份外部hsn原状及构建脚本。git diff --check通过；./build.sh -u成功，二进制含arm64／x86_64。复查签名时文件提供器重新给生成app根目录加FinderInfo，首次重签失败；只移除生成bundle的FinderInfo／ResourceFork后重签，strict deep验证成功，未改构建脚本或源码资源。

探针纠正：G2首次把NSIndexSet.description写入JSON，包含各进程不同的对象地址；其它字段一致，改为序列化实际索引后重新跑真实投影，全部相等。G3首次分别进程测量少量选择出现数个百分点波动，因此把原函数仅在诊断副本重命名，与新函数同进程交错测量；最终采用该组无插桩结果，旧原始记录仍保存。这些是测量修正，没有借机改产品行为。

证据在diagnostics/range-performance-2026-11-11：progress.json记录分支／提交／中位数，G1–G3保存原始结果（gzip）、探针／构建日志与patch，final保存累计对照、源码哈希及verify.py／verification.json。当前最终分支codex/perf-22-selection-splice@5e94e54；产品源不含GAProbeMap、临时reference函数或计数开关。

### 第22项之后再审性能：四个剩余候选与隔离测量 — 2026-11-11

使用者要求再浏览代码，沿用本轮性能／等价标准。本轮是审阅，未修改产品代码、未建立实施分支、未构建产品、未提交／推送；所有原型均在/tmp副本，未启动产品可见窗口。当前基准codex/perf-22-selection-splice@5e94e54。55个源档加2个构建脚本，共57档17891行，执行全文件SHA／结构／循环和昂贵调用扫描，再深查剩余调用链；不是逐行形式证明。源代码逐文件与HEAD相等，两份hsn原有修改保留。证据在diagnostics/optimization-review-after-perf22-2026-11-11/review.json及原始探针、profile.patch、结果与源码清单。

建议顺序H1→H2→H3→H4：

- H1：固定选择的显示投影仍有交叉扫描。GABuildDisplayGroups对每个selection遍历全部source groups查fromGlyphSeed候选；IntersectsSelection再对来源组扫描validSelections，组合结果的sameAsInput也扫选择。G2上轮只处理组合跨度统计，未处理这几段。当前真实Helvetica查询投影，1000字500选择总约5.60ms；5000字2500选择有12500000次source访问，总约107.81ms，其中选择合并80.54ms（含构造catalogue约6.28ms），筛除约27.01ms，组合匹配约0.12ms。无选择5000字总约1.35ms。这里是同一原生当前实现的粗粒度计时，未在内层逐步插计数器；source访问数由实际组数×选择数求得，不能把成本直接当已实现节省。可按精确sourceRange一次建立保序candidate桶，保留原group相交条件与完整GID判等；交集筛除复用现有端点二分方法，selected combination按范围查相关选择。小输入保留直路、不建长期缓存。需保持source顺序、无效／重叠通用范围、catalogue拒绝项、临时行及取消后不得发布旧generation；跳过工作后的poll次数不应冒充取消语义。此项尚未写优化原型。
- H2：侧栏updateGroupsWithSameRows只为判等，两侧variant.glyphKey每行各生成一次字符串，多GID还生成join用的临时串。建议仅在此处直接比较完整glyphIDs数组，导航／pending等真正用key的地方保持。诊断category复制原方法及一行改法，同进程7轮交错，真实原生table查询但不含reload及可见cell绘制：5000列单GID约6.179→1.910ms，四GID24.717→1.946ms；1000列单GID1.220→0.381ms，100列0.121→0.038ms。前后使用内容相等但分别创建的数组，并非只量同指针；只验证了相同行序成功路径。正式改动仍需空／单／多GID、不相等、mutable／重绑对象、选择及真实cell结果对照；模型契约是非nil整型GID序列。不另造缓存。
- H3：GATextPreparation.scalarScript把ICU的shortName转NSString，再转UTF8／std::string并查固定的小map。隔离原型直接把相同的4字节名字以同样tolower打包为Tag，并以switch保存原有五个例外及DFLT判断；ICU调用和Unicode数据库不变，不保存新script缓存。当前ICU对0…0x10FFFF共1114112个码值逐个比较，零差异；两个字体×5文本模式×3长度，共30份TextRun字段对照相同。同进程无插桩O2/flto、7轮交错prepareText计时，5000单位样本：Helvetica拉丁3.422→2.796ms、汉字8.866→8.259、阿拉伯9.415→8.498、混排7.254→6.618、emoji／附标5.246→4.611；PingFang对应约5.830→5.156、7.006→6.339、12.085→11.188、10.034→9.186、7.363→6.693ms。各5000单位样本约省6–18%，只是文字准备阶段。正式实现仍保留特殊tag、错误和来源／identity等完整回归。
- H4：横排未seed的普通组仍在displayAttributedStringForFont中读取variant、切substring、进入verticalQuote逻辑后才发现无替换。隔离原型只把方向在函数内读一次，非seed横排组在上述替换专用工作之前continue，原排序、indices、omissions及TextKit完整重排保留，不造显示副本缓存。7轮交错：5000字普通横排显示副本1.355→0.636ms，完整20次行距重排163.690→149.679ms；1000字31.955→29.579ms；直排5000字209.548→209.455ms基本持平。直接attributed string／source indices及每轮native geometry／hits一致。只测Helvetica普通文本与两方向，正式修改仍需seed、quote特性Off、缺字／foreign-font重试及完整像素对照。单次布局减少约0.7ms，幅度较前三项小，但实现只需局部提早排除，故排第四。

没有把相同的旧建议重新当新成果：原生advance／完整定位结果缓存、名称装饰缓存仍无新证据推翻此前舍弃；广泛缓存显示字符串及fallback状态不优先，已有更简单的局部排除可量到收益。输入规范化／IME、focus、菜单／文件IO、初始资源归并等路径没有新证据足以优先变动，增量构建仍排除。只看源码的可疑循环不自动列为可实施加速，也没有为了凑项目增加缓存。

诊断修正：第一次small探针生成器误从private method声明处抽取，复制了多余实现段而编译失败；改为从实际@implementation后的方法定义抽取，产品源码未动。第一次横排早退原型逐组读取self.vertical，直排副本片段略慢；修正版只读一次方向，最终采用后者及完整native重排计时。原始small.json的row结果仍有效，H4采用small-native.json。不同阶段的数字不可相乘为整应用加速，也不是四项已正式实现或已完整GUI验收。运行环境本机macOS14.8.7／Apple M3。


### 连续性能优化至本轮收敛 — 2026-11-11

使用者授权「和之前一样。做完再浏览一遍，再做……直到找不出可以优化的地方。然后将电脑睡眠」。按H1–H4顺序开始，之后反复审阅／测量／实施；每项生产修改前新建分支，性能第一、简化次之，保持UI／UX／输出，只保留合理实测收益。起点5e94e5428e1cdd8510b392b7d00dc922280a5dc5；未重新引入已拒绝的全定位／原生advance／名称装饰缓存，增量构建仍排除。没有推送、tag、发布或启动产品可见窗口。两份hsn原有资源修改保持。

| 项目 | 分支 | 提交 | 最终修改与收益（本机片段） |
| --- | --- | --- | --- |
| H1 | codex/perf-23-selection-projection | f735dc3 | >=256来源组且>=8选择时建立本次保序seed范围桶、同范围选择桶和端点；小输入／坏端点保留直路，无持久缓存。5000字2500选择的投影119.534→12.150ms；1000字500选择6.210→2.410ms；无／单选择基本持平。共享candidate合并helper，来源交集／顺序不变。 |
| H2 | codex/perf-24-row-glyph-identity | 49780a4 | 同列更新直接比较完整glyphIDs，省掉两侧glyphKey临时串；导航key不变。5000列单GID5.747→1.769ms，四GID23.895→1.822ms。 |
| H3 | codex/perf-25-script-tags | 5e2ae99 | ICU四字节shortName直接Tag打包，保留原五例外及DFLT，去掉NSString／std::string／map过程，无新Unicode库或缓存。Helvetica5000拉丁prepareText3.508→2.822ms，其他脚本字体约6–20%省时。 |
| H4 | codex/perf-26-horizontal-display | c186651 | 方向读一次，横排未seed组在替换专用读取／substring之前跳过，仍完整原生布局。5000普通字20次必要行距重排138.552→124.237ms；有seed299.101→289.406ms。 |
| I1 | codex/perf-27-glyph-name-prefix | 0b09b1b | synthetic名称regex之前只排除不可能的ASCII首字母，非ASCII及原regex完整保留。每10000次Helvetica31.589→27.196ms、Lucida17.995→13.599、Skia20.058→13.638；PingFang22.320→22.598、Roboto25.707→25.466，近持平，不宣称所有字体都有收益。 |
| I2 | codex/perf-28-feature-source-tags | e744a6f | 第一个ASCII空格之前的tag用range／substring取得，不建立split数组，原去重顺序及标签内容保持。每10000新variant加1／3／8来源6.482→5.058、23.754→13.637、105.432→50.163ms。 |
| I3 | codex/perf-29-owned-glyph-hits | 01b7652 | 唯一调用者传入fresh且不再使用旧范围的native hit，映射直接消费该记录，省第二份临时hit。MergeHits输出仍独立，不泛化共享。5000普通字20次重排127.422→120.544ms，密集seed294.002→291.474ms；收益小但删除冗余对象且不加缓存。 |
| J1 | codex/perf-30-single-glyph-decoration | d066c4e | 单GID直接用已冻结／去重／升序的unicodeMap aliases，空GID直接清空，名称helper与多GID共用；多GID去重／排序及调用者base补值不变。每10000次Helvetica27.329→20.708、PingFang22.086→15.347、Lucida13.715→7.088、Skia13.943→7.058、Roboto25.203→17.939ms。 |

各项按实际原始／新源单独编译，未把内层细粒度插桩时间当算法收益。多数7轮中位，H1批量投影、H3同进程交错原／新函数；层级不同，不相乘为整应用倍数。H1初门槛64在100组无合理收益，正式提高为256。取消只要求触发后nil／未触发则完整，省掉工作后的poll次数不保证相同。

逐项等价：H1有320份随机通用投影（重叠／乱序／重复／空／NSNotFound／溢出范围）、6份真实完整投影、9份密集完整输出及90次取消安全断言；H2有81份原生侧栏像素／几何／选择／滚动／临时与空／多GID状态；H3有10554份完整TextRun／Item及unpaired-selector，其中3204份同类型同文本错误，另1114112个码值的scalarScript一致；H4有108份真实横／竖排三字体、三seed密度、竖排feature开关和三行距的像素／几何／leading命中／来源索引。I1有30000份名称分类、14529个真实GID名称及aliases；I2有3000份完整来源清单；I3有3000份直接映射及108份原生状态；J1有30000份分类及19529份单／空／多GID完整装饰输出，全部相等。探针私有属性通过KVC；仅诊断副本加export，生产无GAProbe或reference函数。

捨弃两项：徽章宽度缓存只在强制内部layout改善，实际1000次configure+layout在1／2／8／32码为67.593→69.537、89.820→93.711、236.575→238.303、850.285→852.343ms，没有实际收益，不增加font／width寿命状态。K1在修改前建立codex/perf-31-lazy-feature-sources；把mutable来源数组延后至首次add，3000份来源和9份真实完整投影一致，但每100000个无来源构造13.922→8.430ms，有1／3来源44.492→46.283、128.760→134.497ms；三字体100／1000／5000字完整投影大致±3%、无稳定实际收益，已恢复GAFontEngine.m精确前版，不提交该原型，返回最后保留的第30分支。

实施后连续第2／3／4／5轮复查，最终57个源码／构建脚本17966行，以完整文件哈希、结构／循环／分配扫描、当前diff及残余热调用链审查收敛，不称逐行形式证明。剩余徽章、来源getter缓存、绘制单GID分路、广泛TextKit／fallback缓存没有证据支持相称收益；GSUB／AAT发现、provenance及坏表事务恢复仍必需，IME／焦点／原生布局和菜单IO冷路不为凑项目而改。结论是目前未找到符合标准的新项，不承诺数学上没有任何优化。

最终从未插桩起点5e94e54和最终d066c4e分别编译，3份完整模型投影及22项取消／事务断言、9份完整原始候选结果、306份多字原生像素／几何／命中、81份侧栏状态及3888份基线状态全部一致。缓存基线与强制重读零差异，1倍参考的边缘基线最大误差9.094947017729282e-13pt。只在macOS14.8.7／Apple M3离屏验证；可见GUI与其它系统未验收。

./build.sh -u成功，二进制含arm64与x86_64。文件提供器再次为生成app附加FinderInfo／ResourceFork，strict验证先失败；只清生成bundle的这两项并ad-hoc重签，strict deep通过。提供器后来又附回，故最终验证脚本明确在清掉生成bundle属性后立即验证，记录此时间边界，不改源资源／构建脚本、不承诺外部metadata不会再出现。实际测试源哈希与当前一致；五个目标源文件外152个tracked文件内容及模式保持（包括两份hsn原状），git diff --check通过。

证据在diagnostics/performance-convergence-2026-11-11：progress.json列八项分支／本地提交／计时及轮次／拒绝决策，单项保存原始gzip／探针／日志／产品patch，review保存探索及拒绝原型，snapshots保存源码manifest与相对Git版本的诊断patch，final保存累计结果、构建／签名日志及verify.py／verification.json。最终分支codex/perf-30-single-glyph-decoration@d066c4ed186030d0bf156ee2cd247a52a6279129，两个原有本地化改动未提交。所有证据与交接保存后按用户明确请求执行pmset sleepnow；命令状态以progress.json／sleep-result.json为准。

### 按字形名称来源显示名称、CID 或 GID — 2026-11-11

用户授权按字体面采用字形名称数据，并确认 CID-keyed 字体可显示实际 CID 后执行。在 codex/glyph-label-provenance 实施：加载 face 时读 post 或 CFF1，name-keyed 取实际名称，CID-keyed 将 charset 映射转为 CID 标签，缺项回 GID。删去 CoreText 名称格式猜测；post 2.0 的非零 GID 指向未命名索引 0 时回 GID；支持 post 1／2／2.5、CFF1 预定义 charset 和格式 0／1／2，CFF2 读 post。不可变标签数据供变轴文档共享，内部继续按 GID 标识每个字形。

macOS 14.8.7／arm64 上，46 个字体面或实例共 803540 个标签与独立字体表解码完全相同。10 个产品离屏侧栏案例覆盖真实合成形态名称、缺项、CFF2、旧 post 2.5、多 GID、非同值 CID 与变轴共享。Hiragino 子集「一」为 GID 2，名称栏显示 CID 4162。Universal 构建通过，移除生成 app 的 FinderInfo／ResourceFork 后 strict deep 验签通过。证据见 diagnostics/glyph-name-origin-2026-11-11/implementation/。

### 字形名称来源分支的全项目省计算复查 — 2026-11-11

使用者要求浏览所有代码找与首行基准快取相似的优化。本轮审阅 codex/glyph-label-provenance@d066c4e 当前工作副本，60 个产品源码／构建脚本共 18377 行。与前次收敛时的完整源文件 manifest 比对，56 档逐字节相同，GAFontEngine.m 改动及 GAGlyphLabels.h／.mm／GAGlyphNameTables.h 新增。重查既有热调用链、字体加载／变轴、预览／侧栏、输入、字形发现与定位，以及新增四档的依赖。没有修改产品代码或既有资源。所有原型及构建在 /tmp/ga-review-20261111.VFoHv2，最终核对 60 档源文件哈希与开始一致。

优先候选三项，原型均在本机 macOS14.8.7／arm64，计时为同进程交错九轮中位，各数字只计各自的代码段。

1. GATextPreparation.mm 普通单个有 nominal GID 的 UTF-16 单位已会保留原字符，但先构造 substring、做 canonical composition、两次转 scalar 并重复查 cmap。原型直接使用已读 UTF-16、原范围和名义 GID，未编码、代理单位、变体选择符及多单位组合保留完整原路径。六字体 10578 组完整 TextRun、Item、来源、未配对 VS 或原错误完全相同。5000 字 Helvetica 2.822→0.780 ms、蘋方 6.273→1.935 ms、Geeza 3.392→1.018 ms；100／1000 字也有收益。正式实现宜共用原 Item 填充并补测原始候选及最终投影。
2. GAMultiGlyphView.m 的 MapGlyphLayoutRuns 映射完已拥有 fresh hit，但 MergeHits 一律排序、建立第二批记录和逐项二分归桶。原型在映射期间证明范围非空、顺序不逆、互不相交且端点有效时直接填好 leadingGlyphIDs 并沿用记录，其余走原合并。48 组四字体横竖排、seed、混合脚本及原生范围、字形顺序、leading 信息与 foreign set 对照完全一致，另强制旧合并比对。5000 字读回 Helvetica 横排 4.725→2.369 ms、蘋方 4.814→2.408 ms、Lucida 5.169→2.612 ms；阿拉伯文 Geeza 约持平。正式接入仍须用当前实际 UI 路径做等价验证。
3. GATextQueryModel.m 的组合字投影在同一 worker 查询／字体实例、相同 GID 与原文范围内，用 rebindVariant 再做一次原已计算的定位。原型只在组合字且同 fontBox 的当前查询投影中复制独立记录并沿用 positions，后续仍独立设定 base；换字体、临时项、来源或上下文变动仍重定位。六字体 120／1200 字共 12 份真实投影全部相等。Skia 1200 字 530 次定位→0，24.138→20.760 ms；Helvetica 213→0，2.605→2.480 ms；Hoefler 495→0，16.993→16.540 ms。建议明确限定同一完整扫描投影的所有权／文本身份，不能把 fontBox 判等当成通用 rebind 跳过依据。正式测例应加明确选择及变轴。

次优先是 GAAllGlyphsView.m 的筛选投影。即使同一 inventory 和完全相同的输出 GID 集合，仍重新组 entries 并分配 pageMetrics／valid 缓冲。蘋方 49519 项、重复应用 37139 项同一集合，每次现行路径约 0.811 ms，重新建约 2.02 MiB 的两个度量缓冲。此项只测了现行成本，尚无新原型收益。可复用排序及存储并在实际新字体实例时失效度量，保留现有布局、滚动、高亮重置／重定位。跨坐标实际 GSUB 输出可变，不能只比 tag。

排后两项。CTRun 直接指针原型 48 组与原复制完全一致，也强制分别为空回退；Helvetica 与蘋方的非空 run 两种指针均为空，Geeza 与 Lucida 可借指针但仅约 2–3% 读回片段收益，不优先为此增加分支。新增名称解析按 face 共享的方向合理；已有 CTFont 上重复构建标签资料的片段约 0.002–0.213 ms，未测出足够理由引入新延迟状态。前几轮已放弃的跨实例 advance、完整定位结果及名称装饰快取没有新证据推翻原结论。

审阅及原型证据见 diagnostics/performance-review-glyph-labels-2026-11-11/review.json 及相邻原始样本、源码探针和 patch。用户请求是審閱，以上留作后续实施候选。

### 逐分支实施四项后续优化 — 2026-11-11

使用者明确授权四项全部实施，每项改动前先建分支。性能优先、结构其次，保持当前 UI／UX／输出，收益不相称即放弃。本轮以 codex/glyph-label-provenance@d066c4e 的实际工作副本为起点。四项各自验证后建立本地提交并顺序叠加，全部保留。起点未提交的字形名称来源与两份 hsn 本地化仍留在工作区。GAFontEngine.m 以单轮补丁单独暂存，最终核对未提交的名称改动块完全一致。

| 分支 | 提交 | 改动、收益及等价结果 |
| --- | --- | --- |
| codex/perf-32-single-scalar-preparation | 01dfb40 | 已编码的单个非代理 UTF-16 单位直接沿用码值、GID 及原文范围，原复杂路径共用 Item 填充。六字体 10578 组完整准备结果／同类型错误一致。5000 字 Helvetica 2.822→0.769 ms，蘋方 6.244→1.957 ms，Geeza 3.401→0.977 ms。 |
| codex/perf-33-ordered-glyph-hits | 2058aac | 映射时检测非空、保序、无交叠的来源范围，符合时直接沿用 fresh hit 并填 leading GID，其他输入走原合并。48 组真实 TextKit 横竖排、固定 GID、混排及 foreign set 完全一致。5000 字读回 Helvetica 横排 4.879→2.442 ms、蘋方 4.933→2.464 ms；Geeza 约持平。 |
| codex/perf-34-combination-positions | 904550a | GAGlyphVariant 支持独立复制记录及可变来源数组。当前查询同实例的组合字沿用原先为该段文字计算的 positions，跨实例仍重新定位。七字体、指定字形与前后变轴共 36 组投影相等，其中 8 组涉及变轴或跨实例。Skia 1200 字 530→0 次定位，23.368→2.654 ms；Hoefler 495→0、15.833→2.348 ms。正式复制共用不可变来源清单，节省先前原型仍重复做的来源标签去重。 |
| codex/perf-35-filtered-grid-reuse | beb965e | 同一 inventory、相同筛选 GID 集合时复用格子排序结果及两个度量缓冲。新 fontBox 仍使度量失效，原高亮重置与布局入口保留。四字体共 192 组像素、条目、滚动、格子尺寸和高亮状态相等，覆盖冷启动、不同设置、实际 liga、相同／不同集合与可变字级。蘋方相同 37139 项 0.831→0.00027 ms、约 2.02 MiB 度量缓冲重建→0；相同 24759 项稀疏集合 0.556→0.0108 ms，变更集合的测量约持平或小幅改善。 |

各项片段计时均在同一进程交错比较，前三项取九轮中位，全字取十一轮。实际整窗耗时随字体、文本与交互而异。全字初版误把内部属性命名为 visibleGlyphIDs，与已有 setVisibleGlyphIDs: 冲突，原生探针抓到递迴；改为 appliedGlyphIDs 并重新编译、重跑该项与累计验证。探针初版另有未注明数组元素类型导致 glyphID 方法歧义的编译问题，修正后才计结果。最终分支及提交只包含修正后的版本。

用起点及最终实际 Sources 快照分别构建，同一 Mac 离屏累计检查 3 份完整模型、22 个取消／事务断言、9 份原始候选、306 份多字原生像素／几何／命中、81 份侧栏及 3888 份基线状态均相等（计时字段除外）。所有基线缓存与强制重读相等，首行边缘对 1 倍参考最大误差 9.094947017729282e-13 pt。7 个目标源码外 153 个文件的字节和模式保持，实际验证源与当前文件吻合，git diff --check 通过。只覆盖本机 macOS 14.8.7 arm64 离屏行为。

产品 universal 构建通过。生成 app 被文件提供器再次附加 FinderInfo，清除生成包的 FinderInfo／ResourceFork 后立即 strict deep 验签通过。未改构建脚本或源资源。最终分支 codex/perf-35-filtered-grid-reuse@beb965e。证据与原始样本见 diagnostics/performance-four-followups-2026-11-11/verification.json 及同目录。临时完整源码和探针构建位于 /tmp/ga-perf-next.5Gkuh5。

### 第35项之后的省计算复查 — 2026-11-11

使用者要求继续浏览代码。现行 codex/perf-35-filtered-grid-reuse@beb965e 的60个源码／建置脚本18421行，与第35项最终源码快照逐文件匹配。重查定位、模型投影、多字预览、字形目录及变轴共享边界。没有改产品源码或操作可见App窗口。临时原型与探针在 /tmp/ga-review-later.Kw9BBo，证据在 diagnostics/performance-review-after-35-2026-11-11/。

优先候选是单GID位置快捷路径。positionsForGlyphIDs只输出首原点时，最后的advance不会反映到返回值。当前执行器的pair、cursive、mark及kern／kerx需要另一个字形才会移动原点；context可嵌套type 1，因此需在字体解析时保留扩展解包后的所有GPOS type 1 coverage，只有此GID完全未覆盖才可沿用单一零原点。继续先做原有文字上下文处理，字级及字体单位需有效，仍输出一项零点。不是将所有单字设零，也不是跨坐标缓存定位值。八字体加一合成fixture，16769个数组结果一致，保留14笔非零位移，直接extension lookup、context嵌套type 1及仅pair控制原点分别{20,40}、{-28,14}、{0,0}pt。每5000次位置调用九轮中位Helvetica 3.278→0.825ms、蘋方3.392→1.367、Skia 30.094→0.832。这是定位片段，不是整次查询。

第二项是横排无指定GID时略过替换排序。上一轮H4跳过普通组的替换内容，但此前仍排序全数组。隔离原型只在横排且未发现任何seed时提早返回普通富文字。正式实现可用rebuildLayout已有的atomic列表作同一判定，保留顺序相同的复杂输入处理。72组原生横竖排、普通／指定GID、控制／缺字的像素、几何、命中及sourceIndices一致。5000字Helvetica每次完整行距重排4.475→3.747ms，蘋方4.449→3.733ms。Lucida长文本原生上下文GSUB成本占比大，节省比例小，采样确认时间集中于CoreText shaping。合成密集seed对照仍走原排序。

第三项是多字快照内的来源／显示记录共用。两边同一UTF-16范围时，新建一份记录即可，仍由map查得来源；缺字省略等导致坐标不同才独立建立显示组。建立快照期间直接持有上次来源记录，避免逐组再从map查回；合并组合时同对象只改一次范围。来源及显示对象的身份允许相同，已查目前消费者只读字串、GID及范围，不依赖是两个对象。三字体72份测试（包含拆分组合、缺字、控制及指定GID）完整输出一致。5000字Helvetica快照5.515→4.961ms，蘋方5.684→5.184ms。正式实施还需核对真实查询投影与多字点选回侧栏。

舍弃直接批量BMP nominal mapping。十二个字体现有Unicode aliases对照中有一份不同。HiraginoSans-W3 的批量 CoreText 调用回报成功，但把原版逐码忽略的U+FE00、U+FE01映射到GID65535，不能仅凭布尔成功认为等价。蘋方现有字库构建18.919→17.475ms的收益不足以接受此差异。本轮不将该原型列作实施项。

### 先实测再保留三项定位与预览优化 — 2026-11-11

使用者授权三项先测后决定，特别要求第2、3项收益足以匹配结构复杂度。以现行 codex/perf-35-filtered-grid-reuse@beb965e 工作副本为起点，在隔离副本验证拟接入代码。三项收益皆成立，各自在改产品源前建立分支并顺序叠加本地提交。未混入原有未提交的字形名称或两份hsn本地化。

| 分支 | 提交 | 保留原因及量测 |
| --- | --- | --- |
| codex/perf-36-single-glyph-origin | c2c5f31 | 解析时记录GPOS type 1覆盖，已解包extension及被context调用的覆盖皆在内。原有文字上下文之后，单GID且无覆盖时沿用一个零原点。16769个位置数组相等，其中14个非零；直接、巢状及pair控制{20,40}、{-28,14}、{0,0}pt。Skia 5000次定位29.409→0.794ms，1000字已暖发掘缓存的rawScanContent 15.087→2.287ms，Helvetica 1.780→1.205，Amstelvar 3.505→1.174，完整候选与位置相等。 |
| codex/perf-37-skip-unused-preview-sort | 3bb1598 | 复用rebuildLayout已有atomic列表，把是否有seed传给显示副本构建。横排无seed在富文字及缺字属性准备后直接返回，无额外扫描／快取。Helvetica 5000字完整行距重排4.191→3.745ms，蘋方5.872→5.325ms。指定GID及Lucida长上下文路径大致持平，个别测例小幅波动。90组横竖排原生像素、几何、命中及显示索引完全相等。 |
| codex/perf-38-preview-source-locations | c7bd2e4 | 改为每组一份显示记录。内部映射仅存原文起点不同的项，长度由该组共用；合并只延长，不会改变起点。移除第二套source组、重复文字／范围更新及每组map反查。对外由sourceRangeForMultiGroup:统一解析坐标，唯一控制器消费者直接用范围。Helvetica 5000字快照5.374→2.961ms，蘋方6.344→3.659ms。81份完整预览快照含9份真实查询投影相等；实际控制器接收227个区间时对侧栏发出的GID及来源范围请求一致，覆盖前缀省略、内侧缺字、组合、间断来源及首组件失败后的base回退。侧栏探针只记录调用，不打开窗口。 |

片段计时为同进程交错九轮中位。预览计时初跑的快照两个函数选取方向写反，已改正并重跑；仅用最终preview-results，错误标签数据仅作为实验历史保留。第3项缩减资料模型，未沿用前轮两份记录有时指向同对象的原型设计。

累积回归与第35项完整源码清单及原数据比较，3份模型及22项取消／事务、9份原始候选、306份多字像素／几何／命中、81份侧栏状态及3888份基线逐字段相等（计时除外），基线与强制重读一致，边缘误差9.094947017729282e-13pt。实际验证源码与当前哈希匹配，7目标源码外153文件字节及模式保持。macOS14.8.7／arm64离屏验证。产品universal构建通过。生成包上文件提供器再次加回FinderInfo，归档验证改在/tmp的无附加属性副本执行，逐档哈希与产品包一致并通过strict deep验签。最终分支 codex/perf-38-preview-source-locations@c7bd2e4。证据见 diagnostics/performance-three-followups-2026-11-11/verification.json 及相邻数据、探针和patch；完整隔离快照在 /tmp/ga-perf-three.Q45IIc。

### 第38项之后的侧栏与预览分配复查 — 2026-11-11

使用者要求继续看代码。本轮审阅 codex/perf-38-preview-source-locations@c7bd2e4，59份源码和build.sh与前轮验收源码／起点哈希完全相符。热路径复查及原型均在 /tmp/ga-review-38.7HCS5I；产品代码、分支和既有修改未动。证据见 diagnostics/performance-review-after-38-2026-11-11/review.json。

建议两项。第一，GABuildDisplayGroups普通组有完整variants数组，只有含连字候选时才需过滤另建数组。DisplayCopy保留独立组，但可沿用原不可变数组。源组已严格按位置、长度排序且未另加seed组时也可跳过sort；范围重复、乱序及追加seed保留现行排序。分开比较两优化及组合，共288次真实字体投影对照一致，含重复／逆序／指定字形。4种真实1000字投影中，组合Helvetica 1.043→0.874ms、蘋方0.455→0.218、Geeza 0.870→0.655、Skia 2.083→1.903；主要来自省掉变体临时数组，单独省排序在蘋方约0.033ms。5000个普通模拟组Helvetica 1.883→0.903ms；该数字不是整次分析耗时。

第二，GAMultiGroupIdentity维持完整范围、文字、seed、insertedLigature和完整GID序列的快照比较。把每组NSValue范围及内层NSArray改成固定六槽的平面数组，两个槽放range location/length。无跨请求新状态或改变重建条件。3字体现有TextView横／竖排及5类原地字段修改共180组像素、原生几何、命中及索引一致。同一文本及5000组重复setText的隔离比较Helvetica 1.763→0.832ms、蘋方1.744→0.805。这里只计更新及判等，layoutActive=NO。

淘汰更激进的普通组不建identity。它静态上看似只影响是否重建，但原地更新普通组的GID时有24个原生对照的几何和像素不一致。让两边同样再次布局可恢复一致，支持保留当前重建节奏；没有把差异归到某一未证实的TextKit机制。暂缓仅在最终原生fallback处理完成后映射命中：无需跨布局状态，但实际模型投影输入720单位的完整重排仅25.375→25.019ms，240单位3.110→2.986ms，收益相对小且只在二次排版发生。对照覆盖原生字体替代、控制字和指定字形，暂不排入前两项。初版长密集fallback基准因原生重排耗时长而终止，缩小为240／720单位后记录成功样本。三方向均未接入产品。


### 逐分支实施侧栏清单与预览比对优化 — 2026-11-11

使用者明确授权两项各自先建分支，实测有收益且 UI／UX／结果一致才保留。起点 codex/perf-38-preview-source-locations@c7bd2e4，原有名称来源和两份 hsn 本地化修改留在工作区。各项以实际拟保留源文件建立隔离副本，旧函数仅加入诊断副本作同进程交错对照。

第一项先建 codex/perf-39-sidebar-variant-list-reuse。DisplayCopy 保留独立组，先检查是否有连字候选，仅在需要过滤时另建 variants 数组。六个直接用例确认复制隔离、不可变数组沿用、连字过滤顺序、全连字与空组。五字体120份真实投影相等，覆盖逆序、重复范围和明确选择。投影直接送进真实侧栏，360次离屏像素、行矩形、选取 GID、临时项标志和滚动范围相等。100／1000字两规模同进程九轮交错中位均有收益。1000字Helvetica 1.075→0.941 ms、蘋方2.460→2.147、Geeza0.853→0.677、Skia1.896→1.716、Lucida0.455→0.238。该计时只含侧栏投影片段。保留第一项。原排序逻辑保持，正式源码只改DisplayCopy。原始数据、探针及源清单见 diagnostics/performance-two-followups-2026-11-11/。


第一项本地提交29609e6后，建立codex/perf-40-flat-preview-identity。第二项将每组NSValue范围及内层NSArray改为固定六槽平面数组，保留原先所有判等字段及复制语义。三字体横竖排、普通／指定GID与五类原地字段变更，180组原生像素、布局几何、命中、leading GID和显示索引相等，另逐次比对实际显示副本的重建次数一致。100／1000／5000组重复setText在layoutActive=NO条件下，同进程九轮交错中位均改善约50–54%。5000组Helvetica1.658→0.771 ms、蘋方1.667→0.785、Geeza1.666→0.792。此数字只计设置及判等片段。保留第二项，本地提交25d0cd7。正式源仅改GAMultiGroupIdentity，无额外跨请求状态。

累计回归先确认本轮起点所有源码哈希与第38项验收源码清单完全相符，再用最终实际源独立构建。3份完整模型及22项取消／事务断言、9份原始候选、306份多字像素／布局／命中、81份侧栏状态及3888份基线逐字段相等，仅排除seconds计时字段。基线缓存与强制重读均相等，首行边缘误差9.094947017729282e-13 pt。两个目标源码外158文件字节及模式保持，最终验证源与当前文件吻合，git diff --check通过。产品universal构建通过，在/tmp无文件提供器附加属性的逐档字节一致副本上strict deep验签通过。范围是macOS14.8.7／arm64离屏验证，真实窗口操作由用户验收。证据见diagnostics/performance-two-followups-2026-11-11/verification.json及相邻原始数据、探针、patch和源清单，完整隔离副本位于/var/folders/7g/9md6b191673fmyv9wssspz840000gn/T/ga-perf-two.3r80zua9。当前分支codex/perf-40-flat-preview-identity，顺序包含两项本地提交。


### 第40项之后的查询排序与身份分配复查 — 2026-11-11

使用者要求继续看代码。本轮起点codex/perf-40-flat-preview-identity@25d0cd7，与上一轮验收源码清单的60份源码／build.sh逐文件一致，共18467行。复查查询模型、raw结果构造、共享完整查询／段落缓存、组合候选去重、布局、侧栏选择、输入排程、变轴控制及资源归并的热调用边界。隔离副本与原型在/var/folders/7g/9md6b191673fmyv9wssspz840000gn/T/ga-review-40.2e1iau20。产品源码、分支及既有修改保持，结束时160份初始文件的字节及模式相同。证据见diagnostics/performance-review-after-40-2026-11-11/review.json。

三项建议。第一，discoverContent缓存的是排序前的完整候选，discoverText每次命中缓存仍mutableCopy并稳定排序。原型把现有排序移到完成发现、存入缓存之前，缓存冻结后的最终顺序，命中直接沿用。没有增加缓存或键。六字体96份首次／命中候选、48份完整raw输出与30个取消阈值结果一致，含明确GID。九轮同进程交错、交替重查两份已缓存文字，1000字完整rawScanContent Helvetica1.280→1.223 ms、蘋方10.898→10.137、Geeza1.986→1.842、Skia2.979→2.669、Hoefler2.225→2.005、Lucida2.428→2.316。单独发现入口Skia0.300→0.0007 ms，但完整查询仍重新定位。这些收益仅在完整查询命中时适用，当前模型已经跳过完全相同的连续分析。正式接入还需补预算耗尽、共享变轴实例、并发与取消后发布语义及实际UI累计验证。

第二，GAGlyphQueryKey为每个明确选择建立内层NSArray，身份结构私有。原型保持文字、原范围、完整GID序列及现有hash规则，仅将每个选择的起点／长度／GID数组按固定三槽放入单一components。189对身份／hash／字典取值关系相同，含空、次序、重复、改字及改范围／GID。1000个选择的键构造0.181→0.124 ms，真实模型入口重复相同分析0.218→0.128 ms；100个选择模型入口0.0249→0.0150 ms。一个选择时约0.000825→0.000850 ms，差0.000025 ms，空选择相同。无新增状态、分支或跨请求缓存。正式实施须补完整模型及选择／原地变更累计对照。该项与第40项的预览身份是两个独立入口。

第三，rawScanContent抽取的base前缀已由唯一discoverText生产者按来源位置排好，仍再排一次roots，之后补未覆盖字符后又排序。原型只省掉第一次roots排序，保留补齐后的最终排序。48份完整raw输出一致。与第一项原型比较，1000字再省约0.071–0.094 ms，改动仅删一行。正式实施须明确生产者排序契约并补相同起点／特殊来源范围及累计回归。这个提案与前轮暂缓的侧栏投影排序不同。

淘汰组合候选直接以NSArray取代glyphKey字串作NSSet去重。六字体真实100／1000字投影有约0–14%收益，52份真实／合成输出一致，但本机同长度数组hash相同（两组不同双GID数组均为2），大量同长候选产生严重碰撞。64笔不同双GID组合0.171→0.483 ms、512笔1.660→27.197、2048笔6.645→439.667。不能照搬前轮两数组直接判等的收益，集合去重的成本不同。没有为此新增hash包装或第二套散列规则。

以上均为macOS14.8.7／arm64隔离原型、同进程交错九轮中位及数据等价检查，保留为实施候选，未作GUI等价验收。原型生成最初因源码目录内DS_Store被当UTF-8读入而中断，改成先比字节、只解码改动文件后重建；另在编译前修正函数提取必须从implementation之后定位，避免误抓私有声明。最终结果仅来自修正后探针。


使用者追问三项是否真正值得，以及第二项与上一轮的关系。复核现行两个身份入口及原始计时后，将实施建议收敛为优先第1、3项，第2项暂缓。第2项零选择无收益、单选择未量到改善，1000个选择时模型重复请求约省0.0894 ms，性能收益的适用面和绝对值有限。该项是查询输入身份GAGlyphQueryKey的三槽平面化，前轮第40项是预览显示身份GAMultiGroupIdentity的六槽平面化，方法相同、消费阶段及字段各自独立。此为代理对成本收益的建议修正，尚非使用者的实施决定。第1项只在重查完整缓存命中时节省排序，当前模型对连续相同请求已有直接返回；第3项删除生产者已保证顺序后的重复排序，改动一行。未修改产品源码。


### 逐分支实施查询排序与身份分配三项 — 2026-11-11

使用者明确「都做」，授权三项逐项先建分支、量测收益及等价后保留。以codex/perf-40-flat-preview-identity@25d0cd7当前工作副本为起点，保留原有字形名称来源与两份hsn资源修改。

第一项先建codex/perf-41-sorted-query-cache，将原有NSSortStable排序移到完整发现的缓存写入前，冻结最终数组，缓存命中沿用排序后结果。沿用原取消poll点及计数。接口注释明确base优先且按来源位置排序。六字体144份首次／命中候选、72份完整raw结果、252项取消／重试／完整缓存保留、144份并行共享读写、4份Skia及Amstelvar极端坐标共享缓存结果通过。真实构造65层context lookup触发执行深度限制，4次对照保留相同候选并标incomplete，均未写入完整缓存，重试确认再次发现。原型的额外取消poll已在正式实施时省掉，以保持原有检查次数。100／1000字同进程九轮交错重查两份完整缓存输入。1000字rawScanContent Helvetica1.298→1.244 ms、蘋方10.967→10.169、Geeza1.963→1.812、Skia2.900→2.600、Hoefler2.202→1.993、Lucida2.394→2.255。收益限定完整缓存命中。第一项保留。证据见diagnostics/performance-query-followups-2026-11-11/。


第一项本地提交6b658d2后，建立codex/perf-42-flat-query-identity。第二项仅把GAGlyphQueryKey每个选择的起点／长度／完整GID数组放入固定三槽，沿用全部hash规则。189对完整身份／hash／字典查找关系、5项可变输入隔离及边界范围、三字体21项原地选择范围／GID／文字变动与恢复后的完整模型相等。实际重复模型入口九轮交错中位：1000选择0.2299→0.1377 ms、100选择0.025125→0.015400、10选择0.003800→0.002800，空选择0.000450→0.000425、单选择0.000800→0.000750（后两者近持平）。以大量明确选择为收益场景，仅三行追加代替一行嵌套数组，不增加分支或缓存。第二项保留。


第二项本地提交95ef140后，建立codex/perf-43-reuse-ordered-roots。第三项只删rawScanContent构造roots之前的第一次排序，依第一项公开注明的生产者顺序契约，补齐字素来源后的最终排序保持。72份真实字体完整raw输出及7份空／重复／同起点不同长度／零长／部分覆盖的有序范围输入相等。1000字九轮交错中位：Helvetica1.209→1.138 ms、蘋方10.444→10.227、Geeza1.838→1.766、Skia2.601→2.518、Hoefler1.982→1.897、Lucida2.250→2.167；计时以第一、二项已接入的版本为对照。第三项保留，本地提交b9da2ef。GAFontEngine.m原有未提交名称改动留在工作区，index只暂存一行删除，并在最终验证中以初始全文替换该一行后逐字节核对。

三项累计从最终实际源独立构建，比较第40项验收源（已逐档核对起点相符）及原始输出。3份完整模型及22项取消／事务断言、9份完整原始候选、306份多字原生像素／几何／命中、81份侧栏状态、3888份基线逐字段相同，仅排除seconds。缓存基线与强制重读相同，首行边缘对1倍参考最大误差仍9.094947017729282e-13 pt。最终源清单与当前文件一致，四目标外156份初始文件字节及模式保持，GAFontEngine.m名称改动按初始全文加本轮单行删除严格核对相符。Universal产品构建与/tmp逐档字节一致、无文件提供器附加属性副本的strict deep验签通过。范围为本机macOS14.8.7／arm64离屏，实际窗口互动由用户验收。最终分支codex/perf-43-reuse-ordered-roots@b9da2ef，顺序包含6b658d2、95ef140、b9da2ef。原始结果、比较脚本、源manifest、探针及patch见diagnostics/performance-query-followups-2026-11-11/verification.json及同目录，完整隔离源位于/var/folders/7g/9md6b191673fmyv9wssspz840000gn/T/ga-perf-query.hyuhw_64。

诊断构建最初用C的Unicode escape表示U+0001而被编译器拒绝，改为八进制字串escape后重新构建并通过，正式产品源码不含此测例。验证报告初版把预览资料的cases字段误读为native，显示计数0；完整逐字段比较已通过，修正报告统计为306并重跑验证脚本。

### 第43项之后的收尾复查与停止建议 — 2026-11-11

使用者要求继续看代码，并询问是否已难找到值得做的新优化、接近停止。本轮从codex/perf-43-reuse-ordered-roots@b9da2ef复核查询／候选聚合、切轴重绑与排程、GPOS定位、预览来源及缺字重试、侧栏选取与临时项、全字定位／筛选及名称读取的当前调用链。60份源码／build.sh哈希与上一轮最终验收清单完全相符。现有完整查询与段落缓存、定位上下文、变体delta、页面度量、同输出复用、有序范围与二分路径均已接入。没有发现新的、同时具备合理收益证据及简单改法的实施候选。

后续潜在方向仍集中于更广的定位／显示副本缓存、计划复用、特殊度量或来源条件分支。既有证据中已出现字体间退步、首用成本、微小收益、额外失效管理或结果差异，当前复查未发现足以推翻这些取舍的新依据。没有把剩余循环本身当作值得修改的理由，也没有把源码复查当新性能测量或GUI验收。建议在此结束本轮普遍性能优化，之后由实际卡顿或具体性能剖析结果驱动新的定向工作。本轮仅复查及记录，产品源码与分支保持。

### 全项目逻辑整理与既有优化成本审核 — 2026-11-11

使用者把本轮重点改为全代码逻辑整理，并授权有充分理由时撤回收益不大的既有优化；随后强调全代码的逻辑整理为主，允许先完成正在做的成本审核。本轮以codex/perf-43-reuse-ordered-roots@b9da2ef的实际工作副本为起点，按App、Input、Font、FontLayout、Views及构建入口检查模块职责、接口消费者、状态所有权、表示转换、取消／失败／发布边界与既有性能分支。60份源码／build.sh清单、职责及保留理由记录于diagnostics/logical-review-2026-11-11/audit.json。方法是模块和数据流审阅，不宣称形式化逐路径证明。

既有优化成本复核后，本轮没有新增撤回。已拒绝的原生advance缓存与已删除的名称装饰缓存保持原决定；当前较小收益的身份平面化、已排序输出复用和单行排序删除，也减少中间对象或重复工作，没有新失效状态。大输入builder／范围索引、LTR pen、定位上下文、变体delta、隐藏布局等仍有合理收益或行为依赖。保留原生输入生命周期、菜单所属窗口、文件替换身份核对、GSUB／AAT预算与坏表延迟失败规则，没有把表格式差异或回调时序硬合并。

第一项改动前建立codex/logic-01-sidebar-glyph-identities。侧栏pending、选取恢复、捲动锚点及通知去重统一使用完整glyphIDs数组，主窗口三个调用点及侧栏接口一起改名为selectGlyphIDsAfterNextReload。数组采用copy保存值，nil仍表示没有请求，空数组仍是有效的空GID序列。glyphKey仅留作组合候选集合去重，避免重新引入此前NSArray hash碰撞方案。前后完整源分别编译，三字体75份侧栏像素／行框／选取／捲动状态及3份回调序列完全相等，覆盖空／单／多GID、未命中base回退、两种捲动策略、可变请求数组、来源位移、重载和清空恢复。本地提交c69c646。

第二项前建立codex/logic-02-combination-projection-stage。GABuildDisplayGroups先完成来源与明确选择投影，再调用私有GAInsertCombinationGroups处理组合范围分组、跨度计数、排序、独立组合根与插入锚点。机械核对抽出的原函数体在参数groups改名为scanGroups之后逐字相同，没有新增跨调用状态。五字体120份投影、600项取消／完成结果及360次实际离屏侧栏状态相等。本地提交0e67765。主函数和组合阶段各自表达完整职责，没有为格式相似的方法再增加通用包装类。

两项累计用最终实际源独立构建。与第43项验收资料比较，3份完整模型及既有取消／事务断言、9份原始候选、306份预览像素／原生几何／命中、81份侧栏状态、3888份基线逐字段相同，仅排除seconds。缓存基线与强制重读相同，首行边缘误差9.094947017729282e-13 pt。最终源码哈希与实际测试源吻合，四目标之外156份初始文件字节及模式一致，包含原有GAFontEngine.m名称来源及hsn资源修改。Universal产品构建通过，在/tmp逐档字节一致且无文件提供器附加属性的副本上strict deep验签通过。范围为本机macOS14.8.7／arm64离屏，真实窗口互动由用户验收。证据见diagnostics/logical-review-2026-11-11/verification.json及相邻探针／patch／原始数据，临时完整快照位于/var/folders/7g/9md6b191673fmyv9wssspz840000gn/T/ga-logic-review.ednsqypi。当前分支codex/logic-02-combination-projection-stage依序包含两项提交。

### 广义质量收尾复查 — 2026-11-11

使用者要求再review一遍，检查广义可改进之处并准备收工。本轮从codex/logic-02-combination-projection-stage@0e67765复核状态／回调生命周期、窗口关闭时作废、异步结果发布、菜单所属窗口、输入撤销与标记、文件复制身份核对、错误与取消分类、预算耗尽、接口消费者及上一轮新身份／组合投影边界。60份源码／build.sh与上一轮实际验收源哈希完全一致，四个既有逻辑改动目标之外的156份初始文件内容及模式保持。沿用已核对来源的既有验收数据，本轮没有重跑构建或原生测试，也没有新增产品改动候选。建议结束本轮产品性能及逻辑整理。

一项低优先级维护记录留给将来的常态回归工作。diagnostics/logical-review-2026-11-11/final-model.m、final-paragraphs.m及final-regression.m等诊断入口仍引用个人字体目录和/tmp/ga-vf-baseline.KvUE2A内的字体验证材料；这些字体当前全部存在，但临时目录清理或迁移机器后，需要重新准备。现有verify.py核对归档输出和源清单，本身不生成全部原生测例。未来如把这组探针发展成日常可重复的测试入口，应集中配置字体位置与依赖准备。历史探针及其原始证据保持，暂存路径整理作为独立测试工具工作，不据此扩展本轮产品代码范围。

### 取消独立诊断工具整理并收尾 — 2026-11-11

使用者最初允许改善诊断重跑依赖，代理创建codex/test-01-native-regression-runner分支及Tests/NativeRegression草稿。随后使用者确认这些属于独立诊断工具，明确决定「不用管了，我们的主程序没问题就行」。按此取消测试工具工作，移出全部未提交Tests/NativeRegression草稿及其本轮构建资料，保留为可恢复的系统暂存副本；空父目录一并清理。该临时分支没有提交，核对与逻辑整理分支同为0e67765后返回codex/logic-02-combination-projection-stage并删除空分支。前后160份原有文件的字节及模式严格相同，原有诊断归档及主程序成果保持。试验中的环境探针检查未完成，草稿未作为可用工具交付。本轮按产品程序整理完成的状态收工。

### 再次广义产品审阅 — 2026-11-11

使用者再次要求review广义可改进之处。本轮在codex/logic-02-combination-projection-stage@0e67765复核主程序的窗口／菜单所属关系、关闭与快速变轴时的请求作废、worker完整发布与延后编辑、选取数组的值快照、颜色菜单无窗口情形、字体文件复制失败路径、GSUB执行限制、cmap／名称表读取边界和首行基准失效规则。核对颜色比较的实际调用方向，空窗口时为nil接收者，没有把假设违反nonnull参数契约的情况列作实际缺陷。60份源码／build.sh仍与最终验收源逐字节一致，原逻辑改动四目标外156份初始文件内容及模式保持。

此次没有发现新的、具备具体依据且值得实施的主程序改动。大控制器继续拆对象会牵涉窗口与异步回调所有权，目前没有足够收益理由；既有优化取舍也没有新证据需要推翻。结论基于原码及既有已验数据，本轮没有新增构建或原生运行验证。尊重使用者已取消的独立诊断工具工作，未重新开启该方向。建议保留当前成果，结束这轮普遍整理。

### 閩南話術語與幫助校訂 — 2026-11-11

依使用者要求校訂閩南話繁簡資源：font 統一使用「字體／字体」，開啟位置的子選單省去重複的字體名，並修訂部分選單和幫助的閩南語用字與句法；臺灣用語參考教育部臺灣台語常用詞辭典，閩南地區用字仍需熟悉當地語言者複核。長沙話繁體幫助中「顯示方式」改為與選單一致的「顯示方灋」。檢查各語言「」引用、格式參數，以及兩套閩南話鍵值與英語對應；改動資源通過 plutil lint 和 git diff --check，未進行 GUI 驗證。


### 三轮逐文件精简、逻辑与结构整理 — 2026-11-11

使用者明确授权三轮按文件整理：第一轮删除无效代码／接口／省缺值赋值，第二轮整理复用与逻辑顺序，第三轮按职责整理 Sources 文件。代码直接修改，每处说明；注释可以直接修正；UI、UX 与结果保持；发现的 Bug 或产品决定留待下一轮共同处理。此次授权仅用于这组三轮，不以旧的逐次确认规则重复阻挡。

起点为 codex/logic-02-combination-projection-stage@619bce7 实际工作副本。改动前保存 Sources、Resources 和 build.sh 到 /tmp/ga-three-round-cleanup-h2zvauha/round-0，保留原有七份资源修改与其他工作区内容。三轮依序创建 codex/cleanup-round-1-unused-code、codex/cleanup-round-2-logic、codex/cleanup-round-3-source-structure。没有本地提交或推送，因此三个分支名仍指向相同起点；各轮工作树状态另有完整暂存快照，独立 patch 存于 diagnostics/three-round-source-cleanup-2026-11-11/，不能把单纯切换这些分支当作还原某轮源码。

按原有59份 Sources 文件建立接口／符号引用清单，核对单次出现的委派、事件、属性 setter、旧SDK公开接口声明及各初始化调用路径。没有找到可确认已经无调用的产品或测试接口，未删除系统回呼。首轮实际25处变更，其中21处是局部强引用对象声明省去显式 nil；ARC仍自动初始化为nil，后续状态清空赋值、数值及C指针初始化均保留。每处如下：

| 编号 | 文件与位置 | 说明 |
| --- | --- | --- |
| 1–4 | GAAppDelegate.m | 常用文字菜单的command、右键分隔线separator、字体复制error及命名冲突nameError省去nil初始化 |
| 5–7 | GAMainWindowController.m | 全字追加selection、延后编辑匹配match、侧栏激活selection省去nil初始化 |
| 8–10 | GAFontEngine.m | 候选builders、indices及重复候选existing省去nil初始化 |
| 11–12 | GAFontResource.m | 文件类型value及复制error省去nil初始化 |
| 13 | GAGlyphLabels.mm | 名称解析结果names省去nil初始化 |
| 14 | GASubstitutionEngine.mm | 另一方向的来源otherMode省去nil初始化 |
| 15 | GAInput.m | 待插入的字符串inserted省去nil初始化 |
| 16 | GADetailViewController.m | 当前滚动视图scrollView省去nil初始化 |
| 17 | GAMultiGlyphView.m | 排版字体font省去nil初始化 |
| 18–21 | GASidebarViewController.m | 临时项旧父行oldParent、重绑parent、旧oldGlyphIDs及选择源group省去nil初始化 |
| 22 | GAMainWindowController.m | 删除sidebarItem.allowsFullHeightLayout=YES，SDK明确省缺为YES，创建后未被其他值覆盖 |
| 23 | GAMainWindowController.m | 删除新建字名NSToolbarItem的bordered=NO，SDK明确省缺为NO；自订视图为无bordered接口的NSStackView |
| 24 | GASidebarViewController.m | 删除新建列表usesAutomaticRowHeights=NO，SDK明确省缺为NO；原有行高计算保留 |
| 25 | GAGlyphBuffer.h | 删除Budget.discovery的类内false初值；唯一构造器始终通过discovery(isDiscovery)赋值，复制／移动仍复制原值 |

保留sidebarItem.canCollapse=NO：sidebarWithViewController工厂明确设为YES，删掉会改变行为。保留单字视图的layerContentsRedrawPolicy：NSView的省缺策略与wantsUpdateLayer有关，并非现有显式值。构造后以回呼或兼容路径更新的状态不当作无效代码。

第二轮第26处：GAFontFeatures.chooseSelector将booleanChoice与exclusive两个同样调用setExclusiveSelector的分支合并，booleanChoice只读取一次，继续按原先selected状态选择Off／On项目；普通互斥项仍使用被点selector，非互斥设置与清空逻辑保持。未把原生输入、后台事务、取消、快照发布或布局失效等仅表面相似的路径合并。

第三轮第27处：唯一被GAGlyphLabels.mm包含的私有GAGlyphNameTables.h内容原样放入该实现文件，移除include与独立表文件，标准名称／SID／Expert charset数据和作用域不变。所有include保留在文件顶部，常数表位于解析代码之前。Sources从59份减为58份，连同根build.sh为59份代码／构建文件。其他小型标头仍有跨文件消费者，保留当前目录分工。GLOSSARY中的过时数量与不存在的h/cpp配对按实际来源修正。

验证：21处ARC改动的10个翻译单元在arm64／x86_64共20对LLVM比较中，指令与数据一致；其中4对仅有内联汇编srcloc源码偏移随字符删除改变，报告独立注明。私有表搬移的两架构完整LLVM逐字节一致。排印选择以前后完整GAFontFeatures实现对照8个真实系统字体，共58个组（含10个纯OpenType布尔组、40个互斥组）及462份状态，目录、全部勾选、settings及replaySettings完整JSON逐字节一致。最终29个Objective-C／Objective-C++／C++翻译单元的Clang静态分析及未用私有字段检查无诊断，universal构建通过，最终源清单与分析源吻合。原有Resources及build.sh共106个文件的字节和模式与开始时完全相同，git diff --check通过。

未启动或操作实际产品窗口，没有把源码／编译等价当作跨系统GUI实机验收。此次没有确认需要新增修复的产品Bug或需要使用者决定的行为。审阅范围为逐文件引用、初始化、职责边界及相关调用路径，不声称形式化证明所有运行时路径。完整说明、每轮patch、源码清单、静态分析及对照结果见diagnostics/three-round-source-cleanup-2026-11-11/verification.json和同目录资料。


### 第四轮逐文件检查与GSUB构造初始化精简 — 2026-11-11

使用者确认节奏为每次连续完成一轮，再统一逐处说明，随后要求再做一轮检查。开始前建立codex/cleanup-round-4-review，沿用619bce7上的既有未提交成果，未提交／推送。58份Sources文件与前三轮最终清单逐字节相符；改前Sources、Resources、build.sh快照在/tmp/ga-cleanup-review-4-64ac0wml。

本轮复查接口消费者、系统回呼、构造初始化、窗口／Popover关闭、变轴与查询取消、菜单所属窗口、输入Undo及来源编辑映射、临时字形重绑、全字延后库存与待套用筛选、C++缓冲区和来源回放。按文件重新记录符号与源码哈希。保留全字pendingGlyphIDs与hasPendingGlyphIDs：nil本身也是清除筛选的有效请求，不能与没有待处理请求混为一谈。保留SubstitutionBuffer默认构造器：替换追踪的条件路径实际建立空缓冲区。没有发现可确认已经无调用的接口或需要使用者决定的新增行为。

产品源码只改GASubstitution.cpp的一处初始化流程：Substitution.nextIdentity_原先先在声明处设为1，再在唯一构造函数体中无条件改成buffer_.nextIdentity()；改为在构造初始化列表直接取得该值，函数体为空。没有改变身份编号计算、缓冲区内容、递增、预算、取消及回放规则。该成员为最后一个成员，计算仍位于其余成员完成构造之后。AAT Runner的同名字段从1开始累计，会实际读初值，故保留；FeatureOutputs.nextSlotState_也是真正的递增起点。

隔离比较以前后完整字体布局核心分别构建，不启动NSApplication或产品窗口。8个真实系统字体（4个具有GSUB表）共176组空／普通／单GID／多GID指定输入、首次及缓存查询、位置数据，40组取消／重试，及642份横竖方向来源反查结果，完整JSON逐字节相同。覆盖Latin连字、组合符号、换行、Arabic、CJK及emoji控制序列。最初尝试两架构优化LLVM逐字节对照并不相等：删除冗余初值会移除初始store及改变SSA编号；没有把该对照误报为编译输出相同，行为等价依据为初始化调用关系及独立核心完整输出比较。

修改翻译单元的Clang静态分析与未用私有字段检查无诊断，universal构建通过。最终分析源与实际源哈希吻合；除目标源码外，原有161份非Finder元数据的Sources／Resources／build.sh文件字节及模式保持，包含前三轮成果及既有语系修改。此轮没有新增GUI操作或跨系统实机验收，也没有确认新的待处理Bug。每轮检查仍不等于形式化逐路径证明。证据、独立patch、源码清单、核心对照及检查报告见diagnostics/cleanup-round-4-review-2026-11-11/verification.json与同目录资料。

### macOS 26／27 側欄與標題欄 UI — 2026-11-11

使用者要求處理六項UI問題，隨後澄清第一項只在macOS26失效、27原位置正確；第三項只驗證、不修改。對照公開Zonz-Ly/GlyphAtlas v1.6（6dd2d34843d29bf9692dbd9d712a5fee3949d0ca），原側欄輸入框直接錨定window.contentLayoutGuide，26偏移−8pt、27偏移0pt。現版26+改用NSSplitViewItemAccessoryViewController後跳過原約束，造成26位移回歸；27的預設位置恰好符合0pt。此前撤回的是NSTitlebarAccessoryViewController，與目前的分欄accessory不同，本輪未重新引入標題欄accessory。

保留的產品改動限GAMainWindowController.m、GAInput.h／.m、GASidebarViewController.h／.m及GAViewMode.h六檔。26且側欄展開時，以split根視圖additionalSafeAreaInsets.top=−8pt移動整個accessory，detail額外加回8pt維持原安全邊界，收起側欄時兩者歸零。27不啟用補償。這避免將輸入框移出系統裁切容器。26+列表與滾動區背景透明；26.1+ accessory.preferredScrollEdgeEffectStyle改用softStyle，26.0保留系統預設。舊SDK補公開聲明並在執行期查找公開類，最低系統版本不變。

收起側欄時VF與輸入項目之間加入原生固定空白，無軸時一併移除VF與空白。工具欄輸入採GAGlyphInputField／GAGlyphInputCell（NSTextField／NSTextFieldCell），原生圓角和內距，無搜尋圖示或清除按鈕；側欄保留原GASearchField外觀與高度。兩種控件經GAGlyphInputControl及共用編輯過渡、失焦存儲與idle同步函式維持同一文字存儲、Undo、換行標記和焦點回呼；編輯器改名GAGlyphInputEditor。原始27離屏階層顯示NSSearchField在工具欄生成新的原生搜尋按鈕，且28pt輸入框外另包36pt玻璃，焦點圈仍屬內層。輸入工具欄項目指定容器view後、加入工具欄前明確設bordered=NO，移除額外玻璃，讓原生控件的外框與焦點圈一致。另一App須先核對是否同樣有兩層包覆，再遷移此設定。

第三項曾試改以視窗座標直接判斷背景，使用者澄清只驗證後已完整撤回；最終GADetailViewController.m與本輪初始逐位元組相同。依使用者後續要求，以本機macOS27.2實際窗口驗證Apple Symbols多字長文：頂端背景透明，向下捲使字框進入標題欄後背景出現，返回頂端恢復透明；改成短篇Hx後置中且背景透明。未重現26所述「字框進入後較晚變不透明」。可依使用者判斷暫視為26系統版本差異，但未在26實機區分預期效果與系統Bug，不能將27結果寫成26已證實正常。程式端原0.5pt門檻的離屏結果亦與實際幾何相符。

本機27可見Skia窗口確認獨立VF按鈕、Popover錨點、無搜尋圖示／清除按鈕，以及外緣焦點圈。編輯中黑字在此也重現，使用者提供14舊版截圖確認不是本輪新增。字色探索未改善：直接讀editor.textColor的試版因nil進字典退出，改為省略明確前景色仍顯黑字。依使用者「如果沒辦法就暫不處理」，兩個試改均已精確撤回，恢復既有controlTextColor及標記樣式，不留下兜底或字色分支；黑字問題暫緩，未宣稱已修好。

離屏驗證文字／原分隔符往返、共享編輯器、收放選區、失焦存儲、跨位置Undo／Redo、VF與空白增刪、TextField類型、無額外玻璃與softStyle設定。在獨立副本僅將GAUsesMacOS26Layout改為YES，核對−8pt、完整可見、detail安全區與無補償佈局相同，以及收合補償歸零；這仍是27主機執行，不是26實機驗收。26定位與ScrollEdge觀感仍由使用者驗收。Resources與build.sh保持原樣，依原腳本構建本機產物。起始副本無.git，本輪無提交或推送。改前六檔、獨立差異、最終源清單、探針與結果在diagnostics/macos26-27-ui-2026-11-11/；完整改前副本在/tmp/ga-macos-ui.2RsdfI/。


### 獨立工具欄控件、側欄收放與直接觸摸後續 — 2026-11-11

使用者要求：27展開側欄時字名／VF不帶泡泡；撤回此前輸入框顏色修正，回到GitHub正式v1.6的顏色規則；收放時原側欄字名／VF／輸入框隨側欄收走，收起後標題欄使用獨立VF＋TextField；盡量處理27.2直接觸摸的全字雙擊與多字方向縮放。後續明確保留工具欄輸入泡泡、修復列表跳位並禁止原生工具欄右鍵的移除／顯示模式自訂。使用者自行確認v1.6沒有Remove Item，最終指出舊版也有Bug，決定不回退舊版工具欄架構。

保留八個來源檔的定向改動。字名項明確bordered=NO；輸入項恢復bordered=YES，26+TextField使用ExtraLarge原生尺寸，本機高36pt，泡泡與控件等高，外緣焦點圈保留。未恢復舊GAFontTitleView的hitTest穿透。15+allowsDisplayModeCustomization=NO；delegate的toolbarImmovableItemIdentifiers回傳既定工具欄項，使用公開API禁止移動／移除。v1.6同時有hitTest差異及明確bordered=NO，簡化A/B能驗證省略後本機item.bordered成YES，但menuForEvent只返回空占位，不能據此宣稱Remove Item唯一根因已隔離；舊版無選單由使用者實測，不是本輪GUI對照所得。

側欄收起前保留實測輸入框／列表上緣並凍結scrollView自動內距，保持當前捲動原點；原輸入框由split accessory移入側欄本身，原字名／VF組也按實測位置留在側欄，隨原生側欄收走。工具欄使用另一組控件，兩處顯示同步，共用編輯器及Undo。展開完成後先恢復原工具欄，再解除固定、恢復accessory約束與自動內距。原列表固定不再只存續於收起動畫；隱藏期間維持，避免工具欄樣式／高度切換重新改寫內容內距。無動畫及減少動態效果走同一完整流程。無新增標題欄accessory、截圖占位。

顏色依v1.6公開原碼恢復controlTextColor、secondaryLabelColor及prepareFieldEditor／plainCopyOfAttributedText規則。失焦兩控件直接使用編輯器顯示副本；刪除失焦單色模式、專用顏色焦點回呼、GAGlyphInputControl協議及相關死碼。五個相關函式在規範私有變數名、空白與註解後與正式版相同。這是使用者要求的回退，沒有宣稱14以來的黑色編輯文字已確定修好。

全字網格27+新增touch-only NSClickGestureRecognizer（buttonMask=0、雙擊、允許捲動取消），與原鼠標路徑共用命中／上屏回呼；未全局開啟NSIsTouchNative。多字使用NSMagnificationGestureRecognizer子類，在原生touches入口先讀觸點，再交super處理狀態和取消。直接觸點以locationInView取得兩指位置，不依賴可空device；觸控板保留normalizedPosition×deviceSize。沿用35°／75°方向門檻及Began鎖定，不在一段手勢中換操作。

本機27.2實際窗口確認字名無泡泡、隱藏後輸入框有泡泡、無搜尋／清除圖示、聚焦外圈；之後CUA讀取超時，最後右鍵選單未能再做可見驗收。最後離屏探針核對工具欄配置、輸入框與可見行上緣、捲動後連續兩輪收放位置、文字分隔符、共享編輯器、選區及跨位置Undo／Redo，全數通過。獨立副本強制26佈局分支同樣通過，仍不等於26實機驗收。直接／間接代理觸點檢查方向分派、鎖定、結束及取消，網格檢查識別器設定和命中回呼；無觸屏硬體，未驗證真實識別串流。26.5 SDK語法／availability及本機arm64構建通過。Resources、build.sh、GADetailViewController.m與本輪改前逐位元組相同，沒有更改第三項不透明判斷。最後工具欄設定需要完全退出並重開App生效。

改前八檔、獨立patch、來源雜湊、探針、顏色對照與限制在diagnostics/ui-controls-touch-followup-2026-11-11/；本輪完整改前副本在/tmp/ga-ui-followup.yyvMkI/。沒有.git，沒有提交或推送。


### 側欄展開順序與舊系統 VF 間隔 — 2026-11-11

使用者確認上一輪整體效果良好，追加兩項細節：顯示側邊欄前先改窗口佈局；macOS14的隱藏側欄工具欄中VF與輸入框距離過寬，26與27相同。使用者說「菜單欄」，依前後文按側邊欄處理。核對上一輪前備份，updateToolbarForHiddenSidebar:hidden原在動畫前執行；上一輪為保留原字名／VF隨側欄移動，把展開時的工具欄恢復延至completion，也連帶延後窗口佈局，屬該輪引入的順序回歸。本次只改GAMainWindowController.m：將工具欄樣式、安全區補償與detail安全區模式移到toggleSidebar動畫之前，強制完成一次佈局；原字名工具欄項仍在展開完成後恢復，輸入框／列表位置及滾動內距固定機制保留。

舊系統過寬間隔對應額外NSToolbarSpaceItemIdentifier。現在僅26+插入／移除此空白以分開玻璃泡泡，12–15改用原生相鄰項目間距，沒有自訂固定寬度。未在14實機驗收；26／27路徑保留原空白。既有macOS27離屏探針及獨立強制26佈局分支均通過，涵蓋捲動後反覆收放、輸入框及列表位置、選區、Undo及泡泡；仍非26實機或動畫中間幀驗證。本機arm64構建及26.5 SDK語法檢查通過。

使用者詢問這次元素不跳是否用了新方法：解釋此前只固定列表外框不足以防AppKit改寫滾動內距，現採側欄內實測位置固定、暫停自動內距及保留捲動原點，原控件隨側欄移動、工具欄使用獨立控件，完成後恢復約束；仍用原生動畫，沒有截圖占位。差異、改前來源與檢查結果在diagnostics/sidebar-layout-order-spacing-2026-11-11/。未提交或推送。


### ScrollEdge 硬邊示意截圖 — 2026-11-11

使用者詢問柔和／硬邊的區別並要求硬邊截圖。核對Apple NSScrollEdgeEffectStyle與WWDC26 Modernize your AppKit app：soft為漸進模糊／淡出，hard為清晰截斷，automatic由系統和情境決定；27浮動文字情境會解析為hard，與先前橫線現象吻合，但未將所有背景斷裂歸為同一原因。使用獨立臨時預覽App及目前產品Controller，在本機27.2對兩窗口分別設softStyle／hardStyle，載入Skia與同一文字，經CUA取得真實窗口截圖；兩者列表捲軸值對齊，選取／焦點不同，並非逐像素比較。硬邊截圖可見輸入區下緣清晰橫線與內容截斷。產品來源與正式構建未改，柔和設定保持。圖片及預覽源碼在diagnostics/scroll-edge-comparison-2026-11-11/。


### 輸入框內距統一9pt與控件預設值清理 — 2026-11-11

使用者要求檢查並刪除工具欄TextField、側欄VF／字名／輸入框與工具欄VF中等同原生預設的設定，另要求TextField沿用SearchFieldCell的文字內距。起初查得現有內距為26的12pt／其他版本9pt；使用者質疑12pt未曾由其指定。重新核對當前原碼、GitHub v1.6已讀原碼及11月3日紀錄，確認該12pt確實是文字內距，並非讀到同值的外距；是過往AI適配時的手調值，沒有使用者指定或Apple規定的證據。使用者最新明確指示「都改成9」，故兩種控件所有系統統一文字左右9pt，未改Accessory外距。

只改GAInput.m、GASidebarViewController.m與GAMainWindowController.m。將原SearchFieldCell內縮邏輯抽成GAInputRectByInsettingTextEdges，TextField的titleRect／drawingRect及SearchField的三種rect共用；移除精確26的12pt分支和失去用途的GAViewMode import。保留原生垂直rect、bezel與焦點圈。刪除工具欄TextField重複的bezeled=YES，以及字名工具欄項paletteLabel=item.label；後者設定label後原生paletteLabel已相同，且不支援自訂。

其餘逐項檢查後保留：輸入字級13.5不同於原生13；Large／ExtraLarge不同於Regular；TextField圓角、單行上限1、scrollableYES、允許自訂文字屬性均與此建構方式的預設不同。字名尾端省略、展開Tooltip、medium字體、windowFrameTextColor與壓縮優先權也不同。側欄VF無框、載入前隱藏、stack間距均為指定行為。工具欄輸入／VF的borderedYES保留，Apple文件及原生初建值均為NO；字名項雖在初建時也是NO，先前實際插入工具欄會解析出泡泡，仍須明確NO，不能把建構前值當作最終值。舊系統VF按鈕的Toolbar bezel也不同於factory的Automatic。

本機27離屏量測：省略bezeled重複設定後，背景、圓角、尺寸、行數和捲動旗標一致；工具欄輸入框仍492×36pt，繪字及實際編輯器rect由x=4／寬484變為x=9／寬474，左右正好9pt。既有收放位置、選區、分隔符、共享Undo／Redo、VF與泡泡回歸通過；獨立強制26佈局分支同樣通過，但未在26或14實機驗收。26.5 SDK語法檢查和本機arm64構建通過。來源備份、獨立差異、預設值探針及結果在diagnostics/input-padding-defaults-2026-11-11/；未提交或推送。

### 完整恢復先切換工具欄、再展開側欄 — 2026-11-11

使用者回報展開順序仍錯，要求整個切換成側欄展開佈局，包含隱藏側欄時的標題欄配置先消失，然後才展開；要求核對舊碼必要部分。前次只提前toolbarStyle與安全區，updateToolbarForHiddenSidebar:NO仍在completion，獨立VF＋TextField因此未提前移除，是前次修正不完整。

只改GAMainWindowController.m：展開時先解除原字名／VF在側欄的固定約束並移出側欄，然後兩個方向統一在動畫前呼叫updateToolbarForHiddenSidebar:hidden，移除原工具欄項、切換當前輸入控件並插入目標項，再完成layout，最後才改sidebarItem.collapsed。這恢復更早版本的必要順序：完整更新工具欄在原生側欄動作前執行。completion只保留側欄輸入框／列表解除固定、恢復accessory和自動滾動內距及焦點，不再重建工具欄。

為避免前次只測完成狀態的盲點，本輪原生離屏探針在NSSplitViewItem.setCollapsed:NO的入口直接檢查：工具欄已是GAFontName＋TrackingSeparator、獨立輸入框不再啟用、側欄內容仍固定。相同探針在改前版本重現工具欄／輸入控件時序失敗，改後及獨立強制26佈局分支全部通過，原有收放捲動位置、選區與Undo回歸亦通過。強制26仍是在27主機，沒有26實機或可見動畫中間幀驗證。26.5 SDK語法檢查及本機arm64構建通過。來源備份、舊順序摘錄、差異和探針結果在diagnostics/sidebar-complete-layout-order-2026-11-11/。

同時回答使用者關於15及以前VF與文字框間距：前次僅取消這些系統額外的NSToolbarSpaceItemIdentifier，使用原生相鄰項目間距，未加自訂固定寬；26／27保留原生空白分開兩個玻璃泡泡。此輪沒有再改間距。未提交或推送。

### 工具欄輸入折行、run驗證及失焦字色詢問 — 2026-11-11

使用者要求嘗試移除工具欄TextField的單行限制，比較側欄差異並確認各種特性與run正常。只從GASidebarViewController.m刪除maximumNumberOfLines=1與cell.scrollable=YES兩行，恢復與SearchField相同的0／NO；圓角、Large／ExtraLarge、9pt內距、原生泡泡與共享編輯器全部保留。本機27原生編輯器實測，360字在側欄成16行、舊工具欄1行、刪除兩項後工具欄6行，仍為36pt外框；較寬整合案例4行。這是編輯時按寬度折行及框內縱向移動，不是自動增高工具欄。先前回答「圓角單行樣式也必須更換」過於絕對，實測區分原生Cell靜態呈現與field editor後予以更正；未改bezel。

離屏整合以真實Skia Regular、Times New Roman及Geeza Pro Regular，保留完整Controller非同步分析／發布／預覽管線，共112項通過。比較四種文字（拉丁連字、各種分隔符、組合符／CJK／emoji、Arabic）的完整候選GID／來源／定位與多字投影在兩輸入位置一致；切換保持共享編輯器與選區；9個實際字體Feature group的選擇傳到原生預覽並跨收放保留。真實Skia未編碼morx:10:1替換建立run；另用當前真實GID構造明確雙GID／多來源與單GID run測試，這些fixture不是宣稱字體特性本身輸出同一組合。檢查邊界輸入後run移位、內部修改只解散該run、Undo／Redo恢復範圍和屬性、換行符往返、複製／剪下／貼上、組字暫緩查詢與commit後發布，以及多字方向／裝飾傳遞。剪貼測試在探針進程中將generalPasteboard指向獨立測試剪貼簿，未使用使用者剪貼簿。

初版探針有兩個前提錯誤：切換後額外focusInput重設選區、切字體時在新非同步document替換前就讀到舊document。修正探針等待條件及重複聚焦後通過，未因這些失敗額外改產品碼。組字檢查是直接調用原生marked-text協議，不是真實輸入法候選介面。26.5 SDK語法檢查與arm64構建通過。使用者隨後明確表示不用再測，之後未跑測試或操作CUA；已編好的獨立GUI預覽未啟動，也未追加26／14實機驗證。改前來源、兩行差異、折行量測、探針與最終結果在diagnostics/toolbar-textfield-wrapping-2026-11-11/。

期間使用者詢問改回搬動同一組輸入框／VF會怎樣：說明內容位置固定與控件實例分開是兩件事，列表仍可固定，但移走的原控件無法繼續隨側欄收走；直接搬SearchField會重遇27原生搜尋／清除圖示，兩邊共用TextField則需另評估樣式／尺寸及焦點切換。只作說明，未改獨立控件架構。

最後使用者詢問27失焦文字不變淺而14會變淺，澄清為點同一窗口其他位置。只查來源與Apple文件，未改字色、未另測：普通文字在prepareFieldEditor及GANormalizedSidebarInput寫入controlTextColor，失焦syncDetachedInput繼續使用帶色屬性的存儲副本。Apple將controlTextColor定義為啟用控制項的文字色，而非失焦色；attributedStringValue／allowsEditingTextAttributes文件說明字體和字色屬性會控制呈現。這指出我們的顏色路徑可能影響27原生失焦呈現，但未做原生對照，不能據此證實是產品Bug或27刻意新特性。27 release notes中textColor=nil編輯色不一致的修復不等於此現象，未混為同一問題。折行修改與此字色處理無關。未提交或推送。

### 最終 UI 改動三輪精簡與結構整理 — 2026-11-11

使用者明確授權直接改碼，逐檔優先檢查本次UI改動，依序刪無效／預設設定、整合邏輯、整理Sources結構；每處程式修改須說明，註解可直接修正；UI／UX／輸出不變，新Bug或產品決策才彈窗。此授權涵蓋直接改動與必要等價核對，不再援用早先逐次確認要求。中途使用者要求加快、只查必要項，遂只完成已啟動的對照與引用收尾。目錄無.git，每輪改前獨立快照，沒有建立假分支、提交或推送。

第一輪兩處：GASidebarViewController.updateSidebarTopConstraint在inputAccessory存在時已返回，而產品26+固定安裝accessory；刪除後段舊26／27位移分支，僅保留舊系統−1pt。GAMultiGlyphView移除已由公開header宣告的pageRect重複私有原型，getter實作與呼叫保留。已核對的輸入、側欄與字形視圖公開接口皆有產品呼叫；原生delegate／action／touch覆寫不因缺少普通直接呼叫而誤刪。舊顏色回呼、協議、固定接口先前已清除；觸摸doubleTap的buttonMask、雙擊數及可被捲動取消均非預設，保留。

第二輪五處：GAInput.m將相同firstResponder焦點判斷移至共用焦點區，數值框與兩種字形輸入Cell共用；保留不同父類的super編輯覆寫與Undo過渡。新增共用GATopOffsetInView，替代Main字名、側欄輸入框與側欄列表三處相同的flipped頂距公式。Main將字名／VF的固定與復位抽成pinSidebarTitleAtFrame／unpinSidebarTitle，仍先完整切換工具欄再開始側欄動畫，completion只恢復輸入／列表約束與焦點。輸入工廠先決定Large／ExtraLarge再一次指定controlSize，最終字體仍13.5pt；只在側欄初始化Enter text提示，工具欄不再先寫入立即被字名覆蓋的提示。只另修正過時註解與空白，無字色／換行／run行為變更。

第三輪四處：Input/僅有GAInput.h／.m這組原生UI控件，移入Views/並刪除空目錄；GAViewMode.h改名GAAppKit.h，對齊其實際內容：模式／能力、座標換算、僅26佈局與SDK相容聲明；GAMacOS26SidebarInputTopOffset只剩Main使用，−8pt常量移到該實作私有區；同步GAAppDelegate.m、Main.h／.m、GAAllGlyphsView.m、GADetailViewController.h、GASidebarViewController.m、GAVariationViewController.m引用及build.sh來源集合。Sources仍58檔，連根build.sh共59檔，子目錄5→4。Font及FontLayout職責完整，沒有為減檔數合併其獨立模組。

以不可變改前來源與最終來源分別編譯離屏AppKit探針，24組深／淺外觀×三視圖×側欄顯隱×編輯／失焦的PNG逐位元組相同，幾何JSON一致；另匯出相同編輯序列的86份完整查詢／run／特性／多字投影快照，JSON逐位元組相同，SHA256均為9c9c1a05fa6d8159c103c07122bcf3e26fa4f65a95a33c4a8a77124740e5b509。112項特性／run／編輯檢查、切換入口順序／重複捲動位置／VF／觸點分派檢查通過；強制26佈局分支在27主機通過，非26實機。26.5 SDK語法檢查和本機arm64構建通過。沒有新增14／26或觸屏硬體驗證，也未捕捉可見動畫中間幀。Font、FontLayout與Resources逐位元組保持，Detail.m未動，既有失焦字色疑問仍未定性，沒有改其策略。本輪未發現須新增產品決策的已確認Bug。

每輪獨立patch、改前檔案、變更清單、最終來源雜湊、畫面、完整輸出與探針在diagnostics/final-ui-cleanup-2026-11-11/。完整改前與每輪工作快照在/tmp對應ga-final-cleanup.6auchu6b（實際路徑見verification.json）。


### 版本號更新為 1.7 — 2026-11-11

依使用者要求，Resources/Info.plist的CFBundleShortVersionString由1.6改為1.7，CFBundleVersion維持5。使用者明確要求不用構建，本輪未構建、未更新dist產物，未提交或推送。


### 構建版本號改為 8 — 2026-11-11

使用者確認這是第8版，將Resources/Info.plist的CFBundleVersion由5改為8；對外版本號維持1.7。沿用不用構建的要求，未構建或更新dist產物。


### 字形表側欄切換初始垂直位移研究 — 2026-11-11

使用者提供側欄展開／收起的 Futura 字形表截圖，要求研究切換開始時因頂部留白不同而產生的輕微上下跳動，以及最簡單的補償。此輪僅讀取當前來源，未修改產品碼、未啟動 App 或新增執行期驗證。當前工作副本有 .git，分支為 codex/macos-27-ui-adaptation，工作區已有其他未提交改動；不能沿用前輪紀錄中的無 .git 假設。

GAAllGlyphsView.setScrollsUnderToolbar: 以 GAPreserveScrollPosition 包住模式更新，後者保存的是兩軸可捲動範圍內的百分比。layout 同時將 grid.topInset 在普通展開狀態的18pt與工具欄覆蓋／全屏狀態的0pt間切換，並切換 AppKit 自動內容內距。相同比例無法保證橫列在視窗中的高度不變。Main.toggleSidebar 在原生收放開始前依序更換 toolbarStyle、安全區模式、工具欄項目並完成 layout；補償若只放在動畫完成後會保留開始時的跳動，若捕捉範圍只涵蓋內距 setter，也可能漏掉其前後的工具欄幾何變化。

建議以網格首列上緣作幾何參考，記錄整次工具欄配置更新前後的視窗座標差，在原生寬度動畫開始前一次調整 clip origin；同一高度差對所有橫列等量生效，不需逐格記錄、固定工具欄高度或建立新動畫。一般縮放／換欄仍保留既有策略。這是待實作／量測的方案，尚未證明動畫中間幀效果。產品邊界：頂端首排若維持原視窗高度，收起後可能進入工具欄遮擋區；反向展開或短清單也可能因合法捲動範圍無法完整補償。不能同時承諾首排始終貼新安全區下緣及所有橫列絕對高度不變。


### 字形表側欄切換位置補償，包含全屏分支 — 2026-11-11

使用者確認前輪方案及頂部遮擋／合法捲動範圍的邊界，要求留意全屏下的側欄收放。沿用 codex/macos-27-ui-adaptation；只修改 GAMainWindowController.m、GAAllGlyphsView.h／.m、GADetailViewController.h／.m，未提交或推送。

Main 在原生側欄動作前，以 Detail 新接口包住既有工具欄樣式、安全區、工具欄項目及最終視窗 layout 更新。Detail 僅對當前字形表套用 AllGlyphs 的同步位置保存；其他模式直接執行原更新。AllGlyphs 捕捉首排上緣的視窗座標，更新後轉回網格座標，將差額加到 clip origin，再交原生 constrainBoundsRect 限制。無新增動畫、狀態欄位、固定工具欄高度或延後修正；全屏保留原有「收起側欄或全屏」啟用自動內距與 topInset=0 的條件，補償只取實際幾何差。一般縮放及寬度換欄的比例保存不變。

本機 macOS14.8.7 arm64 構建完成。隔離非可見 AppKit 探針使用當前完整 Controller 與2000格字形表，在 NSSplitViewItem.setCollapsed: 入口（工具欄更新後、原生寬度變化前）讀取首排的視窗高度。一般與強制 fullScreen styleMask 讀值的分支各連續收放3次，12次起始高度差均0.000000pt，另6項全屏分支自動內距及 topInset=0 檢查通過。總18項檢查；探針的全屏是分支fixture，不是實際進出全屏、不代表macOS26／27或動畫中間幀已驗收。沒有顯示窗口或操作使用者App。

改前5份來源、單獨差異與探針／日誌在 diagnostics/grid-sidebar-offset-2026-11-11/；暫存完整目錄為 /var/folders/7g/9md6b191673fmyv9wssspz840000gn/T/ga-grid-sidebar-offset.utl1hbg1。首排位於頂端時可能進入工具欄後方，短清單／反向展開可能受捲動上限限制，沿用前輪已說明的產品邊界。實際全屏收放及可見動畫仍待使用者驗收。

### 複核全字補償公式：換欄再次改寫位置 — 2026-11-11

使用者實際觀察仍有未對齊，要求複核計算公式。此輪只診斷，未改產品碼。補償公式「新 clip origin = 當下 origin + 新首排網格 y − 舊視窗錨點轉回新網格後的 y」在目前 1:1 座標下方向正確。問題是補償只包住工具欄配置；之後側欄改變寬度，GAAllGlyphsView.setFrameSize: 又用 GAPreserveScrollPosition 保留捲軸百分比，縮放了剛補好的偏移。

本機 macOS 14.8.7 離屏，以完整 Controller、2000 格及 800×600 pt 畫布從頂端收起：setCollapsed: 入口首排視窗高度維持 582 pt，完成分欄重排後變為 572.492494 pt，即下移 9.507506 pt。欄數 11→15，對應可捲動範圍 8926→6430 pt；補償後距最小捲動原點的 34 pt，被比例保存變成 34×6430÷8926＝24.492494 pt，與位移吻合。並非座標正負號或四捨五入問題。強制全屏 styleMask 讀值的分支同樣從起始 0 pt 誤差變成完成時下移 3.914855 pt；此為分支 fixture，不是實際全屏。前輪只量 setCollapsed: 入口，沒有量後續換欄，驗證不足。

另外，收起狀態先捲回最頂後再展開，普通模式首排需向下 34 pt、全屏 fixture 需向下 14 pt 才能保持高度，但原生最小 origin 分別為 0 與 −38 pt，因此無法完整補償。這是前輪已說明的頂端限制，與換欄再次改寫是兩個問題。

待確認的修正方向：全字在整段側欄收放期間，寬度更新亦按橫列的實際視窗高度保存，動畫完成後恢復一般比例保存；其他視圖與一般縮放不變。尚未實作，不宣稱可見動畫已解決。探針及完整日誌在 diagnostics/grid-sidebar-offset-audit-2026-11-11/。

### 討論一次反補償的限制 — 2026-11-11

使用者認為整段側欄收放改用絕對位置不夠優雅，詢問能否反補償。核對現有比例還原及網格高度公式：若只要求終點補償34pt，可預補34×8926÷6430＝47.198134pt，讓換欄縮放後回到34pt；但起始會多補13.198134pt，無法同時保持起始及過程對齊。一般地，固定預補量d經比例保存後為d×R(t)÷R(0)，可捲動範圍R(t)在換欄時分段變化，一個固定d不能在不同範圍下都得到同一非零補償。這只排除「一次預補、其他計算完全不變」能消除整段位移，不代表所有反補償方案都不可行。要保持既有內容比例並避免該誤差，可進一步研究將固定pt的留白補償與內容比例分開計算；尚未選定或實作，不擴大修改到其他視圖。

### 試用一次預先反補償 — 2026-11-11（驗證邊界更正見「可見橫列與總留白複核」）

使用者明確偏好預先補償，要求試改一版；沿用全字限定、普通與全屏兩種側欄切換範圍。修改限於 Main.m、AllGlyphs.h／.m 與 Detail.h／.m 五份來源，沿用目前分支，未提交或推送。

將前一版同步位置保存接口改名為 precompensateGlyphGridForWidth:duringChanges:／precompensateForWidth:duringChanges:，不留舊接口。Main 以 split view 的實際寬度，減去展開側欄寬度及原生分隔線厚度（收起時不減）取得目標網格寬度。網格將既有欄數及高度公式提取為 columnsForWidth:／heightForColumns:，正式排版與目標高度預算共用，未複製第二套網格規則。工具欄更新後仍量實際視窗座標差 d，但預補改為 d×目前可捲動範圍÷目標可捲動範圍。目標範圍以目前原生範圍加上預算文件高度差取得，工具欄內距沿用當前實際值；普通及全屏不另加固定高度。任一範圍不大於0.5pt時無法傳遞比例補償，直接保留原生結果。所有補償仍受原生合法捲動範圍限制。

僅逆推工具欄帶來的補償量；原有內容捲動比例、setFrameSize:、縮放及原生側欄動畫未改，沒有加入動畫期間狀態或 completion 修正。這是使用者選擇的「終點補償」版本，不保證起始或中間橫列固定。中段／底端仍會有正常的內容比例重排，不能把首排（可能在可見區之外）的絕對高度變化都當成補償錯誤。

本機 macOS14.8.7 arm64 構建完成。非可見完整 Controller 探針在2000格、800×600pt畫布檢查普通／強制全屏styleMask分支、0／40%／90%位置及兩個切換方向，共12組。目標網格寬度預算與最終實際寬度均一致；最終「原生內容百分比結果加回實際工具欄位移，再依原生上下限限制」的捲動原點誤差均小於0.01pt。從頂端收起時，普通及全屏fixture的首排最終位移均0pt；從已捲回頂端的收起狀態展開，仍受前述上下限限制。強制全屏仍非實際全屏，未開啟可見窗口、未驗證26／27或動畫中間幀。差異、改前來源、探針與日誌在 diagnostics/grid-precompensation-2026-11-11/，暫存工作目錄 /tmp/ga-grid-precompensation.fy00w0e9。

### 可見橫列與總留白複核 — 2026-11-11

使用者回報預補版仍不對，指出可能從一開始公式即錯。補問後確認實際條件為一般視窗、已捲動、切換開始便偏移，過程中各排保持水平；不能把離屏非動畫探針的入口／完成時序直接當成實際動畫的可見時序。使用者進一步指出隱藏側欄後的上方空白可能是標題欄高度而非0。此輪只診斷，未改產品碼。

本機14.8.7、2000格、800×600pt畫布、40%捲動位置，改量距視窗中部最近的真實單元格上緣，使用產品 rectForIndex: 及原生座標換算。展開時 grid.topInset=18pt、原生contentInsets.top=0，捲到頂端的總留白18pt；收起後 grid.topInset=0、原生contentInsets.top=52pt，總留白52pt。使用者對總留白的區分正確，不能把網格的0當總留白，也不能再手加52造成重複。前版座標量測在此測例已取得兩者差，因此沒有證據將現有錯誤單獨歸為漏加標題欄高度。

收起側欄時，中部單元格上緣由視窗 y=290.8pt變280.4pt，下移10.4pt；展開另一次同條件測例由312pt變322.4pt，上移10.4pt（視窗座標y向上）。與此同時，前版「比例結果加回工具欄位移」檢查仍回報誤差0pt，證明該檢查只驗證了選定算式的執行，沒有驗證使用者要的可見橫列對齊。撤回以該通過結果暗示整體公式符合需求的判斷。

目前格子44pt、垂直間距8pt，每排節距52pt。前版畫面外第一排的整體位移為−998.4pt，相當於−19.2排；扣除整排移動仍剩0.2排=10.4pt，與實際可見橫列誤差一致。問題模型漏掉了換欄後可見排號與節距的關係；僅修正工具欄留白或反算其比例都不能約束可見列高度。後續若提新方案，須以實際可見單元格的視窗高度為驗收目標，不能只驗證clip原點符合自己選定的比例公式。尚未選定／實作修正。探針與日誌在 diagnostics/grid-visible-row-audit-2026-11-11/。

### 以可見橫列的行距位置作一次預補 — 2026-11-11

使用者要求改一版。沿用目前分支，本輪產品碼只修改 GAAllGlyphsView.m 的預補方法，並補上既有 cellSide getter 的私有宣告；Main／Detail接口、原生側欄動畫、一般比例保存、其他視圖均未修改。未提交或推送。

先依目標文件高度取得換欄後的可捲動範圍，預算未補償時的原比例終點。把原橫列參考與該終點的高度差，按 stride=cellSide+8pt 取最近餘數，保留換欄必然改變的整排數，只修正可見橫列在一排行距內的偏差。選中的對齊終點若越過捲動上下限，改用相鄰一排的合法終點；仍無合法位置則保留原生結果。最後將終點修正量乘目前範圍／目標範圍，仍只在動畫開始前一次預補，不加入過渡狀態。系統工具欄內距已由原生座標換算納入，不另加固定標題欄高度。

本機14.8.7 arm64構建完成。隔離非可見完整Controller探針直接呼叫產品rectForIndex:，比較視窗固定中部附近的真實單元格上緣；不用預補公式或捲軸原點當對齊判準。2000格、800×600pt畫布，兩種格子比例1.0／1.7、普通／強制全屏styleMask分支、0／40%／90%／100%捲動位置、收放兩方向共32組，橫列高度誤差均小於0.01pt。原本40%普通模式290.8→280.4pt的下移，現在為290.8→290.8pt；反向312→322.4pt現在為312→312pt。1.7比例的非整數行距亦對齊。全屏是分支fixture，並非真實全屏或26／27實機；未開啟可見窗口，動畫中間幀待使用者驗收。

差異、改前單檔、探針及日誌在 diagnostics/grid-row-alignment-2026-11-11/，暫存目錄 /tmp/ga-grid-row-alignment.9ypdtcly。短清單或極窄捲動範圍未保證存在合法的同相位橫列位置，不以額外留白或越界捲動強行製造。

### 使用者確認對齊版本，清理補償試驗殘留 — 2026-11-11

使用者實際驗收後明確表示「這次完全是對的」「就用這一版」，並授權清理無效程式與殘留。保留上一節以可見橫列行距餘數計算的一次預補，不再變更對齊模型、作用視圖、原生動畫或一般捲動策略。此確認未具體列出全屏及各系統驗收範圍，不擴張成所有平台均已實測。

核對本輪 Main、Detail、AllGlyphs 接線及來源引用：舊 preserveRowPositionDuringChanges:／preserveGlyphGridRowPositionDuringChanges: 接口已不存在，現行預補接口、欄數／高度共用方法均有產品呼叫；沒有新增調試日誌、臨時旗標、動畫狀態或測試入口殘留。歷次探針都位於 diagnostics 或 tmp，不參與產品構建；保留診斷證據，不刪歷史資料。

僅做兩項等價整理：AllGlyphs.m 將目前可捲動高度保存為 currentRange，供預算、檢查、正反比例共同使用；移除 targetRange 的 MAX(0, …)，因後續 targetRange<=0.5 的必要檢查已涵蓋全部非正範圍。AllGlyphs.h 的接口註解由舊「工具欄位移」更新為「換欄後可見橫列對齊」。所有運算順序、行距餘數、上下限選排與實際座標換算維持。沿用現有分支，未提交或推送。改前兩檔及獨立差異在 diagnostics/grid-row-cleanup-2026-11-11/，暫存目錄 /tmp/ga-grid-cleanup.gvyewxls。

### 側欄收放往返的首次整排偏移 — 2026-11-12

使用者回報橫列位置已對齊，但側欄顯示→隱藏→再顯示時，部分位置第一次會跳到相鄰一排，之後反覆收放均停留在新排；有些位置不跳。本輪只診斷，未修改產品碼、未構建或操作可見窗口。

以現行完整Controller、本機14.8.7、2000格、800×600pt畫布、44pt格高及8pt間隔重現。每個起始位置只設定一次捲動位置，連續4個收放循環，中途不重設百分比：10%位置889.2→941.2pt，首次增加52pt，後3次差0；40%位置3556.8→3504.8pt，首次減少52pt，後3次差0；80%與95%也首次減少52pt；5%、20%、30%、50%、60%、70%、90%無整排偏移。方向可正可負，不是只往下。上次32組逐向橫列對齊檢查每個方向前都重設位置，沒有覆蓋連續往返，因此不能作為往返可逆的證據。

原因：remainder選最近行距位置時保留了橫列相位，但丟棄相對於原始比例的選排偏差；回程把已吸附的真實捲動位置當作新百分比再選最近排，去回各自取最近值不能保證抵消。較寬網格排數較少，兩個不同窄版排號可能選到同一寬版位置，單靠該位置無法推回原排。第一次來回落到固定點後，後續相同尺寸的收放就穩定，與使用者觀察一致。未因這個問題推翻已驗收的橫列高度對齊。

修正方向待確認：保留吸附前的原始位置或吸附誤差，反向切換以未丟失的基準計算；中途有使用者捲動或幾何／內容變更時按新位置更新基準。尚未設計完整生命週期或實作，不承諾只改四捨五入方向即可解決。初版探針曾在手工設entries後未標記layout，第一個5%測例讀到未更新範圍而產生假大幅跳動；修正資料前提後重測，該假結果不採用。最終探針及日誌在 diagnostics/grid-roundtrip-audit-2026-11-12/，暫存目錄 /tmp/ga-grid-roundtrip-audit.18uuojtq。

### 使用者要求改從總留白差處理，不選最近行 — 2026-11-12

使用者回看未修改版本，指出由無工具欄覆蓋轉為有覆蓋時總往下、反向總往上，方向只隨前後總留白大小改變；詢問是否根本不必判斷最近行。此輪僅重新檢查原始來源及代數，未改產品碼。前述「要保存取整誤差才能回原排」只適用已採最近橫列吸附、且要保留該吸附行為的模型；不能擴大成所有留白補償都必須新增誤差狀態。

同寬度、同視口及其餘幾何不變時，畫面向下的留白位移可寫為（新總留白−舊總留白）×（1−捲動比例）；18→52pt、40%位置即下移20.4pt，方向與使用者描述一致。不能將此同寬度關係直接當作整段換欄後每條橫線固定的證明。可研究把捲動比例的基準改成扣除不同頂部留白後的內容位置，以連續座標轉換補償留白，不做行距餘數、最近排選擇或去回取整。純代數例子以展開參考原點0／最大8892、收起參考原點−18／最大6378，40%內容比例可3556.8→2540.4→3556.8pt精確往返；未驗證此替代方案的實際AppKit時序、全屏、端點與視覺效果。此方向保留原本寬度變化帶來的分行，不再額外強制所有橫列同相位，須向使用者分清這個行為邊界。

### 重新推導無記憶的可逆行座標公式及邊界 — 2026-11-12

使用者要求再想其他能同時保持橫列對齊及往返回原行的公式。產品碼未改；在獨立來源副本將最近行餘數選擇替換為直接保存相同行號／排內位置的視窗座標，仍以原有比例反推一次預補。數學上可逆且不取整，但目標必須位於新布局的合法捲動範圍。這改變了換欄後內容的進度，不再是相同的全文百分比。

本機14.8.7、相同2000格及800×600pt畫布，連續4次往返：起始5%至70%的測例均回到原origin；10%為889.2→871.2→889.2pt，40%為3556.8→3538.8→3556.8pt。80%起始7113.6pt需超出寬版最大origin6378pt，被原生限制後回程只有6396pt，與起點差−717.6pt；90%與95%也因此丟失原位置。不能將中段成功宣稱全範圍可逆，亦不建議為此新增尾端空白或允許越界捲動。

另按實測合法範圍計算：普通窄版origin為0..8892pt，寬版−52..6378pt，行距52pt。固定一組可見橫列高度（窄版origin餘數5.2pt；寬版需39.2pt）後，窄版有171個合法對齊位置，寬版僅123個。因此在「只以真實垂直捲動位置為狀態、橫列高度精確對齊、維持原生合法範圍」的條件下，無法為所有窄版起點建立唯一寬版位置；這個限制不限於目前最近行公式。它不排除保留一個邏輯比例／誤差後可逆，也不排除改變對齊或合法範圍規則，但這些是不同方案。

仍建議將未取整比例作為邏輯位置，或保留等價的比例誤差，讓視覺對齊不覆寫原始基準；具體生命週期尚未實作，保留現行產品行為。隔離副本、探針與結果在 diagnostics/grid-reversible-formula-2026-11-12/，暫存目錄 /tmp/ga-grid-reversible-formula.zz4bi_jk。

### 討論將補償移入網格排版 — 2026-11-12

使用者提出換思路：在排版時完成補償，詢問想法。本輪僅讀現行來源與研究接口，未修改產品碼、未構建或跑新原型。新方向是保留原生未吸附的捲動比例，將橫列相位差放到網格排版起點；不再把取最近行後的比例寫回捲軸。這讓未取整的資訊保留在實際捲動位置中，視覺差額由布局承擔；它不受前面「固定布局、同相位合法位置數較少」的同一前提限制，因布局本身也可有偏移。仍需原型驗證，尚未證明全範圍往返可逆。

當前 grid.topInset 同時由 rectForIndex: 決定格子起點、drawRect: 決定篩選起點，並由 heightForColumns: 計入文件高度，不能只將它改成動態補償量，否則又會改變捲動範圍。候選設計需分開結構留白與對齊偏移，讓正常百分比保持原資訊，並統一處理格子位置、繪製／dirtyRect選行、命中、定位與首末排的文件範圍。若文件高度因偏移改變，必須一併解決其與比例保存的耦合，不能只平移繪圖或保證不裁切而未量測。

另查Apple官方NSCollectionViewLayoutInvalidationContext：提供contentOffsetAdjustment與contentSizeAdjustment，允許布局提交內容偏移／大小修正；不代表系統會自行決定本App的橫列對齊或往返錨點。現行網格是自繪NSView，不能直接套用該collection-view接口；沒有因此決定改寫為NSCollectionView。來源：https://developer.apple.com/documentation/appkit/nscollectionviewlayoutinvalidationcontext?language=objc 。

### 改用排除頂部留白的連續內容進度 — 2026-11-12

使用者確認本聊天最新方案並要求執行：以內容位置計算比例，把不同頂部留白作座標偏移，保留自然換欄，移除最近行吸附與去回取整。本輪沒有改為動態網格排版偏移，也沒有新增比例誤差狀態；前述兩項僅為其他討論方案。產品修改僅限 GAAllGlyphsView.m 及該公開header的一行說明，沿用 codex/macos-27-ui-adaptation，未提交或推送。

在工具欄更新前取內容參考起點 b=grid.topInset−18pt，以及內容範圍 C=原生最大捲動原點−b，保存未取整比例 p=(目前原點−b)/C。18pt來自既有正常網格邊距，不是新增工具欄高度。更新工具欄後，沿用共用欄數／高度預算得目標最大原點與新參考起點，用同一p換算目標原點，限制於原生合法範圍，再反向換算成一次預補。寬度動畫仍用原來的GAPreserveScrollPosition完成重排。刪除原首排錨點座標、位移、行距、remainder、最近排及相鄰合法排選擇，也刪除失去跨類呼叫用途的cellSide私有宣告；getter本身保留。Main／Detail接口、正常格子位置／繪製／命中、其他模式及一般縮放未變。

正常展開時b=0、範例C=8892pt；收起時b=−18pt、目標C=6396pt，40%可3556.8→2540.4→3556.8pt。全屏同樣使用實際原生範圍，不設特定工具欄高度。內容比例可在原生額外頂部留白區為負值，不能任意夾為0；只有最終目標原點交原生範圍限制。任一內容或原生範圍不大於0.5pt時無有效比例可傳遞，保留原生結果。受端點截斷或內容／尺寸改變時不保證可逆，不承諾所有位置均能恢復。本版亦不再承諾換欄前後每條橫列同相位，這是使用者最新要求保留自然換欄的方案邊界。

本機14.8.7 arm64構建完成。隔離非可見完整Controller以2000格、800×600pt畫布，兩種比例1.0／1.7、普通／強制全屏styleMask分支、0／10%／40%／80%／95%／100%起點，各連續4個往返，中途不重設捲動位置，共96次往返；全部回到原origin誤差<0.01pt、原欄數一致。原先10%首次+52pt、40%與80%首次−52pt的測例均回原值，每次後續循環亦相同。另空表及8格短表共兩項無非有限原點檢查通過，總98項。每個來回case均由側欄顯示開始；未將此結果擴大成「從收起狀態最頂端開始也一定可逆」。全屏為分支fixture，非真實全屏或26／27實機，未開可見窗口，外觀／可見時序仍待使用者驗收。

改前兩檔、獨立差異、探針及結果在 diagnostics/grid-content-position-2026-11-12/；暫存目錄 /tmp/ga-grid-content-position.ubi__w0t。

### 連續內容公式的切換初始偏移複核 — 2026-11-12

使用者確認新版來回不會跳行，但切換開始仍有少量上下偏移，要求再確認留白補償。此輪僅診斷，未改產品碼、未構建或顯示窗口；保留已驗收的連續往返能力。

隔離完整Controller探針以rectForIndex:0的原生視窗座標，分別量工具欄更新前、callback完成後及precompensate方法返回後。三個採樣點的網格寬度一致，因此在此階段首排高度差亦是所有可見橫列的共同平移，不混入寬度換欄造成的排號變化。一般視窗40%起點，舊寬599pt、目標800pt，總留白18→52pt；工具欄更新後下移20.4pt，預補後相對原位置反而上移7.918880pt。該次來回origin仍精確還原。從頂端開始，預補後上移13.198134pt；90%位置上移1.319813pt。普通反向展開的預補後初始誤差為0pt。

強制全屏styleMask分支在40%收起時預補後上移7.936691pt，反向展開下移3.368421pt；此僅分支fixture，不是真實全屏。量測未宣稱可見動畫中間幀已捕捉。檔案和日誌在 diagnostics/grid-clearance-timing-2026-11-12/，暫存目錄 /tmp/ga-grid-clearance-timing.jo3cucgg。

根因：目前內容進度能保證未截斷時的終點及往返一致，但最後一步把「目標寬度下的原點」反算成預補，並在仍是舊寬度時套用。它不能同時保證預補當下沒有位移；不是標題欄高度漏算或應再加固定高度。前輪只檢查連續往返，尚不足以驗證開始時的留白修正。

建議修正方向待確認：將同一連續內容進度保存放進既有實際大小／內距更新流程，依當下布局直接換算，移除預估終點寬度與反向預補。這不是整段鎖定絕對橫列，也不需最近行取整、誤差快取或動畫歷史；但具體實作及可見效果尚未驗證，亦需交代側欄隱藏時一般手動resize改採相同內容比例的影響。未擅自實作。

### 依實際尺寸及內距還原內容進度，移除預補 — 2026-11-12

使用者授權「好，改」。沿用現有分支，產品變更限Main.m、AllGlyphs.h／.m、Detail.h／.m五檔，未提交或推送。保留已確認可往返的內容座標 b=topInset−18pt、C=原生最大origin−b；不再推算目標寬度，而是在每次實際幾何更新完成後直接套回 b+p×C。

AllGlyphs新增名稱正確的 preserveContentPositionDuringChanges: 取代 precompensateForWidth:duringChanges:；setFrameSize:、setScrollsUnderToolbar: 均共用它，移除兩個setter內重複layout呼叫。Detail的 preserveGlyphGridContentPositionDuringChanges: 僅在全字模式先完成舊layout，再包住Main的完整工具欄更新。Main刪除split總寬、側欄寬及分隔線的目標寬度預算。刪除反向預補、current／target原生範圍比例換算及兩個專用列數／高度預估方法，原網格計算合回唯一updateLayoutForWidth:。沒有最近行選擇、額外狀態、動畫監視、completion修正或特殊全屏高度。

新公式不僅用於側欄動畫：全字的一般手動尺寸變化也採同一內容比例，側欄隱藏時與舊原生捲軸百分比基準有小幅差異；側欄展開的普通狀態b=0，與舊比例基準相同。縮放仍沿用原策略，其他視圖與原生動畫未變。

初版共用方法保留了舊預補入口開頭的layoutSubtreeIfNeeded，移入setFrameSize:後在尚未套用新frame時重入Auto Layout，隔離探針因此stack overflow。LLDB回溯確認preserveContentPositionDuringChanges:→setFrameSize:→NSViewActuallyUpdateFrameFromLayoutEngine反覆循環。已移除此位置的前置layout，改為只在Detail外層入口完成舊layout，尺寸setter捕捉現有幾何、套用新frame後才統一layout；沒有加掩蓋重入的旗標或兜底。此問題於本輪交付前解決。

最終非可見完整Controller探針沿用2000格、800×600pt畫布，兩種格子比例、普通／強制全屏分支、0／10%／40%／80%／95%／100%起點，各4次連續往返，共96次往返原origin及欄數一致；空表與8格短表亦通過有限原點檢查，共98項。同時在Detail外層方法返回、原生側欄動作前量rectForIndex:0的視窗高度，確認寬度未變，192次初始位移檢查均<0.01pt。原本一般40%預補後上移7.918880pt及全屏fixture40%上移7.936691／下移3.368421pt的階段，現在皆無初始平移。全屏仍為14.8.7上的styleMask分支fixture，非真實全屏或26／27實機，未顯示窗口或捕捉可見動畫中間幀。

改前五檔、獨立差異、可重跑探針與日誌在 diagnostics/grid-live-content-position-2026-11-12/；暫存目錄 /tmp/ga-grid-live-content-position.lefl97qk。最終產品依目前來源重新構建，避免交付中途版本；實際GUI仍待使用者驗收。

### 使用者否決連續比例版；重查已驗收對齊版與完整換欄公式 — 2026-11-12

使用者回報位置仍跑，指出先前已有位置正確版本，要求重新徹查公式與方法。本輪只診斷，產品來源與dist未變、未開可見窗口。不得把使用者要求「不判斷最近行」解讀為放棄原始「橫列畫面高度對齊」目標；此前文檔稱使用者接受自然換欄的邊界，不能當成放棄垂直對齊的授權。最新實際尺寸／內距還原版已被使用者否決，不是待驗收成功版。

以相同現行公共來源分別編譯三組五檔快照：原始未補償、使用者曾確認對齊且清理後版本（content-position改前快照）、目前連續比例版。非可見完整Controller，2000格、800×600pt，1.0／1.7尺度，普通／FullScreen getter分支，0／10%／40%／80%／95%／100%六起點共24組。測量真實rectForIndex: cell頂緣轉視窗座標；切換後選最接近切換前參考線的實際橫列，不以補償公式自身作oracle。原始版20/24單次不對齊、0/24往返原點差；曾對齊版0/24單次不對齊、13/24往返原點差；目前版18/24單次不對齊、0/24往返原點差。每例只做一次往返，用來對照幾何不變量，並非動畫驗證。

普通40%例：寬599→800pt、11→15欄、182→134排，行距52pt；原點3556.8。曾對齊版隱藏後2498.8，橫列視窗高度290.8→290.8，回程原點3504.8（−52pt）；目前版隱藏後2540.4，橫列290.8→280.4（−10.4pt），回程3556.8。全屏分支40%目前版最近原參考線偏移−7.031579pt，曾對齊版0pt，但回程+52pt。全屏是macOS14.8.7非可見styleMask fixture，不是真實全屏或26／27畫面。

公式重查（向下為正）：橫列視窗位置 Y=V+t−o+r*s，V為clip視口視窗起點、t為網格內留白、o為clip bounds捲動原點、r為排號、s為行距。保持整組橫列高度要求 Δ(V+t−o) 是s的整數倍。native inset影響合法origin與原生比例，不是可以再重複加到這條實際座標公式的獨立平移。同寬、同視口時，舊原生比例引入的留白漂移=(1−p_native)*Δ(t+nativeInset)；目前內容比例在此特例消除了漂移。但換欄時以 b=t−18、C=maxOrigin−b、p=(o−b)/C 保存p，當V、視口高度不變且文件足夠長，ΔC=Δ排數*s，故ΔY=−p*Δ排數*s（允許改變整數排號後取同一橫列相位）。40%乘48排為19.2排，0.2*52=10.4pt，精確對應測量。改變套用時機不能把任意分數排變成整數排，頂部留白補償也不能代替換欄橫列對齊。

前輪192個「初始位移0」只量工具欄block返回、欄數未變時；98項往返只證明回原點，兩者均未驗證換欄後單次橫列高度。另舊對齊版在非可見同步流程內的precomp返回值也可能大幅偏移（本例首排視窗座標−49.829425pt），但不能把內部中間值說成真實已呈現的一幀，也不能推翻使用者曾對可見行為的驗收。本輪沒有真實動畫逐幀證據，不宣稱捕捉了使用者看到的第一幀。

方法結論：不能再以只保存連續百分比替代橫列對齊；亦不能僅恢復舊吸附而不處理回程資訊丟失。若保持原生合法範圍和固定等距排版，需要將未對齊前的邏輯進度與畫面對齊後的實際捲動位置分開，後一次切換沿用原始進度；使用者真正捲動／換字體／篩選／縮放等需有明確重設生命週期。另一方向是讓排版自身承擔偏移，但涉及繪製、命中和文件範圍；尚未實作或將任一候選宣稱成功。現有Sources不變。

可重跑比較腳本、三版五檔快照、SHA256與測量日誌在 diagnostics/grid-formula-review-2026-11-12/；本輪原始臨時工作目錄 /tmp/ga-grid-formula-review-20261112。

### 依使用者最新決定改為一次頂部留白差補償，清除取行與進度記錄 — 2026-11-12

使用者先授權恢復舊對齊並解決往返跳行。中途曾實作原生比例記錄及上一結果的origin／尺寸／合法範圍核對，恢復舊remainder對齊及寬度預估；加入1e−6pt邊界容差，避免浮點誤差把頂端判成越界而選相鄰行。該中間版非可見探針264項通過、與曾驗收版24個首次隱藏結果一致，來源與證據位於 diagnostics/grid-aligned-roundtrip-2026-11-12/。此為被後續指令取代的中間試驗，不能當作目前產品行為。

使用者再次提出固定方向取行的想法後，代理純數學算例發現普通30%可2667.6→1921.6→2719.6，定向取整本身仍可能往返差52pt。使用者問取行位置，隨後明確要求停止，指出問題應只在側欄收放前按頂部留白差與捲動百分比補償。代理停止修改並解釋頂端0／底端1定義下公式應為Δ留白×(1−p)。最後使用者明確授權「就照這個簡單的公式改，把前面取最近行和記錄進度的代碼清掉。我自己來驗證它的可行性」。以此最新指令為準，不再加入保證完整換欄橫列相位／往返的額外機制。

本輪五檔：Main.m、AllGlyphs.h／.m、Detail.h／.m。Main仍在工具欄更新完成、原生側欄寬度動畫開始前補償；移除目標寬度計算，接口改為compensateGlyphGridTopSpacingDuringChanges:／compensateForTopSpacingDuringChanges:。AllGlyphs在更新前取得原生捲動比例p與舊總留白，總留白為grid.topInset+scrollView.contentInsets.top；更新後依新舊留白差*(1−p)直接增加目前clip origin，再交原生限制。來源捲動範圍≤0.5pt時只完成更新，不作無意義比例補償。普通與全屏都使用實際系統內容內距，不硬編碼標題欄高度。

刪除remainder／最近行、行距補償、原始進度快取、預期origin／limits／size、相關font／filter／scale失效程式、專用epsilon、目標寬度／高度預算及反向預補；columnsForWidth:與heightForColumns:合回原updateLayoutForWidth:。原生尺寸／內距／縮放比例保存維持GAPreserveScrollPosition。沒有改其他視圖或原生側欄動畫。沒有提交／推送。改前五檔和本輪patch在diagnostics/grid-top-spacing-formula-2026-11-12/。

依使用者要求本輪不跑探針／UI測試，不開App；只作來源殘留檢查與正常構建。可行性及普通／真實全屏的可見效果均由使用者自行驗證。

### 簡單留白公式頂端補償不足：後續原生比例重排會縮放補償 — 2026-11-12

使用者回報頂端p=0應補34pt，實際看起來少於34pt。此輪只核對來源和代數，不改產品碼、不構建、不跑探針或UI。現行compensateForTopSpacingDuringChanges:先將34pt加到工具欄更新後的clip origin；隨後側欄寬度動畫引發setFrameSize:，其GAPreserveScrollPosition把已包含補償的origin重新換成原生比例，再套入新範圍。因此補償亦被乘以「新範圍／舊範圍」，頂端p=0只成立於補償前，不能假設加完34pt仍是0%。

以既有2000格、599→800pt寬度資料作代數例子：工具欄更新後仍窄版範圍−52…8874（長8926），寬版−52…6378（長6430）；−52先加34到−18，隨後變成−52+34*6430/8926=−27.507506。有效補償只有24.492494pt，比34少9.507506pt。這些是既有幾何資料配合現行來源的推算，不是本輪實測，也不是使用者目前字體／視窗的精確數值。應區分單純留白變化下的公式和整段換欄流程，不能只因p=0代入得到34就宣稱最終畫面實得34。調整方向是讓補償不被後續比例換算再次縮放；本輪未選擇或實作新方案。

### 改用使用者指定的共同基準範圍公式 — 2026-11-12

上一輪曾在setFrameSize:追加扣掉已縮放補償、加回固定點數的處理，topSpacingCompensation僅維持一次側欄transition，Main finish強制完成layout再清除。該版完成本機構建，但在文件更新與回覆前被使用者中止；來源備份在本輪before及diagnostics/grid-fixed-spacing-compensation-2026-11-12/before/。使用者提出1000／1034、頂端去程+34、回程乘103.4%得−34的模型，代理說明共同基準分母，使用者再授權「也許可以簡化公式。按這個做吧」。

本輪改為字面共同基準公式，化簡R/baseRange*(1−p)為remaining/baseRange。工具欄改動前捕捉原生可捲動範圍R、目前origin、總留白G=grid.topInset+contentInsets.top；remaining=maxOrigin−origin限制於0…R，baseRange=R−G+GAAllGlyphsVerticalMargin（既有18pt）。工具欄更新完成、原生側欄寬度動畫開始前，增加(newG−oldG)*remaining/baseRange。R或baseRange≤0.5pt不作無意義的除法補償。基準依同寬度、同視口下正常18pt網格留白定義，不把文件總高度混成捲軸的可捲動範圍。

清掉上一輪topSpacingCompensation欄位、setFrameSize:逐次補回、All／Detail的finish接口、Main的對應完成回呼與為其追加的layout。恢復原有setFrameSize:比例保存。沒有最近行、跨次進度、預估目標寬度或反向預補。五檔修改範圍與前輪一致，沒有提交／推送。本輪來源／差異位於diagnostics/grid-common-range-formula-2026-11-12/。

需要明確記住限制：這是按使用者指定的公式試改；共同分母調整本身並不取消後續GAPreserveScrollPosition的縮放。普通頂端且oldG=18時baseRange=R，新公式仍得到+34pt；之後寬度變化仍會縮放此值。不能聲稱該變更已解決前輪34→24.49pt例子的問題，也不能把純數學+34／−34抵消當成AppKit套用時序的完整證明。已在本輪commentary向使用者指出此項。仍遵從使用者自行驗證，不跑新探針、不做GUI操作，僅來源檢查與正常構建。

### 共同基準版反覆切換緩慢向上漂移的代數診斷 — 2026-11-12

使用者回報新版很接近，但每次收放穩定小幅向上爬升，要求檢查哪裡算錯。本輪只讀現行來源並以Python Fraction精確有理數計算，不改產品碼、不構建、不啟動App或跑GUI／AppKit探針。

已確認兩個計算基準問題。第一，remaining在changes()前讀取，但補償套用在changes()後，此時setScrollsUnderToolbar:中的GAPreserveScrollPosition已按新捲動範圍換算過origin；不能再把前一狀態中的±補償量直接當作回程互逆。用使用者1000／1034模型，在同寬度、無其他幾何變化且不觸發邊界的40%例即可推出偏差：初始400，原生換算至413.6，再加34*600/1000=20.4，得434；回程先按原生比例換成434*1000/1034=419.7292069632495，再減34*(1034−434)/1000=20.4，終點399.32920696324953，比起點少0.6707930367504835pt。這是精確分數運算的結果，不是浮點或累積rounding。一次往返origin誤差=−d²*(1−p)/(B+d)，除底端p=1外方向固定朝較小origin；頂端可能被原生min夾住而掩蓋誤差。

第二，目前baseRange=R−oldSpacing+18仍依當下欄數／寬度計算；側欄收放造成換欄時，它不是兩方向相同的共同分母。既有2000格fixture中，去程窄版base=8892、回程寬版base=6396。按現行完整比例與補償順序作代數推算，40%起點3556.8連續四次回程為3548.7191608763、3540.6260822938、3532.5207457142、3524.4031325712，各次約−8.0808／−8.0931／−8.1053／−8.1176pt。數字僅為既有幾何資料的推算，不是使用者當前字體／視窗實測。

兩個問題須分清：移除共同分母倍率可消除同寬度例中的額外項，但不能單憑此宣稱換欄後也可逆，因前後內容範圍不同。此輪尚未設計或實作替代公式，不能再次承諾一行改動即可同時解決完整動畫與往返。先向使用者說明changes()前後混用位置、回程已被原生比例改過及共同分母實際隨寬度改變。

### 讓去回使用同一座標轉換，修正共同分母版的累積漂移 — 2026-11-12

使用者在前輪診斷後授權「好的，那就改」。本輪針對原生比例換算與補償混用基準、去回分母隨寬度變化未被正確處理的問題，改為直接在新座標中還原位置。仍不取最近行、不保存跨次進度，不新增暫存補償或動畫完成回呼，不做GUI／探針，依先前使用者指示自行驗證畫面。

實作：更新前讀G=grid.topInset+contentInsets.top、B=原生範圍−G+18、D=maxOrigin−origin；changes()並layout後讀新G、新B、新maxOrigin，直接設定origin新=maxOrigin新−D舊*B新/B舊。同一幾何往返時D回=D舊*(B新/B舊)*(B舊/B新)=D舊，前提是兩範圍有效且未被原生上下限截斷。B隨寬度改變是這次轉換的明確輸入，不再把不同數值的B直接稱為同一數值分母。D不夾到B，避免抹掉額外頂部空間的資訊。

AllGlyphs的setFrameSize:與setScrollsUnderToolbar:改為共用此位置轉換，移除兩setter中的原生GAPreserveScrollPosition；縮放保留原策略。helper由compensateForTopSpacingDuringChanges:改名preserveContentPositionDuringChanges:，對應Detail／Main名稱同步；不再額外相加ΔG*remaining/baseRange。共用helper不作前置layout，只在Detail外層入口作前置layout，避免已知setFrameSize:重入問題；changes()後統一layout。全字一般手動resize亦改採同一基準，其他視圖未變。

這個直接還原公式在minOrigin=−nativeTopInset的通常長文件情況下，與先前內容基準版b=grid.topInset−18、C=maxOrigin−b、p=(origin−b)/C在數學上等價。必須保留歷史限制：先前此模型能往返但使用者曾回報換欄橫列高度仍跑，不能因本次推導而宣稱它同時保證整行相位。最新多輪指令已移除最近行與進度記錄，本輪只修目前共同分母版的累積漂移，保留自然換欄；普通／全屏可見效果仍由使用者評估。

五檔改動限Main.m、AllGlyphs.h／.m、Detail.h／.m。改前來源及patch在diagnostics/grid-reversible-base-2026-11-12/。未提交／推送；僅正常構建與來源檢查，沒有將舊探針結果冒作本輪新測量。

### 使用者確認偏移與換欄同步；分段複核留白與重排 — 2026-11-12

使用者確認目前來回不再向上爬，但開始時仍略有上下偏移，要求確認留白補償。透過非阻塞問題區分未換欄就整片平移、換欄同步平移，使用者明確回覆「換欄時同時上下移」。這是目前版本的觸發條件，不能再將它誤寫為寬度尚未改變時的留白偏移。

本輪只診斷，不改產品來源、不構建dist、不操作使用者App。為分開兩階段，以現行來源編譯既有非可見完整Controller幾何probe，800×600pt、2000格、scale1，普通／FullScreen getter分支，各0／10%／40%起點；記錄Main工具欄callback返回、外層位置還原返回（兩者寬度未變），以及換欄完成後的實際cell轉視窗座標。12次方向的工具欄callback及外層還原均為0（浮點微量）位移；普通頂端換欄亦0，普通10%換欄偏+10.4pt、40%偏−10.4pt，且各次回程origin均回原值。全屏分支對應偏移+5.614035／+15.452632／−7.031579pt，也均回原值。此為macOS14.8.7非可見幾何與styleMask分支，不是真實全屏或可見動畫逐幀；使用者回覆獨立確認觀察偏移與換欄同步。

原因與前次模型限制相符：現在保存的是連續內容進度，寬度變化令總排數改變，該進度映射到的origin差不必為整數行距。例如普通40%、11→15欄，182→134排，少48排，40%乘48為19.2排，0.2排*52pt=10.4pt。留白更新當下對齊不等於寬度重排後橫列仍同相位。不能再加一筆留白差去消除此重排差額，亦不能擅自恢復使用者已要求刪除的最近行或跨次進度狀態。本輪只向使用者確認問題所在，尚未選擇新產品方案。

探針、編譯腳本和結果在diagnostics/grid-spacing-stage-audit-2026-11-12/；臨時工作目錄/tmp/ga-spacing-stage-audit-20261112。

### 使用者放棄修復並要求捨棄全部未提交改動 — 2026-11-12

使用者先要求退回codex/macos-27-ui-adaptation；代理確認當前已在該分支，原擬只撤銷側欄補償並保留其他既有變更。使用者隨即明確糾正「不用，一個都不用留」，因此本輪捨棄全部未提交Git變更，不只本次捲動修復。執行git reset --hard codex/macos-27-ui-adaptation及git clean -fd，回到619bce7（Add Hokkien localization and update glyph labels）。清除三個未追蹤來源GAAppKit.h、Views/GAInput.h、Views/GAInput.m；已追蹤檔案及刪除狀態全部還原。git status --porcelain為空，分支名稱仍是codex/macos-27-ui-adaptation。沒有提交或推送。

按回復後來源重建dist/Glyph Atlas.app完成。未開App、未做GUI驗證。Git忽略的README內部文檔、diagnostics歷史證據和構建產物未用git clean -x刪除。此前尚未提交的macOS27適配、其他來源清理、翻譯和所有側欄捲動方案均已撤銷；不可因分支名稱包含macos-27就認為適配碼仍在。GLOSSARY中此前工作區的細節須重新以目前619bce7來源核對，本條為最新狀態依據。

### 恢復分支命名時的工作區內容，正式建立修復前快照提交 — 2026-11-12

使用者發現回到分支提交後檔案不對，代理查reflog：2026-11-11 22:51:34建立codex/current-overwritten-files，22:52:06改名codex/macOS-27-UI-匹配，22:52:14改名codex/macos-27-ui-adaptation，三者都指向當天10:52:41的619bce7；當晚UI適配等工作僅在未提交工作區。代理承認前輪未充分區分分支建立時工作資料夾與分支已提交內容。使用者最新明確要求恢復此次側欄捲動修復前、即22:52:14命名時的版本，並作一次提交。

本輪找到/tmp/ga-archive-import-dxeks585/incoming完整匯入副本，而非僅五份grid來源。依diagnostics/archive-import-2026-11-11/incoming-manifest.json，Sources／Resources／build.sh共162個檔案SHA256及mode全數吻合；修復最初的五份來源與此匯入副本逐位元組相同；其餘Sources與回退前完整probe副本也全數一致。由此恢復完整未提交工作區，包括UI適配、來源整理、翻譯與版本1.7／build8；此次所有grid捲動補償實驗均不含在內。刪除當時已移除的舊Input路徑、GAViewMode.h及GAGlyphNameTables.h，保留正常來源移動。GLOSSARY同步恢復匯入版本，三條過時的捲動補償描述已去除；歷史PRODUCT-LOG和diagnostics保留。

恢復過程中Resources出現12份不在原清單的帶「 2」檔名副本；未推定其來源，已移到本輪diagnostics/unexpected-duplicates/，未納入提交。再次核對Git index中162份檔案hash全數匹配原始清單，且來源／資源／腳本範圍沒有多餘路徑。正常重建dist，未開App或做GUI驗證。

本地提交eed46c0（Snapshot macOS 27 UI adaptation before scroll experiments），在codex/macos-27-ui-adaptation上，29個差異檔／路徑（含Git辨識rename）。提交後git status --porcelain為空，未推送。完整還原副本、來源清單、hash/mode驗證和commit證據位於diagnostics/restore-pre-grid-workspace-2026-11-12/。目前有效版本已恢復為此提交，不再是前輪暫時退回的619bce7裸狀態。

### 將修復前快照推送到GitHub main — 2026-11-12

使用者要求把當前提交發到GitHub。起點為codex/macos-27-ui-adaptation@eed46c0，工作區乾淨。fetch後origin/main由40d7f34更新為6dd2d34，遠端獨有0192a50與6dd2d34兩個README開啟說明提交；本地獨有48個提交，無法直接快轉。於獨立/tmp/ga-publish-pre-scroll-snapshot工作區準備合併，兩份README語言列表發生衝突，保留本地已新增的Hokkien／閩南話，開啟說明採自動合併結果。

完成衝突處理後，index對eed46c0完全無檔案差異：遠端的開啟說明內容本地其實已包含。依使用者整合並發布當前版本的授權建立合併提交16ea306（Merge origin/main while preserving the restored snapshot），完整tree與eed46c0相同，僅補歷史關係。原工作分支快轉至16ea306後，以git push origin HEAD:main成功推送，沒有force、rebase、改寫歷史或PR，也未變更本地main。

git ls-remote確認GitHub main為16ea306fd4f74ec1abfa0d968858d48656e6e5f7；來源快照eed46c0亦在其祖先歷史。git status乾淨。臨時合併worktree與分支已清理。沒有檔案內容變更，因此沒有重複構建／測試。

### 合作规则改为本地提交，并按GitHub版本整合分支 — 2026-11-12

使用者明确要求将合作笔记里的「建立新分支」全部改为「在本地提交一次」，整理全部已有分支，一个GitHub版本一个分支，未采用试验例外，其余保留为提交。本轮直接执行此授权，不改产品来源，也不重写历史。

COLLABORATION-NOTES的逐轮保存规则、Git章节和备份回退章节均改为本地提交；每轮开始前有待保存工作就提交，结束后保存已授权的实际改动，干净工作区不造空提交。明确分支不会保存未提交内容，同版本功能／性能／清理不再各建分支；本地保存的长期授权与远端推送的明确授权分开。补充分支／提交时间与回退范围核对，避免再次把分支建立时工作区当成分支提交。GLOSSARY同步当前分支及本地提交政策；PRODUCT-LOG历史事件不批量改写。

查询GitHub Releases与远端refs确认正式发布v1.0…v1.6；建立version/1.0…version/1.6七个本地分支，逐一指向GitHub标签提交。将原当前codex/macos-27-ui-adaptation改名version/1.7，仍为16ea306；1.7为开发版，不创建正式发布tag。main快转至origin/main@16ea306。两个codex/legacy/experiment/分支保留为未采用试验；四份未合并历史副本改用archive/glyph-atlas-2-early、archive/gsub-navigation-and-zoom、archive/gsub-working-copy、archive/localization-working-copy标签保存其提交。

首次fetch --tags发现本地v1.6@391219a与GitHub v1.6@6dd2d34不同，fetch拒绝覆盖。已先建立archive/local-v1.6-before-github-sync-2026-11-12保存旧本地指向，再仅将本地v1.6同步为GitHub指向。未修改或推送远端标签／分支。未直接覆盖任何未归档的提交。

原74个本地分支整理为11个：7个正式版本+1个当前开发版+main+2个试验。删除的工作分支原先已有提交，未另造重复提交；整理前后147个提交均可从保留refs追溯，lost_commits为空。当前HEAD与产品工作区完全未变，git status干净。另一个已有detached worktree未操作。仅更改Git引用与本地忽略的内部文档，因此无产品构建或UI测试。

整理前完整Git bundle（已verify）、全部refs、合作笔记副本、GitHub发布清单、操作脚本、归档映射与结果保存在diagnostics/version-branches-2026-11-12/；核对文件verification.json。没有推送GitHub。

### 审查未合并历史并统一接入版本提交，明确发布前版本区间 — 2026-11-12

使用者要求再看未合并历史是否有实际合入价值，删除零散归档、统一保存；补充版本定义：v1.0发布后所有后续修改属于v1.1，直到v1.1发布，依此类推。目前v1.6发布后的工作属于v1.7。COLLABORATION-NOTES的Git章节已据此明确版本区间、发布分支端点及下一版本归属；GLOSSARY同步。之前按GitHub标签建立的正式版本分支端点符合该区间定义，无需将分支名整体错移一号。

审查四个未合并历史副本及它们独有的0997543候选／导航提交，差异和具体决定见diagnostics/history-consolidation-2026-11-12/review.json及四份patch。0997543的contextual Decisions／规则完整回放／下游候选传播，在当前GASubstitution.cpp有对应实现与后续优化；共享GAPreserveScrollPosition及缩放位置保存、source-aware侧栏更新在现版亦存在。8bcedb4的网格尺寸保存、WOFF类型辅助、共用字形绘制、较新输入／预览拆分在现版已覆盖或由后来架构替代；未选取旧架构覆盖新代码。83aa8ae的Sources树ef7a2867…与0997543完全相同，额外差异仅封装／图标／文档范围，没有新来源功能。c1d20d0的唯一来源差异是旧VF面板间距及Shift selector判断；当前已有selector判断与后来的75pt字段／4pt行距布局，旧66→70pt等布局不恢复。此为源码与历史审阅，不冒充旧版完整运行测试；未发现需新增合入当前产品的独立功能。

按用户统一保存授权，在version/1.7创建955cc7b（Consolidate reviewed legacy history without changing the current product），使用ours策略将8bcedb4、83aa8ae、c1d20d0作为额外parent；0997543已在前两者祖先中一并纳入。该提交只连接历史，不采用历史文件树，tree与第一parent16ea306完全相同。原147个提交均保持可达，现148个；164个Sources／Resources／build.sh及对外README文件SHA256和mode全数不变。没有产品代码变化，未构建或做GUI测试。

确认所有archive标签目标都是HEAD祖先后，删除四个历史副本标签及前轮本地v1.6旧指向标签，共5个；原始Git bundle仍保存在前轮diagnostics作操作回退证据，没有删除现有诊断目录。当前开发branch/version1.7继续使用既有11分支结构，两个未采用实验分支保留，main仍与GitHub已发布的16ea306一致。工作区干净，没有推送GitHub。未来归档流程调整为审查价值、实际有价值代码按授权采用、历史统一接入版本提交后清理零散标记，不把历史接入说成采用旧功能。


### 单字视图跟随本次新输入的最后一字，复用全字待选流程 — 2026-11-12（范围已过时，更新请看「输入选字规则扩展为全局」）

使用者希望文字输入时单字视图自动显示最后新输入的一字；明确原文「甲乙」中间输入「丙丁」后应选「丁」，并要求尽可能沿用全字视图双击追加的流程、复用代码。按此授权实施，范围为Main.m、Sidebar.h／.m三个产品文件，不另建分支；开始前version/1.7@955cc7b工作区干净，未建空提交。

在既有recordFieldEdit:的文字存储通知中记录原生编辑后的范围，独立于已发布快照的来源追踪；onTextChanged回呼携带该范围。Main仅在Single Glyph且新增范围非空时取新增内容最后一个UTF-16位置，调用全字追加已有selectGlyphIDsAfterNextReload:，再走原scheduleAnalysis、generation核对、快照发布、侧栏选择通知和组滚动。该位置只用于寻找包含它的来源组，不切割代理对或构造文字。待选接口扩展空GID数组表示直接选base，并明确跳过精确空GID匹配，避免误选零输出候选；非空数组的全字追加／激活流程及nil取消语义保留。

输入法仍沿用hasMarkedText门槛，确认上屏后才提交跟随；纯删除不设跟随，Undo／Redo清除编辑范围并保持现有还原流程。新输入覆盖旧待选，手动改变侧栏选取沿用现有取消机制。输入焦点不因自动选择而转移，工具栏与侧栏共用编辑器。多字及全字模式的普通输入不新增自动跳转。未建立第二套查找／预览或额外shaping。

依项目约定仅正常构建及来源差异检查，不启动App、不跑UI或额外探针。输入法上屏时序、连续输入／粘贴、中间插字与实际显示待使用者GUI验收，不将源码路径当作实机通过证据。

正常本机arm64构建完成，git diff --check通过。本地提交c037227（Follow newly entered text in single glyph view），仅纳入上述三个产品文件；提交后工作区干净，未推送GitHub。

### 输入选字规则扩展为全局 — 2026-11-12（删除规则已过时，更新请看「删除选中字形后选择前一字」）

使用者纠正前轮范围：输入自动选字是全局规则，不仅是单字视图；同时逐项询问此前提出的五项规则是否实现。当前version/1.7@c037227工作区干净，未建空提交。本轮仅删除Main输入变更回呼中的Single Glyph条件，三种视图的原生输入／粘贴均使用同一个pending管线，继续按这次新增内容最后位置选择基本字形。全字模式随后沿用现有选择通知定位／闪烁，多字模式仍保留原生排版。没有新增第二套自动选取逻辑，也不改变全字双击的精确GID待选。

逐项来源核对：1）记录原生更新后的新增范围，取最后位置，涵盖逐字、贴上与中间插入；2）controlTextDidChange在hasMarkedText时返回，不发新跟随查询，正式上屏依原生通知处理；3）在对应快照经generation与原文核对后才应用pending，随后走原选中通知，不转移输入焦点；4）新输入替换pending及worker generation，过期快照不套用，手动改变侧栏选取清除pending；5）纯删除范围长度为0，不建立新待选，仍走原选择恢复。第五项原「仅单字视图」已被使用者本轮全局要求取代。上述为源码检查，尚未真实操作输入法／粘贴／快速输入等GUI场景，不将实现路径等同实机验收。

本机arm64正常构建及git diff --check通过。仅Main.m的一行范围条件变化保存为本地提交bdda6e8（Follow input selection across all preview modes），工作区干净，未推送GitHub；未启动App或做GUI操作。

### 删除选中字形后选择前一字 — 2026-11-12

使用者在了解原纯删除会保留仍存在的选取、选中来源被删则退第一基本字后，明确要求「如果刪掉的文字處於被選擇的狀態，則選擇前一個字」。本轮按侧栏／预览的选中字形来源理解，不把文字框的文字选区本身当作触发条件。起点version/1.7@bdda6e8工作区干净，未造空提交。开始时说明边界：第一字被删且前面无字，选剩余第一字；全删空沿原清空路径。

在既有recordFieldEdit:确认原生编辑范围有效后，用编辑前的来源映射判断选中范围是否与纯删除相交。相交则将删除起点前一UTF-16位置作为自动待选目标；该位置仅查包含它的来源组，不截断代理对或重建文字。一次删多字取整段删除起点前一字。删除不相交的其他来源不新增跳转，输入／粘贴仍取本次新增末位。选中字形的来源在前次删除中已消失且仍有自动待选时，连续删除改用该待选位置判断；不相交删除亦映射其位置，避免旧查询未回时丢失目标。只沿用有效的原生编辑记录，不以共同字串前后缀推测重复字符的删除位置。

将既有来源编辑映射循环提成GARemapSourceRangeThroughEdits，原currentInputRangeForDisplayedRange:与删除判定共用。私有inputEditedRange改为inputAutoSelectionRange，onTextChanged回呼直接传自动选取目标；Main复用同一个selectGlyphIDsAfterNextReload:@[]和scheduleAnalysis，无第二套选取／滚动／预览代码。产品修改仍限Main.m、Sidebar.h／.m三个文件。输入焦点、hasMarkedText、Undo／Redo及手动选择取消机制沿用原路径。默认只正常构建与来源检查，不启动App、不跑UI或额外探针，实际连续删除／组合字符等画面仍待使用者验收。

本机arm64正常构建与git diff --check通过。本地提交c91482c（Select the preceding character when deleting the selected source），只纳入上述三份产品文件；提交后工作区干净，未推送GitHub。

### 收拢输入待选职责与删除策略，局部清理 — 2026-11-12

使用者回复「好，沒問題了」接受当前行为，并授权整理本部分及相关代码，使逻辑与位置更合理，做少量清洁。开始时version/1.7@c91482c工作区干净，未造空提交。不扩大到字体查询、全字几何或其他模块。

本轮将原生输入自动待选的准备留在GASidebarViewController.controlTextDidChange:，使用同一个selectGlyphIDsAfterNextReload:完成空GID选基本字形或nil取消旧待选；移除「侧栏计算目标→Main接收目标→回调侧栏设pending」的往返。onTextChanged恢复无参数通知，Main只调用scheduleAnalysis。Undo／Redo的pending取消同样归回侧栏didReplayInputEdit:；Main仍负责其独有的pendingGlyphEdit取消与重查，两类通知不合并。

将已经验证的删除后选字判断抽为侧栏内私有autoSelectionRangeAfterDeleting:，recordFieldEdit:保留原生编辑范围验证、记录与调用顺序；该策略仍在追加本次编辑前使用原选中来源和已有编辑映射。保留连删时的空GID待选追踪、不相交删除映射、第一字边界和全删空处理。插入定位、hasMarkedText门槛、焦点、来源范围判定、pending精确GID与零输出区分、generation／原文核对、捲动通知均沿用原逻辑。来源包含匹配与其他入口的相交匹配语义不同，不强行合并。产品变动仍限Main.m、Sidebar.h／.m三份文件。

使用者的接受作为本部分行为验收记录，不推定其逐一测试了所有输入法和异步边界。本轮按约定只正常构建与来源检查，不启动App或新增探针／UI测试。

本机arm64正常构建与git diff --check通过。本地提交7d9b2e1（Keep native input selection policy in the sidebar controller），三份产品文件合计28行新增／32行删除；提交后工作区干净，未推送GitHub。

### 全字追加与原生输入共用侧栏收尾 — 2026-11-12

使用者询问输入自动选字与全字双击追加是否已合并，并提出全字发起、侧栏负责插入后处理的分工，要求UI／UX／结果不变。前轮仅评估，未改码；本轮使用者明确「請按你的專業意見來，交給你了」后实施。起点version/1.7@7d9b2e1工作区干净，未造空提交。

保留全字Grid只回报entry、Main准备Unicode字符／借用字符／固定GID标记的职责。扩展侧栏appendInputString:selection:selectingGlyphIDs:actionName:，将Main原先取得追加范围后设置pending、scheduleAnalysis、focusInput的收尾移到侧栏；接口返回void，不再将内部范围交给Main回传。追加仍经原commitGlyphInput:提交输入、登记Undo、同步控件；失败立即返回，不执行待选／查询／移焦。

新增私有inputDidChangeSelectingGlyphIDs:textRange:，只负责原有Group捲动策略的待选登记与onTextChanged分析通知，原生controlTextDidChange:和全字追加共用。普通输入仍传空GID表示base，删除无新目标仍传nil取消，全字追加传被点击的完整GID以保留精确命中／base回退。全字成功路径顺序仍为commit结束Undo分组→pending→同步回呼scheduleAnalysis→focusInput；Native路径仍在prepareFieldEditor后执行pending与回呼，handlingNativeInputEdit仅包原生入口，不把全字追加的后续属性清理混入原生文字Undo。主视窗保留唯一scheduleAnalysis接线及已有generation／原文校验。

产品范围仍限Main.m、Sidebar.h／.m。没有修改全字手势／命中、字体候选／payload规则、侧栏激活与Shift插入、排版、滚动策略或结果消费。按约定只正常构建与来源检查，不启动App或新增探针／UI测试；上述顺序一致为来源核对，不冒充可见界面逐项验收。

本机arm64正常构建与git diff --check通过。本地提交68eebe2（Share sidebar input finalization with glyph grid appends），只纳入上述三份产品文件；提交后工作区干净，未推送GitHub。

### 输入选字整合后清理与待选扫描收敛 — 2026-11-12

使用者接受上一轮整合结果，要求清理残留、优化尚可优化的逻辑，并询问进一步整合建议。本轮开始version/1.7@68eebe2工作区干净，未造空提交。检查本部分Sources调用链，旧inputEditedRange、带范围参数的onTextChanged与返回NSRange的追加接口均已不存在，没有为凑清理而删除有效的nil／空GID区别、编辑记录验证或Undo状态。

在Sidebar.m的rowForPendingSelection中以本次待选GID／来源范围局部值保持判定清楚，将「先整表找精确GID，未命中再整表找base」合为一次行扫描：记住第一个base，继续优先找第一个完整GID精确匹配；精确命中立即返回，否则回首个base。空GID直接选首base，不匹配零输出候选。来源范围的先精确、再包含规则不变，未假设group在rows中只出现一段，也未新增索引／快取。减少的是精确GID未命中时的一次重复扫描，未做性能量测，不声称端到端加速比例。

更新GASourceEdit注释，明确其范围为编辑前输入坐标，涵盖原生编辑与快照差异两种来源。rowForGlyphIDs:inGroup:仍被滚动锚点恢复使用，保留；包含范围匹配、相交范围匹配语义不同，保留。产品实际只改Sidebar.m。默认仅构建与来源检查，不启动App或新增探针／UI测试。

进一步整合建议：可单独评估侧栏字形替换的提交收尾，使Main继续准备payload与原文范围、侧栏负责提交后待选及分析通知；须显式保留普通替换SelectedToTopIfNeeded、Shift插入不设待选、原焦点保留与原Undo边界，不能直接套用全字追加的Group／focusInput流程。本轮没有扩大实施该项。

本机arm64正常构建与git diff --check通过。本地提交6f7faf6（Resolve pending glyph selection in a single row scan），仅Sidebar.m；提交后工作区干净，未推送GitHub。

### 保留现有职责边界，并推送本轮到GitHub main — 2026-11-12

使用者认为侧栏替换收尾继续整合的价值不明显；代理重新评估，底层提交／Undo／待选／查询已共用，剩余几行调度的行为区别明确，进一步泛化会增加参数与分支，因此不列为待执行计划。使用者接受当前边界，随后明确要求「commit 到 GitHub」。

推送前version/1.7@6f7faf6工作区干净。fetch后origin/main仍为16ea306，是当前HEAD祖先，左右独有计数0／11，可直接快转；11个祖先差异包含既有955cc7b历史整合及其4个旧历史提交，产品tree相对远端实际仅Main.m、Sidebar.h／.m三份差异，不将旧历史连接说成新采用旧功能。执行git push origin HEAD:main成功，未开PR、未force、未rebase或改写历史，也未切分支或改本地main。

git ls-remote确认GitHub main与本地HEAD均为6f7faf6640e9ab23f487b67c844fbd34df9c0463，工作区干净。无新产品代码变更，未重复构建或操作GUI；本轮输入选字、删除跟随、职责整理与扫描优化已上传。

### VF按钮原生参数Tooltip；排查字名偶发不展开 — 2026-11-12（Tooltip已撤回，更新请看「撤回VF Tooltip并继续诊断原生字名展开」）

使用者要求侧栏显示／隐藏时的VF按钮都增加当前轴参数Tooltip，例如「XXX: 300, YYY: 500」，并明确尽量沿用原生。另回报侧栏展开时字名字尾省略后偶尔无法悬停展开；一次开第二窗口后第一窗口也恢复。异步询问触发时机，使用者答「不記得／沒有固定條件」。本轮起点version/1.7@6f7faf6；已有README.cn.md的3增4删是本轮前的使用者修改，不修改或纳入本轮源码提交。

实现仅Main.m：updateVariationToolTip按fontResource.axes顺序，以已有字体轴显示名与variationCoordinates生成逗号空格分隔的名称／数值对。NSNumberFormatter配置同现有VF数字框：Decimal、本地化、无千位分隔、最多4位小数，不另加无效默认赋值。内容设于原variationButton.toolTip及当前独立NSToolbarItem.toolTip；收起侧栏新建的工具栏项沿用同一文字，12–13自订NSButton初建时同步。loadResource默认坐标及onCoordinatesChanged滑杆／数字／预设路径更新；无轴则nil。没有手写悬停计时、NSTrackingArea或弹窗，也不新增本地化键。

对照本机SDK NSView／NSControl／NSToolbarItem／NSWindow头及Apple官方文档：普通Tooltip由toolTip属性提供，NSToolbarItem会将tooltip转给其view；allowsExpansionToolTips是文字被截断时的另一原生机制。官方参考：https://developer.apple.com/documentation/appkit/nsview/tooltip 、https://developer.apple.com/documentation/appkit/nscontrol 、https://developer.apple.com/documentation/appkit/nswindow/invalidatecursorrects%28for%3A%29 。

字名当前已设allowsExpansionToolTips=YES，使用普通NSStackView、无自订hitTest／鼠标穿透；标题变化时会invalidateIntrinsicContentSize，已挂入本窗才调用invalidateCursorRectsForView:。每窗toolbar identifier亦独立，没有找到能直接解释两个窗口一起恢复的产品代码路径。原生悬停／区域刷新是待验证方向，不是已证实根因；不新增猜测性生命周期覆写或改用普通字名Tooltip，不声称已修复此偶发问题。未启动App或操作GUI；正常构建与来源检查，真实悬停及其他系统仍待使用者验收。

本机arm64正常构建与git diff --check通过。本地提交cc2fd9c（Show current variation coordinates in native VF button tooltips），只纳入Main.m。未推送；使用者原有README.cn.md修改仍留工作区，未混入提交。

### 撤回VF Tooltip并继续诊断原生字名展开 — 2026-11-12

使用者要求「Tooltip還是刪掉，太醜了，恢復上一版本」，并要求查字名偶发不展开原因。本轮在cc2fd9c上执行git revert --no-edit cc2fd9c，建立f9e044d；Main.m与Tooltip前的6f7faf6逐字一致。只撤回该项23行源码，不reset历史，不修改或纳入使用者原有README.cn.md的3增4删。按恢复后的来源正常重建dist，未推送。字名产品逻辑只诊断、不修补。

使用者确认发生系统为macOS14。以当前产品Controller建立独立非可见探针，三个窗口宽度600／380／1000pt，检查空标题、加载长名后、布局后、建立第二窗后、侧栏收放后；记录显示最终字段宽116pt、原生展开宽464.477216pt，命中GAFontTitleField，allowsExpansionToolTips为YES，NSToolTipManager拥有的tracking area为116×16pt、options4225。建立第二个非可见窗口未改变第一窗的上述数据；该结果仅为几何和注册状态，不能推断真实hover已通过。

中途使用者提供关键复现：隐藏侧栏再显示会触发；在另一个正常窗口显示一次全名，再回原窗即可恢复。对应来源路径toggleSidebar会unpinSidebarTitle／updateToolbarForHiddenSidebar，将同一fontTitleView从侧栏卸下并放回新建的原生工具栏项目。首轮独立可见诊断副本记录到动画期间多次cursor／tracking重建，最终仍有正确展开范围和一项tracking area，不足以直接认定仅缺一次invalidateCursorRects。正式来源未加试探性生命周期覆写。

为查真实显示链，在/tmp/ga-title-expansion-20261112准备独立bundle ID com.zonz.GlyphAtlas.TitleExpansionProbe的可见副本，仅副本中记录GAFontTitleField及NSToolTipManager的事件、timer、current expansion与panel状态。它使用独立偏好，正式App源码和prefs不加诊断；测试字体为系统Arial Rounded Bold。自动工具没有纯移动停留接口，其点击／滚动未送出原生mouseEntered／tooltip timer事件，不能把这种操作当作hover测试。已请使用者在该副本的两个窗口手动重做复现和跨窗恢复，等待对应事件证据；当前不声称根因已查明。

### 实际复现定位到展开动画后的原生悬停区域遗失 — 2026-11-12

使用者在独立Title Probe两窗手动执行后回复「已復現，另一窗展開後恢復」。这次捕捉到真实mouseEntered／Exited、1.5秒timer及displayToolTip调用。关键证据来自GAFontTitleField的原生cursor／tracking生命周期：问题窗口45760在展开动画期间从4pt增长到116pt宽，原生tracking被移除后多次resetCursorRects均未重新登记；最后一帧时间816190924.572，trackingCount为0。直到816190930.335切到另一窗口，原问题窗和对照窗同时重新计算expansion及cursor，原问题窗trackingCount恢复1。字名内容、完整展开宽146.37790882587433pt及命中并未损坏。此次定位到注册链的失效，并解释切窗为何恢复；不把未验证的AppKit内部缓存机制说成确定原因。

在独立来源副本试验最小候选：仅在toggleSidebar既有展开完成回呼结尾、!hidden时，完成当前窗口layout后调用公开invalidateCursorRectsForView:。保持原生allowsExpansionToolTips，不加tooltip文字、timer或自订tracking。在同样真实动画中，最后一帧816191217.742396仍为0，完成回呼刷新816191217.761576即重新计算展开范围并恢复trackingCount1，毋须先切到别窗。该候选只验证区域登记恢复，尚未请使用者再测该版可见hover，因此不宣称正式App已修复。

全部可见测试均为独立bundle，已通过CUA关闭；原正式App进程未替换。正式Sources仍与6f7faf6一致，仅存在撤回Tooltip的f9e044d提交，用户README.cn.md原修改保留。没有将候选修复或诊断hooks混进产品、没有推送。证据源、独立编译脚本、原始hover／manager记录、非可见结果和候选副本归档在diagnostics/title-expansion-2026-11-12/；summary.json区分产品现状、真实复现与候选验证边界。私有manager显示字段未作为最终浮层可见性的证明，实际复现／恢复采用使用者观察与原生区域记录共同判断。

### 采用侧栏展开结束后刷新原生字名区域的最小修正 — 2026-11-12

使用者明确授权「好，按這個最小改法修吧」。本轮起点version/1.7@f9e044d，Main.m无未提交改动，只有使用者原有README.cn.md修改，后者不修改、不纳入。正式产品仅在toggleSidebar既有finish回呼结尾新增4行：!hidden时完成currentWindow.contentView.superview布局，再invalidateCursorRectsForView:titleFontNameField。没有改动字名文字、原生展开外观、双击缩放、收放动画、原焦点恢复或其他Tooltip。

Main.m与前轮已验证的GAMainWindowController-proposed.m逐字一致，git diff --check通过；只移入这处最小修正，没有加入任何诊断hooks、私有接口、timer或自订tracking。原诊断已经验证真实动画后的区域登记由0恢复1；本轮依约定只正常构建，不重新操作GUI，实际hover由使用者验收。

本机arm64正常构建完成。本地提交41e28ad（Restore native title expansion tracking after sidebar animation），只纳入Main.m，未推送GitHub；使用者原有README.cn.md修改仍留工作区。

### 使用者验收字名展开修正，并推送GitHub main — 2026-11-12

使用者回覆「好了，沒問題了，commit 到 GitHub」，确认当前修正并明确授权推送。fetch后origin/main仍为6f7faf6，是version/1.7@41e28ad的祖先，左右独有计数0／3。三个本地提交分别为VF Tooltip增加、撤回及字名修正，最终产品tree相对远端只有Main.m新增的4行原生区域刷新；未将撤回的Tooltip作为当前功能。

执行git push origin HEAD:main成功，未开PR、未force、未改写历史或切换版本分支。git ls-remote确认远端main与HEAD均为41e28add0b87421cbcd1ca5fe634fe2454100923。使用者原有README.cn.md的3增4删仍在本地未提交，未混入本次推送；内部交接文档按既有规则本地维护。没有新代码改动或重复构建／GUI操作。

### 两份根目录README忽略本地修改，保留GitHub内容 — 2026-11-12

使用者要求.gitignore列入两份README，以后不参与commit。核对README.md／README.cn.md已经被Git追踪，说明单加ignore不生效、取消追踪会在下一次推送从GitHub移除后，使用者明确选择「保留 GitHub 的 README，只忽略本地修改」。因此不执行git rm --cached，也不删除本地或仓库文件。

在既有.gitignore结尾追加/README.md和/README.cn.md，保留其他规则，并补结尾换行。执行git update-index --skip-worktree -- README.md README.cn.md，git ls-files -v两项均为S。原README.cn.md本地3增4删仍原样保留，只是日常status／add／commit不再纳入；README本身仍在index及HEAD，未暂存删除或内容变化。该标记是当前工作副本的本地索引状态，不随推送传播；已在合作笔记明确后续提交政策及换副本需重新核对，不能把.gitignore说成对已追踪文件自动生效。

本轮只提交.gitignore，不包含两份README的本地内容，不改产品来源，也无产品构建／UI操作；尚未推送GitHub。

本地提交566a1be（Ignore local README changes while retaining repository documentation），index仅暂存.gitignore；提交后两份README标记仍为S，普通git status无待提交变更。本地README.cn.md的既有编辑只是被索引标记略过，并未丢弃。

### 说明GitHub Release的Verified与提交签章关系 — 2026-11-12

使用者说明每次要在README动一点内容，发Release才显示认证；仅命令行提交会显示未认证，询问原因。本轮只读本地与GitHub元资料及官方文档，不修改签章设置、不创建／上传key、不改历史。git log %G?显示最近本地提交均N（未签署），当前有效git config未找到user.signingkey、commit.gpgsign或gpg格式设置；本地身份仍为自动推导的提交者信息。

GitHub REST核对41e28ad为verification.verified=false、reason=unsigned、committer=Zonz；网页提交6dd2d34为verified=true、reason=valid、committer=GitHub。latest Release为v1.6，其tag是直接指向6dd2d34的commit ref，因此此处Release显示的Verified来自该网页提交的签章。GitHub官方说明网页建立的提交自动由GitHub用GPG签署；README编辑只是产生了一笔新的网页签署提交，不会替前面命令行提交补签。

可行方向为后续在此仓库配置本地SSH／GPG提交签章并关联GitHub签章公钥，即可让之后的命令行提交获得验证，不需要每次改README；本轮仅解释，未将该方向视为执行授权。参考：https://docs.github.com/en/authentication/managing-commit-signature-verification/about-commit-signature-verification 、https://docs.github.com/en/authentication/managing-commit-signature-verification/signing-commits 。

### 设置本仓库SSH提交签章，恢复README正常追踪；本轮不提交 — 2026-11-13

使用者要求配置以后命令行提交可被GitHub验证，恢复两份README原设置，并明确「這一輪先不commit」。起点version/1.7@566a1be；本轮不执行git commit／commit-tree、不重写旧提交、不推送。将.gitignore工作区恢复为41e28ad内容（撤销两条README忽略规则），并对README.md／README.cn.md清除skip-worktree；两项均显示H，原README.cn.md的3增4删保留。.gitignore及README.cn.md均留工作区未暂存。

GitHub CLI账户为Zonz-Ly（id32699823），其现有OAuth scopes没有user或SSH signing-key管理权限，相关私有读取返回404；未扩大CLI权限。改用公开user签章key清单核对无现存key，并核对网页提交6dd2d34使用的noreply邮箱32699823+Zonz-Ly@users.noreply.github.com。当前ssh-agent无身份，~/.ssh无可用公钥。按授权创建专用于本仓库的Ed25519签章key，私钥仅存~/.ssh/glyphatlas_signing_ed25519、权限600；只向GitHub登记.pub，私钥不输出、不进入仓库。

仅通过git config --local设置user.name=Zonz、上述GitHub隐私邮箱、gpg.format=ssh、user.signingkey为专用私钥路径、commit.gpgsign=true，以及.git/glyphatlas_allowed_signers作本地验证。没有修改全局Git设置或HTTPS远端认证。以普通临时文本在git namespace做SSH detached签署／验证，得到Good git signature，未创建测试commit，HEAD仍566a1be。公钥指纹SHA256:VpTZinggbkCeDTaltlp7Cq6mNDCuR+DBYSUgu3ETRWw。

GitHub连接工具无账户签章key管理接口，CLI现有权限也不能登记；在Firefox新分頁打开GitHub签章key表单，核对登录账户Zonz-Ly，填入Title「GlyphAtlas signing — Zonz Mac」、Key type=Signing Key及生成公钥。表单已准备，按电脑操作对新增可信签章key的当次确认要求，请使用者确认最终送出；此时尚未点击Add SSH key，等待答复。该确认不会建立commit。

使用者明确回复「確認，加入這把 Signing Key」后点击Add SSH key。GitHub随后要求sudo mode验证码；由使用者直接在Firefox完成，未向聊天提供验证码。使用者回复已完成后，页面显示成功加入该标题，并在Signing keys区列出上述匹配指纹。已观察到最终登记成功，未触及Vigilant mode或其他账户设置，CLI OAuth权限亦未扩大。公钥登记用于签章验证，未登记为Authentication Key。

最后通过GitHub公开签章key清单核对，id1327094的公钥与本地.pub的算法／key数据完全一致；本地私钥权限600、仓库签章配置正确。HEAD仍566a1be，暂存区为空，两份README标记均H，.gitignore内容与41e28ad一致，现有README.cn.md编辑保留，git diff --check通过。本轮没有创建任何Git提交或推送；验证止于真实SSH detached签章／验签及GitHub公钥登记，未用测试commit获取远端Verified徽章。以后新提交由本地默认签章，届时可读远端verification确认；历史不改写。

### Removed the extra layout call before native title-region refresh - 2026-11-13

The user requested an isolated test retaining only the native region invalidation after sidebar animation, to determine whether the preceding layoutSubtreeIfNeeded could be removed. Previous evidence tested both calls together and did not establish that layout was necessary.

Built an isolated com.zonz.GlyphAtlas.TitleNoLayoutProbe with the single candidate deletion and diagnostic-only lifecycle logging. On macOS 14.8.7, Arial Rounded MT Bold in a 600x400pt window, all six actual sidebar expansion cycles restored trackingCount from 0 to 1 in subsequent native updates (5.366, 12.271, 10.393, 8.269, 7.989, 14.068ms). At the checkpoint, fieldNeedsLayout was false but rootNeedsLayout was true: this does not prove there was no pending layout. The first three cycles did not execute the separate input-focus restoration layout; the fourth retained that existing focus path. No custom region or timer was added to the product.

The user manually collapsed/expanded the same isolated window and hovered the truncated title without visiting another font window, then confirmed the full name displayed. Logs captured two real mouseEntered -> 1.5s native timer -> displayToolTip chains for window 46481. Private panel-status fields are not used as evidence of visible display. Evidence, logs and probe source: diagnostics/title-expansion-nolayout-2026-11-13/.

Production change: deleted exactly one layoutSubtreeIfNeeded before the completion invalidateCursorRectsForView: in Sources/App/GAMainWindowController.m. All other layout calls, focus handling, animation and native expansion remain. Normal arm64 build passed. Kept changes uncommitted and did not push, preserving the earlier gitignore restoration and user README.cn.md edits.

### Research only: native toolbar transition with large multi-character top margin - 2026-11-13

The user clarified the target is background appearance/disappearance while scrolling with the sidebar already hidden, then requested thinking through the multi-character case where top whitespace exceeds toolbar height while preserving current trigger positions. No product edits, builds, UI actions, or commits in this research round.

Current multi-character document includes topGap=max(0,pageVerticalMargin-toolbarTopInset) inside its frame; updateToolbarAppearance instead compares pageRect's actual top against the viewport below the toolbar. This explains the distinction between document-edge scrolling and page-edge overlap. Candidate for isolated verification: represent the extra whitespace outside the page-bearing document via native contentInsets, preserving the combined scroll extent and visual page coordinates, then let native overlap handling operate. This is a hypothesis, not a proven native trigger mechanism. Public contentInsets documentation states automatic adjustment overrides manually assigned values during tiling, so a naive assignment is not a valid complete solution; preserving native toolbar insets requires explicit investigation. Do not implement or claim equivalence based only on this proposal.

Re-read 2026-11-09 native-scroll-shadow diagnostics in this log: macOS 14.8.7 automatic style retained a fine line at the top and single-glyph view; scroll-view-root and split-view variants did not remove that line while retaining scroll shadow. Prior animator tests of titlebarAppearsTransparent/titlebarSeparatorStyle had no native property animation. Therefore other modes also cannot yet be assumed visually equivalent under automatic styling. References: Apple NSScrollView contentInsets and automaticallyAdjustsContentInsets documentation.

### Standalone native-inset toolbar validation: geometry matches, background timing does not - 2026-11-13

User authorized building a separate lightweight app to validate moving excess multi-character top whitespace into native scroll contentInsets while preserving existing page positions, scroll behavior and background trigger. Created diagnostics/native-toolbar-insets-2026-11-13/Native Insets Probe.app (independent bundle com.zonz.GlyphAtlas.NativeInsetsProbe), only Cocoa/QuartzCore and a painted page, with selectable current/native-padded/native-inset modes, three margin settings, long/short pages, a sweep button and return-to-top button. Native candidate sets automatic titlebar appearance once, disables automatic scroll insets to supply the combined measured toolbar inset plus extra margin, and reduces document height by the transferred margin. No per-scroll background switching in either native mode.

On real macOS14.8.7, 900x600pt window, measured native toolbar height52pt. Final sweep records162 samples, 54 current-vs-candidate pairs. Offset, legal scroll range, page-top window position and page-vs-toolbar overlap all match exactly (max differences0pt). Every requested offset was reached or correctly clamped. Margin100pt/long page example: both ranges1000pt, page top500pt at offset0; offset48 aligns page top548pt with toolbar bottom548pt. Current background remains transparent through48pt and appears at49pt, returning transparent at0. Native-inset candidate already visibly shows native gray background/fine separator at0 and retains it on return; actual CUA screenshots confirmed the appearance, independent of NSWindow flag values. Thus the native-inset-only candidate does not satisfy background timing despite geometry equivalence. This is not proof all native approaches are impossible.

CUA also exercised actual scroller value49pt and native scrolling to bottom in both modes; candidate scrolled back to top. Tool direction labels were inverted by native natural-scroll behavior; no custom wheel handling exists in the probe. This is not a full momentum/elasticity equivalence claim. Left the separate app open in candidate mode at top for inspection. No product source changes, product build, commit or push this round; existing .gitignore/README.cn.md and the prior one-line Main.m deletion are unchanged.

Initial sweep retained with -initial suffix but rejected as equivalence evidence: scrollToPoint left pending smooth movement, and initial toolbar coordinate logging failed to account for flipped NSScrollView coordinates. Fixed the probe to use constrained setBoundsOrigin for fixed sampling, record requested vs actual offsets, and measure toolbar bottom in window coordinates, then reran all scenarios. Final evidence: summary.json, sweep.json, comparison.json, events.jsonl, main.m and build.py under diagnostics/native-toolbar-insets-2026-11-13/. Host/version and simplified-page limits are explicit in summary.json.

### Other public native approaches: scope distinction - 2026-11-13

After the standalone inset candidate failed background timing, the user asked whether another reasonable native solution exists. Read current public AppKit documentation and local macOS14 SDK headers. No documented macOS14 API was found that accepts our page-overlap threshold and requests the system-owned titlebar background fade; this is a search result, not proof every native layout approach is impossible. Prior property-animator failure remains relevant.

A feasible separate category for discussion is an app-owned NSVisualEffectView using the public titlebar material, animated through native NSView alpha/animator facilities while retaining existing page-overlap logic and all scroll geometry. Materials and animation are native; background ownership, placement and transition triggering are app-managed, so it must not be described as AppKit automatically managing the real titlebar background. Its exact material compositing, separator and shadow appearance need separate visual comparison; no implementation or new runtime test is authorized by the question alone. macOS26 scroll-edge APIs are newer behavior, not a macOS14 solution nor a proven guarantee of exact current timing. No product changes, builds, commits or pushes this round.

### Added native-material fade and current-switch animator modes to standalone probe - 2026-11-13

User authorized adding the proposed native-material fade to the existing isolated app, then explicitly requested testing the current approach with animation added as well. Added two popup choices: mode3 native titlebar material plus fade, and mode4 existing titlebar switches through window.animator. Product source remains untouched.

Mode3 keeps the padded-document geometry and existing page-overlap >0.5pt trigger. The system titlebar remains transparent/without separator; a separate NSVisualEffectView (public titlebar material, within-window blending) is placed in the content root behind toolbar controls, with a native NSBox separator at its bottom. Native NSView animator fades its alpha over a chosen250ms demonstration duration; reduced-motion setting requests zero duration but that setting was not separately tested. No drawing or mouse-handling overrides were added for the overlay. Mode4 keeps the original real NSWindow titlebar background/separator and passes both setters through animator in the same250ms animation group.

Ran270 settled samples covering five modes, three margin settings, long/short pages and nine offsets. For each new mode,54 baseline pairs had exactly0pt differences in page position, legal range and offset; trigger targets matched in all samples. Diagnostic 60Hz presentation-layer sampling recorded intermediate alpha in both fade-in and fade-out for mode3 (e.g. about0.009 at18ms,0.191 at51ms,0.934 at185ms,1 by267ms). Mode4 switched transparency/separator immediately; visible native titlebar material presentation opacity remained1 in sampled frames, with no gradual opacity observed. This agrees with the earlier public-property animator diagnosis.

Mode3 is not an exact replica of the system titlebar: the toolbar controls retain styling for a transparent titlebar, and the probe does not reconstruct the native scrolling shadow. CUA screenshot confirmed the material end state; visual acceptance of animation/style is left to the user. App reopened with five choices and final state mode3 at top. A final CUA action was interrupted because the user interacted with the app; re-read state and stopped further actions rather than overwriting user interaction. One CUA timeout was recovered by rebinding. Evidence: summary-five-modes.json, sweep-five-modes.json, events.jsonl and main.m in diagnostics/native-toolbar-insets-2026-11-13/. The earlier three-mode source/results are preserved with -three-modes suffix. No production build, commit or push.

### User rejects separate material layer; distinguish native shadow from background fade - 2026-11-13

User does not want to split the toolbar background into an app-owned native-material view because cross-version maintenance may be burdensome; asked for other viable approaches. Treat mode3 as a demonstrated but unselected experiment, not an integration plan.

Rechecked public NSWindow header/documentation and NSAnimationContext allowsImplicitAnimation: animator already enables implicit animations, so merely adding that flag is not a distinct supported solution to the failed mode4. Apple's WWDC20 documentation describes an automatic scrolling shadow/pocket for full-size scroll views, not a public animation contract for titlebarAppearsTransparent. A useful remaining investigation would be an actual system-app comparison to determine whether the desired visual is the scroll shadow while background remains present, or a real background visibility transition. Native automatic appearance with a persistent background is a legitimate lower-maintenance option only if the changed resting background/timing is accepted; it is not equivalent to the current requirement. No additional confirmed public macOS14 solution preserving all current timing and system-owned background is established. No product edits or new UI tests this round.

### 仅多字超额顶部留白保留手动标题栏背景，其余交给AppKit — 2026-11-13

使用者明确放弃继续研究原生渐变，并授权新规则：多字视图顶部留白超过标题栏高度（没有补偿高度的情况）由App自己控制，其余情况直接交给AppKit。按严格大于处理，相等归原生；不将已拒绝的独立材质／动画方案接入产品。

GAMultiGlyphView新增只读pageTopGapBelowToolbar，计算toolbarTopInset>0时max(0,pageVerticalMargin-toolbarTopInset)，否则0。documentSize和pageRect原有相同计算改为共用该getter，公式及几何结果不变。GADetailViewController.updateToolbarAppearance默认设置titlebarAppearsTransparent=NO及separatorStyle=Automatic；仅MultiCharacter且该gap>0时保留原页面顶端相对工具栏下缘的>0.5pt重叠判定，并保留无垂直滚动范围时透明的原规则。缩放／内容／窗口变化跨过gap=0时会回到默认原生策略，不新增缓存状态。

滚动／document frame通知仅保留多字，删除不再需要的全字背景监听和全字距离分支。updateMultiLayout结束后刷新策略，以覆盖顶部留白变化而document frame恰好不变的情况；现有递归布局保护保留。Main初始化移除全局强制透明／无分隔的两行，让窗口采用系统默认；此前移除字名完成回呼额外layout的一行保持。四个产品文件为Main.m、Detail.m、Multi.h／.m。没有改捲动范围、补偿公式、绘制、文字排版或标题栏控件。

正常本机arm64构建通过，git diff --check通过；本轮未做新探针或操作正式App，实际GUI由使用者验收，不能将之前独立示意页探针当成本轮产品验证。保留.gitignore恢复及使用者README.cn.md修改；沿用暂不提交的要求，没有commit或push。

### MagnetLite reference corrects incomplete native-titlebar conclusion — 2026-11-13

After seeing persistent titlebar background/line in single-glyph mode, user directed inspection of /Users/zonz/Documents/ChatGPT/Zonz/MagnetLite. Read current Sources/MLSettings.m, Tests/NativeSettingsTests.m, ORIGINAL-COMPARISON.txt:120-130 and diagnostics/0.2.13/validation.txt plus saved AppKit-separator-decision.txt. No source or settings in either product were modified this round.

Current MagnetLite uses only public AppKit: fullSizeContentView, Unified toolbar/tracking separator, Automatic window and both split-item separators, a full-frame NSScrollView directly owned by the body controller, automatic insets, drawsBackground=YES, and semantic NSColor.controlBackgroundColor. It has no scroll observer writing titlebar transparency or custom background material view. Its current source comments explicitly identify the semantic scroll background and full-frame view as inputs to native scrolling-pocket recognition. Earlier0.2.12 private separator setter was removed in0.2.13 and is not the current method.

The0.2.13 record reports real macOS14.8.7 Dark CUA checks of independent left/right scroll states, no separator at top, native material when scrolled, return-to-top disappearance and sidebar cycle. Saved local disassembly shows _updateSectionState consults the scroll adapter background and checks controlBackgroundColor/textBackgroundColor in seamless-style selection; this is version-specific implementation evidence, not a public cross-version guarantee. The record also says a wrapper/root view and explicit Shadow alone did not fix it with windowBackgroundColor; semantic background change was important, not merely setting Automatic.

Glyph Atlas currently has custom GAPreviewColors backgrounds (253/255 light,60/255 dark or overrides), a multi-mode container, nested all-glyph scroll view, and a non-scroll single-glyph view. The lightweight probe also used a numeric white background, so its persistent-background result does not establish that native seamless behavior is unavailable. Correct the previous categorical explanation: AppKit is not inherently required to keep the visible line/background at rest; our tested configuration failed to select the same native style. Adapting MagnetLite while preserving Glyph Atlas custom preview colors and mode geometry remains unverified. Source inspection only this round, no new build or GUI run, no commit/push.

### Abandoned toolbar background changes and restored the previous implementation - 2026-11-13

User explicitly abandoned further native background work and requested restoration. Verified all pending Detail.m and Multi.h/.m changes belonged solely to the latest hybrid policy and restored those three files from HEAD. Main restored the two original transparent/no-separator initialization lines, retaining the earlier independently tested one-line deletion in the font-title completion callback. The only remaining product diff against HEAD is that earlier deletion. No rollback of user README.cn.md edits, pending gitignore restoration, SSH signing configuration or Git history. The rejected policy patch was retained under diagnostics/native-toolbar-insets-2026-11-13/; it includes the preexisting title completion deletion, so it is historical evidence rather than an automatically applicable rollback patch.

Normal arm64 build passed, diff whitespace clean. No formal app UI operation, commit or push. GLOSSARY restored to the original manual background policy. User asked whether switching branches suffices: explained uncommitted edits can follow a checkout or block it, so branch switching would not selectively undo this task while preserving unrelated changes. Restoration is already complete.

### 多字長文字上下抖動：幾何與捲動分層診斷 — 2026-11-13

使用者回報整頁上下果凍狀抖動，macOS 14、橫排、側欄展開和收起都有，約2000字可嘗試，未指定字體。本輪僅診斷，正式Sources與dist不變，不提交或推送。原.gitignore、README.cn.md與Main.m的既有單行刪除保持。

來源中捲動通知僅更新標題欄外觀，不直接重排全文或回寫捲動位置。初次獨立Detail容器的wantsLayer結果不足以判斷正式視窗：完整Main/split/toolbar父層量測確認scroll、clip、page和文字的layer都存在。已向使用者修正先前外層無圖層的懷疑，不能據此補開wantsLayer。完整Main非可見量測以Helvetica約2002字、側欄展開599pt／收起800pt，各12個位置，穩定後pageRect、document/text frame及container origin均不變，最大捲動原點偏差5.7e-14pt；不冒充可見動畫驗證。

使用者明確同意開啟獨立診斷副本。普通open受LaunchServices沙箱通信限制，按既有明確授權提權開啟成功。副本獨立bundle ID，沒有操作正式App。使用者在Glyph Atlas Scroll Probe手動確認重現：首份6.595秒紀錄包含536次主執行緒timer採樣與301次捲動通知，沒有rebuildLayout或document frame改變，pageRect、text frame及container origin各只有一個值。通知本體最大0.0064ms；timer間隔中位10.746ms、最大28.017ms。timer間隔不是顯示器／compositor實際幀時間，不能由此宣稱渲染時序正常。

第二份Glyph Atlas Synchronous Scroll Probe僅在診斷category覆寫GAMultiGlyphView.+isCompatibleWithResponsiveScrolling為NO，使用Apple公開opt-out。使用者回報仍然一樣抖動；19份session共1066採樣無全文重排或document frame變動。未將停用非同步捲動當作修復採用。

第三份Glyph Atlas Render Comparison提供選單「捲動診斷→直接繪製文字」：沿用現成TextKit2排版和GID讀回，勾選時將原文字視圖alpha設0，由page.drawRect以NSTextLayoutFragment.drawAtPoint:inContext:繪製相交fragment，取消則回原生文字圖層。僅修改診斷來源副本，正式產品不變。已開啟並等待使用者同一視窗比較，目前尚未定位根因。

證據與來源SHA256在diagnostics/multi-scroll-audit-2026-11-13/；可執行副本及新捲動JSON仍在/tmp/ga-multi-scroll-audit-20261113/。可見捲動重現由使用者進行；CUA僅讀取第三份副本的開啟面板與診斷選單，確認已開啟，沒有代替使用者捲動或更改介面。Apple公開文件支持圖層與捲動對照方法，不等於已證實本問題為系統Bug。

後續使用者回報直接繪製仍然一樣抖動，並補充似乎僅慢速移動時發生。原生繪製累計10份session／5120採樣、停用非同步19份／1066採樣、直接繪製2份／2191採樣，均無rebuildLayout、document frame變動或採樣內pageRect／text frame／container origin變化。既有bounds紀錄全部落於0.5pt格點，慢速小步可見0.5／1／1.5／2pt；這是位置資料，尚未證明抖動來自像素量化，也不能把慢速線索直接當成系統或硬體問題。

CUA只讀第三副本目前視窗，確認實際字體為ThemeX Hiragino Sans.ttc的「極限柊野黑 正形 本」，PostScript名由本機CoreText逐面核對為ThemeX_HiraginoSans-Trd-Normal；讀取使用者已放入的測試原文作本機對照資料，內容不作本任務指令。另建Native Scroll Reference獨立App，預填該面51pt及原段文字，提供TextKit2原生NSTextView、TextKit1原生NSTextView、純色橫線三項。兩種文字都直接作為NSScrollView.documentView，沒有產品的page容器、側欄、GID反查或捲動外觀回呼；橫線只作非文字參照，不承諾成本與文字相同。已在既有診斷授權內開啟，CUA只讀確認三控制與文字已顯示，未代替使用者捲動，目前等待慢速比較結果。此最小視窗與產品外觀／布局並非完全相同，不能由單項結果無條件歸咎某個模組。正式Sources與dist仍無本輪變更。

### 多字慢速捲動抖動：暫停時的有效結論與續查入口 — 2026-11-13

使用者明確要求「我們先停下來，寫好已有的結論。稍後我們再繼續」。排查在此暫停；以下為本輪目前有效交接，前幾段的「等待使用者」均已取得回覆。**根因尚未定位，沒有採用任何產品修復。** 不把失敗的對照改法接入正式Sources，也不要因已有猜測而跳過驗證。

#### 已確認的現象與比較結果

- 使用者觀察：macOS 14、橫排、整頁上下抖動，側欄展開／收起都有；約2000字可試，後補充似乎主要發生在慢速移動。此次主機紀錄為macOS 14.8.7、2× backing scale。
- 實際案例為使用者字體`~/Library/Fonts/ThemeX Hiragino Sans.ttc`的「極限柊野黑 正形 本」（`ThemeX_HiraginoSans-Trd-Normal`）。預填後續對照用51pt與從診斷視窗讀到的原段文字；本機文字副本多了末尾換行，不聲稱與最初輸入逐位元組相同。
- 使用者確認純原生對照的**TextKit 2、TextKit 1、純色橫線三種都平穩**，另自行回報同樣採用TextKit 2的TextEditor也沒有此狀況。TextEditor是使用者觀察，沒有由代理獨立檢查其實作或設定。
- 因此目前應查Glyph Atlas自身的視圖整合／繪製配置與原生最小配置的差異；不能籠統宣稱「TextKit 2本身必然抖動」、一般慢速像素步進、特定字體或硬體就是原因。仍可能是產品配置觸發的AppKit特定組合問題，尚未區分。

| 已做對照 | 使用者視覺結果 | 能得出的結論 |
| --- | --- | --- |
| 正式來源的獨立診斷副本 | 同樣抖動 | 診斷副本可重現原問題 |
| 僅停用responsive scrolling | 仍然相同 | 單獨停用非同步捲動不能解決，不能當作修復採用 |
| 沿用既有TextKit排版，改由page直接繪製fragment | 仍然相同 | 單獨換掉原生文字圖層繪製沒有改善；文字視圖及排版仍存在，不能據此排除全部TextKit整合因素 |
| 僅將document高度向上對齊實體像素 | 仍然相同 | 小數文件高度單獨取整不能解決；不代表所有座標／圖層對齊方式都已驗證 |
| 原生NSTextView直接作documentView，TK2／TK1及橫線 | 三種都平穩 | 原生最小配置是有效正對照；與產品仍有視圖巢狀、座標方向、背景及圖層環境等差異 |

高度取整的切換確實生效：原始document高6748.5969387755104pt，勾選後6749pt；文字frame改為y=0.40306122448967585pt、高6748.5969387755104pt。使用者仍回報相同，不能把「開關沒有真的改到幾何」當作此次失敗原因。此改法只在`Glyph Atlas Pixel Comparison`的診斷category內，正式檔案未改。

#### 紀錄支持什麼，以及不支持什麼

暫停時歸檔JSON統計：原實作12份session／5439次timer採樣；停用非同步19份／1066次；直接繪製2份／2191次；像素對照原始1份／181次、對齊1份／666次；更深bounds審計3份／994次。這些捲動session均無`rebuildLayout`或document frame變動。前幾組的pageRect、text frame與textContainerOrigin在各session採樣中固定。捲動通知本身耗時很短，未找到反覆全文重排或產品回寫捲軸的證據。

最後的`Glyph Atlas Bounds Audit`保留原產品行為，另記scroll／clip／page／text的NSView frame、bounds、visibleRect，以及CALayer model／presentation的bounds、position、transform、sublayerTransform與animationKeys。使用者在這份也確認重現。三份994次採樣內，page和text的bounds、layer bounds／position、transform等均固定，監測層沒有animationKeys；變化集中在正常捲動的clip bounds及其layer／presentation bounds，以及page／text的visibleRect。沒有抓到文字內部bounds原點或外層圖層位置額外上下變動的證據。深度JSON的`page`鍵被巢狀圖層紀錄取代，該組未另外保留pageRect字串；彙總已避免把正常visibleRect變化誤算成幾何不穩定。

重要限制：timer是主執行緒採樣，**不是顯示器／compositor的實際幀時間**；讀到的presentationLayer也是採樣狀態，不是螢幕像素追蹤。沒有錄製畫面或量化每幀文字墨跡位置。不能把上述固定幾何當作「使用者看到的抖動不存在」，也不能由採樣的偶發30–50ms間隔直接指認掉幀根因。0.5pt格點在紀錄中存在，但平穩的原生對照也有像素格點，不能單憑此解釋差異。

原生對照歸檔累計TK2 21份session／5198採樣、TK1 5份／1273採樣、橫線18份／2761採樣。這些數量只是操作紀錄；三者平穩的視覺結論來自使用者，不由timer資料替代。

#### 續查時先讀這裡

- 核心來源：`Sources/Views/GAMultiGlyphView.m`的`GACreateMultiTextView`、`positionTextView`、`documentSize`、`pageRect`與`drawRect`；`Sources/Views/GADetailViewController.m`的捲動容器建立及`updateMultiLayout`。產品page為預設未翻轉NSView，內嵌原生翻轉NSTextView；此組合與原生直接documentView的差異**尚未做成對照**，不要把它當作已證實根因。
- 同樣尚未受控核對的差異包括：完整split／toolbar父層帶入的實際圖層配置、頁面背景／陰影與原生不透明文字背景、原生viewport繪製／合成耗時及螢幕實際幀位置。這只是待區分範圍，不是已選定的下一個改法。不要重複把已失敗的關非同步、改直接繪製或只取整高度當作解法。
- 證據總表：`diagnostics/multi-scroll-audit-2026-11-13/pause-summary.json`；原生與產品紀錄在其`native-results/`和`live-results/`。診斷`.m`／`.sh`、各次構建log、非可見結果、實際測試文字與來源SHA256均已複製到同一目錄。
- 六個已開過的獨立App及可執行產物仍在`/tmp/ga-multi-scroll-audit-20261113/`，未在暫停時強制關閉或刪除；`/tmp`不保證長期保存。重新製作時腳本引用當前產品Sources與`.build`物件，要先核對來源SHA256與當前狀態，不能假設重編後仍是本輪完全相同版本。
- 本輪沒有改正式Sources、沒有重建dist、沒有commit／push。既有工作區仍只有`.gitignore`、`README.cn.md`與Main.m的既有單行刪除。交接文件與diagnostics是此次新增紀錄。可見捲動由使用者完成，CUA僅讀取指定診斷App的介面確認。


### 多字慢速捲動抖動：專屬捲動實驗室與加長文本 — 2026-11-13

使用者恢復排查，明確要求把其餘可能方向整合成專屬測試App；製作、修正與操作均限於獨立診斷副本。產物為`diagnostics/multi-scroll-lab-2026-11-13/Glyph Atlas Scroll Lab.app`，獨立bundle ID `com.zonz.GlyphAtlas.ScrollLab20261113`，不註冊產品字體檔案類型。正式Sources、Resources與build.sh逐檔SHA256對照開始時快照均未改；既有三項Git工作區改動保持，沒有重建dist、commit或push。

實驗室將開始時的來源與資源凍結在baseline/，以prepare.py產生隔離來源及差異，再由build.sh獨立編譯。提供42個情境（B00、S01–S31、H01–H06、L01–L03、C00），包含31個可組合開關：頁面翻轉座標、frame／inset對齊、零內距／邊距、背景／陰影／不透明、父層與子層圖層、重繪／並行／點陣快取、原生增高、GID讀回／基線補償／預繪範圍、工具列／標題列／尺寸回呼、彈性／方向鎖定，以及此前無改善的非同步與直接繪製對照。結構對照涵蓋完整Main、Detail、page＋scroll、完整Main換原生document、純原生TK2／TK1／橫線，以及原生加根圖層。這是目前可實作的待查範圍，不宣稱已窮盡所有原因。結構拆除可能同時改變布局與父層責任；圖層開關可能被AppKit忽略或重建，以「實際配置」頁和紀錄判斷。

使用者補充「我改了更長的文本，可以用下」。從既有診斷目錄native-reference-text.txt取得目前10644個UTF-16單位的單行文本，設為sample.txt及App預設；原2086單位／21行文本保留為sample-short.txt。sample-sources.json記錄來源及SHA256，兩段資料分別建立fixture ID，評價不混用。預設沿用ThemeX_HiraginoSans-Trd-Normal、51pt、1倍行距，缺字體時要求選擇，不靜默替換。

控制面板提供套用／還原基準、原生手動捲動、5／15／30／60／120pt/s程式慢捲、方向、結果與補充觀察；每次套用重建預覽。⌥⌘0返回面板，⌥⌘1顯示預覽；⌃⌘J／K／U記錄抖動／平穩／無法判斷。程式慢捲依經過時間算位置，與觸控板不同。詳細timer／幾何／方法計時預設關閉；即使開啟也不等於實際顯示幀率。Results/Results.json、Trials/與Fixtures/保存各次配置、文字與使用者評價，既有進度保留。

兩段文本各完成42項隱藏視窗結構檢查，均0失敗；長文本檢查另核對B00與翻轉座標S01的文字頂端保持一致。這些只支持配置可建立及所檢查幾何成立，不支持抖動改善。CUA確認選項切換、補充儲存、自動捲動開始／停止、面板快捷鍵，以及最新面板選項正常可見、長文本已載入。代理未自行填入視覺抖動評價。驗證資訊在self-check*.log、self-check.json、ui-smoke-summary.json、validation-summary.json；source-patches.diff記錄隔離來源差異。

交付時使用者已在App內開始測試；當時長文本fixture a1ded262c5177d84的已儲存評價為B00仍抖動、H04純原生TK2平穩，S03／S04／S08／S09／S10／S11／S12／S13／S14／S17／S19仍抖動。這是讀到的使用者操作結果快照，後續以Results/最新紀錄為準；不能據單項開關宣稱整個方向完全排除。根因仍未定位，沒有產品修復。


### 多字慢速捲動抖動：42項視覺回報完成，頁面繪製成為優先方向 — 2026-11-13

使用者回報「我測完了」。只讀取實驗室Results及來源，沒有操作App、修改診斷或產品程式碼。10644單位的fixture a1ded262c5177d84共42項均有使用者評價：33項有抖動、9項平穩。完整快照、各case選項及結果索引SHA256保存於diagnostics/multi-scroll-lab-2026-11-13/completed-results-summary.json，原Results不改。

最關鍵的單項對照為S07平穩；B00與其餘S01–S31全部仍抖動。H01只保留Detail、H02只保留page＋scroll仍抖動，H03完整產品視窗換原生文字document平穩。H04／H05／H06與L01／L02／L03全部平穩；C00平穩，但實際選項只是nativeInFull，與H03重複，不是另一個組合證據。故頁面自身繪製路徑是目前優先排查處，外層工具列／側欄不是此案例必需條件。不能把這些結果擴張成所有TextKit或圖層因素均已排除。

重要範圍修正：S07名稱雖為「不畫頁面陰影」，實際呼叫main.toggleShowsMetrics，multi.setShowsMetrics只標記重繪，drawRect略過整個GADrawPage。該函式同時建立NSShadow（22pt blur、offset 0,-8）並填滿完整page的圓角矩形。因此目前只支持「略過這段頁面繪製後使用者觀察平穩」，尚未分清陰影、頁面填色、繪製面積或合成路徑。不要宣稱根因已完全證實，也不要直接刪除產品陰影。

B00與S07初始記錄的文字幾何、頁面大小、字體、內距及窗口相同；結束時的實際文字frame原點另有約0.262pt差異，且測試所處捲動位置不同。這並不推翻S07線索，但下一步應在同一頁面中段反覆開關基準／S07確認，再拆「保留頁面填色但不設陰影」及保持外觀的陰影繪製範圍／快取對照。這是後續診斷方向，尚未實作或取得新視覺結果。S12／S13實際配置分別仍保留部分圖層／文字獨立圖層，不能冒充完整無圖層或已完全合併測試。


### 多字慢速捲動抖動：P00–P04原位拆分頁面填色與陰影 — 2026-11-13

使用者明確要求「繼續，在測試app裡縮小範圍做對照」。只更新既有獨立Scroll Lab，正式Sources、Resources、build.sh逐檔與開始時SHA256仍一致；未重建dist或commit／push。phase1-evidence/凍結上一輪診斷來源、42項結論及Results索引；原Results各run逐項相等，使用者評價沒有覆寫。

新增置頂P00–P04五項，保留原42項及其評價。P00原樣呼叫GADrawPage；P01略過整段頁面填色與陰影但保持showsMetrics不變；P02保留原圓角頁面填色、完全不建立或設定NSShadow；P03保留完整來源、陰影顏色與(0,-8)位移，只把blur 22pt改為0；P04保留22pt blur與位移，將來源高度限制於dirtyRect上下各96pt，人工端點位於重繪區之外。P04是診斷近似候選，不聲稱已接受外觀等價。S07名稱更正為「略過頁面繪製〔原S07〕」，舊run標題與數據保留。

prepare.py只在生成副本中把多字GADrawPage呼叫轉送LabDrawPage；LabRuntime.m實作五種繪製與P模式的輕量draw/source範圍計數，不記顯示幀率。LabMain.m讓P項之間重用同一scene/page/text/storage，不關視窗、不重排文字、不改捲動位置，僅更新診斷選項、標題與needsDisplay；run保留sceneInstanceID、前後幾何及geometryUnchanged。從其他舊情境進入或改字體／文本時仍正常重建。新增⌥⌘2切回原始、⌥⌘3返回上一個非原始P對照，以及「固定目前位置／回到固定位置」。P模式停止程式捲動時不額外呼叫updateLayout；原本live-scroll結束的產品路徑保留。每個P run仍獨立記錄評價，不自動套用S07結果。

LabDrawingChecks.m與--self-check-drawing僅檢查新五項及同物件切換、離屏繪製；6項檢查0失敗。離屏頁面中段1×／300pt高取樣：P00與直接呼叫原函式逐位元組相同；同背景下P01與P02相同；P03確實改變陰影；P04與原始取樣差異0，這不代表所有位置／比例或實際動畫均等價。證據在drawing-self-check.json、drawing-check-artifacts/、drawing-validation-summary.json。

CUA確認P00↔P01、P00↔P02快捷鍵／預設切換，面板五項與固定位置控制正常顯示，捲軸值保持0.3500081960574241。最後版另確認P00↔P04並返回P00控制面板，run的同物件切換幾何均相等。P04實際一次重繪區高1068pt、陰影來源1260pt，完整頁面內容高29891pt，縮短確實生效。沒有由代理慢捲判定或寫入抖動評價；長文本10644單位保持。App已開啟，等待使用者只測P00–P04並反覆回原始對照。


### 多字慢速捲動抖動：P項回報及重測差異 — 2026-11-13

使用者回報這輪已測完。只讀Results，未操作App、修改任何程式或填評價。page-drawing-v1有7個已評run、涵蓋P00–P04五項；最新評價為P00原始有抖動、P01略過整段平穩、P02只留填色平穩、P03陰影模糊設零平穩、P04縮短來源仍抖動。**P01與P02初測均曾記為有抖動，後來另開run重測為平穩；兩次均保留，不能只留下較符合假說的結果。**P03／P04之後的P00回訪沒有評價，不能自動補成已反覆確認基準。

七個已評run均為fixture a1ded262c5177d84、同一scene 448A69EC-1000-4D50-8839-3A0C9B46E51B，切換前後幾何相等。實際showsMetrics保持YES、10644單位、ThemeX_HiraginoSans-Trd-Normal 51pt、詳細採樣關閉；document與text frame固定一致，包括文字frame約-0.262pt的原點。這支持本輪確實只原位切換診斷繪製，但不是逐幀螢幕墨跡或compositor計時。

P04實際264次繪製全部縮短來源，193–1260pt，原完整頁面高29891pt；使用者仍評抖動，這項縮短來源方案沒有改善，不能說開關未生效。P01明確未畫頁面來源；P02完全不設定NSShadow；P03保留完整來源及原陰影顏色／位移但blur為0。合併最新回報後，模糊陰影繪製仍是最強續查線索；初測／重測差異使其尚不足以當作已確認根因。原始結果及各run設定存page-drawing-results-summary.json，Results本身不改。

下一步建議先在固定位置重複P00↔P03及P00↔P02，正反方向都確認，再做保留原模糊外觀的預繪陰影對照；尚未實作，也沒有採用取消模糊或刪除陰影的產品改法。


### 多字慢速捲動抖動：使用者決定放棄本輪排查與修復 — 2026-11-13

使用者要求最小修改且不接受任何外觀改變；因此關閉頁面陰影或將模糊設零不符合要求。陰影快取僅曾提出，沒有實作或採用。使用者隨後明確表示「好，放弃」；本輪排查與修復到此停止，不繼續製作快取或要求更多測試。根因仍未完全證實，沒有將診斷改法整合正式產品。保留diagnostics/multi-scroll-lab-2026-11-13/、原始Results與初測／重測差異，日後只有使用者重新提出才恢復。此次只更新交接文件，不操作App、不改程式、不構建或提交。


### 恢復直接開啟命令，將三個字體資料夾入口移入開啟面板 — 2026-11-13（切換方式已由下節修正）

使用者明確要求刪除「開啟字體於」子選單，恢復「開啟⋯」，並在開啟面板加入三個自訂資料夾按鈕。GAAppDelegate的File選單改成直接Open…命令，保留⌘O及隱藏⌘N；NSOpenPanel.accessoryView使用原生NSStackView與三個NSButton，預設展開，依序為目前使用者、所有使用者、系統內建，直接設定同一面板的directoryURL至~/Library/Fonts、/Library/Fonts、/System/Library/Fonts。保留多選及字體類型限制。移除原子選單專用的pendingOpenPanelDirectory、關閉再開流程及多餘入口；GAFontFolderURL仍由資料夾按鈕與原拷貝功能共用。三個按鈕的間距8pt、上下留白各8pt為本輪設定值，不作系統規範宣稱。

33份Localizable.strings以原有譯文建立Open…及不帶省略號的資料夾按鈕名稱，移除Open At、Recent Location…與舊資料夾鍵；Help.01只同步命令名稱，不改其餘正文。台灣／香港選單採使用者指定的「開啟⋯」。兩份對外README未由代理修改，本輪既有README.cn.md改動照原樣保留；對外使用說明仍含舊選單名稱，依約由使用者維護。

開始時工作區已有.gitignore、README.cn.md、zh-Hans的Custom譯名及Main側欄layout呼叫四項未提交修改。代理原說分開提交，使用者明確糾正「不要分開提交」，因此全部既有修改與本輪改動合為一次本地提交babddc2（Move font folder shortcuts into the Open panel），共37檔，工作區乾淨，未推送。改前34份來源／語系輸入與既有patch保存在diagnostics/open-panel-font-folders-2026-11-13/。本輪正常本機構建完成，未啟動App、不操作GUI、不作探針或視覺驗收；附件按鈕的實際顯示與切換效果由使用者驗收。


### 明確未提交修改一律合併本地保存的長期規則 — 2026-11-13

使用者要求寫進協作筆記：「凡是工作區有未提交的修改的那就一起提交了，不礙事。」COLLABORATION-NOTES第3.4節已直接改成工作區全部未提交修改一起保存，不按來源、用途或本輪／既有拆分；移除原先禁止納入其他用途未提交檔案的限制。仍保留工作區乾淨時不建空提交、本地提交與遠端推送分開授權，以及不得擅自修改無關程式碼的邊界。本輪前述babddc2已依這項要求合併保存所有37檔修改。


### 修正面板資料夾按鈕無反應，整組改為居中 — 2026-11-13

使用者提供截圖，回報三個按鈕點擊無用，並要求居中。查本機AppKit NSSavePanel.h，directoryURL明確註明只能在configuration phase設定；前輪在已顯示的面板中賦值屬錯誤使用，不能再聲稱同面板能直接導航。修改GAAppDelegate：按鈕保存pendingOpenPanelDirectory後cancel，completion清除狀態並以指定directoryURL建立、顯示新面板；外部openFiles仍先清掉待切換目錄。重複Open置前、字體限制、多選及原生開檔完成路徑保留。可能看到面板重新顯示，未冒稱無閃動原位導航。

NSStackView的stackViewWithViews:原生把內容放在leading區域，前輪因此靠左。改用initWithFrame:建立stack，setViews:inGravity:NSStackViewGravityCenter，附件autoresizingMask設為NSViewWidthSizable；保留8pt按鈕間距及上下留白，刪除與原生預設相同的alignment設定。沒有變動語系或其他產品檔案。正常本機構建完成，未啟動App／操作GUI／跑探針，真實點擊與居中效果仍待使用者驗收。


### 資料夾按鈕改回左側並採系統內容邊距；確認面板公開自訂邊界 — 2026-11-13

使用者追問能否直接跳轉、要求按鈕恢復左側且留白如「隱藏選項」，另詢問能否取代該系統按鈕。核對本機NSSavePanel.h的directoryURL註記與Apple公開NSOpenPanel／NSSavePanel／NSView文件，目前未找到其他受支持的顯示中直接導航接口，也未找到替換系統Options按鈕的公開接口。向使用者修正前輪過於絕對的「只能重開」說法：目前找到的公開接口方案需要重開，不宣稱所有私有做法都不可能。沒有進行私有接口或模擬按鍵試驗。

GAAppDelegate的附件改為NSView容器，NSStackView回到leading排列，左緣約束至容器的layoutMarginsGuide.leadingAnchor，右緣不超出同一guide；容器寬度跟隨面板，保留上下8pt及按鈕間距8pt。這是讀AppKit標準內容留白，不是寫死截圖的20pt或查找系統內部按鈕；不能將尚未實機確認的跨系統精確對齊當成已驗證。資料夾切換仍為取消後在新面板顯示前指定目錄，沒有更改系統「隱藏選項」功能。本機正常構建完成，未啟動App或操作GUI，實際左緣與系統按鈕對齊待使用者觀察。

官方資料：https://developer.apple.com/documentation/appkit/nsopenpanel 、https://developer.apple.com/documentation/appkit/nssavepanel/directoryurl 、https://developer.apple.com/documentation/appkit/nsview/layoutmarginsguide 。NSView文件說明layoutMarginsGuide提供建議內容留白，成為contentView時由系統更新；非contentView則使用safe area外的系統標準間距。官方NSOpenPanel說明10.15起面板由獨立程序繪製。


### 按使用者偏好恢復上一版居中排列 — 2026-11-13

使用者要求「退回到上一版，我還是喜歡居中」。僅撤回9ccab7e新增的左側標準邊距容器與約束，GAAppDelegate恢復aacf560的NSStackViewGravityCenter排列、隨面板調整寬度及上下8pt／按鈕間距8pt。資料夾切換保留取消後以指定目錄重新顯示面板的修正，沒有回到無效的顯示中directoryURL賦值。採新增本地提交保存，不reset或改寫歷史；GLOSSARY同步目前居中狀態。


### 輸入框移出自訂Cell的試作與成本取捨 — 2026-11-14

使用者先要求只研究，後授權把側欄與工具列可移走的內距、焦點及Undo職責移至Field／編輯器，側欄Cell保留26+外觀用途，27由使用者驗收。使用者特別澄清改前要確保當前最新檔案已提交：核對起點version/1.7@70b5c4a，Git乾淨，來源與HEAD一致；保存162份來源／資源／構建腳本的SHA256和完整before副本，沒有建立空提交。

試作只改GAInput.m。工具列改用原生Cell，側欄保留同名Cell類別與隱藏搜尋／取消配置；失焦用段落縮排，編輯用textContainerInset，補上9pt減原生內距的差額。Field接管焦點與原生編輯入口，保留共用存儲與Undo保護。額外處理placeholder的普通／富文字格式、自然對齊、編輯前切換、原生setter重啟編輯及重入，否則會發生雙重內距、提示顏色改變或遞迴。這些是試作過程，未採用為產品架構。

本機14.8.7的側欄、工具列與方框補償壓力案例共78個階段狀態一致，包括失焦、驗證拒絕、合成滑鼠、側欄收放、Undo／Redo、字形指定屬性、程序化組字及編輯中更新placeholder。原有外觀與補償案例各144組布局，各有靜態與編輯中PNG，共576張前後零像素差異；首字、游標、折行及外框尺寸相同，內部編輯器frame可以不同。獨立可見視窗24項跨視窗、拒絕交接、空白點擊和非活動視窗Undo／Redo對照通過。完整字體查詢、真實GID替換、run修改與還原、分隔符和隔離剪貼簿亦做了對照。剪貼簿在沙箱內建立為nil，改前亦相同；經授權在沙箱外執行獨立探針後通過，未使用使用者的普通剪貼簿。初版快照用NSIndexSet.description帶入物件地址，已辨識為序列化問題並改探針輸出實際索引。26／27沒有新增實機驗證，程序化組字不算真實輸入法候選介面驗收。

使用者後補充：如果用自定Cell能省事，沒必要為了挪走而寫一堆程式碼。因此本輪未採用搬遷。試作把GAInput.m由601行增至726行，新增177行、刪除52行，淨增125行；代理先前把新增177行誤說成淨增，已向使用者更正。舊Cell本來只是薄原生幾何與編輯入口，主要狀態及Undo保護已在共用函式／編輯器，機械搬遷沒有使整體更簡潔。

| 項目 | 保留薄Cell | 遷移試作的額外代價 |
| --- | --- | --- |
| 內距 | 一套文字區域函式，保留原生垂直幾何 | 失焦縮排與編輯器內距兩套機制，要計算差額並同步刷新 |
| 空白提示 | 原生Cell處理顏色、排版與編輯切換 | 普通／富文字切換、自然對齊、getter相容與編輯前時序 |
| 焦點及Undo | edit／select／end薄入口呼叫共用保護 | 更多Field入口、setter重啟保護及過渡重入處理 |
| 文字屬性 | 保留原有屬性 | 區分顯示縮排與模型屬性，進入編輯後剝離顯示段落屬性 |
| 系統依賴 | 沿用原有Cell路徑 | 仍讀原生Cell幾何、設定原生提示，未完全避開Cell API，還增加跨版本組合驗證 |

這是本次具體原型的成本，不代表所有替代設計必然如此，也不證明自訂Cell不可替代。完整試作、patch及SHA256保存於diagnostics/input-field-cell-migration-2026-11-14/unadopted/。已只把本輪GAInput.m試改精確恢復HEAD，162份產品檔案SHA256全數回到改前；重新構建universal產物完成。當前HEAD仍70b5c4a，工作區乾淨，沒有新增來源提交或推送。交接文件以最後的簡潔性取捨為準。使用者最後要求整理移出Cell的成本對照，以上表為依據。


### 工具列原生字體與純29pt編輯器內距試驗 — 2026-11-14（已結束，更新請看下節）

使用者要求工具列不指定字體、採init(string:)、純textContainerInset左右29pt，藉此與本機原生9pt區分，並要求看看效果。改前確認version/1.7@70b5c4a乾淨，保存兩份來源與162份產品檔案雜湊於diagnostics/toolbar-inset-29-trial-2026-11-14/。工具列改用textFieldWithString:、移除font指定及Cell的titleRect／drawingRect覆寫；保留薄編輯過渡與Undo入口。原生編輯器配置會重設過早指定的inset，因此在既有GAInputFieldDidGainFocus中、原生配置完成後直接指定{29,0}，不減既有9pt，不加段落縮排；側欄恢復{0,0}。閒置鏡像依各自Field字體正規化，避免共用文字存儲中的側欄13.5pt覆蓋工具列原生字體。側欄原有13.5pt與Cell幾何保留。

本機14.8.7診斷確認工具列原生13pt、scrollable=YES、maximumNumberOfLines=0，編輯器inset與containerOrigin為{29,0}；Undo／Redo通過，側欄往返仍13.5pt／inset0。universal構建完成。本地提交6a11024，兩檔14行新增／12行刪除，Git乾淨，未推送。原生init(string:)的換行／捲動預設也隨初始化方式改變，不能宣稱此試驗所有行為與舊版等價。

其後透過CUA啟動dist/Glyph Atlas.app，開啟系統Helvetica.ttc並輸入HAMBURGEFONTS 0123456789，隱藏側欄。真實工具列截圖顯示：編輯中首字約x260px，點空白處結束編輯後首字約x202px，2倍截圖差58px即29pt。結束編輯回到原生靜態位置，證實本輪純textContainerInset只改編輯器；本機編輯中外框至文字約38pt，是原生約9pt加指定29pt，並非總共29pt。26／27未實機驗證。早期離屏toolbar PNG大部分內容未繪出，不作外觀判斷依據。


### 採用init(frame:)、工具列預設字體與Cell左右9pt — 2026-11-14

使用者確認仍要折行，並在完整比較後同意：保留init(frame:)、取消工具列明確字體指定、恢復薄Cell左右9pt，移除29pt試驗inset。改前核對version/1.7@6a11024乾淨，最新試驗已提交，無需空提交。GAInput.m精確恢復70b5c4a的焦點入口及工具列titleRect／drawingRect覆寫，沒有改動Undo或側欄Cell；GASidebarViewController工具列建立改回initWithFrame:NSZeroRect，保留前輪的工具列預設字體及各Field閒置鏡像字體正規化，側欄仍13.5pt。不新增與原生預設重複的wraps／scrollable設定。

前一輪本機獨立初始化對照已確認同樣後續配置下init(frame:)為wraps=YES、scrollable=NO、原生13pt，init(string:)為wraps=NO、scrollable=YES、原生13pt；尺寸最終由Auto Layout決定，字體不必依賴初始化方式選擇。代理此前把預設字體與初始化方式綁在一起推薦、又因發現預設差異反覆改建議，已向使用者更正：兩種方式皆可設定折行，本次選init(frame:)是符合既有折行需求且最少設定。此次僅按已確認方案修改與正常構建，不新增GUI或測試驗證；26／27仍由使用者驗收。

本輪universal構建完成；本地提交9b5041c（Restore wrapping toolbar input with native font and cell padding），兩檔8行新增／7行刪除，Git乾淨，未推送。


### 側邊欄也改用系統預設字體 — 2026-11-14

使用者明確要求側邊欄取消指定字體、其他保持不變。改前核對version/1.7@9b5041c乾淨，當前最新來源已提交。僅刪除GASidebarViewController.newInputFieldForToolbar中側邊欄的if (!toolbar)及系統13.5pt常規字體賦值，共兩行；側邊欄與工具列均不再明確指定font，閒置鏡像仍依各自field.font正規化。保留initWithFrame、Large／ExtraLarge、Cell左右9pt、隱藏搜尋／取消按鈕、焦點與Undo的既有實作。不新增測試或GUI操作，未宣稱各系統預設字級相同。

本輪universal構建完成，本地提交5e75e57（Use the native font for the sidebar input），一檔僅刪除兩行，Git乾淨，未推送。


### 全來源硬編碼字號／字重盤點與13.5pt來源 — 2026-11-14

使用者只要求查閱：為何兩處輸入指定13.5pt，並列出全程式碼所有硬編碼字號與字重。核對當前5e75e57，未修改程式碼。最早可追到4d77d58（2026-10-19，Add files via upload）的側邊欄搜尋框，已明確指定13.5pt Regular；9916de0（10-20）新增inputFont的同值備用分支；a1ee179（11-10）把既有值搬進共用newInputField，eed46c0（11-12的快照）已見共用側欄／工具列工廠繼續賦值。提交未交代13.5的選值理由；11-11控件預設值清理記錄只因不同於原生13而保留，不能當成必要性證據。當前建立時賦值已刪，但GASidebarViewController.m:437–438的inputFont仍在控件font為nil時返回13.5pt Regular；此前取消兩處建立時賦值不等於完全清除13.5，已向使用者指出。

盤點當前Sources所有AppKit／CoreText字體建立、font賦值、字號常數及字重trait：介面五個用途為Main:329/332/334/335字名13pt Medium（含同值備用）、GlyphViews:106 Unicode標籤10pt Regular等寬數字系統字、:362–363特性來源標籤10pt Regular同字體、:427–430字形名12.5pt（基本字形Bold、其他Regular）、Sidebar:437–438輸入備用13.5pt Regular。預覽另有Multi:9基準51pt，:1047乘使用者縮放；FontEngine:6整形基準200pt，:237建立字體；FontResource:116/120/137/193四處16pt用於資源／變軸／樣式處理。Multi:27的CoreText copy size=0沿用原字號，不是0pt顯示。除列出用途外未找到其他主程式字號／字重賦值；預覽與內部計算不強制套用UI的Regular／Medium／Bold。diagnostics內獨立探針及歷史快照不算主程式清單。


### 移除輸入字體13.5pt備用值，實測原生預設並追至Git起點 — 2026-11-14

使用者要求取消最後的13.5pt備用值、改用系統預設，其他項目只列預設供對照；追加要求追到側欄最早指定13.5的版本。改前5e75e57乾淨，僅把inputFont的systemFontOfSize:13.5 weight:Regular改為systemFontOfSize:NSFont.systemFontSize；仍先採當前控件自己的font，不改其他字體或行為。

本機14.8.7的獨立AppKit探針確認：labelWithString、initWithFrame的TextField、Large SearchField均13pt Regular；systemFontSize為13，generic system亦13pt Regular。monospacedDigitSystemFontOfSize:0 weight:Regular為13pt；titleBarFontOfSize:0為13pt AppleSystemUIFaceHeadline、weight trait為0，不應把它和普通label視覺字形混為一談。labelFontSize常數為10，但本項目labelWithString實際初始化font是13，不能用常數10冒充控件初始預設。比較其餘三種label與字名欄時以移除font覆寫、保留相同建立方式為準，都是13pt Regular；取消等寬數字字體也會失去指定的等寬數字。51pt預覽、200pt整形、16pt資源處理沒有直接對應的UI控件預設，不能一律套13。探針及結果保存diagnostics/native-font-defaults-2026-11-14/，沒有操作GUI或改其他產品程式。

追加追查已遍歷本地所有refs的13.5變更、舊路徑及Git根提交。唯一根為e620328（2026-10-19 Initial commit），tree僅README.md，沒有程式碼；其後4d77d58（2026-10-19 16:34:08 +08:00 Add files via upload）首次加入全部來源，GlyphAtlas/Sources/GASidebarViewController.m的viewDidLoad中已指定13.5pt Regular。因此4d77d58就是現有Git可追溯的最早側欄13.5版本，並非只是路徑搬遷造成的查找終點；無Git內的更早未指定版本可比，也沒有選13.5的理由記錄。9916de0於翌日新增同值inputFont備用值。

本輪universal構建完成；本地提交c765dee（Use the system default for the input font fallback），一檔1行新增／2行刪除，Git乾淨，未推送。


### 按系統字體角色統一介面字號，保留Medium — 2026-11-14

使用者明確指定：原13／12.5／13.5pt常規字體改用systemFontOfSize:0，粗體用boldSystemFontOfSize:0，Medium保留；原10pt均改labelFontOfSize:0，不要等寬。追加確認先前已改的輸入框也遵循同規則，因此側欄與工具列共用建立函式明確設field.font=systemFontOfSize:0，inputFont備用亦改同API，而非僅省略font或用NSFont.systemFontSize。字形名按isBase選boldSystemFontOfSize:0／systemFontOfSize:0；GABadgeFont與sourceLabel改labelFontOfSize:0。僅改GASidebarViewController.m與GAGlyphViews.m，字名字體原13pt Medium及描述符程式精確保持，預覽51／內部200／資源16不變。改前c765dee乾淨，未建空提交。只作正常universal構建與diff檢查，沒有新增測試或GUI驗收；跨系統字級、標籤寬度與外觀由使用者驗收。

本地提交09f767e（Use native font roles for input fields and glyph labels），兩檔7行新增／8行刪除，universal產物更新，Git乾淨，未推送。


### Medium只保留字重，字號亦改為0 — 2026-11-14

使用者澄清前輪「Medium保留」只指字重，字號同樣要系統預設0。前輪代理把整個13pt Medium設定保留，理解過寬。本輪改前09f767e乾淨，僅改GAMainWindowController字名字體三處字號：titleBarFontOfSize:13→0、fontWithDescriptor:size:13→0、備用systemFontOfSize:13 weight:Medium→size0。Medium trait及描述符建立方式保持；其他字體角色與預覽／內部計算尺寸不變。僅正常universal構建及diff檢查，不新增測試或GUI驗收。

本輪universal產物已更新，本地提交5a141e3（Use the default title font size while retaining medium weight），一檔3行新增／3行刪除，Git乾淨，未推送。


### Unicode碼標籤恢復等寬數字 — 2026-11-14

使用者要求Unicode碼標籤恢復之前的等寬數字。本輪僅把GAGlyphViews.m的GABadgeFont由labelFontOfSize:0改成monospacedDigitSystemFontOfSize:0 weight:Regular，字號沿用前輪的0，不恢復硬編碼10pt；特性來源標籤仍labelFontOfSize:0，其他字體與佈局設定不變。改前5a141e3乾淨，無需空提交；只正常universal構建及diff檢查，不新增測試或GUI驗收。

本輪universal產物已更新，本地提交d80130e（Restore monospaced digits in Unicode badges），一檔1行替換，Git乾淨，未推送。


### Unicode碼標籤字號採labelFontSize — 2026-11-14

使用者追加指定字號設為+labelFontSize。本輪僅把GABadgeFont的monospacedDigitSystemFontOfSize參數由0改為NSFont.labelFontSize，保留Regular與等寬數字，其他字體不變。改前d80130e乾淨；正常universal構建及diff檢查，不新增測試或GUI驗收。

本輪universal產物已更新，本地提交b3a47ca（Use the system label size for Unicode badges），一檔1行替換，Git乾淨，未推送。


### 介面預設值盤點及不限硬編碼的程式碼Review — 2026-11-14

使用者要求查出類似自行指定但可採系統預設的介面設定，只列出、不修改；途中追加完成後再做一輪不限硬編碼的代碼Review。本輪起點及終點均b3a47ca，Git來源完全未改，沒有構建／提交／GUI操作。

掃描App與Views的控件建立、屬性、常數、自繪及格式器，獨立AppKit物件探針於14.8.7核對原生預設。確認三處可疑重複：GAGlyphViews:359的初建labelColor（保留configureWithVariant動態暫時字色）、:143的initTextCell Left、Sidebar:239的rowSizeStyle Custom。Open panel stack spacing8也等於本機預設8，但已由使用者確認排列，單獨標為既有指定。其餘可選系統管理的外觀項目包括VF／字名間距、手配預覽深淺色、兩層alpha、固定文字／badge高度、table intercellSpacing、變軸面板間距與75pt值欄、舊toolbar min/max、窗口24pt級聯。徽章底色／圓角和紙面陰影屬自繪產品外觀，沒有可直接等價替換的原生badge預設；9pt內距、Large／ExtraLarge、隱藏搜尋鈕、泡泡border、安全區、Undo及格式限制各有既有用途，不當成缺陷。預設值及逐項候選存diagnostics/ui-native-defaults-audit-2026-11-14/。注意本機Table SourceList初建rowHeight24／intercellSpacing{17,0}，與header舊一般預設註解{3,2}不同，不能冒稱跨系統通用值。

後續Review檢查開檔與暫存複製、變軸生命週期、非同步generation與取消、輸入正規化／固定GID／Undo所有權、預覽投影，以及解析器bounds／例外處理重點路徑；29個實作翻譯單元Clang analyzer全數exit0、無診斷。沒有查到新的可確認功能缺陷；沒有將靜態檢查通過當作完整驗收。此前已重現且由使用者暫緩的斜體越界筆畫命中、刻意損壞cmap的越界GID仍是既有項目，本輪未重跑、不計新發現。真實輸入法及26／27、完整畸形字體fuzzing未覆蓋。分析命令、逐檔log與範圍記錄在diagnostics/source-review-2026-11-14/。


### 保留三處重複預設的明確設定 — 2026-11-14

使用者追問側欄其他位置是否也明確指定顏色，表示若有則保留字形名稱建立時labelColor以保持一致，另外兩項同樣處理。核對側欄輸入controlTextColor、來源secondaryLabelColor／選取alternateSelectedControlTextColor、Unicode標籤與展開提示狀態色、字形縮圖labelColor／選取色均有明確設定。三項均保留：初建名稱labelColor、rowSizeStyle Custom、Unicode展開文字Left。前者與周邊明確語義顏色寫法一致；Custom表明本表採用自訂／delegate動態行高；Left明確記錄英文Unicode名稱提示的對齊意圖。重複原生預設不等於必須刪除，使用者本輪接受保留，後續不再將三項當待清理任務。程式碼無修改，Git仍乾淨。


### 以同類設定一致性重新裁定兩處重複預設 — 2026-11-14

使用者要求後兩項也必須具備與初建labelColor相同的保留理由，否則刪除。核對全Sources：Unicode碼標籤在同一GAUnicodeBadgeLabel中明確alignment=Center，展開名稱明確alignment=Left，保留兩種呈現均明確指定alignment的一致寫法；rowSizeStyle全介面僅此一處，沒有同類設定一致性理由，因此刪除Sidebar初始化的rowSizeStyle=Custom。依SDK明定原生預設及前輪本機探針，仍採Custom／delegate動態行高。使用者最新指令取代上節三項全保留；labelColor與展開Left未改。改前b3a47ca乾淨，僅刪除一行，正常universal構建與diff檢查，不新增測試或GUI驗收。

本輪universal產物已更新，本地提交f601263（Use the native custom row size style default），一檔刪除一行，Git乾淨，未推送。


### 一併移除Unicode展開名稱明確靠左，交由使用者驗證 — 2026-11-14

使用者追加要求Unicode那項也一起刪、要自行驗證。本輪僅刪除GAGlyphViews.m的_expansionCell.alignment=Left；碼標籤本體的Center、展開名稱字體／顏色／裁切、初建名稱labelColor均保留。加上前輪f601263已刪rowSizeStyle設定，目前兩處均採原生預設。改前f601263乾淨；正常universal構建及diff檢查，依使用者要自行驗證，不跑額外測試或GUI操作。最新要求取代上節保留展開Left的決定。

本輪universal產物已更新，本地提交8d0bdb8（Use native alignment for Unicode name expansion），一檔刪除一行，Git乾淨，未推送。


### Unicode名稱展開提示依介面方向對齊及延伸 — 2026-11-14

使用者以RTL介面截圖釐清情境，確認採用最小方案、其他保持不變，必要時允許加回Left。改前8d0bdb8乾淨。只在GAUnicodeBadgeLabel.expansionFrameWithFrame新增原生userInterfaceLayoutDirection判斷、依方向設定Cell的Right／Left，將現有寬度計算存成width；RTL以原框NSMaxX減width設定origin.x，LTR沿用原origin。每次取得展開框都更新方向，避免Cell首次建立時的方向被永久快取。保留原生AppKit提示、自訂英文Unicode名稱、字體／狀態色／4pt文字留白、垂直幾何及裁切、碼標籤本體置中，未改列表或右側預覽方向。恢復的Left是方向分支的一部分，可在方向切回LTR時重設先前的Right。前輪原生Cell探針顯示僅設userInterfaceLayoutDirection不足以自動改英文對齊及擴框位置，故本輪明確處理兩者。

僅正常universal構建及diff檢查，不新增測試或GUI驗收；實際RTL展開效果交由使用者驗證。

本輪universal產物已更新，本地提交6ef9ff0（Follow interface direction for Unicode name expansion），一檔5行新增／1行刪除，Git乾淨，未推送。


### Unicode展開方案覆核與介面RTL掃描 — 2026-11-14

使用者要求檢查目前Unicode展開是否已是最優雅方案，並列出其他類似未處理RTL的位置，禁止改碼。本輪起訖6ef9ff0，來源Git無差異。檢查App／Views的alignment、方向、leading/trailing約束、物理x定位、自繪image、grid命中及快捷鍵。隔離探針直接編譯當前產品來源，建立不顯示的原生視窗／控件，對LTR／RTL配置呼叫現有布局方法，證據在diagnostics/rtl-interface-audit-2026-11-14/。首次探針缺NSView category方法宣告導致編譯失敗，僅修診斷宣告後成功，產品無修改。

當前展開實測LTR alignment Left／原左緣，RTL Right／原右緣保持。普通Cell.expansionFrame在SPACE可放入時返回NSZeroRect，ARABIC LETTER ALEF返回的原生框與既有留白／垂直尺寸不同，且僅明確Right未自動改其擴框x；不能直接以該API替代現方案並聲稱提示功能與外觀不變。在保留現有原生提示、名稱、內距與顯示條件的範圍，未找到比現有局部方向分支更簡單且等價的替代。

兩個可重現方向問題：Main.pinSidebarTitleAtFrame把實際NSMinX當成leading常數，400pt容器、100pt字名在LTR原x20固定後20，RTL原x280卻固定後20，將在收起側欄固定字名時偏移；UnicodeCodesView.layout用width-badgeWidth，在40pt組內0031(34pt)與1F600(40pt)均為x6／x0，不隨RTL反轉，因此鏡像到左側的碼標籤組仍對齊右緣。這是隔離原生布局重現，不冒稱26／27可見動畫驗收。

同類潛在處是26+ accessory輸入固定時以NSMinX／NSMaxX配leading／trailing，現有對稱留白可遮蔽，未本機驗證26 API。需產品決定、未判錯誤者：手繪字形網格仍由左往右遞增（探針首格兩方向皆x20.8）、變軸數值固定Right、自繪配色image三角色固定左起；Command左右覆寫固定邏輯起終點需另核對RTL內容鍵盤語意，這與介面鏡像不同且原為既定快捷鍵設計。未將字形本體、預覽書寫方向、對稱9pt內距或原生leading/trailing控件誤當應一律鏡像的缺陷。清單只供使用者決定，未實作修正／構建正式App／操作GUI／新增提交。


### 码牌采用原生约束、固定字名改用物理边界、RTL仅换弹性空白一侧 — 2026-11-14

使用者授权将Unicode码牌与收起侧栏固定字名按原生方式修改，上一轮修改若可等价简化也处理，并要求RTL工具栏输入右侧空白改到左侧。代理初拟把VF／输入整组镜像，使用者立即澄清输入框和VF位置不需要调整，已撤回VF重排；最终只改变弹性空白相对输入框的一侧。改前version/1.7@6ef9ff0干净，最新来源已提交；保存两份改前源码于diagnostics/rtl-native-layout-fix-2026-11-14/before/。

仅改GAGlyphViews.m及GAMainWindowController.m。码牌建立时设translatesAutoresizingMaskIntoConstraints=NO，原生trailingAnchor对齐，沿用badgeWidth、16pt高、3pt纵距并逐个topAnchor串接；删除整个手算frame的layout覆写。固定字名仅将leadingAnchor改为leftAnchor，保留实际NSMinX对应的坐标与其余高度／宽度限制。工具栏输入仍先插入，弹性空白在LTR索引1、RTL索引0，随后沿用原updateToolbarVariationItem；该VF方法最终与HEAD逐字相同。Unicode名称展开仍需返回自定义矩形，保留上一轮局部RTL分支，未改字体、颜色、裁切、留白及输入／Undo行为。其他RTL审阅候选未纳入。

本机14隔离AppKit对照直接编译改前／改后产品来源，以进程临时启动参数设置LTR／RTL，不写用户偏好、不显示GUI。比较码牌2种宽度、容器变宽、换单码、清空及恢复5阶段；LTR外框、行距、展开框完全相同，RTL的四／五位码牌均x0。固定字名RTL从改前x280→20修正为280→280。静态／可变项目加入／重复加入／移除／收放重建5状态，LTR工具栏顺序不变；RTL为[flex,input]或[VF,flex,input]，VF与输入先后保持，原生约束无冲突警告。6项比较均通过；26／27及可见动画效果未新增实机验收。证据与comparison.json同诊断目录。

诊断初版为模拟VF直接new了未初始化defaultDescriptor的GAFontResource，退出释放时在改前同样触发CFRelease(NULL)；最初误查为序列化问题，读取本机崩溃栈后确认是无效fixture。改为通过resourcesFromDescriptors创建真实有效资源后，四个改前／改后方向进程均exit0。该问题没有产品入口重现证据，不列为新增产品缺陷，未为诊断问题修改产品。最终仅正常universal构建及本轮针对性布局对照，没有重复宽泛测试或GUI操作。

本輪最終universal產物已更新；本地提交1fd66e9（Use native badge constraints and preserve RTL sidebar geometry），兩檔13行新增／13行刪除，Git乾淨，未推送。


### 撤回固定字名修改，RTL彈性空白移至VF之前 — 2026-11-14

使用者回報「收起側邊欄固定字名」修錯，明確要求不再修、退回上一版；另要求彈性空白加在VF左邊。改前1fd66e9乾淨。只改Main：pinSidebarTitleAtFrame的leftAnchor恢復為6ef9ff0的leadingAnchor，整個方法與該版精確一致；不以先前隔離測例否定使用者實機回報，不繼續修此處。保留Unicode碼牌原生約束及既有展開提示。

工具列LTR順序維持[VF,input,flex]；RTL改為[flex,VF,input]（有VF時），靜態字體仍[flex,input]。VF插入／移除索引依介面方向採0／1，是否已有VF也檢查同索引；26+原生固定間隔仍在VF之後，RTL為[flex,VF,space,input]。VF與輸入框先後不交換，彈性空白不再夾在兩者之間。正常universal構建及針對性項目順序核對，無GUI操作；實際收放外觀仍由使用者驗收。

本輪universal產物已更新，本地提交4dcdd91（Restore sidebar title pinning and place RTL flexible space before VF），一檔8行新增／6行刪除；LTR／RTL各5個工具列狀態通過、固定字名方法與6ef9ff0逐字相同。Git乾淨，未推送。
