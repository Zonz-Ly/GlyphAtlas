#import "GAFontEngine.h"
#import "FontLayout/GASubstitutionEngine.h"
#import "FontLayout/GAGlyphLabels.h"
#import <AppKit/AppKit.h>

const CGFloat GAFontShapingSize = 200.0;

#pragma mark - GAAllGlyphEntry

@implementation GAAllGlyphEntry
@end

@implementation GAGlyphResolution
@end

#pragma mark - GAGlyphVariant

static NSString *GAFeatureSourceTag(NSString *source) {
    NSRange separator = [source rangeOfString:@" "];
    return separator.location == NSNotFound ? source : [source substringToIndex:separator.location];
}

@implementation GAGlyphVariant

- (instancetype)init {
    self = [super init];
    if (self) {
        _glyphIDs = @[];
        _positions = @[];
        _featureSources = @[];
        _unicodeScalars = @[];
        _glyphName = @"";
    }
    return self;
}

- (void)addFeatureSources:(NSArray<NSString *> *)sources {
    NSMutableArray<NSString *> *merged = nil;
    for (NSString *source in sources) {
        if (source.length == 0) continue;
        NSString *tag = GAFeatureSourceTag(source);
        BOOL duplicate = NO;
        for (NSString *existing in merged ?: _featureSources) {
            if ([GAFeatureSourceTag(existing) isEqualToString:tag]) {
                duplicate = YES;
                break;
            }
        }
        if (duplicate) continue;
        if (!merged) merged = [_featureSources mutableCopy];
        [merged addObject:source];
    }
    if (merged) _featureSources = [merged copy];
}

- (id)copyWithZone:(NSZone *)zone {
    GAGlyphVariant *copy = [[GAGlyphVariant allocWithZone:zone] init];
    copy.fontBox = self.fontBox;
    copy.glyphIDs = self.glyphIDs;
    copy.positions = self.positions;
    copy->_featureSources = _featureSources;
    copy.base = self.base;
    copy.unicodeScalars = self.unicodeScalars;
    copy.glyphName = self.glyphName;
    copy.ligature = self.ligature;
    copy.temporary = self.temporary;
    copy.fromGlyphSeed = self.fromGlyphSeed;
    copy.sourceTextRange = self.sourceTextRange;
    return copy;
}

@end

static CGPoint GAGlyphPositionAtIndex(NSArray<NSValue *> *positions, NSUInteger index) {
    return index < positions.count ? positions[index].pointValue : CGPointZero;
}

void GADrawGlyphVariant(GAGlyphVariant *variant, CGContextRef context) {
    NSArray<NSNumber *> *glyphIDs = variant.glyphIDs;
    NSArray<NSValue *> *origins = variant.positions;
    NSUInteger count = glyphIDs.count;
    CGGlyph *glyphs = calloc(count, sizeof(CGGlyph));
    CGPoint *positions = calloc(count, sizeof(CGPoint));
    for (NSUInteger index = 0; index < count; index++) {
        glyphs[index] = glyphIDs[index].unsignedShortValue;
        positions[index] = GAGlyphPositionAtIndex(origins, index);
    }
    CTFontDrawGlyphs(variant.fontBox.font, glyphs, positions, count, context);
    free(glyphs);
    free(positions);
}

#pragma mark - GACharacterGroup

@implementation GACharacterGroup
@end

#pragma mark - GAFontBox

/// Page metrics used only by `pageForVariant:` in this file. Keeping the
/// initializer and typo values private avoids exposing page internals through
/// the public GAFontBox API.
@interface GAFontBox ()
/// OS/2 sTypo metrics in font units for this coordinate instance, adjusted by
/// MVAR hasc/hdsc. The descender keeps the font's sign; page code uses its
/// magnitude because some fonts store it as a positive depth.
@property (nonatomic, readonly) BOOL hasTypoMetrics;
@property (nonatomic, readonly) CGFloat typoAscender;
@property (nonatomic, readonly) CGFloat typoDescender;
- (instancetype)initWithFont:(CTFontRef)font
                typoAscender:(CGFloat)typoAscender
               typoDescender:(CGFloat)typoDescender
              hasTypoMetrics:(BOOL)hasTypoMetrics;
@end

@implementation GAFontBox {
    CTFontRef _font;
}

- (instancetype)initWithFont:(CTFontRef)font
                typoAscender:(CGFloat)typoAscender
               typoDescender:(CGFloat)typoDescender
              hasTypoMetrics:(BOOL)hasTypoMetrics {
    self = [super init];
    if (self) {
        _font = (CTFontRef)CFRetain(font);
        _typoAscender = typoAscender;
        _typoDescender = typoDescender;
        _hasTypoMetrics = hasTypoMetrics;
    }
    return self;
}

- (CTFontRef)font {
    return _font;
}

- (void)dealloc {
    if (_font) {
        CFRelease(_font);
    }
}

@end

#pragma mark - GAFontDocument

@implementation GAScanCandidate
@end

@implementation GARawScanResult
@end

static NSArray<NSNumber *> *GAScalarsForString(NSString *string) {
    NSMutableArray<NSNumber *> *scalars = [NSMutableArray array];
    for (NSUInteger index = 0; index < string.length; index++) {
        unichar unit = [string characterAtIndex:index];
        if (CFStringIsSurrogateHighCharacter(unit) &&
            index + 1 < string.length &&
            CFStringIsSurrogateLowCharacter([string characterAtIndex:index + 1])) {
            unichar low = [string characterAtIndex:index + 1];
            uint32_t scalar = CFStringGetLongCharacterForSurrogatePair(unit, low);
            [scalars addObject:@(scalar)];
            index++;
        } else {
            [scalars addObject:@(unit)];
        }
    }
    return scalars;
}

NSArray<GACharacterGroup *> *GAGroupsForScanResult(NSString *text, GARawScanResult *result) {
    NSMutableArray *groups = [NSMutableArray arrayWithCapacity:result.sourceRanges.count];
    for (NSValue *value in result.sourceRanges) {
        GACharacterGroup *group = [[GACharacterGroup alloc] init];
        group.textRange = value.rangeValue;
        group.text = [text substringWithRange:group.textRange];
        group.variants = @[];
        [groups addObject:group];
    }
    return groups;
}

/// The shared immutable substitution program owns table bytes, not this document.
@interface GAFontDocument ()
- (instancetype)initWithDescriptor:(CTFontDescriptorRef)descriptor URL:(NSURL *)url
                    sourceDocument:(GAFontDocument *)source NS_DESIGNATED_INITIALIZER;
@end

@implementation GAFontDocument {
    CTFontRef _font;
    GAFontBox *_fontBox;
    GASubstitutionEngine *_substitutionEngine;
    GAGlyphLabels *_glyphLabels;
    NSDictionary<NSNumber *, NSArray<NSNumber *> *> *_unicodeMap;
    NSArray<GAAllGlyphEntry *> *_allGlyphEntries;
}

- (instancetype)initWithDescriptor:(CTFontDescriptorRef)descriptor URL:(NSURL *)url {
    return [self initWithDescriptor:descriptor URL:url sourceDocument:nil];
}
- (instancetype)initWithDescriptor:(CTFontDescriptorRef)descriptor
                               URL:(NSURL *)url
                    sourceDocument:(GAFontDocument *)source {
    self = [super init];
    if (!self)
        return nil;
    CTFontDescriptorRef configured = CTFontDescriptorCreateCopyWithAttributes(
        descriptor,
        (__bridge CFDictionaryRef) @{(__bridge NSString *)kCTFontCascadeListAttribute : @[]});
    _font = CTFontCreateWithFontDescriptor(configured, GAFontShapingSize, NULL);
    if (configured)
        CFRelease(configured);
    if (_font == NULL)
        return nil;
    _fontURL = [url copy];
    _glyphLabels = source ? source->_glyphLabels : [GAGlyphLabels labelsForFont:_font];
    NSArray<NSString *> *languages = CFBridgingRelease(CTFontCopySupportedLanguages(_font));
    for (NSString *language in languages) {
        if ([NSLocale characterDirectionForLanguage:language] == NSLocaleLanguageDirectionRightToLeft) {
            _hasRightToLeftLanguages = YES;
            break;
        }
    }
    _fullName = CFBridgingRelease(CTFontCopyDisplayName(_font));
    if (!_fullName.length)
        _fullName = CFBridgingRelease(CTFontCopyPostScriptName(_font));
    if (!_fullName.length)
        _fullName = NSLocalizedString(@"Untitled Font", @"Font name fallback");
    NSDictionary *coordinates =
        CFBridgingRelease(CTFontDescriptorCopyAttribute(descriptor, kCTFontVariationAttribute));
    _substitutionEngine =
        [[GASubstitutionEngine alloc] initWithFont:_font
                                       coordinates:coordinates
                                           sharing:source ? source->_substitutionEngine : nil];
    _typesettingLanguageTags = [_substitutionEngine languageTags];
    CGFloat typoAscender = 0;
    CGFloat typoDescender = 0;
    BOOL hasTypoMetrics = [_substitutionEngine typoMetricsAscender:&typoAscender
                                                         descender:&typoDescender];
    _fontBox = [[GAFontBox alloc] initWithFont:_font
                                  typoAscender:typoAscender
                                 typoDescender:typoDescender
                                hasTypoMetrics:hasTypoMetrics];
    if (source) {
        @synchronized(source) {
            _unicodeMap = source->_unicodeMap;
            _allGlyphEntries = source->_allGlyphEntries;
        }
    }
    return self;
}
- (void)dealloc {
    if (_font)
        CFRelease(_font);
}
- (GAFontDocument *)documentWithDescriptor:(CTFontDescriptorRef)descriptor {
    return [[GAFontDocument alloc] initWithDescriptor:descriptor URL:_fontURL sourceDocument:self];
}
- (GARawScanResult *)rebindResult:(GARawScanResult *)result content:(NSString *)content
                       cancelled:(BOOL (^)(void))cancelled {
    NSMutableArray *candidates = [NSMutableArray arrayWithCapacity:result.candidates.count];
    for (GAScanCandidate *old in result.candidates) {
        if (cancelled && cancelled())
            return nil;
        GAScanCandidate *c = [[GAScanCandidate alloc] init];
        c.glyphIDs = old.glyphIDs;
        NSString *source = NSMaxRange(old.sourceRange) <= content.length
                               ? [content substringWithRange:old.sourceRange]
                               : content;
        c.positions = [_substitutionEngine positionsForGlyphIDs:c.glyphIDs content:source];
        c.sources = old.sources;
        c.base = old.base;
        c.ligature = old.ligature;
        c.fromGlyphSeed = old.fromGlyphSeed;
        c.sourceRange = old.sourceRange;
        c.targetGroupIndex = old.targetGroupIndex;
        [candidates addObject:c];
    }
    GARawScanResult *rebound = [[GARawScanResult alloc] init];
    rebound.incomplete = result.incomplete;
    rebound.candidates = candidates;
    rebound.sourceRanges = result.sourceRanges;
    return cancelled && cancelled() ? nil : rebound;
}
- (GAGlyphVariant *)rebindVariant:(GAGlyphVariant *)old content:(NSString *)content {
    GAGlyphVariant *v = [old copy];
    v.fontBox = _fontBox;
    v.positions = [_substitutionEngine positionsForGlyphIDs:v.glyphIDs content:content];
    return v;
}

- (NSDictionary<NSNumber *, NSArray<NSNumber *> *> *)unicodeMap {
    @synchronized(self) {
        if (_unicodeMap != nil) {
            return _unicodeMap;
        }

        NSMutableDictionary<NSNumber *, NSMutableArray<NSNumber *> *> *map =
            [NSMutableDictionary dictionary];
        CFCharacterSetRef characterSet = CTFontCopyCharacterSet(_font);
        if (characterSet != NULL) {
            for (uint32_t scalar = 0; scalar <= 0x10FFFF; scalar++) {
                // Native character sets report empty planes without scanning
                // every scalar; nominal glyph mapping remains CoreText-owned.
                if ((scalar & 0xFFFF) == 0 &&
                    !CFCharacterSetHasMemberInPlane(characterSet, scalar >> 16)) {
                    scalar += 0xFFFF;
                    continue;
                }
                if (scalar >= 0xD800 && scalar <= 0xDFFF) {
                    continue;
                }
                if (!CFCharacterSetIsLongCharacterMember(characterSet, scalar)) {
                    continue;
                }

                UniChar units[2];
                CFIndex length = CFStringGetSurrogatePairForLongCharacter(scalar, units) ? 2 : 1;

                CGGlyph glyphs[2] = {0, 0};
                if (!CTFontGetGlyphsForCharacters(_font, units, glyphs, length)) {
                    continue;
                }
                if (glyphs[0] == 0) {
                    continue;
                }
                NSNumber *key = @(glyphs[0]);
                NSMutableArray<NSNumber *> *scalars = map[key];
                if (scalars == nil) {
                    scalars = [NSMutableArray array];
                    map[key] = scalars;
                }
                [scalars addObject:@(scalar)];
            }
            CFRelease(characterSet);
        }

        NSMutableDictionary<NSNumber *, NSArray<NSNumber *> *> *frozen =
            [NSMutableDictionary dictionaryWithCapacity:map.count];
        [map enumerateKeysAndObjectsUsingBlock:^(NSNumber *key,
                                                 NSMutableArray<NSNumber *> *value,
                                                 BOOL *stop) {
            (void)stop;
            frozen[key] = [value copy];
        }];
        _unicodeMap = [frozen copy];
        return _unicodeMap;
    }
}

static NSString *GADisplayLabelForGlyph(GAGlyphLabels *labels, NSNumber *number) {
    return [labels labelForGlyph:number.unsignedIntegerValue]
        ?: [NSString stringWithFormat:@"GID %@", number];
}

- (NSArray<NSNumber *> *)unicodeScalarsForGlyphIDs:(NSArray<NSNumber *> *)glyphIDs {
    if (!glyphIDs.count) return @[];
    NSDictionary<NSNumber *, NSArray<NSNumber *> *> *map = self.unicodeMap;
    // unicodeMap already stores unique aliases in ascending scalar order.
    if (glyphIDs.count == 1) return map[glyphIDs.firstObject] ?: @[];
    NSMutableSet<NSNumber *> *scalars = [NSMutableSet set];
    for (NSNumber *glyph in glyphIDs)
        [scalars addObjectsFromArray:map[glyph] ?: @[]];
    return [scalars.allObjects sortedArrayUsingSelector:@selector(compare:)];
}

- (void)decorateVariant:(GAGlyphVariant *)variant {
    variant.unicodeScalars = [self unicodeScalarsForGlyphIDs:variant.glyphIDs];
    if (variant.glyphIDs.count == 0) {
        variant.glyphName = @"";
        return;
    }
    if (variant.glyphIDs.count == 1) {
        variant.glyphName = GADisplayLabelForGlyph(_glyphLabels, variant.glyphIDs.firstObject);
        return;
    }
    NSMutableArray<NSString *> *glyphNames = [NSMutableArray array];
    for (NSNumber *glyph in variant.glyphIDs)
        [glyphNames addObject:GADisplayLabelForGlyph(_glyphLabels, glyph)];
    variant.glyphName = [glyphNames componentsJoinedByString:@"/"];
}

#pragma mark - Font substitution discovery

- (GAGlyphResolution *)resolveGlyphIDs:(NSArray<NSNumber *> *)glyphIDs
                            textRange:(NSRange)range
                                 text:(NSString *)text
                           selections:(NSArray<GAGlyphSelectionRun *> *)selections
                               groups:(NSArray<GACharacterGroup *> *)groups
                             vertical:(BOOL)vertical
                 featureSettings:(NSArray<NSDictionary *> *)featureSettings
            baseWritingDirection:(NSInteger)direction
                     languageTag:(NSString *)languageTag
                            cancelled:(BOOL (^)(void))cancelled {
    NSMutableArray<GAGlyphVariant *> *parents = [NSMutableArray array];
    NSMutableArray *sequences = [NSMutableArray array];
    for (GACharacterGroup *group in groups) {
        if (!NSEqualRanges(group.textRange, range)) continue;
        for (GAGlyphVariant *variant in group.variants) {
            [parents addObject:variant];
            [sequences addObject:variant.glyphIDs];
        }
    }
    GASubstitutionOrigin *source = [_substitutionEngine originForGlyphIDs:glyphIDs
        sourceRange:range text:text selections:selections candidates:sequences
        vertical:vertical featureSettings:featureSettings
        baseWritingDirection:direction
        languageTag:languageTag
        cancelled:cancelled];
    if (!source || cancelled()) return nil;
    GAGlyphVariant *parent = parents[source.sourceIndex];
    GAGlyphVariant *variant = [[GAGlyphVariant alloc] init];
    variant.fontBox = _fontBox;
    variant.glyphIDs = glyphIDs;
    variant.positions = [_substitutionEngine positionsForGlyphIDs:glyphIDs
        content:[text substringWithRange:range]];
    [variant addFeatureSources:source.sources];
    variant.sourceTextRange = range;
    variant.ligature = parent.isLigature;
    variant.fromGlyphSeed = parent.fromGlyphSeed;
    variant.temporary = YES;
    [self decorateVariant:variant];
    GAGlyphResolution *result = [[GAGlyphResolution alloc] init];
    result.parent = parent;
    result.variant = variant;
    return result;
}

- (GARawScanResult *)rawScanContent:(NSString *)content
                         selections:(NSArray<GAGlyphSelectionRun *> *)selections
                          cancelled:(BOOL (^)(void))cancelled {
    BOOL incomplete = NO;
    NSArray<GASubstitutionMatch *> *matches = [_substitutionEngine discoverText:content
                                                                     selections:selections
                                                                     incomplete:&incomplete
                                                                      cancelled:cancelled];
    if (!matches)
        return nil;
    NSMutableArray<NSValue *> *ranges = [NSMutableArray array];
    for (GASubstitutionMatch *match in matches)
        if (match.base) [ranges addObject:[NSValue valueWithRange:match.sourceRange]];
    NSComparator order = ^NSComparisonResult(NSValue *a, NSValue *b) {
        return a.rangeValue.location < b.rangeValue.location ? NSOrderedAscending
             : a.rangeValue.location > b.rangeValue.location ? NSOrderedDescending : NSOrderedSame;
    };
    NSArray<NSValue *> *roots = [ranges copy];
    __block NSUInteger root = 0;
    [content enumerateSubstringsInRange:NSMakeRange(0, content.length)
                                options:NSStringEnumerationByComposedCharacterSequences |
                                        NSStringEnumerationSubstringNotRequired
                             usingBlock:^(NSString *substring, NSRange range,
                                          NSRange enclosingRange, BOOL *stop) {
        (void)substring;
        (void)enclosingRange;
        (void)stop;
        while (root < roots.count && NSMaxRange(roots[root].rangeValue) <= range.location)
            root++;
        if (root == roots.count || roots[root].rangeValue.location >= NSMaxRange(range))
            [ranges addObject:[NSValue valueWithRange:range]];
    }];
    [ranges sortUsingComparator:order];
    GARawScanResult *result = [[GARawScanResult alloc] init];
    result.incomplete = incomplete;
    result.sourceRanges = ranges;
    if (cancelled && cancelled())
        return nil;
    NSArray<NSValue *> *sourceRanges = result.sourceRanges;
    NSMutableArray *candidates = [NSMutableArray array];
    for (GASubstitutionMatch *match in matches) {
        if (cancelled && cancelled())
            return nil;
        if (!match.sourceRange.length || NSMaxRange(match.sourceRange) > content.length)
            continue;
        NSUInteger lo = 0, hi = sourceRanges.count;
        while (lo < hi) {
            NSUInteger mid = (lo + hi) / 2;
            if (NSMaxRange(sourceRanges[mid].rangeValue) <= match.sourceRange.location)
                lo = mid + 1;
            else
                hi = mid;
        }
        NSUInteger first = lo;
        hi = sourceRanges.count;
        while (lo < hi) {
            NSUInteger mid = (lo + hi) / 2;
            if (sourceRanges[mid].rangeValue.location < NSMaxRange(match.sourceRange))
                lo = mid + 1;
            else
                hi = mid;
        }
        NSUInteger last = lo ? lo - 1 : NSNotFound;
        if (first >= sourceRanges.count)
            continue;
        GAScanCandidate *c = [[GAScanCandidate alloc] init];
        c.glyphIDs = match.glyphIDs;
        c.positions = [_substitutionEngine
            positionsForGlyphIDs:c.glyphIDs
                         content:[content substringWithRange:match.sourceRange]];
        c.sources = match.sources;
        c.sourceRange = match.sourceRange;
        c.fromGlyphSeed = selections.count > 0;
        c.targetGroupIndex = last;
        c.ligature = first != last;
        c.base = match.base && first == last;
        [candidates addObject:c];
    }
    result.candidates = candidates;
    return cancelled && cancelled() ? nil : result;
}

static NSNumber *GAVariantBucket(NSArray<NSNumber *> *glyphs, BOOL ligature, NSRange range) {
    NSUInteger hash = glyphs.count;
    for (NSNumber *glyph in glyphs)
        hash = (hash * 31) ^ glyph.hash;
    hash = (hash * 31) ^ ligature;
    if (ligature) {
        hash = (hash * 31) ^ range.location;
        hash = (hash * 31) ^ range.length;
    }
    return @(hash);
}

static void GAPublishVariantBuilders(NSMapTable *builders) {
    for (GACharacterGroup *group in builders.keyEnumerator)
        group.variants = [builders objectForKey:group];
}

- (BOOL)applyRawResult:(GARawScanResult *)result
                groups:(NSArray<GACharacterGroup *> *)groups
             cancelled:(BOOL (^)(void))cancelled {
    NSMapTable<GACharacterGroup *, NSMutableArray<GAGlyphVariant *> *> *builders;
    NSMapTable<GACharacterGroup *, NSMutableDictionary *> *indices;
    for (GAScanCandidate *candidate in result.candidates) {
        if (cancelled && cancelled()) {
            GAPublishVariantBuilders(builders);
            return NO;
        }
        NSUInteger target = candidate.targetGroupIndex;
        if (target >= groups.count) {
            continue;
        }
        GACharacterGroup *group = groups[target];
        // Small groups are cheaper to scan directly. Index only groups that
        // would otherwise keep copying and comparing a growing candidate list.
        BOOL indexed = group.variants.count >= 32;
        NSMutableArray<GAGlyphVariant *> *variants = indexed
            ? [builders objectForKey:group] : nil;
        NSMutableDictionary<NSNumber *, NSMutableArray<GAGlyphVariant *> *> *buckets =
            [indices objectForKey:group];
        if (!variants) {
            variants = [group.variants mutableCopy];
            if (indexed) {
                if (!builders) {
                    builders = [NSMapTable strongToStrongObjectsMapTable];
                    indices = [NSMapTable strongToStrongObjectsMapTable];
                }
                buckets = [NSMutableDictionary dictionary];
                for (GAGlyphVariant *variant in variants) {
                    NSNumber *key = GAVariantBucket(variant.glyphIDs, variant.isLigature,
                                                   variant.sourceTextRange);
                    if (!buckets[key]) buckets[key] = [NSMutableArray array];
                    [buckets[key] addObject:variant];
                }
                [builders setObject:variants forKey:group];
                [indices setObject:buckets forKey:group];
            }
        }
        NSNumber *key = indexed ? GAVariantBucket(candidate.glyphIDs, candidate.isLigature,
                                                 candidate.sourceRange) : nil;
        GAGlyphVariant *existing;
        // A bucket narrows the search; full identity still decides equality.
        for (GAGlyphVariant *variant in indexed ? buckets[key] : variants) {
            if (![variant.glyphIDs isEqualToArray:candidate.glyphIDs] ||
                variant.isLigature != candidate.isLigature)
                continue;
            if (candidate.isLigature && !NSEqualRanges(variant.sourceTextRange, candidate.sourceRange))
                continue;
            existing = variant;
            break;
        }
        if (existing != nil) {
            if (candidate.fromGlyphSeed) {
                existing.fromGlyphSeed = YES;
                existing.sourceTextRange = candidate.sourceRange;
            }
            [existing addFeatureSources:candidate.sources];
            continue;
        }
        GAGlyphVariant *variant = [[GAGlyphVariant alloc] init];
        variant.fontBox = _fontBox;
        variant.glyphIDs = candidate.glyphIDs;
        variant.positions = candidate.positions;
        [variant addFeatureSources:candidate.sources];
        variant.base = candidate.isBase;
        variant.fromGlyphSeed = candidate.fromGlyphSeed;
        variant.sourceTextRange = candidate.sourceRange;
        if (candidate.ligature) {
            variant.ligature = YES;
        }
        [self decorateVariant:variant];
        if (candidate.isBase && variant.unicodeScalars.count == 0) {
            variant.unicodeScalars = GAScalarsForString(group.text);
        }
        [variants addObject:variant];
        if (indexed) {
            if (!buckets[key]) buckets[key] = [NSMutableArray array];
            [buckets[key] addObject:variant];
        } else {
            group.variants = variants;
        }
    }
    GAPublishVariantBuilders(builders);
    return !cancelled || !cancelled();
}

- (NSArray<NSString *> *)glyphFeatureTags {
    return [_substitutionEngine glyphFeatureTags];
}

- (NSIndexSet *)glyphOutputsForFeatureTag:(NSString *)tag cancelled:(BOOL (^)(void))cancelled {
    return [_substitutionEngine glyphOutputsForFeatureTag:tag cancelled:cancelled];
}

- (NSArray<GAAllGlyphEntry *> *)allGlyphEntries {
    if (_allGlyphEntries != nil) {
        return _allGlyphEntries;
    }
    NSDictionary<NSNumber *, NSArray<NSNumber *> *> *map = [self unicodeMap];
    CFIndex glyphCount = CTFontGetGlyphCount(_font);
    NSMutableArray<GAAllGlyphEntry *> *entries =
        [NSMutableArray arrayWithCapacity:(NSUInteger)MAX(0, glyphCount)];
    for (CFIndex glyph = 0; glyph < glyphCount; glyph++) {
        GAAllGlyphEntry *entry = [[GAAllGlyphEntry alloc] init];
        entry.glyphID = @(glyph);
        entry.unicodeScalars = map[@(glyph)] ?: @[];
        [entries addObject:entry];
    }
    _allGlyphEntries = [entries copy];
    return _allGlyphEntries;
}

- (NSNumber *)verticalSubstituteForGlyph:(CGGlyph)glyph {
    return [_substitutionEngine verticalGlyph:glyph];
}
- (NSArray<GAGlyphVariant *> *)variantsForGlyphIDs:(NSArray<NSNumber *> *)glyphIDs
                                        cancelled:(BOOL (^)(void))cancelled {
    if (!glyphIDs.count)
        return @[];
    NSArray<GASubstitutionMatch *> *matches = [_substitutionEngine discoverGlyphIDs:glyphIDs
                                                                             cancelled:cancelled];
    if (!matches)
        return nil;
    NSMutableArray *variants = [NSMutableArray array];
    for (GASubstitutionMatch *match in matches) {
        if (cancelled && cancelled())
            return nil;
        GAGlyphVariant *v = [[GAGlyphVariant alloc] init];
        v.fontBox = _fontBox;
        v.glyphIDs = match.glyphIDs;
        v.positions = [_substitutionEngine positionsForGlyphIDs:v.glyphIDs content:@""];
        [v addFeatureSources:match.sources];
        v.base = match.base;
        [self decorateVariant:v];
        [variants addObject:v];
    }
    return [variants copy];
}

#pragma mark - Drawing

/// Raw ink bounds in shaping points. Zero-ink glyphs produce CGRectZero.
static CGRect GAInkBounds(CTFontRef font, const CGGlyph *glyphs, NSUInteger count,
                          NSArray<NSValue *> *positions) {
    CGRect *rects = calloc(count, sizeof(CGRect));
    CTFontGetBoundingRectsForGlyphs(font, kCTFontOrientationHorizontal, glyphs,
                                    rects, (CFIndex)count);

    CGRect unionRect = CGRectNull;
    for (NSUInteger index = 0; index < count; index++) {
        CGRect rect = rects[index];
        if (CGRectIsNull(rect) || CGRectIsEmpty(rect)) {
            continue;
        }
        CGPoint position = GAGlyphPositionAtIndex(positions, index);
        rect.origin.x += position.x;
        rect.origin.y += position.y;
        unionRect = CGRectIsNull(unionRect) ? rect : CGRectUnion(unionRect, rect);
    }
    free(rects);

    if (CGRectIsNull(unionRect) || CGRectIsEmpty(unionRect)) {
        return CGRectZero;
    }
    return unionRect;
}

/// Sum of the horizontal advances in font units. CGFont advances are raw font
/// units and do not include the trak table's size-dependent tracking.
static CGFloat GAAdvanceWidthInFontUnits(CTFontRef font, const CGGlyph *glyphs, NSUInteger count) {
    if (font == NULL) {
        return 0;
    }
    int *advances = calloc(count, sizeof(int));
    CGFontRef cgFont = CTFontCopyGraphicsFont(font, NULL);
    if (cgFont != NULL) {
        CGFontGetGlyphAdvances(cgFont, glyphs, count, advances);
        CFRelease(cgFont);
    }
    CGFloat width = 0;
    for (NSUInteger index = 0; index < count; index++) {
        width += advances[index];
    }
    free(advances);
    return width;
}

static BOOL GAHasVerticalMetrics(CTFontRef font) {
    NSData *vmtx = CFBridgingRelease(CTFontCopyTable(font, kCTFontTableVmtx, 0));
    NSData *vhea = CFBridgingRelease(CTFontCopyTable(font, kCTFontTableVhea, 0));
    return vmtx.length >= 4 && vhea.length >= 36;
}

/// Sum of the vertical advances in shaping points. Requires vmtx/vhea.
static CGFloat GAVerticalAdvance(CTFontRef font, const CGGlyph *glyphs, NSUInteger count) {
    CGSize *advances = calloc(count, sizeof(CGSize));
    CTFontGetAdvancesForGlyphs(font, kCTFontOrientationVertical, glyphs, advances, (CFIndex)count);
    CGFloat height = 0;
    for (NSUInteger index = 0; index < count; index++) {
        // CoreText puts the vertical advance in CGSize.width.
        height += MAX(advances[index].width, advances[index].height);
    }
    free(advances);
    return height;
}

+ (GAGlyphPage)pageForVariant:(GAGlyphVariant *)variant
           usesVerticalMetrics:(BOOL)usesVerticalMetrics {
    NSArray<NSNumber *> *glyphIDs = variant.glyphIDs;
    NSUInteger count = glyphIDs.count;
    if (count == 0) {
        return (GAGlyphPage){0};
    }
    CGGlyph *glyphs = calloc(count, sizeof(CGGlyph));
    for (NSUInteger index = 0; index < count; index++)
        glyphs[index] = glyphIDs[index].unsignedShortValue;
    CTFontRef font = variant.fontBox.font;
    CGFloat unitsPerEm = CTFontGetUnitsPerEm(font);
    CGFloat shapeToUnits = unitsPerEm / GAFontShapingSize;

    // The raw bounds are in shaping points; the page is in font units.
    CGRect ink = GAInkBounds(font, glyphs, count, variant.positions);
    ink = CGRectMake(CGRectGetMinX(ink) * shapeToUnits,
                     CGRectGetMinY(ink) * shapeToUnits,
                     CGRectGetWidth(ink) * shapeToUnits,
                     CGRectGetHeight(ink) * shapeToUnits);
    BOOL hasInk = !CGRectIsEmpty(ink);

    BOOL hasVertical = usesVerticalMetrics && GAHasVerticalMetrics(font);
    CGFloat originUnits = 0;
    if (hasVertical) {
        // CoreText exposes the per-glyph vertical origin (VORG for CFF, a
        // font-wide origin for TrueType). It is stable across variation axes
        // when the font defines no origin variation.
        CGSize translation = CGSizeZero;
        CTFontGetVerticalTranslationsForGlyphs(font, glyphs, &translation, 1);
        originUnits = -translation.height * shapeToUnits;
    }
    CGFloat width = GAAdvanceWidthInFontUnits(font, glyphs, count);
    CGFloat height;
    BOOL hasTypoMetrics = variant.fontBox.hasTypoMetrics;
    CGFloat typoDescender = fabs(variant.fontBox.typoDescender);
    if (hasVertical) {
        height = GAVerticalAdvance(font, glyphs, count) * shapeToUnits;
    } else {
        // The width-only page: advance width × typographic height. It must not
        // read vmtx, so the grid and sidebar do not pay for vertical metrics.
        // OS/2 typo metrics win when present; the descender magnitude is used
        // because some fonts store it as a positive depth.
        if (hasTypoMetrics) {
            height = variant.fontBox.typoAscender + typoDescender;
        } else {
            height = (CTFontGetAscent(font) + CTFontGetDescent(font)) * shapeToUnits;
        }
    }
    free(glyphs);
    if (width <= 0) {
        width = hasInk ? CGRectGetWidth(ink) : unitsPerEm * 0.01;
    }
    if (height <= 0) {
        height = hasInk ? CGRectGetHeight(ink) : unitsPerEm;
    }

    CGFloat baseline;
    if (hasVertical) {
        baseline = height - originUnits;
    } else if (hasTypoMetrics) {
        baseline = typoDescender;
    } else {
        baseline = CTFontGetDescent(font) * shapeToUnits;
    }

    return (GAGlyphPage){CGSizeMake(width, height), baseline, ink};
}

@end
