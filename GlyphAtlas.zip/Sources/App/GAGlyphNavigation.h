#import <Foundation/Foundation.h>
#import "Views/GAAppKit.h"

NS_ASSUME_NONNULL_BEGIN
@class GAGlyphIdentity;
@class GAInputSourceAnchor;

@interface GAGlyphNavigationStep : NSObject <NSCopying>
@property (nonatomic) GAViewMode mode;
@property (nonatomic, copy, nullable) NSString *filterTag;
@property (nonatomic) BOOL filterChange;
@property (nonatomic, copy, nullable) NSArray<NSNumber *> *glyphIDs;
@property (nonatomic, copy, nullable) GAGlyphIdentity *glyphIdentity;
@property (nonatomic) NSRange range;
@property (nonatomic, copy, nullable) NSString *sourceText;
@property (nonatomic, copy, nullable) NSString *glyphLabel;
@property (nonatomic, strong, nullable) NSMutableDictionary<NSString *, NSValue *> *sourceRecoveryRanges;
/// Live input coordinates while the displayed snapshot still has older text.
@property (nonatomic, strong, nullable) GAInputSourceAnchor *pendingSourceAnchor;
@property (nonatomic, readonly) BOOL allowsViewOnly;
- (BOOL)matchesLocation:(nullable GAGlyphNavigationStep *)other;
- (BOOL)matchesSourceInText:(nullable NSString *)text;
- (BOOL)matchesSourceAtRange:(NSRange)range inText:(nullable NSString *)text;
- (void)rememberSourceRange:(NSRange)range inText:(NSString *)text;
@end

/// Positions on either side of the current view, including unavailable sources.
@interface GAGlyphNavigationHistory : NSObject
@property (nonatomic, strong, readonly) NSArray<GAGlyphNavigationStep *> *backSteps;
@property (nonatomic, strong, readonly) NSArray<GAGlyphNavigationStep *> *forwardSteps;
@property (nonatomic, strong, readonly, nullable) GAGlyphNavigationStep *restoredStep;
/// Start a new navigation, optionally omitting the departing location.
- (void)recordStep:(nullable GAGlyphNavigationStep *)step;
/// Copy the restored departure, preserving a filter event not paired with a single-glyph visit.
- (nullable GAGlyphNavigationStep *)restoredOrigin;
/// Complete a view change without leaving the same destination in Back.
- (void)finishAtStep:(GAGlyphNavigationStep *)step;
/// A returned grid position can be updated beside a matching glyph view.
/// An unlocated ordinary grid is superseded by the selected glyph's grid origin.
- (BOOL)canReplaceGridOrigin:(GAGlyphNavigationStep *)origin;
- (BOOL)moveToStep:(GAGlyphNavigationStep *)step leavingStep:(GAGlyphNavigationStep *)current;
- (void)clear;
@end

NS_ASSUME_NONNULL_END
