#include "GAGlyphBuffer.h"
namespace ga::layout {
LigatureStructures::value_type multipleSubstitutionStructure(
    LigatureStructures::value_type structure, int component, size_t outputCount) {
    if (outputCount == 1) return structure;
    // A decomposed base contributes one component per output. An attached
    // mark keeps its external association, not its own old ligature structure.
    if (outputCount > 1 && component < 0 && structure.first) return {1, structure.second};
    return {};
}
LigatureStructures canonicalLigatureStructures(const std::vector<int> &components,
    const std::vector<uint64_t> &owners, LigatureStructures structures) {
    if (std::none_of(structures.begin(), structures.end(), [](auto s) { return s.first != 0; })) return {};
    std::map<uint64_t, uint64_t> labels;
    // Use the existing mark-first labels, including the implicit single owner.
    for (size_t i = 0; i < components.size(); ++i) if (components[i] >= 0) {
        uint64_t owner = owners.empty() ? 1 : owners.at(i);
        if (owner) labels.try_emplace(owner, labels.size() + 1);
    }
    for (auto &structure : structures) {
        if (!structure.first) structure.second = 0;
        else if (structure.second)
            structure.second = labels.try_emplace(structure.second, labels.size() + 1).first->second;
    }
    return structures;
}
std::vector<Cluster> clusters(const Buffer &buffer) {
    std::vector<Span> spans;
    for (const auto &item : buffer)
        spans.push_back(item.source);
    std::sort(spans.begin(), spans.end());
    std::vector<Cluster> result;
    for (Span span : spans) {
        if (!result.empty() && span.start < result.back().source.end)
            result.back().source = unite(result.back().source, span);
        else
            result.push_back({span, {}});
    }
    // Overlapping sources form one atomic replacement. In particular, when
    // only the final GID of a multi-GID seed ligates with its neighbor, the
    // seed's surviving prefix must accompany the new ligature in the result.
    for (const auto &item : buffer) {
        auto found = std::upper_bound(
            result.begin(), result.end(), item.source.start,
            [](uint32_t start, const Cluster &cluster) { return start < cluster.source.start; });
        if (item.glyph != 0xffff) {
            auto &cluster = *(found - 1);
            if (!cluster.ligatureStructures.empty() || !item.components.empty()) {
                cluster.ligatureStructures.resize(cluster.glyphs.size());
                cluster.ligatureStructures.emplace_back(item.components.size(),
                    item.components.empty() ? 0 : item.ligatureIdentity);
            }
            if (!cluster.markComponents.empty() || item.component >= 0) {
                cluster.markComponents.resize(cluster.glyphs.size(), -1);
                cluster.markComponents.push_back(item.component);
                cluster.markLigatures.resize(cluster.glyphs.size(), 0);
                cluster.markLigatures.push_back(item.ligatureIdentity);
            }
            cluster.glyphs.push_back(item.glyph);
        }
    }
    return result;
}
std::vector<uint64_t> Change::inputKey() const {
    std::vector<uint64_t> key;
    for (const auto &input : inputs) {
        key.insert(key.end(), {input.source.start, input.source.end, input.glyphs.size()});
        key.insert(key.end(), input.glyphs.begin(), input.glyphs.end());
        if (!input.ligatureStructures.empty()) {
            key.push_back(UINT64_MAX - 1);
            for (auto structure : canonicalLigatureStructures(input.markComponents, input.markLigatures, input.ligatureStructures))
                key.insert(key.end(), {structure.first, structure.second});
        }
    }
    if (!surroundingMarks.empty()) {
        key.push_back(UINT64_MAX);
        for (const auto &mark : surroundingMarks)
            key.insert(key.end(), {mark.source.start, mark.source.end, mark.glyph,
                                   uint64_t(mark.component), mark.ligatureIdentity});
    }
    return key;
}
void Trace::changed(const Buffer &before, const Buffer &after, const std::string &feature) {
    auto [firstOld, firstNew] =
        std::mismatch(before.begin(), before.end(), after.begin(), after.end(), sameGlyphAndSource);
    bool sameBuffer = firstOld == before.end() && firstNew == after.end();
    if (sameBuffer && std::none_of(before.begin(), before.end(),
                                  [](const Item &item) { return item.source.empty(); }))
        return;
    Buffer oldWindow, newWindow;
    std::vector<MarkAssociation> associationChanges;
    auto noteAssociation = [&](const Item &old, const Item &next) {
        if (old.component != next.component || old.ligatureIdentity != next.ligatureIdentity)
            associationChanges.push_back({next.source, next.glyph, next.component, next.ligatureIdentity});
    };
    auto prefix = after.begin();
    for (auto old = before.begin(); old != firstOld; ++old, ++prefix) noteAssociation(*old,*prefix);
    auto oldTail = before.rbegin(), newTail = after.rbegin();
    while (oldTail != std::make_reverse_iterator(firstOld) &&
           newTail != std::make_reverse_iterator(firstNew) && sameGlyphAndSource(*oldTail,*newTail)) {
        noteAssociation(*oldTail, *newTail);
        ++oldTail;
        ++newTail;
    }
    if (!provenance && !sameBuffer) {
        auto [lastOldReversed, lastNewReversed] = std::mismatch(
            before.rbegin(), std::make_reverse_iterator(firstOld),
            after.rbegin(), std::make_reverse_iterator(firstNew), sameGlyphAndSource);
        auto lastOld = lastOldReversed.base(), lastNew = lastNewReversed.base();
        Span scope{UINT32_MAX, 0};
        bool positive = true;
        auto include = [&](const Item &item) {
            scope = unite(scope, item.source);
            positive &= !item.source.empty();
        };
        std::for_each(firstOld, lastOld, include);
        std::for_each(firstNew, lastNew, include);
        auto intersects = [&](const Item &item) {
            if (item.source.empty()) return true;
            return item.source.intersects(scope);
        };
        // Include unchanged glyphs in an affected atomic source cluster.
        for (;;) {
            Span prior = scope;
            while (firstOld != before.begin() && intersects(firstOld[-1])) {
                --firstNew;
                include(*--firstOld);
            }
            while (lastOld != before.end() && intersects(*lastOld)) {
                ++lastNew;
                include(*lastOld++);
            }
            if (prior == scope) break;
        }
        if (positive && std::none_of(before.begin(), firstOld, intersects) &&
            std::none_of(lastOld, before.end(), intersects)) {
            oldWindow.assign(firstOld, lastOld);
            newWindow.assign(firstNew, lastNew);
        }
    }
    bool window = !oldWindow.empty() || !newWindow.empty();
    auto old = clusters(window ? oldWindow : before), next = clusters(window ? newWindow : after);
    size_t firstChange = changes.size();
    auto append = [&](Span source, const std::vector<Glyph> &glyphs,
                      const std::vector<int> &components = std::vector<int>{},
                      const std::vector<uint64_t> &ligatures = std::vector<uint64_t>{},
                      const LigatureStructures &structures = {}) {
        Change change{source, glyphs, feature, {}};
        change.markComponents = components;
        change.markLigatures = ligatures;
        change.ligatureStructures = structures;
        for (const auto &mark : associationChanges)
            if (!mark.source.intersects(source))
                change.surroundingMarks.push_back(mark);
        auto first = std::lower_bound(old.begin(), old.end(), source.start,
            [](const Cluster &input, uint32_t start) { return input.source.end <= start; });
        for (auto input = first; input != old.end() && input->source.start < source.end; ++input)
            change.inputs.push_back(*input);
        changes.push_back(std::move(change));
    };
    // clusters preserves Span ordering; lower_bound also keeps the first equal span.
    for (const auto &cluster : next) {
        auto found = std::lower_bound(
            old.begin(), old.end(), cluster.source,
            [](const Cluster &item, Span source) { return item.source < source; });
        if (found == old.end() || !(found->source == cluster.source) || found->glyphs != cluster.glyphs)
            append(cluster.source, cluster.glyphs, cluster.markComponents, cluster.markLigatures,
                   cluster.ligatureStructures);
    }
    // Prefix maxima allow each old interval to be tested independently, even
    // when source scopes overlap or nest after a rearrangement or insertion.
    std::vector<uint32_t> ends;
    uint32_t maximum = 0;
    for (const auto &cluster : next) {
        maximum = std::max(maximum, cluster.source.end);
        ends.push_back(maximum);
    }
    for (const auto &cluster : old) {
        auto limit = std::lower_bound(
            next.begin(), next.end(), cluster.source.end,
            [](const Cluster &item, uint32_t end) { return item.source.start < end; });
        size_t count = size_t(limit - next.begin());
        if (!count || ends[count - 1] <= cluster.source.start)
            append(cluster.source, {});
    }
    if (provenance && changes.size() != firstChange)
        steps.push_back({before, after, feature});
}
GDEF::GDEF(View table) {
    if (!table)
        return;
    table.require(0, 12);
    glyphClasses = ClassDef(table.offset16(4));
    markAttachmentClasses = ClassDef(table.offset16(10));
    auto version = table.u32(0);
    if (version >= 0x10002) {
        View sets = table.offset16(12);
        if (sets) {
            unsigned count = sets.u16(2);
            sets.array(4, count, 4);
            for (unsigned i = 0; i < count; i++)
                markSets.emplace_back(sets.offset32(4 + i * 4));
        }
    }
    if (version >= 0x10003)
        variations = table.offset32(14);
}
bool GDEF::included(Glyph glyph, unsigned flags, unsigned markSet) const {
    unsigned cls = glyphClasses.get(glyph);
    if ((cls == 1 && (flags & 2)) || (cls == 2 && (flags & 4)) || (cls == 3 && (flags & 8)))
        return false;
    if (cls == 3) {
        if (flags & 16)
            return markSet < markSets.size() && markSets[markSet].contains(glyph);
        if (flags & 0xff00)
            return markAttachmentClasses.get(glyph) == (flags >> 8);
    }
    return true;
}
} // namespace ga::layout
