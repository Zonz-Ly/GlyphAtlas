#import "GASidebarViewController.h"
#import "GAInput.h"
#import "GAGlyphViews.h"
#import "GABoundingBoxView.h"
#import "Font/GAUnicode.h"
#import "GAAppKit.h"

@interface GARowItem : NSObject
@property (nonatomic, strong, nonnull) GACharacterGroup *group;
@property (nonatomic, strong, nonnull) GAGlyphVariant *variant;
@end

@implementation GARowItem
@end

static NSArray<GARowItem *> *GARowsForGroups(NSArray<GACharacterGroup *> *groups,
                                            GAGlyphResolution *temporary) {
    NSMutableArray<GARowItem *> *rows = [NSMutableArray array];
    for (GACharacterGroup *group in groups) {
        for (GAGlyphVariant *variant in group.variants) {
            GARowItem *variantRow = [[GARowItem alloc] init];
            variantRow.group = group;
            variantRow.variant = variant;
            [rows addObject:variantRow];
            if (variant == temporary.parent) {
                GARowItem *temporaryRow = [[GARowItem alloc] init];
                temporaryRow.group = group;
                temporaryRow.variant = temporary.variant;
                [rows addObject:temporaryRow];
            }
        }
    }
    return rows;
}

@interface GASidebarViewController (TableKeyboardActions)
- (void)selectAdjacentBaseForward:(BOOL)forward;
- (void)activateSelectedVariantWithModifiers:(NSEventModifierFlags)modifiers;
- (void)copySelectedGlyphEncoding;
- (BOOL)selectedGlyphHasEncoding;
@end

@interface GASidebarTableView : NSTableView
@property (nonatomic, weak) GASidebarViewController *sidebarController;
@end

@implementation GASidebarTableView

- (void)keyDown:(NSEvent *)event {
    // Return works with no modifier or Shift only.
    BOOL canActivate =
        GAModifiersAre(event.modifierFlags, 0) ||
        GAModifiersAre(event.modifierFlags, NSEventModifierFlagShift);
    BOOL commandOnly =
        GAModifiersAre(event.modifierFlags, NSEventModifierFlagCommand);
    if (canActivate && (event.keyCode == 36 || event.keyCode == 76)) {
        [self.sidebarController
            activateSelectedVariantWithModifiers:event.modifierFlags];
        return;
    }
    if (commandOnly &&
        [event.charactersIgnoringModifiers.lowercaseString isEqualToString:@"c"] &&
        ![self.sidebarController selectedGlyphHasEncoding]) {
        NSBeep();
        return;
    }
    if (event.keyCode == 126 || event.keyCode == 125) {
        BOOL down = event.keyCode == 125;
        if (GAModifiersAre(event.modifierFlags, NSEventModifierFlagOption)) {
            [self.sidebarController selectAdjacentBaseForward:down];
            return;
        }
        if (commandOnly) {
            if (self.numberOfRows > 0) {
                NSInteger row = down ? self.numberOfRows - 1 : 0;
                [self selectRowIndexes:[NSIndexSet indexSetWithIndex:(NSUInteger)row]
                    byExtendingSelection:NO];
                GAScrollToVerticalEdge(self.enclosingScrollView, down);
            }
            return;
        }
    }
    [super keyDown:event];
}

- (void)copy:(id)sender {
    [self.sidebarController copySelectedGlyphEncoding];
}

- (BOOL)validateUserInterfaceItem:(id<NSValidatedUserInterfaceItem>)item {
    if (item.action == @selector(copy:)) {
        return [self.sidebarController selectedGlyphHasEncoding];
    }
    return [super validateUserInterfaceItem:item];
}

@end

@interface GASidebarViewController () <NSTextFieldDelegate,
                                       NSTableViewDataSource,
                                       NSTableViewDelegate>
@property (nonatomic, strong) NSTextField *inputField;
@property (nonatomic, strong) GASearchField *sidebarInputField;
@property (nonatomic, strong, nullable) NSTextField *toolbarInputField;
@property (nonatomic, strong) NSLayoutConstraint *sidebarListTopConstraint;
@property (nonatomic, strong, nullable) NSLayoutConstraint *pinnedSidebarListTopConstraint;
@property (nonatomic, copy) NSArray<NSLayoutConstraint *> *sidebarInputConstraints;
@property (nonatomic, copy, nullable) NSArray<NSLayoutConstraint *> *pinnedSidebarInputConstraints;
@property (nonatomic, strong, nullable) NSLayoutConstraint *pinnedAccessoryHeightConstraint;
@property (nonatomic) BOOL sidebarAdjustsContentInsets;
@property (nonatomic, strong) NSTableView *tableView;
@property (nonatomic, strong) NSScrollView *scrollView;
@property (nonatomic, strong) NSViewController *inputAccessory;
@property (nonatomic, strong) NSArray<GACharacterGroup *> *groups;
@property (nonatomic, strong) NSArray<GARowItem *> *rows;
@property (nonatomic, strong, nullable) GAGlyphResolution *temporaryResolution;
@property (nonatomic, copy, nullable) NSString *displayedText;
@property (nonatomic, copy, nullable) NSString *trackedFieldText;
@property (nonatomic, strong, nullable) NSMutableData *displayedSourceEdits;
@property (nonatomic, strong, nullable) GAGlyphVariant *selectedVariant;
@property (nonatomic) NSRange selectedVariantTextRange;
@property (nonatomic) BOOL suppressSelectionCallback;
@property (nonatomic, copy, nullable) NSArray<NSNumber *> *pendingSelectionGlyphIDs;
@property (nonatomic) NSRange pendingSelectionTextRange;
@property (nonatomic) GAPendingSelectionScroll pendingSelectionScroll;
@property (nonatomic, copy, nullable) NSArray<NSNumber *> *lastNotifiedGlyphIDs;
@property (nonatomic) NSRange lastNotifiedRange;
@property (nonatomic, strong, nullable) NSLayoutConstraint *searchTopConstraint;
@property (nonatomic) BOOL suppressTextChangeCallback;
@property (nonatomic) BOOL handlingNativeInputEdit;
@property (nonatomic) BOOL inputChangedDuringReplay;
@property (nonatomic) NSRange inputAutoSelectionRange;
@property (nonatomic, strong) GAGlyphInputEditor *inputEditor;
/// Rebinds the same visual row sequence, including shifted source ranges,
/// without reloading the table, changing the selected row or scrolling.
/// Returns NO if the rows or selected source need to change.
- (BOOL)updateGroupsWithSameRows:(NSArray<GACharacterGroup *> *)groups
                           rows:(NSArray<GARowItem *> *)rows
                  selectedRange:(NSRange)selectedRange;
- (void)clearTemporaryGlyph;
- (BOOL)selectVariant:(GAGlyphVariant *)variant inGroup:(GACharacterGroup *)group
    temporaryResolution:(nullable GAGlyphResolution *)temporary;
@end

// A source edit uses the input's pre-edit coordinates. Intersecting spans were
// replaced/deleted and must not bind to another character.
typedef struct {
    NSRange changed;
    NSInteger shift;
} GASourceEdit;

static GASourceEdit GASourceEditBetween(NSString *before, NSString *after) {
    if (before == nil || after == nil || [before isEqualToString:after])
        return (GASourceEdit){ NSMakeRange(NSNotFound, 0), 0 };
    NSUInteger prefix = 0, suffix = 0;
    NSUInteger common = MIN(before.length, after.length);
    while (prefix < common && [before characterAtIndex:prefix] == [after characterAtIndex:prefix])
        prefix++;
    while (suffix < common - prefix &&
           [before characterAtIndex:before.length - suffix - 1] ==
               [after characterAtIndex:after.length - suffix - 1])
        suffix++;
    return (GASourceEdit){ NSMakeRange(prefix, before.length - prefix - suffix),
                          (NSInteger)after.length - (NSInteger)before.length };
}

static NSRange GARemapSourceRange(NSRange range, GASourceEdit edit) {
    if (range.location == NSNotFound || edit.changed.location == NSNotFound ||
        NSMaxRange(range) <= edit.changed.location)
        return range;
    if (range.location >= NSMaxRange(edit.changed))
        return NSMakeRange((NSUInteger)((NSInteger)range.location + edit.shift), range.length);
    return NSMakeRange(NSNotFound, 0);
}

static NSRange GARemapSourceRangeThroughEdits(NSRange range, NSData *recordedEdits) {
    const GASourceEdit *edits = recordedEdits.bytes;
    NSUInteger count = recordedEdits.length / sizeof(*edits);
    for (NSUInteger index = 0; index < count && range.location != NSNotFound; index++) {
        range = GARemapSourceRange(range, edits[index]);
    }
    return range;
}

static const CGFloat GASidebarInactiveGlyphListAlpha = 0.37;
static const CGFloat GASidebarInputSpacing = 9;

static void GAApplyInputAttributes(NSTextStorage *storage, NSAttributedString *text) {
    [storage beginEditing];
    [text enumerateAttributesInRange:NSMakeRange(0, text.length) options:0
        usingBlock:^(NSDictionary<NSAttributedStringKey, id> *attributes, NSRange range, BOOL *stop) {
            (void)stop;
            [storage setAttributes:attributes range:range];
        }];
    [storage endEditing];
}

@implementation GASidebarViewController

- (void)loadView {
    // The sidebar item + NSTableView Source List style provide the material.
    self.view = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 280, 760)];
}

- (NSTextField *)newInputFieldForToolbar:(BOOL)toolbar {
    NSTextField *field = toolbar
        ? [[GAGlyphInputField alloc] initWithFrame:NSZeroRect]
        : [[GASearchField alloc] initWithFrame:NSZeroRect];
    field.translatesAutoresizingMaskIntoConstraints = NO;
    NSControlSize controlSize = NSControlSizeLarge;
    if (toolbar) {
        if (@available(macOS 26.0, *)) controlSize = NSControlSizeExtraLarge;
        field.bezelStyle = NSTextFieldRoundedBezel;
    } else {
        field.placeholderString = NSLocalizedString(@"Enter text", @"Enter text");
        NSSearchFieldCell *cell = (NSSearchFieldCell *)field.cell;
        cell.searchButtonCell = nil;
        cell.cancelButtonCell = nil;
    }
    field.controlSize = controlSize;
    field.font = [NSFont systemFontOfSize:0];
    // Custom selection attributes live in the field's attributed string and
    // must survive the field editor's edit cycle.
    field.allowsEditingTextAttributes = YES;
    field.delegate = self;
    field.accessibilityLabel = NSLocalizedString(@"Enter text", @"Enter text");
    return field;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.sidebarInputField = (GASearchField *)[self newInputFieldForToolbar:NO];
    self.inputField = self.sidebarInputField;
    self.inputEditor = [[GAGlyphInputEditor alloc] initWithFrame:NSZeroRect];
    self.inputEditor.fieldEditor = YES;
    self.inputEditor.allowsUndo = YES;
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(recordFieldEdit:)
        name:NSTextStorageWillProcessEditingNotification object:self.inputEditor.textStorage];

    GASidebarTableView *tableView = [[GASidebarTableView alloc] initWithFrame:NSZeroRect];
    tableView.sidebarController = self;
    self.tableView = tableView;
    self.tableView.autoresizingMask = NSViewWidthSizable;
    self.tableView.rowHeight = 44;
    self.tableView.headerView = nil;
    self.tableView.style = NSTableViewStyleSourceList;
    self.tableView.intercellSpacing = NSMakeSize(0, 0);
    self.tableView.focusRingType = NSFocusRingTypeNone;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.target = self;
    self.tableView.doubleAction = @selector(tableDoubleClicked:);

    NSTableColumn *column = [[NSTableColumn alloc] initWithIdentifier:@"main"];
    column.resizingMask = NSTableColumnAutoresizingMask;
    [self.tableView addTableColumn:column];

    self.scrollView = [[NSScrollView alloc] initWithFrame:NSZeroRect];
    self.scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    self.scrollView.hasVerticalScroller = YES;
    self.scrollView.autohidesScrollers = YES;
    self.scrollView.documentView = self.tableView;
    self.scrollView.contentInsets = NSEdgeInsetsMake(4, 0, 14, 0);
    if (@available(macOS 26.0, *)) {
        self.scrollView.drawsBackground = NO;
        self.tableView.backgroundColor = NSColor.clearColor;
    }
    self.scrollView.accessibilityLabel = NSLocalizedString(@"Text and alternate glyph list", @"Text and alternate glyph list");

    [self.view addSubview:self.inputField];
    [self.view addSubview:self.scrollView];

    BOOL tahoeLayout = GAUsesMacOS26Layout();
    NSLayoutGuide *safeArea = self.view.safeAreaLayoutGuide;
    self.sidebarListTopConstraint =
        [self.scrollView.topAnchor constraintEqualToAnchor:self.sidebarInputField.bottomAnchor
                                                  constant:GASidebarInputSpacing];
    [NSLayoutConstraint activateConstraints:@[
        [self.inputField.leadingAnchor constraintEqualToAnchor:
            tahoeLayout ? safeArea.leadingAnchor : self.view.leadingAnchor
                                                        constant:tahoeLayout ? 12 : 9],
        [self.inputField.trailingAnchor constraintEqualToAnchor:
            tahoeLayout ? safeArea.trailingAnchor : self.view.trailingAnchor
                                                         constant:tahoeLayout ? -12 : -9],
        self.sidebarListTopConstraint,
        [self.scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.scrollView.bottomAnchor constraintEqualToAnchor:
            tahoeLayout ? safeArea.bottomAnchor : self.view.bottomAnchor
                                                    constant:tahoeLayout ? -8 : 0],
    ]];
}

- (void)viewDidAppear {
    [super viewDidAppear];
    [self updateSidebarTopConstraint];
}

- (void)enableScrollEdgeEffectForSplitViewItem:(NSSplitViewItem *)item {
    [self view];
    self.searchTopConstraint.active = NO;
    self.searchTopConstraint = nil;
    self.sidebarListTopConstraint.active = NO;
    [self.sidebarInputField removeFromSuperview];

    NSView *content = [[NSView alloc] initWithFrame:
        NSMakeRect(0, 0, NSWidth(self.view.bounds),
                   self.sidebarInputField.fittingSize.height + GASidebarInputSpacing)];
    [content addSubview:self.sidebarInputField];
    self.sidebarInputConstraints = @[
        [self.sidebarInputField.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:12],
        [self.sidebarInputField.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-12],
        [self.sidebarInputField.topAnchor constraintEqualToAnchor:content.topAnchor],
        [self.sidebarInputField.bottomAnchor constraintEqualToAnchor:content.bottomAnchor
                                                          constant:-GASidebarInputSpacing],
    ];
    [NSLayoutConstraint activateConstraints:self.sidebarInputConstraints];

    // Resolve at runtime so builds with an older SDK can use the public class.
    NSSplitViewItemAccessoryViewController *accessory =
        [NSClassFromString(@"NSSplitViewItemAccessoryViewController") new];
    accessory.automaticallyAppliesContentInsets = NO;
    if (@available(macOS 26.1, *)) {
        accessory.preferredScrollEdgeEffectStyle =
            [NSClassFromString(@"NSScrollEdgeEffectStyle") softStyle];
    }
    accessory.view = content;
    self.inputAccessory = accessory;
    self.sidebarListTopConstraint =
        [self.scrollView.topAnchor constraintEqualToAnchor:self.view.topAnchor];
    self.sidebarListTopConstraint.active = YES;
    [item addTopAlignedAccessoryViewController:accessory];
}

- (void)updateSidebarTopConstraint {
    self.searchTopConstraint.active = NO;
    self.searchTopConstraint = nil;
    if (self.inputAccessory) return;
    NSLayoutGuide *guide = (NSLayoutGuide *)self.view.window.contentLayoutGuide;
    if (!guide) return;

    self.searchTopConstraint = [self.sidebarInputField.topAnchor constraintEqualToAnchor:guide.topAnchor constant:-1];
    self.searchTopConstraint.active = YES;
}

- (void)setSidebarContentTopPinned:(BOOL)pinned {
    if (pinned == (self.pinnedSidebarInputConstraints != nil)) return;
    if (pinned && !self.inputAccessory && !self.searchTopConstraint) {
        // Defaults can collapse the sidebar before its first viewDidAppear.
        [self updateSidebarTopConstraint];
        [self.view.window.contentView.superview layoutSubtreeIfNeeded];
    }
    self.pinnedSidebarListTopConstraint.active = NO;
    self.pinnedSidebarListTopConstraint = nil;
    self.sidebarListTopConstraint.active = !pinned;
    if (pinned) {
        NSEdgeInsets insets = self.scrollView.contentInsets;
        NSPoint origin = self.scrollView.contentView.bounds.origin;
        self.sidebarAdjustsContentInsets = self.scrollView.automaticallyAdjustsContentInsets;
        self.scrollView.automaticallyAdjustsContentInsets = NO;
        self.scrollView.contentInsets = insets;
        [self.scrollView tile];
        [self.scrollView.contentView scrollToPoint:origin];
        [self.scrollView reflectScrolledClipView:self.scrollView.contentView];
        NSRect inputFrame = [self.view convertRect:self.sidebarInputField.bounds fromView:self.sidebarInputField];
        self.searchTopConstraint.active = NO;
        if (self.inputAccessory) {
            NSView *host = self.inputAccessory.view;
            self.pinnedAccessoryHeightConstraint =
                [host.heightAnchor constraintEqualToConstant:NSHeight(host.frame)];
            self.pinnedAccessoryHeightConstraint.active = YES;
            [NSLayoutConstraint deactivateConstraints:self.sidebarInputConstraints];
            [self.sidebarInputField removeFromSuperview];
            [self.view addSubview:self.sidebarInputField positioned:NSWindowAbove relativeTo:self.scrollView];
        }
        CGFloat inputTop = GATopOffsetInView(self.view, inputFrame);
        NSMutableArray<NSLayoutConstraint *> *constraints = [NSMutableArray arrayWithArray:@[
            [self.sidebarInputField.topAnchor constraintEqualToAnchor:self.view.topAnchor constant:inputTop],
            [self.sidebarInputField.heightAnchor constraintEqualToConstant:NSHeight(inputFrame)],
        ]];
        if (self.inputAccessory) {
            [constraints addObjectsFromArray:@[
                [self.sidebarInputField.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor
                                                                   constant:NSMinX(inputFrame)],
                [self.sidebarInputField.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor
                                                                    constant:NSMaxX(inputFrame) - NSWidth(self.view.bounds)],
            ]];
        }
        self.pinnedSidebarInputConstraints = constraints;
        [NSLayoutConstraint activateConstraints:constraints];
        NSRect frame = self.scrollView.frame;
        CGFloat top = GATopOffsetInView(self.view, frame);
        self.pinnedSidebarListTopConstraint =
            [self.scrollView.topAnchor constraintEqualToAnchor:self.view.topAnchor constant:top];
        self.pinnedSidebarListTopConstraint.active = YES;
    } else {
        [NSLayoutConstraint deactivateConstraints:self.pinnedSidebarInputConstraints];
        self.pinnedSidebarInputConstraints = nil;
        if (self.inputAccessory) {
            [self.sidebarInputField removeFromSuperview];
            [self.inputAccessory.view addSubview:self.sidebarInputField];
            [NSLayoutConstraint activateConstraints:self.sidebarInputConstraints];
            self.pinnedAccessoryHeightConstraint.active = NO;
            self.pinnedAccessoryHeightConstraint = nil;
        } else {
            [self updateSidebarTopConstraint];
        }
        NSPoint origin = self.scrollView.contentView.bounds.origin;
        self.scrollView.automaticallyAdjustsContentInsets = self.sidebarAdjustsContentInsets;
        [self.scrollView tile];
        [self.scrollView.contentView scrollToPoint:origin];
        [self.scrollView reflectScrolledClipView:self.scrollView.contentView];
    }
}

- (void)useInputInToolbar:(BOOL)toolbar {
    if (toolbar && !self.toolbarInputField) {
        GAGlyphInputField *field = (GAGlyphInputField *)[self newInputFieldForToolbar:YES];
        self.toolbarInputField = field;
        [field setContentHuggingPriority:NSLayoutPriorityFittingSizeCompression
                          forOrientation:NSLayoutConstraintOrientationHorizontal];
        [field.widthAnchor constraintGreaterThanOrEqualToConstant:120].active = YES;
    }
    NSTextField *input = toolbar ? self.toolbarInputField : self.sidebarInputField;
    if (input == self.inputField) return;
    // Both controls use the same editor and undo history, one at a time.
    self.inputField.editable = NO;
    self.inputField.selectable = NO;
    self.inputField = input;
    input.editable = YES;
    [self syncDetachedInput];
}

- (void)setToolbarInputPlaceholder:(NSString *)placeholder {
    self.toolbarInputField.placeholderString = placeholder;
}

- (void)viewDidLayout {
    [super viewDidLayout];
    [self.tableView sizeLastColumnToFit];
}

- (NSFont *)inputFont {
    return self.inputField.font ?: [NSFont systemFontOfSize:0];
}

- (NSColor *)inputTextColor {
    return [NSColor controlTextColor];
}

/// Returns only the attributes this app understands: the default font,
/// the app-owned foreground color, selection runs, and line-break markers. Everything else
/// (pasted colors, backgrounds, paragraph styles, links, attachments) is
/// discarded.
- (NSAttributedString *)plainCopyOfAttributedText:(NSAttributedString *)text {
    return GANormalizedSidebarInput(text, [self inputFont], [self inputTextColor]);
}

- (void)prepareFieldEditor {
    NSTextView *editor = (NSTextView *)self.inputField.currentEditor;
    if (editor == nil) {
        return;
    }
    NSFont *font = [self inputFont];
    NSColor *color = [self inputTextColor];
    // Allow programmatic attributes (selection runs), but keep user edits and
    // pastes plain so external formatting cannot enter the field.
    BOOL wasSuppressed = self.suppressTextChangeCallback;
    self.suppressTextChangeCallback = YES;
    editor.richText = NO;
    editor.usesFontPanel = NO;
    editor.typingAttributes = @{
        NSFontAttributeName: font,
        NSForegroundColorAttributeName: color,
    };
    self.suppressTextChangeCallback = wasSuppressed;

    NSTextStorage *storage = editor.textStorage;
    if (storage.length == 0) {
        return;
    }
    NSRange all = NSMakeRange(0, storage.length);
    __block BOOL needsNormalization = NO;
    [storage enumerateAttributesInRange:all
                                options:0
                             usingBlock:^(NSDictionary<NSAttributedStringKey, id> *attrs,
                                          NSRange range, BOOL *stop) {
        // AppKit may extend a marker's attributes to adjacent pasted text.
        if (attrs[GALineBreakAttributeName] != nil) {
            unichar marker = GAInputSeparatorMarker([attrs[GALineBreakAttributeName] unsignedShortValue]);
            for (NSUInteger i = range.location; i < NSMaxRange(range); i++) {
                if (!marker || [storage.string characterAtIndex:i] != marker) {
                    needsNormalization = YES;
                    *stop = YES;
                    break;
                }
            }
            return;
        }
        for (NSAttributedStringKey key in attrs) {
            if ([key isEqualToString:GAGlyphSelectionAttributeName]) {
                continue;
            }
            if ([key isEqualToString:NSFontAttributeName] &&
                [attrs[key] isEqual:font]) {
                continue;
            }
            if ([key isEqualToString:NSForegroundColorAttributeName] &&
                [attrs[key] isEqual:color]) {
                continue;
            }
            needsNormalization = YES;
            *stop = YES;
            return;
        }
    }];
    if (!needsNormalization) {
        return;
    }

    self.suppressTextChangeCallback = YES;
    GAApplyInputAttributes(storage, GANormalizedSidebarInput(storage, font, color));
    self.suppressTextChangeCallback = wasSuppressed;
}

- (NSAttributedString *)attributedText {
    return GAModelTextFromFieldText([self plainCopyOfAttributedText:self.inputEditor.textStorage]);
}

- (NSString *)text {
    return GAModelStringFromFieldText(self.inputEditor.textStorage);
}

- (NSRange)inputSelectionRange {
    NSTextView *editor = (NSTextView *)self.inputField.currentEditor;
    return editor != nil ? editor.selectedRange : NSMakeRange(NSNotFound, 0);
}

- (BOOL)isInputFocused {
    NSText *editor = self.inputField.currentEditor;
    return editor != nil && self.inputField.window.firstResponder == editor;
}

- (void)setGlyphSelection:(GAGlyphSelection *)selection inRange:(NSRange)range
             registerUndo:(BOOL)registerUndo {
    NSTextStorage *storage = self.inputEditor.textStorage;
    if (NSMaxRange(range) > storage.length) return;
    GAGlyphSelection *previous = [storage attribute:GAGlyphSelectionAttributeName
                                            atIndex:range.location effectiveRange:NULL];
    if (selection == previous) return;
    if (registerUndo) {
        [self.inputEditor.undoManager registerUndoWithTarget:self
            handler:^(GASidebarViewController *target) {
                [target setGlyphSelection:previous inRange:range registerUndo:YES];
            }];
    }
    if (selection) [storage addAttribute:GAGlyphSelectionAttributeName value:selection range:range];
    else [storage removeAttribute:GAGlyphSelectionAttributeName range:range];
}

- (void)updateGlyphSelectionsFromText:(NSAttributedString *)text ranges:(NSArray<NSValue *> *)ranges {
    GAGlyphInputEditor *editor = self.inputEditor;
    NSTextStorage *storage = editor.textStorage;
    NSUndoManager *manager = editor.undoManager;
    BOOL registerUndo = self.handlingNativeInputEdit && manager.undoRegistrationEnabled && manager.groupingLevel > 0;
    // Keep the cleanup with its text edit, and prevent the next keystroke
    // from being coalesced into the text operation ahead of this cleanup.
    if (registerUndo) [editor breakUndoCoalescing];
    [storage beginEditing];
    for (NSValue *value in ranges) {
        NSRange range = value.rangeValue;
        [text enumerateAttribute:GAGlyphSelectionAttributeName inRange:range options:0
            usingBlock:^(GAGlyphSelection *selection, NSRange subrange, BOOL *stop) {
                (void)stop;
                [self setGlyphSelection:selection inRange:subrange registerUndo:registerUndo];
            }];
    }
    [storage endEditing];
    [self syncDetachedInput];
}

- (void)syncDetachedInput {
    NSAttributedString *text = [self.inputEditor.textStorage copy];
    if (self.sidebarInputField.currentEditor == nil)
        self.sidebarInputField.attributedStringValue =
            GANormalizedSidebarInput(text, self.sidebarInputField.font, [self inputTextColor]);
    if (self.toolbarInputField && self.toolbarInputField.currentEditor == nil)
        self.toolbarInputField.attributedStringValue =
            GANormalizedSidebarInput(text, self.toolbarInputField.font, [self inputTextColor]);
}

- (BOOL)commitGlyphInput:(NSAttributedString *)attributedText
          replacingRange:(NSRange)range actionName:(NSString *)actionName {
    GAGlyphInputEditor *editor = self.inputEditor;
    if (editor.hasMarkedText) return NO;
    NSAttributedString *replacement = [self plainCopyOfAttributedText:GAFieldTextFromModelText(attributedText)];
    NSTextStorage *storage = editor.textStorage;
    if ([storage isEqualToAttributedString:replacement]) return YES;

    NSRange all = NSMakeRange(0, storage.length);
    NSRange selection = editor.selectedRange;
    BOOL changesCharacters = ![storage.string isEqualToString:replacement.string];
    NSUndoManager *undoManager = editor.undoManager;
    BOOL registersUndo = undoManager.undoRegistrationEnabled;
    [editor breakUndoCoalescing];
    if (registersUndo) [undoManager beginUndoGrouping];
    self.suppressTextChangeCallback = YES;
    BOOL applied = [editor shouldChangeTextInRange:all
                               replacementString:changesCharacters ? replacement.string : nil];
    if (applied) {
        if (changesCharacters) {
            if ([self.trackedFieldText isEqualToString:storage.string]) {
                GASourceEdit edit = {range, (NSInteger)replacement.length - (NSInteger)storage.length};
                [self.displayedSourceEdits appendBytes:&edit length:sizeof(edit)];
                self.trackedFieldText = replacement.string;
            } else {
                self.displayedSourceEdits = nil;
            }
            [storage replaceCharactersInRange:all withAttributedString:replacement];
        } else {
            GAApplyInputAttributes(storage, replacement);
        }
        [editor didChangeText];
        if (self.inputField.currentEditor == editor && selection.location != NSNotFound) {
            NSUInteger location = MIN(selection.location, storage.length);
            editor.selectedRange = NSMakeRange(location, MIN(selection.length, storage.length - location));
        }
        if (registersUndo) [undoManager setActionName:actionName];
    }
    self.suppressTextChangeCallback = NO;
    if (registersUndo) [undoManager endUndoGrouping];
    if (applied) {
        self.pendingSelectionGlyphIDs = nil;
        [self syncDetachedInput];
    }
    return applied;
}

- (void)replaceInputText:(NSString *)text {
    if (!self.inputFocused && ![self.inputField.window makeFirstResponder:self.inputField]) return;
    [self prepareFieldEditor];
    NSTextView *editor = (NSTextView *)self.inputField.currentEditor;
    [editor insertText:text replacementRange:NSMakeRange(0, editor.string.length)];
}

- (void)selectGlyphIDsAfterNextReload:(NSArray<NSNumber *> *)glyphIDs
                            textRange:(NSRange)textRange
                               scroll:(GAPendingSelectionScroll)scroll {
    self.pendingSelectionGlyphIDs = glyphIDs;
    self.pendingSelectionTextRange = textRange;
    self.pendingSelectionScroll = scroll;
}

/// Native input and grid appends share the same pending-selection handoff.
- (void)inputDidChangeSelectingGlyphIDs:(NSArray<NSNumber *> *)glyphIDs
                            textRange:(NSRange)range {
    [self selectGlyphIDsAfterNextReload:glyphIDs textRange:range
                                scroll:GAPendingSelectionScrollGroup];
    if (self.onTextChanged) self.onTextChanged();
}

- (NSString *)selectedGlyphSourceText {
    GARowItem *row = [self selectedVariantRow];
    NSRange range = row.variant.sourceTextRange;
    if (row.variant.isLigature && range.location != NSNotFound) {
        NSString *text = self.text;
        if (NSMaxRange(range) <= text.length) return [text substringWithRange:range];
    }
    return row.group.text ?: @"";
}

- (GARowItem *)rowItemAtIndex:(NSInteger)row {
    if (row < 0 || row >= (NSInteger)self.rows.count) return nil;
    return self.rows[(NSUInteger)row];
}

- (GARowItem *)selectedVariantRow {
    return [self rowItemAtIndex:self.tableView.selectedRow];
}

/// Keep the selected variant and its source range as one state update.
- (void)rememberSelectedRow:(NSInteger)row {
    GARowItem *item = [self rowItemAtIndex:row];
    self.selectedVariant = item.variant;
    self.selectedVariantTextRange = item ? item.group.textRange : NSMakeRange(NSNotFound, 0);
}

- (void)activateRowAtIndex:(NSInteger)row
                 modifiers:(NSEventModifierFlags)modifiers {
    GARowItem *item = [self rowItemAtIndex:row];
    if (item && self.onGlyphActivated) {
        self.onGlyphActivated(item.group, item.variant,
                              GAModifiersAre(modifiers, NSEventModifierFlagShift));
    }
}

- (void)activateSelectedVariantWithModifiers:(NSEventModifierFlags)modifiers {
    [self activateRowAtIndex:self.tableView.selectedRow modifiers:modifiers];
}

- (BOOL)selectedGlyphHasEncoding {
    GARowItem *item = [self selectedVariantRow];
    return item.variant.unicodeScalars.count > 0;
}

- (void)copySelectedGlyphEncoding {
    GARowItem *item = [self selectedVariantRow];
    if (item.variant.unicodeScalars.count == 0) {
        NSBeep();
        return;
    }
    NSString *string = GAStringFromUnicodeScalars(item.variant.unicodeScalars);
    if (string.length == 0) {
        NSBeep();
        return;
    }
    NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
    [pasteboard clearContents];
    [pasteboard setString:string forType:NSPasteboardTypeString];
}

- (void)tableDoubleClicked:(id)sender {
    [self activateRowAtIndex:self.tableView.clickedRow
                   modifiers:NSApp.currentEvent.modifierFlags];
}

- (void)appendInputString:(NSString *)string
               selection:(GAGlyphSelection *)selection
       selectingGlyphIDs:(NSArray<NSNumber *> *)glyphIDs
              actionName:(NSString *)actionName {
    if (string.length == 0) {
        return;
    }
    NSMutableAttributedString *text = [self.attributedText mutableCopy];
    NSRange range = NSMakeRange(text.length, string.length);
    [text appendAttributedString:[[NSAttributedString alloc] initWithString:string]];
    if (selection != nil) {
        [text addAttribute:GAGlyphSelectionAttributeName value:selection range:range];
    }
    if (![self commitGlyphInput:text replacingRange:NSMakeRange(range.location, 0) actionName:actionName]) return;
    [self inputDidChangeSelectingGlyphIDs:glyphIDs textRange:range];
    [self focusInput];
}

- (void)focusInput {
    NSWindow *window = self.inputField.window;
    if (window == nil || ![window makeFirstResponder:self.inputField]) return;
    [self prepareFieldEditor];
}

- (void)restoreInputSelection:(NSRange)selection {
    [self focusInput];
    NSTextView *editor = (NSTextView *)self.inputField.currentEditor;
    NSUInteger start = MIN(selection.location, editor.string.length);
    editor.selectedRange = NSMakeRange(start, MIN(selection.length, editor.string.length - start));
}

- (void)focusGlyphList {
    BOOL inputInSidebar = self.inputField == self.sidebarInputField;
    [self.inputField.window makeFirstResponder:inputInSidebar ? self.tableView : nil];
}

/// The active glyph input gets the retained editor; other controls keep the
/// window's default editor.
- (NSTextView *)fieldEditorForControl:(id)control {
    if (control != self.inputField) {
        return nil;
    }
    NSUndoManager *manager = self.inputField.window.undoManager;
    NSUndoManager *previousManager = self.inputEditor.inputUndoManager;
    if (manager != previousManager) {
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        for (NSNotificationName name in @[NSUndoManagerDidUndoChangeNotification,
                                           NSUndoManagerDidRedoChangeNotification]) {
            if (previousManager) [center removeObserver:self name:name object:previousManager];
            if (manager) [center addObserver:self selector:@selector(didReplayInputEdit:) name:name object:manager];
        }
        self.inputEditor.inputUndoManager = manager;
    }
    return self.inputEditor;
}

- (NSString *)currentFieldText {
    return self.inputEditor.string;
}

- (void)didReplayInputEdit:(NSNotification *)notification {
    if (!self.inputChangedDuringReplay) return;
    self.inputChangedDuringReplay = NO;
    [self syncDetachedInput];
    [self prepareFieldEditor];
    self.pendingSelectionGlyphIDs = nil;
    if (self.onInputUndoRedo) self.onInputUndoRedo();
}

/// Uses the source before this deletion, including edits not yet published.
- (NSRange)autoSelectionRangeAfterDeleting:(GASourceEdit)edit {
    NSRange selectedRange = GARemapSourceRangeThroughEdits(self.selectedVariantTextRange,
                                                          self.displayedSourceEdits);
    // Repeated deletions can remove the selected source before its query
    // publishes. Continue from the pending target in that case.
    BOOL followsPendingSelection = selectedRange.location == NSNotFound &&
        self.pendingSelectionGlyphIDs != nil && self.pendingSelectionGlyphIDs.count == 0;
    if (followsPendingSelection)
        selectedRange = self.pendingSelectionTextRange;
    if (selectedRange.location != NSNotFound &&
        NSIntersectionRange(selectedRange, edit.changed).length) {
        return NSMakeRange(edit.changed.location ? edit.changed.location - 1 : 0, 1);
    }
    return followsPendingSelection ? GARemapSourceRange(selectedRange, edit) : NSMakeRange(0, 0);
}

- (void)recordFieldEdit:(NSNotification *)notification {
    NSTextStorage *storage = notification.object;
    NSUndoManager *manager = self.inputEditor.undoManager;
    BOOL replaying = manager.isUndoing || manager.isRedoing;
    if (replaying) {
        self.inputAutoSelectionRange = NSMakeRange(0, 0);
        self.inputChangedDuringReplay = YES;
    } else if (self.suppressTextChangeCallback || self.inputField.currentEditor != self.inputEditor) {
        return;
    }
    if (!(storage.editedMask & NSTextStorageEditedCharacters)) return;
    NSRange changed = storage.editedRange;
    if (!replaying) {
        self.inputAutoSelectionRange = changed.length
            ? NSMakeRange(NSMaxRange(changed) - 1, 1) : NSMakeRange(0, 0);
    }
    if (!self.displayedSourceEdits) return;
    NSString *before = self.trackedFieldText;
    NSString *after = storage.string;
    NSInteger shift = storage.changeInLength;
    NSInteger oldLength = (NSInteger)changed.length - shift;
    if (changed.location > before.length || NSMaxRange(changed) > after.length ||
        oldLength < 0 || (NSUInteger)oldLength > before.length - changed.location ||
        (NSInteger)before.length + shift != (NSInteger)after.length) {
        self.displayedSourceEdits = nil;
        return;
    }
    NSRange replaced = NSMakeRange(changed.location, (NSUInteger)oldLength);
    // Programmatic glyph edits can register a whole-field replacement with
    // AppKit. Such a replay does not identify the source spans that survived.
    if (replaying && replaced.location == 0 && replaced.length == before.length &&
        replaced.length && changed.length) {
        self.displayedSourceEdits = nil;
        return;
    }
    if (![[before substringToIndex:replaced.location] isEqualToString:[after substringToIndex:changed.location]] ||
        ![[before substringFromIndex:NSMaxRange(replaced)] isEqualToString:[after substringFromIndex:NSMaxRange(changed)]]) {
        self.displayedSourceEdits = nil;
        return;
    }
    GASourceEdit edit = { replaced, shift };
    if (!replaying && changed.length == 0 && replaced.length && after.length)
        self.inputAutoSelectionRange = [self autoSelectionRangeAfterDeleting:edit];
    [self.displayedSourceEdits appendBytes:&edit length:sizeof(edit)];
    self.trackedFieldText = after;
}

- (NSRange)currentInputRangeForDisplayedRange:(NSRange)range {
    if (!self.displayedSourceEdits || ![self.trackedFieldText isEqualToString:self.currentFieldText]) {
        return NSMakeRange(NSNotFound, 0);
    }
    return GARemapSourceRangeThroughEdits(range, self.displayedSourceEdits);
}

- (NSRange)navigationRangeForDisplayedRange:(NSRange)range {
    if (self.displayedSourceEdits) return [self currentInputRangeForDisplayedRange:range];
    NSString *before = self.displayedText;
    NSString *after = self.text;
    if (range.location == NSNotFound || !range.length || NSMaxRange(range) > before.length)
        return NSMakeRange(NSNotFound, 0);
    if ([before isEqualToString:after]) return range;
    NSString *source = [before substringWithRange:range];
    NSRange mapped = GARemapSourceRange(range, GASourceEditBetween(before, after));
    // Undo can replace the entire native storage. Recover only an unchanged,
    // unique source; repeated occurrences must not silently bind elsewhere.
    if (mapped.location != NSNotFound &&
        NSEqualRanges([before rangeOfString:source], range) &&
        NSEqualRanges([before rangeOfString:source options:NSBackwardsSearch], range) &&
        NSEqualRanges([after rangeOfString:source], mapped) &&
        NSEqualRanges([after rangeOfString:source options:NSBackwardsSearch], mapped))
        return mapped;
    return NSMakeRange(NSNotFound, 0);
}

- (void)setGlyphListDimmed:(BOOL)dimmed {
    self.tableView.alphaValue = dimmed ? GASidebarInactiveGlyphListAlpha : 1.0;
}

- (void)controlTextDidBeginEditing:(NSNotification *)obj {
    if (obj.object != self.inputField) return;
    [self prepareFieldEditor];
}

- (void)controlTextDidChange:(NSNotification *)obj {
    if (obj.object != self.inputField || self.suppressTextChangeCallback) {
        return;
    }
    NSTextView *editor = (NSTextView *)self.inputField.currentEditor;
    NSUndoManager *manager = self.inputEditor.undoManager;
    if (editor.hasMarkedText || manager.isUndoing || manager.isRedoing) {
        return;
    }
    NSRange autoSelectionRange = self.inputAutoSelectionRange;
    self.inputAutoSelectionRange = NSMakeRange(0, 0);
    [self prepareFieldEditor];
    self.handlingNativeInputEdit = YES;
    [self inputDidChangeSelectingGlyphIDs:autoSelectionRange.length ? @[] : nil
                               textRange:autoSelectionRange];
    self.handlingNativeInputEdit = NO;
}

- (BOOL)control:(NSControl *)control
    textView:(NSTextView *)textView
    doCommandBySelector:(SEL)commandSelector {
    BOOL backwards = commandSelector == @selector(insertBacktab:);
    if (control == self.inputField && (commandSelector == @selector(insertTab:) || backwards)) {
        if (textView.hasMarkedText) return NO;
        NSArray<NSString *> *texts = [NSUserDefaults.standardUserDefaults arrayForKey:GASavedTextsKey];
        if (!texts.count) {
            NSBeep();
            return YES;
        }
        NSUInteger current = [texts indexOfObject:self.text];
        NSUInteger next = backwards
            ? (current == NSNotFound || current == 0 ? texts.count - 1 : current - 1)
            : (current == NSNotFound || current + 1 == texts.count ? 0 : current + 1);
        [self replaceInputText:texts[next]];
        return YES;
    }
    if (commandSelector == @selector(cancelOperation:) ||
        commandSelector == @selector(insertNewline:)) {
        [self focusGlyphList];
        return YES;
    }
    if (commandSelector == @selector(insertNewlineIgnoringFieldEditor:)) {
        [textView insertText:@"\n" replacementRange:textView.selectedRange];
        return YES;
    }
    return NO;
}

- (NSInteger)baseRowStartingAtIndex:(NSInteger)row step:(NSInteger)step
                       skippingGroup:(GACharacterGroup *)group {
    for (NSInteger index = row; index >= 0 && index < (NSInteger)self.rows.count; index += step) {
        GARowItem *item = self.rows[(NSUInteger)index];
        if (item.group != group && item.variant.isBase) return index;
    }
    return NSNotFound;
}

- (void)selectAdjacentBaseForward:(BOOL)forward {
    NSInteger row = self.tableView.selectedRow;
    GARowItem *item = [self rowItemAtIndex:row];
    NSInteger step = (forward || !item) ? 1 : -1;
    GACharacterGroup *skippedGroup = (forward || item.variant.isBase) ? item.group : nil;
    NSInteger base = [self baseRowStartingAtIndex:item ? row + step : 0
                                           step:step skippingGroup:skippedGroup];
    if (base == NSNotFound) return;
    [self.tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:(NSUInteger)base]
                byExtendingSelection:NO];
    [self scrollGroupContainingRow:base];
}

#pragma mark - Updating groups

/// Restores the first row matching both the source range and complete glyph sequence.
- (NSInteger)rowForGlyphIDs:(NSArray<NSNumber *> *)glyphIDs textRange:(NSRange)textRange {
    if (textRange.length == 0) {
        return NSNotFound;
    }
    for (NSInteger index = 0; index < (NSInteger)self.rows.count; index++) {
        GARowItem *item = self.rows[(NSUInteger)index];
        if (NSEqualRanges(item.group.textRange, textRange) &&
            [item.variant.glyphIDs isEqualToArray:glyphIDs]) {
            return index;
        }
    }
    return NSNotFound;
}

- (NSInteger)rowForGlyphIDs:(NSArray<NSNumber *> *)glyphIDs inGroup:(GACharacterGroup *)group {
    for (NSInteger index = 0; index < (NSInteger)self.rows.count; index++) {
        GARowItem *item = self.rows[index];
        if (item.group == group && [item.variant.glyphIDs isEqualToArray:glyphIDs]) {
            return index;
        }
    }
    return NSNotFound;
}

/// Finds the group at an exact source range.
- (GACharacterGroup *)groupForTextRange:(NSRange)textRange {
    if (textRange.length == 0) {
        return nil;
    }
    for (GACharacterGroup *group in self.groups) {
        if (NSEqualRanges(group.textRange, textRange)) {
            return group;
        }
    }
    return nil;
}

/// Resolves the pending selection by text range first. An empty GID list
/// requests the base row directly; an unavailable GID also falls back to it.
- (NSInteger)rowForPendingSelection {
    NSArray<NSNumber *> *glyphIDs = self.pendingSelectionGlyphIDs;
    if (glyphIDs == nil) {
        return NSNotFound;
    }
    NSRange range = self.pendingSelectionTextRange;
    GACharacterGroup *group = [self groupForTextRange:range];
    if (group == nil) {
        for (GACharacterGroup *candidate in self.groups)
            if (range.location >= candidate.textRange.location &&
                NSMaxRange(range) <= NSMaxRange(candidate.textRange)) {
                group = candidate;
                break;
            }
    }
    if (group == nil)
        return NSNotFound;
    BOOL requestsExactGlyph = glyphIDs.count > 0;
    NSInteger baseRow = NSNotFound;
    for (NSInteger index = 0; index < (NSInteger)self.rows.count; index++) {
        GARowItem *item = self.rows[(NSUInteger)index];
        if (item.group != group) continue;
        if (requestsExactGlyph && [item.variant.glyphIDs isEqualToArray:glyphIDs]) return index;
        if (item.variant.isBase && baseRow == NSNotFound) {
            if (!requestsExactGlyph) return index;
            // Keep the first base as fallback while looking for the exact GID.
            baseRow = index;
        }
    }
    return baseRow;
}

- (NSRect)unobscuredTableVisibleRect {
    NSClipView *clipView = self.scrollView.contentView;
    NSRect safeRect = [self.tableView convertRect:clipView.safeAreaRect fromView:clipView];
    return NSIntersectionRect(self.tableView.visibleRect, safeRect);
}

- (void)scrollTableToY:(CGFloat)y {
    NSRect bounds = self.scrollView.contentView.bounds;
    bounds.origin.y += y - NSMinY([self unobscuredTableVisibleRect]);
    GAScrollToProposedBounds(self.scrollView, bounds);
}

- (void)scrollSelectedRowToTopIfNeeded:(NSInteger)row {
    if (row < 0 || row >= (NSInteger)self.rows.count) {
        return;
    }
    [self.tableView layoutSubtreeIfNeeded];
    NSRect rowRect = [self.tableView rectOfRow:row];
    if (NSIntersectsRect(rowRect, [self unobscuredTableVisibleRect])) {
        return;
    }
    [self scrollTableToY:NSMinY(rowRect)];
}

/// Consumes the request when its query publishes, even if there is no target row.
- (BOOL)applyPendingSelection {
    NSInteger row = [self rowForPendingSelection];
    self.pendingSelectionGlyphIDs = nil;
    if (row == NSNotFound) {
        return NO;
    }
    [self.tableView rectOfRow:row];
    [self.tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:(NSUInteger)row]
                byExtendingSelection:NO];
    if (self.pendingSelectionScroll == GAPendingSelectionScrollSelectedToTopIfNeeded) {
        [self scrollSelectedRowToTopIfNeeded:row];
    } else {
        [self scrollGroupContainingRow:row];
    }
    [self rememberSelectedRow:row];
    self.suppressSelectionCallback = NO;
    [self notifySelectionWithQuickReveal:self.pendingSelectionScroll == GAPendingSelectionScrollGroup];
    return YES;
}

- (void)scrollGroupContainingRow:(NSInteger)row {
    if (row < 0 || row >= (NSInteger)self.rows.count) {
        return;
    }
    // Decide before centering: a visible selection never needs navigation.
    if (self.isViewLoaded) [self.view.window.contentView layoutSubtreeIfNeeded];
    [self.tableView layoutSubtreeIfNeeded];
    NSRect selectedRect = [self.tableView rectOfRow:row];
    NSRect visibleRect = [self unobscuredTableVisibleRect];
    if (NSMinY(selectedRect) >= NSMinY(visibleRect) &&
        NSMaxY(selectedRect) <= NSMaxY(visibleRect)) return;

    GACharacterGroup *group = self.rows[(NSUInteger)row].group;
    NSInteger first = row;
    NSInteger last = row;
    for (NSInteger index = 0; index < (NSInteger)self.rows.count; index++) {
        if (self.rows[(NSUInteger)index].group == group) {
            first = MIN(first, index);
            last = index;
        }
    }
    [self.tableView rectOfRow:first];
    [self.tableView rectOfRow:last];
    NSRect firstRect = [self.tableView rectOfRow:first];
    NSRect lastRect = [self.tableView rectOfRow:last];
    visibleRect = [self unobscuredTableVisibleRect];
    CGFloat groupCenter = (NSMinY(firstRect) + NSMaxY(lastRect)) * 0.5;
    [self scrollTableToY:groupCenter - NSHeight(visibleRect) * 0.5];
    // Only the selected row decides the minimal correction after centering.
    selectedRect = [self.tableView rectOfRow:row];
    visibleRect = [self unobscuredTableVisibleRect];
    if (NSMinY(selectedRect) < NSMinY(visibleRect))
        [self scrollTableToY:NSMinY(selectedRect)];
    else if (NSMaxY(selectedRect) > NSMaxY(visibleRect))
        [self scrollTableToY:NSMaxY(selectedRect) - NSHeight(visibleRect)];
}

- (BOOL)updateGroupsWithSameRows:(NSArray<GACharacterGroup *> *)groups
                           rows:(NSArray<GARowItem *> *)rows
                  selectedRange:(NSRange)selectedRange {
    if (self.pendingSelectionGlyphIDs != nil) return NO;
    if (rows.count != self.rows.count) return NO;
    NSInteger selected = self.tableView.selectedRow;
    if (selected >= 0 && selected < (NSInteger)rows.count &&
        !NSEqualRanges(rows[(NSUInteger)selected].group.textRange, selectedRange)) return NO;
    for (NSUInteger i = 0; i < rows.count; i++) {
        GARowItem *old = self.rows[i], *updated = rows[i];
        BOOL oldGroupStarts = i == 0 || self.rows[i - 1].group != old.group;
        BOOL newGroupStarts = i == 0 || rows[i - 1].group != updated.group;
        // Absolute source locations move after edits. They are rebound below,
        // not a reason to reload an otherwise identical visual row sequence.
        if (oldGroupStarts != newGroupStarts ||
            old.group.textRange.length != updated.group.textRange.length ||
            ![old.group.text isEqualToString:updated.group.text] ||
            old.group.seeded != updated.group.seeded ||
            old.group.insertedLigature != updated.group.insertedLigature ||
            old.variant.isBase != updated.variant.isBase ||
            old.variant.isLigature != updated.variant.isLigature ||
            old.variant.isTemporary != updated.variant.isTemporary ||
            ![old.variant.glyphIDs isEqualToArray:updated.variant.glyphIDs] ||
            ![old.variant.featureSources isEqualToArray:updated.variant.featureSources] ||
            ![old.variant.unicodeScalars isEqualToArray:updated.variant.unicodeScalars] ||
            ![old.variant.glyphName isEqualToString:updated.variant.glyphName]) return NO;
    }
    _groups = [groups copy];
    self.rows = rows;
    if (selected >= 0 && selected < (NSInteger)rows.count) {
        [self rememberSelectedRow:selected];
    }
    NSRange visible = [self.tableView rowsInRect:self.tableView.visibleRect];
    if (visible.location != NSNotFound) {
        for (NSUInteger i = visible.location; i < MIN(rows.count, NSMaxRange(visible)); i++) {
            GAVariantCellView *cell = [self.tableView viewAtColumn:0 row:(NSInteger)i makeIfNecessary:NO];
            [cell configureWithVariant:rows[i].variant];
        }
    }
    return YES;
}

- (NSRange)selectedGlyphTextRange {
    return self.selectedVariant ? self.selectedVariantTextRange : NSMakeRange(NSNotFound, 0);
}

- (BOOL)containsGlyphIDs:(NSArray<NSNumber *> *)glyphIDs textRange:(NSRange)range {
    return [self rowForGlyphIDs:glyphIDs textRange:range] != NSNotFound;
}

- (NSDictionary<NSValue *, NSSet<NSArray<NSNumber *> *> *> *)glyphSequencesForTextRanges:(NSSet<NSValue *> *)ranges {
    NSMutableDictionary<NSValue *, NSMutableSet<NSArray<NSNumber *> *> *> *sequences =
        [NSMutableDictionary dictionary];
    for (GARowItem *row in self.rows) {
        NSRange range = row.group.textRange;
        if (!range.length) continue;
        NSValue *key = [NSValue valueWithRange:range];
        if (![ranges containsObject:key]) continue;
        NSMutableSet<NSArray<NSNumber *> *> *atRange = sequences[key];
        if (!atRange) sequences[key] = atRange = [NSMutableSet set];
        [atRange addObject:row.variant.glyphIDs];
    }
    return sequences;
}

- (BOOL)selectGlyphIDs:(NSArray<NSNumber *> *)glyphIDs textRange:(NSRange)range {
    NSInteger index = [self rowForGlyphIDs:glyphIDs textRange:range];
    if (index == NSNotFound) return NO;
    GARowItem *row = self.rows[(NSUInteger)index];
    return [self selectVariant:row.variant inGroup:row.group
        temporaryResolution:row.variant.isTemporary ? self.temporaryResolution : nil];
}

- (BOOL)selectVariant:(GAGlyphVariant *)variant inGroup:(GACharacterGroup *)group
    temporaryResolution:(GAGlyphResolution *)temporary {
    BOOL replacesRows = self.temporaryResolution != temporary;
    NSArray<GARowItem *> *rows = replacesRows ? GARowsForGroups(self.groups, temporary) : self.rows;
    for (NSUInteger index = 0; index < rows.count; index++) {
        GARowItem *row = rows[index];
        if (row.group != group || row.variant != variant) continue;
        [self notifyWillNavigateToRow:row];
        NSDictionary *anchor = replacesRows ? [self captureScrollAnchor] : nil;
        self.suppressSelectionCallback = YES;
        self.pendingSelectionGlyphIDs = nil;
        // Publish only the final row set. Removing an old temporary item must
        // not select/notify its parent or navigate before the target is ready.
        if (replacesRows) {
            self.temporaryResolution = temporary;
            self.rows = rows;
            [self reloadTableGeometry];
            [self restoreScrollAnchor:anchor];
        }
        [self.tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:index]
                    byExtendingSelection:NO];
        [self rememberSelectedRow:(NSInteger)index];
        [self scrollGroupContainingRow:index];
        self.suppressSelectionCallback = NO;
        [self notifySelection];
        return YES;
    }
    return NO;
}

- (void)clearTemporaryGlyph {
    if (!self.temporaryResolution) return;
    NSDictionary *anchor = [self captureScrollAnchor];
    GAGlyphVariant *selected = self.selectedVariant;
    self.temporaryResolution = nil;
    self.rows = GARowsForGroups(self.groups, nil);
    self.suppressSelectionCallback = YES;
    [self reloadTableGeometry];
    [self.tableView deselectAll:nil];
    for (NSUInteger i = 0; i < self.rows.count; i++)
        if (self.rows[i].variant == selected) {
            [self.tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:i] byExtendingSelection:NO];
            break;
        }
    [self restoreScrollAnchor:anchor];
    self.suppressSelectionCallback = NO;
}

- (void)showGlyphResolution:(GAGlyphResolution *)resolution {
    for (GARowItem *parent in self.rows) {
        if (parent.variant != resolution.parent) continue;
        [self selectVariant:resolution.variant inGroup:parent.group temporaryResolution:resolution];
        return;
    }
}

- (void)selectBaseForTextRange:(NSRange)range {
    GACharacterGroup *group = [self groupForTextRange:range];
    if (!group)
        for (GACharacterGroup *candidate in self.groups)
            if (NSIntersectionRange(candidate.textRange, range).length) {
                group = candidate;
                break;
            }
    for (GARowItem *row in self.rows)
        if (row.variant.isBase && (!group || row.group == group)) {
            [self selectGlyphIDs:row.variant.glyphIDs textRange:row.group.textRange];
            return;
        }
}

- (GAGlyphResolution *)rebindTemporaryForGroups:(NSArray<GACharacterGroup *> *)groups
                                    sourceRange:(NSRange)range
                                      document:(GAFontDocument *)document {
    GAGlyphResolution *temporary = self.temporaryResolution;
    if (!temporary || self.selectedVariant != temporary.variant ||
        self.pendingSelectionGlyphIDs || range.location == NSNotFound)
        return nil;
    GARowItem *selected = [self selectedVariantRow];
    if (selected.variant != temporary.variant) return nil;
    GACharacterGroup *oldGroup = selected.group;
    for (GACharacterGroup *group in groups) {
        if (!NSEqualRanges(group.textRange, range) ||
            ![group.text isEqualToString:oldGroup.text] ||
            group.seeded != oldGroup.seeded ||
            group.insertedLigature != oldGroup.insertedLigature)
            continue;
        GAGlyphVariant *parent;
        for (GAGlyphVariant *variant in group.variants) {
            // A newly persistent result takes over without a duplicate row.
            if ([variant.glyphIDs isEqual:temporary.variant.glyphIDs]) return nil;
            if ([variant.glyphIDs isEqual:temporary.parent.glyphIDs]) parent = variant;
        }
        if (!parent) return nil;
        GAGlyphResolution *rebound = [[GAGlyphResolution alloc] init];
        rebound.parent = parent;
        rebound.variant = [document rebindVariant:temporary.variant content:group.text];
        rebound.variant.sourceTextRange = range;
        return rebound;
    }
    return nil;
}

- (void)updateGroups:(NSArray<GACharacterGroup *> *)groups
           sourceText:(NSString *)text
         fontDocument:(GAFontDocument *)document {
    // Compute the previous selection's source before resetting the edit baseline.
    NSRange selectedRange = self.selectedGlyphTextRange;
    if (selectedRange.location != NSNotFound) {
        selectedRange = self.displayedSourceEdits
            ? [self currentInputRangeForDisplayedRange:selectedRange]
            : GARemapSourceRange(selectedRange, GASourceEditBetween(self.displayedText, text));
    }
    self.temporaryResolution = [self rebindTemporaryForGroups:groups sourceRange:selectedRange document:document];
    self.trackedFieldText = self.currentFieldText;
    self.displayedSourceEdits = [NSMutableData data];
    NSArray<GARowItem *> *rows = GARowsForGroups(groups, self.temporaryResolution);
    if ([self updateGroupsWithSameRows:groups rows:rows selectedRange:selectedRange]) {
        self.displayedText = text;
        return;
    }
    [self setGroups:groups sourceText:text rows:rows selectedRange:selectedRange];
}

- (void)clearGroups {
    self.pendingSelectionGlyphIDs = nil;
    self.displayedSourceEdits = nil;
    self.temporaryResolution = nil;
    [self setGroups:@[] sourceText:nil rows:@[] selectedRange:NSMakeRange(NSNotFound, 0)];
}

- (void)setGroups:(NSArray<GACharacterGroup *> *)groups sourceText:(NSString *)text
             rows:(NSArray<GARowItem *> *)rows selectedRange:(NSRange)selectedRange {
    [NSAnimationContext beginGrouping];
    NSAnimationContext.currentContext.duration = 0;
    @try {
        NSDictionary *scrollAnchor = [self captureScrollAnchor];
        NSArray<NSNumber *> *oldGlyphIDs = self.selectedVariant.glyphIDs;

        _groups = [groups copy];
        self.displayedText = text;
        self.rows = rows;

        self.suppressSelectionCallback = YES;
        [self reloadTableGeometry];

        if ([self applyPendingSelection]) return;

        NSInteger rowToSelect = NSNotFound;
        if (oldGlyphIDs != nil) {
            rowToSelect = [self rowForGlyphIDs:oldGlyphIDs textRange:selectedRange];
        }
        // The selected text may have been deleted; fall back to the first base row.
        if (rowToSelect == NSNotFound) {
            rowToSelect = [self baseRowStartingAtIndex:0 step:1 skippingGroup:nil];
        }

        if (rowToSelect != NSNotFound) {
            if (rowToSelect != self.tableView.selectedRow) {
                [self.tableView
                        selectRowIndexes:[NSIndexSet indexSetWithIndex:(NSUInteger)rowToSelect]
                    byExtendingSelection:NO];
            }
        }
        [self rememberSelectedRow:rowToSelect];
        self.suppressSelectionCallback = NO;
        [self notifySelection];
        [self restoreScrollAnchor:scrollAnchor];
    } @finally {
        [NSAnimationContext endGrouping];
    }
}

- (void)reloadTableGeometry {
    [self.tableView reloadData];
    if (self.rows.count) {
        [NSAnimationContext beginGrouping];
        NSAnimationContext.currentContext.duration = 0;
        NSIndexSet *allRows = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, self.rows.count)];
        [self.tableView noteHeightOfRowsWithIndexesChanged:allRows];
        [NSAnimationContext endGrouping];
        // rectOfRow: realizes the final row before a scroll position is clamped.
        [self.tableView rectOfRow:(NSInteger)self.rows.count - 1];
    }
    [self.tableView tile];
}

// Preserve the visible row, not just a pixel offset that becomes stale when
// candidates above it change height or the native scroller changes width.
- (NSDictionary *)captureScrollAnchor {
    NSPoint origin = self.scrollView.contentView.bounds.origin;
    NSRange visible = [self.tableView rowsInRect:self.tableView.visibleRect];
    NSMutableArray *rows = [NSMutableArray array];
    if (visible.location != NSNotFound) {
        for (NSUInteger i = visible.location; i < MIN(self.rows.count, NSMaxRange(visible)); i++) {
            GARowItem *row = self.rows[i];
            [rows addObject:@{
                @"glyphIDs" : row.variant.glyphIDs,
                @"range" : [NSValue valueWithRange:row.group.textRange],
                @"text" : row.group.text,
                @"ligature" : @(row.group.insertedLigature),
                @"offset" : @(NSMinY(self.scrollView.contentView.documentVisibleRect) -
                               NSMinY([self.tableView rectOfRow:(NSInteger)i]))
            }];
        }
    }
    NSMutableDictionary *anchor = [@{@"origin" : [NSValue valueWithPoint:origin],
                                     @"rows" : rows} mutableCopy];
    if (self.displayedText != nil) anchor[@"text"] = self.displayedText;
    return anchor;
}

- (void)restoreScrollAnchor:(NSDictionary *)anchor {
    NSPoint origin = [anchor[@"origin"] pointValue];
    GASourceEdit edit = GASourceEditBetween(anchor[@"text"], self.displayedText);
    for (NSDictionary *visible in anchor[@"rows"]) {
        NSRange range = GARemapSourceRange([visible[@"range"] rangeValue], edit);
        GACharacterGroup *group;
        for (GACharacterGroup *candidate in self.groups)
            if (NSEqualRanges(candidate.textRange, range) &&
                [candidate.text isEqualToString:visible[@"text"]] &&
                candidate.insertedLigature == [visible[@"ligature"] boolValue]) {
                group = candidate;
                break;
            }
        if (group == nil) continue;
        NSInteger row = [self rowForGlyphIDs:visible[@"glyphIDs"] inGroup:group];
        if (row == NSNotFound && group.variants.count)
            row = [self rowForGlyphIDs:group.variants.firstObject.glyphIDs inGroup:group];
        if (row == NSNotFound) continue;
        NSRect rect = [self.tableView rectOfRow:row];
        CGFloat target = NSMinY(rect) + MIN([visible[@"offset"] doubleValue], NSHeight(rect) - 1);
        origin.y += target - NSMinY(self.scrollView.contentView.documentVisibleRect);
        break;
    }
    NSRect bounds = self.scrollView.contentView.bounds;
    bounds.origin = origin;
    GAScrollToProposedBounds(self.scrollView, bounds);
}

- (void)notifyWillNavigateToRow:(GARowItem *)row {
    if ((!NSEqualRanges(self.selectedVariantTextRange, row.group.textRange) ||
         ![self.selectedVariant.glyphIDs isEqualToArray:row.variant.glyphIDs]) && self.onWillNavigate)
        self.onWillNavigate();
}

- (void)notifySelection {
    [self notifySelectionWithQuickReveal:NO];
}

- (void)notifySelectionWithQuickReveal:(BOOL)quickReveal {
    if (self.onSelectionChanged == nil) {
        return;
    }
    NSArray<NSNumber *> *glyphIDs = self.selectedVariant.glyphIDs;
    NSRange range = self.selectedVariantTextRange;
    BOOL same = (glyphIDs == nil && self.lastNotifiedGlyphIDs == nil) ||
                ([glyphIDs isEqualToArray:self.lastNotifiedGlyphIDs] &&
                 NSEqualRanges(range, self.lastNotifiedRange));
    if (same) {
        return;
    }
    self.lastNotifiedGlyphIDs = glyphIDs;
    self.lastNotifiedRange = range;
    self.onSelectionChanged(self.selectedVariant, quickReveal);
}

#pragma mark - Table data source / delegate

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return (NSInteger)self.rows.count;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row {
    GARowItem *item = [self rowItemAtIndex:row];
    return item ? [GAVariantCellView rowHeightForVariant:item.variant] : 0;
}

- (NSTableRowView *)tableView:(NSTableView *)tableView rowViewForRow:(NSInteger)row {
    GAVariantRowView *view = [tableView makeViewWithIdentifier:@"VariantRow" owner:self];
    if (!view) {
        view = [[GAVariantRowView alloc] initWithFrame:NSZeroRect];
        view.identifier = @"VariantRow";
    }
    return view;
}

- (NSView *)tableView:(NSTableView *)tableView
   viewForTableColumn:(NSTableColumn *)tableColumn
                  row:(NSInteger)row {
    GARowItem *item = [self rowItemAtIndex:row];
    if (!item) return nil;
    GAVariantCellView *cell =
        [tableView makeViewWithIdentifier:@"VariantCell" owner:self];
    if (cell == nil) {
        cell = [[GAVariantCellView alloc] initWithFrame:NSZeroRect];
        cell.identifier = @"VariantCell";
    }
    [cell configureWithVariant:item.variant];
    return cell;
}

- (void)tableViewSelectionDidChange:(NSNotification *)notification {
    if (self.suppressSelectionCallback) {
        return;
    }
    NSInteger row = self.tableView.selectedRow;
    GARowItem *target = [self rowItemAtIndex:row];
    if (!target) {
        [self rememberSelectedRow:NSNotFound];
        [self clearTemporaryGlyph];
        [self notifySelection];
        return;
    }
    [self notifyWillNavigateToRow:target];
    // A manual click overrides any pending auto-selection from an append or
    // activation; later list snapshots must not snap the user back.
    self.pendingSelectionGlyphIDs = nil;
    [self rememberSelectedRow:row];
    if (!self.selectedVariant.isTemporary) [self clearTemporaryGlyph];
    [self notifySelection];
}

@end
