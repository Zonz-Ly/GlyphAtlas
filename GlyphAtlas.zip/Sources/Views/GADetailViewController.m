#import "GADetailViewController.h"
#import "GABoundingBoxView.h"
#import "GAAllGlyphsView.h"
#import "GAMultiGlyphView.h"
#import "App/GAAppDelegate.h"
#import <math.h>

@interface GADetailContainerView : NSView
@property (nonatomic, copy, nullable) void (^resizeHandler)(void (^changes)(void));
@property (nonatomic, strong) GAPreviewColors *previewColors;
@end

@implementation GADetailContainerView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    if (self.previewColors) {
        [[self.previewColors colorForRole:GAPreviewColorBackground] setFill];
        NSRectFill(dirtyRect);
    }
}

- (void)viewDidChangeEffectiveAppearance {
    [super viewDidChangeEffectiveAppearance];
    if (self.previewColors) self.needsDisplay = YES;
}

- (void)setFrameSize:(NSSize)newSize {
    if (self.resizeHandler == nil || NSEqualSizes(self.frame.size, newSize)) {
        [super setFrameSize:newSize];
        return;
    }
    self.resizeHandler(^{
        [super setFrameSize:newSize];
        self.needsLayout = YES;
        [self layoutSubtreeIfNeeded];
    });
}

@end

@interface GADetailViewController ()
@property(nonatomic, strong) GAPreviewColors *previewColors;
@property (nonatomic, strong) GABoundingBoxView *boundingBoxView;
@property (nonatomic, strong) GAAllGlyphsView *allGlyphsView;
@property (nonatomic, strong) GAMultiGlyphView *multiView;
@property (nonatomic, strong) NSScrollView *multiScrollView;
@property (nonatomic) BOOL updatingMultiLayout;
@property (nonatomic) CGFloat boundingBoxInsetFraction;
@end

@implementation GADetailViewController

#pragma mark - View creation

- (void)loadView {
    GADetailContainerView *container =
        [[GADetailContainerView alloc] initWithFrame:NSMakeRect(0, 0, 900, 760)];
    self.view = container;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.previewColors = [[GAPreviewColors alloc] init];
    ((GADetailContainerView *)self.view).previewColors = self.previewColors;

    self.boundingBoxView = [[GABoundingBoxView alloc] initWithFrame:NSZeroRect];
    self.boundingBoxView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.boundingBoxView];

    self.allGlyphsView = [[GAAllGlyphsView alloc] initWithFrame:NSZeroRect];
    self.allGlyphsView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.allGlyphsView];

    self.multiScrollView = [[NSScrollView alloc] initWithFrame:NSZeroRect];
    self.multiScrollView.translatesAutoresizingMaskIntoConstraints = NO;
    self.multiScrollView.hasVerticalScroller = YES;
    self.multiScrollView.hasHorizontalScroller = YES;
    self.multiScrollView.autohidesScrollers = YES;
    self.multiScrollView.backgroundColor = GABoundingBoxBackgroundColor();
    self.multiScrollView.automaticallyAdjustsContentInsets = NO;
    [self.view addSubview:self.multiScrollView];

    self.multiView = [[GAMultiGlyphView alloc] initWithFrame:NSMakeRect(0, 0, 900, 760)];
    self.multiScrollView.documentView = self.multiView;
    NSNotificationCenter *notifications = NSNotificationCenter.defaultCenter;
    for (NSScrollView *scrollView in @[self.allGlyphsView.scrollView, self.multiScrollView]) {
        [notifications addObserver:self selector:@selector(scrollGeometryDidChange:)
                              name:NSViewBoundsDidChangeNotification object:scrollView.contentView];
        [notifications addObserver:self selector:@selector(scrollGeometryDidChange:)
                              name:NSViewFrameDidChangeNotification object:scrollView.documentView];
        scrollView.contentView.postsBoundsChangedNotifications = YES;
        scrollView.documentView.postsFrameChangedNotifications = YES;
    }
    self.boundingBoxView.previewColors = self.previewColors;
    self.multiView.previewColors = self.previewColors;
    [self.allGlyphsView applyPreviewColors:self.previewColors];

    // Tahoe extends this container beneath the sidebar. Only its background
    // fills that region; glyph geometry stays in the unobscured right pane.
    NSLayoutXAxisAnchor *contentLeading = GAUsesMacOS26Layout()
        ? self.view.safeAreaLayoutGuide.leadingAnchor : self.view.leadingAnchor;
    [NSLayoutConstraint activateConstraints:@[
        [self.view.trailingAnchor constraintGreaterThanOrEqualToAnchor:contentLeading constant:300],
        [self.view.heightAnchor constraintGreaterThanOrEqualToConstant:300],
    ]];
    for (NSView *view in @[self.boundingBoxView, self.allGlyphsView, self.multiScrollView]) {
        [NSLayoutConstraint activateConstraints:@[
            [view.leadingAnchor constraintEqualToAnchor:contentLeading],
            [view.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
            [view.topAnchor constraintEqualToAnchor:self.view.topAnchor],
            [view.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
        ]];
    }

    __weak typeof(self) weakSelf = self;
    GADetailContainerView *container = (GADetailContainerView *)self.view;
    container.resizeHandler = ^(void (^changes)(void)) {
        GADetailViewController *controller = weakSelf;
        NSScrollView *scrollView = controller.viewMode == GAViewModeMultiCharacter
            ? controller.multiScrollView : nil;
        GAPreserveScrollPosition(scrollView, ^{
            changes();
            [controller updateMultiLayout];
        });
    };
    self.allGlyphsView.onGlyphDoubleClick = ^(GAAllGlyphEntry *entry) {
        if (weakSelf.onAllGlyphDoubleClick != nil) {
            weakSelf.onAllGlyphDoubleClick(entry);
        }
    };
    self.multiView.onGlyphSelected = ^(NSArray<NSNumber *> *glyphIDs, NSRange range,
                                      NSArray<NSNumber *> *leadingGlyphIDs, NSRange leadingRange) {
        if (weakSelf.onGlyphSelected)
            weakSelf.onGlyphSelected(glyphIDs, range, leadingGlyphIDs, leadingRange);
    };
    self.multiView.onContentSizeChanged = ^{
        [weakSelf updateMultiLayout];
    };
    // Single- and multi-character views share one bounding-box zoom.
    self.boundingBoxView.onSideInsetFractionChanged = ^(CGFloat fraction) {
        weakSelf.multiView.sideInsetFraction = fraction;
    };
    self.multiView.onSideInsetFractionChanged = ^(CGFloat fraction) {
        weakSelf.boundingBoxView.sideInsetFraction = fraction;
    };

    NSMenu *contextMenu = [NSApp.delegate respondsToSelector:@selector(viewMenuForContextInView:)]
        ? [(GAAppDelegate *)NSApp.delegate viewMenuForContextInView:self.view] : nil;
    self.view.menu = contextMenu;
    self.boundingBoxView.menu = contextMenu;
    self.multiView.menu = contextMenu;
    self.allGlyphsView.menu = contextMenu;

    [self updateVisibleView];
}

#pragma mark - Layout

- (void)scrollGeometryDidChange:(NSNotification *)notification {
    [self updateToolbarAppearance];
}

- (void)updateToolbarAppearance {
    NSScrollView *scrollView;
    if (self.viewMode == GAViewModeAllGlyphs) scrollView = self.allGlyphsView.scrollView;
    if (self.viewMode == GAViewModeMultiCharacter) scrollView = self.multiScrollView;

    BOOL overlapsToolbar = NO;
    if (scrollView.automaticallyAdjustsContentInsets) {
        NSClipView *clip = scrollView.contentView;
        NSRect limits = GAScrollPositionLimits(scrollView);
        BOOL scrollsVertically = scrollView.hasVerticalScroller && NSHeight(limits) > 0.5;
        if (scrollsVertically) {
            CGFloat currentY = NSMinY([clip constrainBoundsRect:clip.bounds]);
            CGFloat distance = clip.isFlipped ? currentY - NSMinY(limits) : NSMaxY(limits) - currentY;
            if (scrollView == self.multiScrollView) {
                CGFloat visibleHeight = self.multiView.viewportSize.height - self.multiView.toolbarTopInset;
                distance = NSMaxY(self.multiView.pageRect) - currentY - visibleHeight;
            }
            overlapsToolbar = distance > 0.5;
        }
    }
    NSWindow *window = self.view.window;
    BOOL transparent = !overlapsToolbar;
    NSTitlebarSeparatorStyle style = overlapsToolbar
        ? NSTitlebarSeparatorStyleAutomatic : NSTitlebarSeparatorStyleNone;
    if (window.titlebarAppearsTransparent != transparent) window.titlebarAppearsTransparent = transparent;
    if (window.titlebarSeparatorStyle != style) window.titlebarSeparatorStyle = style;
}

- (void)setUsesToolbarSafeArea:(BOOL)enabled {
    self.boundingBoxView.constrainsPageAtToolbar = enabled;
    [self.allGlyphsView setScrollsUnderToolbar:enabled];
    GAPreserveScrollPosition(self.multiScrollView, ^{
        self.multiScrollView.automaticallyAdjustsContentInsets = enabled;
        if (!enabled) self.multiScrollView.contentInsets = NSEdgeInsetsZero;
        [self.multiScrollView tile];
        [self updateMultiLayout];
    });
    [self updateToolbarAppearance];
}

- (void)viewDidLayout {
    [super viewDidLayout];
    [self updateMultiLayout];
    [self updateToolbarAppearance];
}

- (void)updateMultiLayout {
    if (self.updatingMultiLayout || !self.isViewLoaded || self.multiScrollView.hidden) {
        return;
    }
    NSSize viewport = self.multiScrollView.contentSize;
    NSEdgeInsets insets = self.multiScrollView.contentInsets;
    viewport.width -= insets.left + insets.right;
    viewport.height -= insets.bottom;
    if (viewport.width < 1 || viewport.height < 1) {
        return;
    }
    self.updatingMultiLayout = YES;
    self.multiView.toolbarTopInset = insets.top;
    self.multiView.viewportSize = viewport;
    NSSize size = self.multiView.documentSize;
    if (fabs(NSWidth(self.multiView.frame) - size.width) > 0.5 ||
        fabs(NSHeight(self.multiView.frame) - size.height) > 0.5) {
        self.multiView.frame = NSMakeRect(0, 0, size.width, size.height);
    }
    self.updatingMultiLayout = NO;
}

- (void)setViewMode:(GAViewMode)viewMode {
    _viewMode = viewMode;
    [self updateVisibleView];
}

- (void)updateVisibleView {
    if (!self.isViewLoaded) {
        return;
    }
    self.boundingBoxView.hidden = self.viewMode != GAViewModeSingleGlyph;
    self.allGlyphsView.hidden = self.viewMode != GAViewModeAllGlyphs;
    self.multiScrollView.hidden = self.viewMode != GAViewModeMultiCharacter;
    if (self.multiScrollView.hidden) self.multiView.layoutActive = NO;
    [self updateMultiLayout];
    self.multiView.layoutActive = !self.multiScrollView.hidden;
    [self updateToolbarAppearance];
}

#pragma mark - Shared display state

- (void)applyPreviewColorRepresentation:(NSDictionary<NSString *, NSData *> *)representation {
    self.previewColors = [[GAPreviewColors alloc] initWithRepresentation:representation];
    self.boundingBoxView.previewColors = self.previewColors;
    self.multiView.previewColors = self.previewColors;
    [self refreshPreviewColors];
}

- (void)refreshPreviewColors {
    ((GADetailContainerView *)self.view).previewColors = self.previewColors;
    self.view.needsDisplay = YES;
    self.multiScrollView.backgroundColor =
        [self.previewColors colorForRole:GAPreviewColorBackground];
    [self.boundingBoxView setNeedsDisplay:YES];
    [self.allGlyphsView applyPreviewColors:self.previewColors];
    [self.multiView refreshPreviewColors];
}

- (void)adjustLineHeight:(NSInteger)steps {
    self.multiView.lineHeightMultiple *= pow(GAGlyphZoomStep, steps * 0.5);
}

- (void)setVariant:(GAGlyphVariant *)variant {
    self.boundingBoxView.variant = variant;
}

- (void)setFontDocument:(GAFontDocument *)document {
    self.allGlyphsView.document = document;
    self.multiView.document = document;
}

- (void)setAllGlyphVisibleIDs:(NSIndexSet *)glyphIDs {
    [self.allGlyphsView setVisibleGlyphIDs:glyphIDs];
}

- (void)setShowsMetrics:(BOOL)showsMetrics {
    self.boundingBoxView.showsMetrics = showsMetrics;
    self.multiView.showsMetrics = showsMetrics;
}

- (CGFloat)boundingBoxInsetFraction {
    return self.boundingBoxView.sideInsetFraction;
}

- (void)setBoundingBoxInsetFraction:(CGFloat)fraction {
    self.boundingBoxView.sideInsetFraction = fraction;
    self.multiView.sideInsetFraction = fraction;
}

#pragma mark - Page zoom

/// The page occupies (1 - 2 * inset) of the viewport. Keyboard zoom scales that
/// fraction instead of the inset so the visual step stays constant.
- (void)scaleBoundingBoxBy:(CGFloat)factor {
    CGFloat page = 1.0 - 2.0 * self.boundingBoxInsetFraction;
    CGFloat minimum = 1.0 - 2.0 * GABoundingBoxMaxInsetFraction;
    page = MIN(1.0, MAX(minimum, page * factor));
    self.boundingBoxInsetFraction = (1.0 - page) * 0.5;
}

- (void)zoomBoundingBoxIn {
    [self scaleBoundingBoxBy:GAGlyphZoomStep];
}

- (void)zoomBoundingBoxOut {
    [self scaleBoundingBoxBy:1.0 / GAGlyphZoomStep];
}

#pragma mark - Active view zoom

- (void)zoomIn {
    switch (self.viewMode) {
        case GAViewModeAllGlyphs: [self.allGlyphsView zoomIn]; break;
        case GAViewModeSingleGlyph: [self zoomBoundingBoxIn]; break;
        case GAViewModeMultiCharacter: [self.multiView zoomTextIn]; break;
    }
}

- (void)zoomOut {
    switch (self.viewMode) {
        case GAViewModeAllGlyphs: [self.allGlyphsView zoomOut]; break;
        case GAViewModeSingleGlyph: [self zoomBoundingBoxOut]; break;
        case GAViewModeMultiCharacter: [self.multiView zoomTextOut]; break;
    }
}

- (void)resetZoom {
    switch (self.viewMode) {
        case GAViewModeAllGlyphs:
            [self.allGlyphsView resetZoom];
            break;
        case GAViewModeSingleGlyph:
            self.boundingBoxInsetFraction = GABoundingBoxDefaultSideInsetFraction;
            break;
        case GAViewModeMultiCharacter:
            [self.multiView resetLayoutScale];
            break;
    }
}

#pragma mark - All glyphs

- (void)revealAllGlyphID:(NSNumber *)glyphID quick:(BOOL)quick {
    [self.allGlyphsView revealGlyphID:glyphID quick:quick];
}

- (BOOL)containsAllGlyphAtWindowPoint:(NSPoint)point {
    return self.viewMode == GAViewModeAllGlyphs &&
           [self.allGlyphsView containsGlyphAtWindowPoint:point];
}

#pragma mark - Multi-character view

- (void)scrollMultiToPoint:(NSPoint)point {
    NSClipView *clip = self.multiScrollView.contentView;
    NSRect bounds = clip.bounds;
    bounds.origin = point;
    [clip scrollToPoint:[clip constrainBoundsRect:bounds].origin];
    [self.multiScrollView reflectScrolledClipView:clip];
}

- (void)setMultiText:(NSString *)text groups:(NSArray<GACharacterGroup *> *)groups
           omissions:(NSIndexSet *)omissions {
    NSPoint origin = self.multiScrollView.contentView.bounds.origin;
    [self.multiView setText:text groups:groups omissions:omissions];
    [self scrollMultiToPoint:origin];
}

- (void)setTextAlignment:(NSTextAlignment)alignment {
    self.multiView.textAlignment = alignment;
}

- (void)setWritingDirectionVertical:(BOOL)vertical {
    self.multiView.vertical = vertical;
    [self updateMultiLayout];
}

- (void)setFeatureSettings:(NSArray<NSDictionary *> *)settings {
    self.multiView.featureSettings = settings;
}

- (void)setUnderlined:(BOOL)enabled { self.multiView.underlined = enabled; }
- (void)setStruckThrough:(BOOL)enabled { self.multiView.struckThrough = enabled; }
- (void)setOutlined:(BOOL)enabled { self.multiView.outlined = enabled; }
- (void)setBaseWritingDirection:(NSWritingDirection)direction { self.multiView.baseWritingDirection = direction; }
- (void)setTypesettingLanguage:(NSString *)language { self.multiView.typesettingLanguage = language; }

- (NSDictionary *)currentPreviewSettings {
    return @{@"colors":self.previewColors.representation,
        @"boxInset":@(self.boundingBoxInsetFraction),
        @"textScale":@(self.multiView.textScale),
        @"lineHeightMultiple":@(self.multiView.lineHeightMultiple),
        @"cellScale":@(self.allGlyphsView.cellScale)};
}

- (void)applyOpeningSettings:(NSDictionary *)settings {
    [self view];
    if ([settings[@"colors"] count]) [self applyPreviewColorRepresentation:settings[@"colors"]];
    if (settings[@"boxInset"]) self.boundingBoxInsetFraction = [settings[@"boxInset"] doubleValue];
    if (settings[@"textScale"]) self.multiView.textScale = [settings[@"textScale"] doubleValue];
    if (settings[@"lineHeightMultiple"]) self.multiView.lineHeightMultiple = [settings[@"lineHeightMultiple"] doubleValue];
    if (settings[@"cellScale"]) self.allGlyphsView.cellScale = [settings[@"cellScale"] doubleValue];
}

@end
